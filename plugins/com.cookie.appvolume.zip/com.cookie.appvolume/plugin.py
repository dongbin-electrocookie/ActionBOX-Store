import asyncio
import os
import atexit
import json
import platform
import select
import subprocess
import sys
import threading
import time

IS_MACOS = sys.platform == "darwin"
AudioUtilities = comtypes = None
if sys.platform == "win32":
    try:
        import comtypes
        from pycaw.pycaw import AudioUtilities, ISimpleAudioVolume
    except ImportError:
        print("[Error] pycaw library is not available. Run 'pip install pycaw comtypes'.")


class MacMixerError(RuntimeError):
    def __init__(self, code):
        super().__init__(code)
        self.code = code


class MacMixerClient:
    """One long-lived native audio engine, owned by this plugin runner.

    Requests use private stdin/stdout pipes, not a listening network port.
    No audio data passes through Python, disk, or the browser extension.
    """
    def __init__(self, plugin_dir):
        self.executable = os.path.join(plugin_dir, "macos", "COMBO-X App Volume.app",
                                       "Contents", "MacOS", "COMBO-X-App-Volume")
        self._process = None
        self._lock = threading.RLock()
        self._buffer = b""
        self._sequence = 0
        atexit.register(self.close)

    def _start(self):
        try:
            version = tuple(int(part) for part in platform.mac_ver()[0].split(".")[:2])
        except ValueError:
            version = ()
        if version < (14, 2):
            raise MacMixerError("unsupported_macos")
        if not os.path.isfile(self.executable):
            raise MacMixerError("missing_helper")
        if self._process is None or self._process.poll() is not None:
            self.close()
            os.chmod(self.executable, os.stat(self.executable).st_mode | 0o111)
            self._process = subprocess.Popen([self.executable], stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0,
                close_fds=True, start_new_session=True)
            self._buffer = b""

    def request(self, command, **payload):
        with self._lock:
            try:
                self._start()
                self._sequence += 1
                request = {"id": self._sequence, "command": command, **payload}
                self._process.stdin.write((json.dumps(request) + "\n").encode("utf-8"))
                deadline = time.monotonic() + (60 if command == "change" else 10)
                while time.monotonic() < deadline:
                    while b"\n" in self._buffer:
                        line, self._buffer = self._buffer.split(b"\n", 1)
                        try:
                            response = json.loads(line)
                        except (ValueError, UnicodeError):
                            continue
                        if not isinstance(response, dict) or response.get("id") != self._sequence:
                            continue
                        if not response.get("ok"):
                            raise MacMixerError(response.get("error", "audio_error"))
                        return response
                    remaining = max(0, deadline - time.monotonic())
                    readable, _, _ = select.select([self._process.stdout], [], [], remaining)
                    if not readable:
                        break
                    chunk = os.read(self._process.stdout.fileno(), 16384)
                    if not chunk:
                        raise MacMixerError("helper_stopped")
                    self._buffer += chunk
                    if len(self._buffer) > 65536:
                        raise MacMixerError("audio_error")
                raise MacMixerError("capture_unavailable")
            except MacMixerError as error:
                if error.code in {"helper_stopped", "capture_unavailable", "audio_error"}:
                    self.close()
                raise
            except (OSError, ValueError) as error:
                self.close()
                raise MacMixerError("audio_error") from error

    def close(self):
        with self._lock:
            process, self._process = self._process, None
            self._buffer = b""
            if process is None:
                return
            try:
                if process.stdin:
                    process.stdin.close()  # EOF releases all taps and restores original audio.
                process.wait(timeout=2)
            except (OSError, subprocess.TimeoutExpired):
                try:
                    process.terminate()
                    process.wait(timeout=2)
                except (OSError, subprocess.TimeoutExpired):
                    process.kill()
                    process.wait(timeout=2)
            finally:
                if process.stdout:
                    process.stdout.close()


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.STEP = 0.10
        self.context_settings = {}
        self._mac_mixer = MacMixerClient(self.plugin_dir) if IS_MACOS else None
        self._mac_error = None
        self._locale_cache = {}

        self.icon_map = {
            "vol_up": "VOL_UP",
            "vol_down": "VOL_DOWN",
            "vol_mute": "VOL_MUTE",
        }

        self.I18N = {
            "en": {"ERR_PYCAW": "Error: pycaw library not available", "NO_APPS": "No apps are currently playing audio", "MUTE_STATUS": "MUTE"},
            "ko": {"ERR_PYCAW": "오류: pycaw 라이브러리를 사용할 수 없습니다", "NO_APPS": "현재 오디오를 재생 중인 앱이 없습니다", "MUTE_STATUS": "음소거"},
            "ja": {"ERR_PYCAW": "エラー: pycaw ライブラリを利用できません", "NO_APPS": "現在オーディオを再生中のアプリはありません", "MUTE_STATUS": "ミュート"},
            "de": {"ERR_PYCAW": "Fehler: pycaw-Bibliothek nicht verfügbar", "NO_APPS": "Derzeit gibt keine App Audio wieder", "MUTE_STATUS": "STUMM"},
            "es": {"ERR_PYCAW": "Error: la biblioteca pycaw no está disponible", "NO_APPS": "Ninguna aplicación está reproduciendo audio actualmente", "MUTE_STATUS": "SILENCIO"},
            "fr": {"ERR_PYCAW": "Erreur : la bibliothèque pycaw n’est pas disponible", "NO_APPS": "Aucune application ne lit actuellement de l’audio", "MUTE_STATUS": "MUET"},
            "ru": {"ERR_PYCAW": "Ошибка: библиотека pycaw недоступна", "NO_APPS": "Сейчас ни одно приложение не воспроизводит звук", "MUTE_STATUS": "БЕЗ ЗВУКА"},
            "it": {"ERR_PYCAW": "Errore: libreria pycaw non disponibile", "NO_APPS": "Nessuna app sta riproducendo audio al momento", "MUTE_STATUS": "MUTO"},
            "pt-PT": {"ERR_PYCAW": "Erro: biblioteca pycaw indisponível", "NO_APPS": "Nenhuma aplicação está atualmente a reproduzir áudio", "MUTE_STATUS": "SEM SOM"},
        }

    def _norm_lang(self, lang):
        lang = (lang or "en").strip()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        lang = alias.get(lang, lang)
        return lang if lang in self.I18N else "en"

    def _tr(self, lang, key):
        lang = self._norm_lang(lang)
        if key.startswith("MAC_"):
            if lang not in self._locale_cache:
                try:
                    with open(os.path.join(self.plugin_dir, "locales", lang + ".json"), encoding="utf-8") as handle:
                        self._locale_cache[lang] = json.load(handle)
                except (OSError, ValueError):
                    self._locale_cache[lang] = {}
            return self._locale_cache[lang].get(key, key)
        return self.I18N.get(lang, self.I18N["en"]).get(key, self.I18N["en"].get(key, key))

    def _mac_failure(self, error, lang):
        key = {"unsupported_macos": "MAC_REQUIRE", "missing_helper": "MAC_MISSING_HELPER",
               "not_running": "MAC_NOT_RUNNING", "unsupported_format": "MAC_UNSUPPORTED_FORMAT",
               "capture_unavailable": "MAC_PERMISSION"}.get(error.code, "MAC_ERROR")
        self._mac_error = self._tr(lang, key)
        print(f"[{self.uuid}] macOS: {error.code}")

    def shutdown(self):
        if self._mac_mixer is not None:
            self._mac_mixer.close()

    def _default_action(self):
        return "vol_up"

    def _default_settings(self):
        action = self._default_action()
        return {
            "app_name": "",
            "command": action,
            "_lang": "en",
            "builtin_icon_name": self.icon_map[action],
            "sync_title_on_action_change": False,
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or self._default_action()
        if action not in self.icon_map:
            action = self._default_action()
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map[action]
        merged["_lang"] = self._norm_lang(merged.get("_lang", "en"))
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("app_name"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False),
            s.get("_lang")
        ])

    def _get_builtin_icon_path(self, command):
        icon_name = self.icon_map.get(command or "vol_up", "VOL_UP")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, command):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_builtin_icon_path(command)
        if not os.path.exists(icon_path):
            return
        await self.runner.send_message({
            "event": "setIcon",
            "context": context,
            "payload": {"icon_path": icon_path}
        })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    def _get_audio_apps(self, lang="en"):
        if IS_MACOS:
            try:
                apps = self._mac_mixer.request("list").get("apps", [])
                self._mac_error = None
                return apps
            except MacMixerError as error:
                self._mac_failure(error, lang)
                return []
        if not AudioUtilities:
            return [self._tr(lang, "ERR_PYCAW")]

        comtypes.CoInitialize()
        try:
            apps = set()
            sessions = AudioUtilities.GetAllSessions()
            for session in sessions:
                if session.Process:
                    apps.add(session.Process.name())

            if len(apps) == 0:
                return [self._tr(lang, "NO_APPS")]

            return sorted(list(apps), key=str.lower)
        except Exception as e:
            return [f"Error: {str(e)}"]
        finally:
            comtypes.CoUninitialize()

    def _change_app_volume(self, app_name, action, lang="en"):
        if IS_MACOS:
            try:
                result = self._mac_mixer.request("change", app=app_name, action=action)
                self._mac_error = None
                status = f"[{self._tr(lang, 'MUTE_STATUS')}]" if result["muted"] else f"{result['volume']}%"
                return f"{result['name']}\n{status}"
            except MacMixerError as error:
                self._mac_failure(error, lang)
                return None
        if not AudioUtilities or not app_name:
            return None

        comtypes.CoInitialize()
        try:
            sessions = AudioUtilities.GetAllSessions()
            for session in sessions:
                if session.Process and session.Process.name().lower() == app_name.lower():
                    volume = session._ctl.QueryInterface(ISimpleAudioVolume)
                    display_name = app_name.replace(".exe", "")

                    if action == "vol_mute":
                        current_mute = volume.GetMute()
                        new_mute = 0 if current_mute else 1
                        volume.SetMute(new_mute, None)
                        if new_mute:
                            return f"{display_name}\n[{self._tr(lang, 'MUTE_STATUS')}]"
                        current_vol = int(volume.GetMasterVolume() * 100)
                        return f"{display_name}\n{current_vol}%"

                    if action == "vol_up":
                        current_vol = volume.GetMasterVolume()
                        new_vol = min(1.0, current_vol + self.STEP)
                        volume.SetMasterVolume(new_vol, None)
                        volume.SetMute(0, None)
                        return f"{display_name}\n{int(new_vol * 100)}%"

                    if action == "vol_down":
                        current_vol = volume.GetMasterVolume()
                        new_vol = max(0.0, current_vol - self.STEP)
                        volume.SetMasterVolume(new_vol, None)
                        volume.SetMute(0, None)
                        return f"{display_name}\n{int(new_vol * 100)}%"
        except Exception as e:
            print(f"[{self.uuid}] Volume control failed: {e}")
        finally:
            comtypes.CoUninitialize()
        return None

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")

        if event in ["willAppear", "keyDidAppear"]:
            if context:
                await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            action = data.get("action_command") or payload.get("action_command") or settings.get("command") or cached.get("command") or "vol_up"
            await self._send_builtin_icon(context, action)
            return

        if control_command == "get_audio_apps":
            lang = payload.get("language", "en")
            apps = await asyncio.to_thread(self._get_audio_apps, lang)
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {"command": "audio_app_list", "apps": apps,
                            **({"platform": "darwin", "error": self._mac_error,
                                "notice": self._tr(lang, "MAC_NOTICE")} if IS_MACOS else {})}
            })
            return

        if event == "keyDown":
            cached = self.context_settings.get(context, {})
            merged = self._merge_with_defaults({**cached, **settings})
            if context:
                self.context_settings[context] = merged

            app_name = merged.get("app_name")
            lang = merged.get("_lang", "en")
            current_action = merged.get("command", "vol_up")

            if app_name and current_action:
                new_title_text = await asyncio.to_thread(self._change_app_volume, app_name, current_action, lang)
                if IS_MACOS:
                    await self.runner.send_message({"event": "sendToPropertyInspector", "context": context,
                        "payload": {"command": "mac_audio_status", "error": self._mac_error,
                                    "notice": self._tr(lang, "MAC_NOTICE")}})
                if new_title_text:
                    await self.runner.send_message({
                        "event": "setTitle",
                        "context": context,
                        "payload": {"title": new_title_text}
                    })
