# Codex for COMBO-X (v1.0.0)

The Codex plugin monitors Codex Desktop/CLI session state and provides Codex-specific voice and reasoning controls.

## Actions

- **Codex Status** — Idle, Thinking, Complete, Permission and Error artwork with matching status LED
- **Codex Push to Talk** — holds the configured `composer.startDictation` shortcut while pressed
- **Codex Voice Toggle** — toggles the same dictation shortcut between held and released
- **Codex Reasoning Down / Up** — adjusts the focused Codex composer's reasoning effort
- **Confirm / Cancel** — sends `Enter` or `Esc` to the focused application

Existing Codex shortcuts are preserved. Missing voice/reasoning bindings are assigned an unused reserved chord and written atomically with a backup. Codex hooks are automatically installed or repaired; local rollout JSONL is also monitored as a read-only Desktop fallback.

The former `com.cookie.ai_monitor` action IDs are retained so existing COMBO-X button assignments continue working after the plugin split. Existing AI Monitor user data is copied into the new `com.cookie.codex` data directory on first run.
