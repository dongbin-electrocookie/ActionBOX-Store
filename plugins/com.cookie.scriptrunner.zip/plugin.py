import asyncio
import json
import os
import subprocess
import sys

# Windows 레지스트리 접근용 (Adobe 경로 찾기)
if sys.platform == "win32":
    import winreg

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner  # 관리자 저장 (메시지 보낼 때 사용)
        self.uuid = manifest['UUID']

    async def handle_message(self, data):
        """관리자로부터 메시지를 수신하여 분배"""
        event = data.get("event")
        
        if event == "keyDown":
            await self.on_key_down(data)
        elif event == "sendToPlugin":
            # PI(설정창)에서 "기본 경로 찾아줘" 요청이 오면 처리
            await self.on_pi_request(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        
        exe_path = settings.get("exe_path")
        script_path = settings.get("script_path")

        if not exe_path or not os.path.exists(exe_path):
            print(f"[{self.uuid}] Program path invalid: '{exe_path}'")
            return
            
        if not script_path or not os.path.exists(script_path):
            print(f"[{self.uuid}] Script path invalid: '{script_path}'")
            return

        # print(f"[{self.uuid}] Running script...")
        
        # subprocess.run은 블로킹 함수이므로 공유 런타임이 멈추지 않게 스레드로 분리
        creationflags = 0
        if sys.platform == "win32":
            creationflags = subprocess.CREATE_NO_WINDOW
            
        await asyncio.to_thread(subprocess.run, [exe_path, script_path], creationflags=creationflags)

    async def on_pi_request(self, data):
        context = data.get("context")
        payload = data.get("payload", {})
        command = payload.get("command")

        # Adobe Photoshop/Illustrator 경로 자동 탐지 요청 처리
        if command == "getDefaultPath":
            action_id = payload.get("actionId", "")
            exe_name = None
            
            if 'photoshop' in action_id:
                exe_name = "Photoshop.exe"
            elif 'illustrator' in action_id:
                exe_name = "Illustrator.exe"
            
            if exe_name:
                found_path = self._find_adobe_path(exe_name)
                if found_path:
                    # [수정] runner를 통해 PI로 응답 전송
                    await self.runner.send_message({
                        "event": "sendToPropertyInspector",
                        "context": context,
                        "payload": {
                            "command": "defaultPathFound",
                            "path": found_path
                        }
                    })

    # [헬퍼] Windows 레지스트리 검색 (기존 로직 유지)
    def _find_adobe_path(self, exe_name):
        if sys.platform != "win32":
            return None
        
        app_paths_key = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"
        try:
            # HKEY_LOCAL_MACHINE 검색
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, os.path.join(app_paths_key, exe_name))
            path, _ = winreg.QueryValueEx(key, None)
            winreg.CloseKey(key)
            return path
        except FileNotFoundError:
            try:
                # HKEY_CURRENT_USER 검색
                key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, os.path.join(app_paths_key, exe_name))
                path, _ = winreg.QueryValueEx(key, None)
                winreg.CloseKey(key)
                return path
            except FileNotFoundError:
                # print(f"[{self.uuid}] Could not find '{exe_name}' in registry.")
                return None