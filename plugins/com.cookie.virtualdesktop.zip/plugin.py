import asyncio
import ctypes
import sys
import time

# 윈도우 API 상수 및 코드
VK_CONTROL = 0x11
VK_LWIN = 0x5B
VK_LEFT = 0x25
VK_RIGHT = 0x27
VK_D = 0x44
VK_F4 = 0x73
VK_TAB = 0x09

KEYEVENTF_KEYDOWN = 0x0000
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_EXTENDEDKEY = 0x0001

def press_hardware_key(vk, is_arrow=False):
    # ★ 윈도우가 키 입력을 무시하지 않도록 하드웨어 스캔 코드를 직접 추출합니다.
    scan = ctypes.windll.user32.MapVirtualKeyA(vk, 0)
    flags = KEYEVENTF_KEYDOWN
    if is_arrow:
        flags |= KEYEVENTF_EXTENDEDKEY
    ctypes.windll.user32.keybd_event(vk, scan, flags, 0)

def release_hardware_key(vk, is_arrow=False):
    scan = ctypes.windll.user32.MapVirtualKeyA(vk, 0)
    flags = KEYEVENTF_KEYUP
    if is_arrow:
        flags |= KEYEVENTF_EXTENDEDKEY
    ctypes.windll.user32.keybd_event(vk, scan, flags, 0)

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if sys.platform != "win32": return
        
        # ★ 버그 원인 해결 1: 세부 액션을 직접 드래그했을 때의 상태 파싱
        action_id = data.get("action", "")
        state_val = None
        if "#" in action_id:
            state_val = action_id.split("#")[-1]
            
        settings = data.get("payload", {}).get("settings", {})
        
        # ★ 버그 원인 해결 2: 우선순위에 따른 기본값("next") 강제 할당
        # 1순위: 사용자가 설정창에서 저장한 값
        # 2순위: 우측 탭에서 드래그해 온 세부 액션의 값
        # 3순위: 아무것도 없으면 "next"
        action = settings.get("vd_action") or state_val or "next"
        
        def run_vd_command():
            # 1. 조합키 누르기
            press_hardware_key(VK_CONTROL)
            press_hardware_key(VK_LWIN)
            time.sleep(0.05)
            
            # 2. 메인 키 처리
            if action == "next":
                press_hardware_key(VK_RIGHT, is_arrow=True) 
                time.sleep(0.05)
                release_hardware_key(VK_RIGHT, is_arrow=True)
            elif action == "prev":
                press_hardware_key(VK_LEFT, is_arrow=True)
                time.sleep(0.05)
                release_hardware_key(VK_LEFT, is_arrow=True)
            elif action == "new":
                press_hardware_key(VK_D)
                time.sleep(0.05)
                release_hardware_key(VK_D)
            elif action == "close":
                press_hardware_key(VK_F4)
                time.sleep(0.05)
                release_hardware_key(VK_F4)
            elif action == "view":
                # view는 Ctrl이 필요 없으므로 일단 떼고 실행
                release_hardware_key(VK_CONTROL)
                press_hardware_key(VK_TAB)
                time.sleep(0.05)
                release_hardware_key(VK_TAB)
            
            # 3. 조합키 떼기
            time.sleep(0.05)
            release_hardware_key(VK_LWIN)
            release_hardware_key(VK_CONTROL)

        await asyncio.to_thread(run_vd_command)