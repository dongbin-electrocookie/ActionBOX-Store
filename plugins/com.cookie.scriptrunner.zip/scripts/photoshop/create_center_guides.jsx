#target photoshop

if (app.documents.length === 0) {
  alert("❌ 열린 문서가 없습니다.");
} else {
  var doc = app.activeDocument;

  var originalRulerUnits = app.preferences.rulerUnits;
  app.preferences.rulerUnits = Units.PIXELS;

  var width = doc.width.as("px");
  var height = doc.height.as("px");

  function addGuide(position, direction) {
    var idMk = charIDToTypeID("Mk  ");
    var desc = new ActionDescriptor();
    var idNw = charIDToTypeID("Nw  ");
    var desc2 = new ActionDescriptor();
    var idPstn = charIDToTypeID("Pstn");
    var idPxl = charIDToTypeID("#Pxl");
    desc2.putUnitDouble(idPstn, idPxl, position);
    var idOrnt = charIDToTypeID("Ornt");
    var idOrntType = charIDToTypeID("Ornt");
    var directionType = (direction === "V") ? charIDToTypeID("Vrtc") : charIDToTypeID("Hrzn");
    desc2.putEnumerated(idOrnt, idOrntType, directionType);
    var idGd = charIDToTypeID("Gd  ");
    desc.putObject(idNw, idGd, desc2);
    executeAction(idMk, desc, DialogModes.NO);
  }

  addGuide(width / 2, "V");   // 수직 중앙
  addGuide(height / 2, "H");  // 수평 중앙

  app.preferences.rulerUnits = originalRulerUnits;

  alert("✅ 중앙 가이드가 추가되었습니다!");
}
