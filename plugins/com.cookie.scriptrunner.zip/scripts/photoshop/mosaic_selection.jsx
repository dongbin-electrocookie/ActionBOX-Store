#target photoshop

if (app.documents.length === 0) {
  alert("❌ 열린 문서가 없습니다.");
} else {
  try {
    var doc = app.activeDocument;

    // 선택 영역이 있는지 확인
    try {
      var bounds = doc.selection.bounds; // 선택 영역이 없으면 예외 발생
    } catch (e) {
      alert("⚠ 먼저 모자이크할 영역을 선택해주세요.");
      throw e;
    }

    // 모자이크 필터 적용 (ActionManager 방식)
    var mosaicSize = 4; // 블록 크기

    var idMsc = charIDToTypeID("Msc ");
    var desc = new ActionDescriptor();
    desc.putInteger(charIDToTypeID("Sz  "), mosaicSize); // Sz = Size
    executeAction(idMsc, desc, DialogModes.NO);

    alert("✅ 선택한 영역에 모자이크가 적용되었습니다!");

  } catch (e) {
    // 기타 오류
    // alert("⚠ 오류 발생: " + e.message); ← 주석 처리해도 OK
  }
}
