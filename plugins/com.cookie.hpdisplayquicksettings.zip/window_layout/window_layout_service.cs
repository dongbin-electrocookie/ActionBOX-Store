using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

internal static class NativeMethods
{
    internal const int GA_ROOT = 2;
    internal const int SW_RESTORE = 9;
    internal const int VK_LBUTTON = 0x01;
    internal const int VK_SHIFT = 0x10;
    internal const int VK_CONTROL = 0x11;
    internal const int GWL_EXSTYLE = -20;
    internal const int WS_EX_TRANSPARENT = 0x20;
    internal const int WS_EX_TOOLWINDOW = 0x80;
    internal const int WS_EX_NOACTIVATE = 0x08000000;
    internal const int WM_MOUSEACTIVATE = 0x0021;
    internal const int WM_NCHITTEST = 0x0084;
    internal const int MA_NOACTIVATE = 3;
    internal const int HTTRANSPARENT = -1;

    [StructLayout(LayoutKind.Sequential)]
    internal struct POINT { public int X; public int Y; }

    [DllImport("user32.dll")] internal static extern short GetAsyncKeyState(int key);
    [DllImport("user32.dll")] internal static extern bool GetCursorPos(out POINT point);
    [DllImport("user32.dll")] internal static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] internal static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] internal static extern bool IsIconic(IntPtr hwnd);
    [DllImport("user32.dll")] internal static extern bool IsZoomed(IntPtr hwnd);
    [DllImport("user32.dll")] internal static extern bool ShowWindow(IntPtr hwnd, int command);
    [DllImport("user32.dll")] internal static extern bool MoveWindow(IntPtr hwnd, int x, int y, int width, int height, bool repaint);
    [DllImport("user32.dll")] internal static extern IntPtr GetWindowLongPtr(IntPtr hwnd, int index);
    [DllImport("user32.dll")] internal static extern IntPtr SetWindowLongPtr(IntPtr hwnd, int index, IntPtr value);
}

internal sealed class OverlayForm : Form
{
    private List<Rectangle> zones = new List<Rectangle>();
    private int hoveredZone = -1;

    internal OverlayForm()
    {
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        TopMost = true;
        BackColor = Color.FromArgb(20, 25, 36);
        Opacity = 0.72;
        StartPosition = FormStartPosition.Manual;
        DoubleBuffered = true;
    }

    protected override bool ShowWithoutActivation { get { return true; } }

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams parameters = base.CreateParams;
            parameters.ExStyle |= NativeMethods.WS_EX_TRANSPARENT | NativeMethods.WS_EX_TOOLWINDOW | NativeMethods.WS_EX_NOACTIVATE;
            return parameters;
        }
    }

    protected override void WndProc(ref Message message)
    {
        if (message.Msg == NativeMethods.WM_NCHITTEST)
        {
            message.Result = new IntPtr(NativeMethods.HTTRANSPARENT);
            return;
        }
        if (message.Msg == NativeMethods.WM_MOUSEACTIVATE)
        {
            message.Result = new IntPtr(NativeMethods.MA_NOACTIVATE);
            return;
        }
        base.WndProc(ref message);
    }

    internal void UpdateZones(Rectangle workArea, List<Rectangle> newZones, int hover)
    {
        Bounds = workArea;
        zones = newZones;
        hoveredZone = hover;
        Invalidate();
        if (!Visible) Show();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        for (int i = 0; i < zones.Count; i++)
        {
            Rectangle zone = zones[i];
            zone.Offset(-Left, -Top);
            Color fill = i == hoveredZone
                ? Color.FromArgb(210, 65, 125, 255)
                : Color.FromArgb(95, 55, 113, 245);
            using (SolidBrush brush = new SolidBrush(fill))
            using (Pen pen = new Pen(Color.FromArgb(235, 155, 185, 255), 2))
            {
                e.Graphics.FillRectangle(brush, zone);
                e.Graphics.DrawRectangle(pen, zone);
            }
        }
    }
}

internal sealed class LayoutContext : ApplicationContext
{
    private const string PipeName = "ComboXHpDisplayWindowLayoutV2";
    private readonly string holdFile = Path.Combine(Path.GetTempPath(), "com.cookie.hpdisplayquicksettings.layout_hold");
    private readonly System.Windows.Forms.Timer timer;
    private readonly OverlayForm overlay = new OverlayForm();
    private string layout = "halves";
    private int modifierKey = NativeMethods.VK_SHIFT;
    private IntPtr draggedWindow = IntPtr.Zero;
    private bool gestureActive;
    private bool modifierWasDown;
    private bool mouseWasDown;
    private volatile bool virtualModifierActive;
    private DateTime previewUntil = DateTime.MinValue;
    private int hoveredZone = -1;
    private IntPtr pendingWindow = IntPtr.Zero;
    private Rectangle pendingTarget;
    private DateTime pendingMoveAt = DateTime.MinValue;

    internal LayoutContext(string initialLayout, string initialModifier, bool showInitialPreview, bool initialVirtualHold)
    {
        ApplyCommand(initialLayout + "|" + initialModifier + "|" + (showInitialPreview ? "1" : "0")
            + "|" + (initialVirtualHold ? "1" : "0"));
        Thread pipeThread = new Thread(PipeServerLoop);
        pipeThread.IsBackground = true;
        pipeThread.Start();

        timer = new System.Windows.Forms.Timer();
        timer.Interval = 25;
        timer.Tick += Tick;
        timer.Start();
    }

    private void PipeServerLoop()
    {
        while (true)
        {
            try
            {
                using (NamedPipeServerStream pipe = new NamedPipeServerStream(PipeName, PipeDirection.In))
                {
                    pipe.WaitForConnection();
                    using (StreamReader reader = new StreamReader(pipe))
                    {
                        string command = reader.ReadLine();
                        if (!String.IsNullOrWhiteSpace(command))
                            ApplyCommand(command);
                    }
                }
            }
            catch { Thread.Sleep(250); }
        }
    }

    private void ApplyCommand(string command)
    {
        string[] parts = command.Split('|');
        if (parts.Length > 0 && !String.IsNullOrWhiteSpace(parts[0])) layout = parts[0];
        modifierKey = parts.Length > 1 && parts[1].Equals("ctrl", StringComparison.OrdinalIgnoreCase)
            ? NativeMethods.VK_CONTROL : NativeMethods.VK_SHIFT;
        bool showPreview = parts.Length < 3 || parts[2] != "0";
        if (parts.Length > 3)
            virtualModifierActive = parts[3] == "1";
        previewUntil = showPreview ? DateTime.Now.AddMilliseconds(1600) : DateTime.MinValue;
    }

    private static bool Down(int key) { return (NativeMethods.GetAsyncKeyState(key) & 0x8000) != 0; }

    private bool VirtualModifierDown()
    {
        try
        {
            if (!File.Exists(holdFile)) return false;
            string[] parts = File.ReadAllText(holdFile).Trim().Split('|');
            double expiresAt;
            if (parts.Length < 3 || !Double.TryParse(parts[2], System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture, out expiresAt)
                || expiresAt <= (DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds)
            {
                File.Delete(holdFile);
                return false;
            }
            if (!String.IsNullOrWhiteSpace(parts[0])) layout = parts[0];
            modifierKey = parts[1].Equals("ctrl", StringComparison.OrdinalIgnoreCase)
                ? NativeMethods.VK_CONTROL : NativeMethods.VK_SHIFT;
            return true;
        }
        catch { return false; }
    }

    private void Tick(object sender, EventArgs e)
    {
        if (pendingWindow != IntPtr.Zero && DateTime.Now >= pendingMoveAt)
        {
            PlaceWindow(pendingWindow, pendingTarget);
            pendingWindow = IntPtr.Zero;
        }

        NativeMethods.POINT cursor;
        NativeMethods.GetCursorPos(out cursor);
        bool mouseDown = Down(NativeMethods.VK_LBUTTON);
        bool modifierDown = Down(modifierKey) || virtualModifierActive || VirtualModifierDown();
        bool preview = DateTime.Now < previewUntil;

        if (modifierWasDown && !modifierDown)
        {
            gestureActive = false;
            draggedWindow = IntPtr.Zero;
            previewUntil = DateTime.MinValue;
            preview = false;
            HideZones();
        }
        bool dragStarted = mouseDown && !mouseWasDown && modifierDown;
        bool activatedDuringDrag = mouseDown && modifierDown && !modifierWasDown;
        if ((dragStarted || activatedDuringDrag) && !gestureActive)
        {
            IntPtr candidate = NativeMethods.GetForegroundWindow();
            if (candidate != IntPtr.Zero && NativeMethods.IsWindowVisible(candidate) && candidate != overlay.Handle)
            {
                draggedWindow = candidate;
                gestureActive = true;
            }
        }

        if ((gestureActive && mouseDown) || preview)
        {
            Screen screen = Screen.FromPoint(new Point(cursor.X, cursor.Y));
            ShowZones(screen.WorkingArea, cursor, gestureActive && mouseDown);
        }

        if (!mouseDown && gestureActive)
        {
            int dropZone = hoveredZone;
            IntPtr dropWindow = draggedWindow;
            Rectangle dropTarget = dropZone >= 0
                ? GetZoneRect(Screen.FromPoint(new Point(cursor.X, cursor.Y)).WorkingArea, dropZone)
                : Rectangle.Empty;
            gestureActive = false;
            draggedWindow = IntPtr.Zero;
            HideZones();
            if (dropWindow != IntPtr.Zero && dropZone >= 0)
            {
                pendingWindow = dropWindow;
                pendingTarget = dropTarget;
                pendingMoveAt = DateTime.Now.AddMilliseconds(80);
            }
        }
        else if (!gestureActive && !preview)
        {
            HideZones();
        }
        mouseWasDown = mouseDown;
        modifierWasDown = modifierDown;
    }

    private static void PlaceWindow(IntPtr window, Rectangle target)
    {
        if (NativeMethods.IsIconic(window) || NativeMethods.IsZoomed(window))
            NativeMethods.ShowWindow(window, NativeMethods.SW_RESTORE);
        NativeMethods.MoveWindow(window, target.X, target.Y, target.Width, target.Height, true);
    }

    private void ShowZones(Rectangle workArea, NativeMethods.POINT cursor, bool select)
    {
        List<RectangleF> zones = Layouts.Get(layout);
        List<Rectangle> pixels = new List<Rectangle>();
        hoveredZone = -1;
        for (int i = 0; i < zones.Count; i++)
        {
            Rectangle rect = ToPixels(workArea, zones[i]);
            pixels.Add(rect);
            if (select && rect.Contains(cursor.X, cursor.Y)) hoveredZone = i;
        }
        overlay.UpdateZones(workArea, pixels, hoveredZone);
    }

    private void HideZones()
    {
        overlay.Hide();
        hoveredZone = -1;
    }

    private Rectangle GetZoneRect(Rectangle workArea, int index)
    {
        List<RectangleF> zones = Layouts.Get(layout);
        return ToPixels(workArea, zones[Math.Max(0, Math.Min(index, zones.Count - 1))]);
    }

    private static Rectangle ToPixels(Rectangle area, RectangleF zone)
    {
        const int gap = 5;
        int x = area.X + (int)Math.Round(area.Width * zone.X) + gap;
        int y = area.Y + (int)Math.Round(area.Height * zone.Y) + gap;
        int w = (int)Math.Round(area.Width * zone.Width) - gap * 2;
        int h = (int)Math.Round(area.Height * zone.Height) - gap * 2;
        return new Rectangle(x, y, Math.Max(40, w), Math.Max(40, h));
    }
}

internal static class Layouts
{
    private static RectangleF R(float x, float y, float w, float h) { return new RectangleF(x, y, w, h); }

    internal static List<RectangleF> Get(string name)
    {
        switch (name)
        {
            case "thirds": return new List<RectangleF> { R(0,0,1f/3,1), R(1f/3,0,1f/3,1), R(2f/3,0,1f/3,1) };
            case "wide-center": return new List<RectangleF> { R(0,0,.25f,1), R(.25f,0,.5f,1), R(.75f,0,.25f,1) };
            case "rows": return new List<RectangleF> { R(0,0,1,.5f), R(0,.5f,1,.5f) };
            case "quarters": return new List<RectangleF> { R(0,0,.5f,.5f), R(.5f,0,.5f,.5f), R(0,.5f,.5f,.5f), R(.5f,.5f,.5f,.5f) };
            case "left-main": return new List<RectangleF> { R(0,0,.65f,1), R(.65f,0,.35f,.5f), R(.65f,.5f,.35f,.5f) };
            case "right-main": return new List<RectangleF> { R(0,0,.35f,.5f), R(0,.5f,.35f,.5f), R(.35f,0,.65f,1) };
            case "six": return Grid(3, 2);
            case "nine": return Grid(3, 3);
            case "focus": return new List<RectangleF> { R(0,0,.2f,1), R(.2f,0,.6f,1), R(.8f,0,.2f,1) };
            default: return new List<RectangleF> { R(0,0,.5f,1), R(.5f,0,.5f,1) };
        }
    }

    private static List<RectangleF> Grid(int columns, int rows)
    {
        List<RectangleF> result = new List<RectangleF>();
        for (int y = 0; y < rows; y++)
            for (int x = 0; x < columns; x++)
                result.Add(R((float)x / columns, (float)y / rows, 1f / columns, 1f / rows));
        return result;
    }
}

internal static class Program
{
    private const string PipeName = "ComboXHpDisplayWindowLayoutV2";

    [STAThread]
    private static void Main(string[] args)
    {
        string layout = args.Length > 0 ? args[0] : "halves";
        string modifier = args.Length > 1 ? args[1] : "shift";
        string preview = args.Length > 2 ? args[2] : "1";
        string virtualHold = args.Length > 3 ? args[3] : "0";
        bool created;
        using (Mutex mutex = new Mutex(true, "ComboXHpDisplayWindowLayoutV2.Singleton", out created))
        {
            if (!created)
            {
                try
                {
                    using (NamedPipeClientStream pipe = new NamedPipeClientStream(".", PipeName, PipeDirection.Out))
                    {
                        pipe.Connect(1000);
                        using (StreamWriter writer = new StreamWriter(pipe)) { writer.WriteLine(layout + "|" + modifier + "|" + preview + "|" + virtualHold); }
                    }
                }
                catch { }
                return;
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LayoutContext(layout, modifier, preview != "0", virtualHold == "1"));
        }
    }
}
