import asyncio
import base64
import io
import json
import os
import sys
import time
import urllib.parse
import urllib.request
import tempfile
import html
import webbrowser
from pathlib import Path

# Optional imports. The plugin reports a friendly error if these are missing.
try:
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build
    GOOGLE_AVAILABLE = True
except Exception:
    GOOGLE_AVAILABLE = False

try:
    from PIL import Image, ImageDraw, ImageFont
    PIL_AVAILABLE = True
except Exception:
    PIL_AVAILABLE = False


SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]
DEFAULT_QUERY = "is:unread"
DEFAULT_TITLE_FORMAT = "Gmail\\n{count}"
DEFAULT_GEMINI_MODEL = "gemini-3.1-flash-lite"
DEPRECATED_GEMINI_MODELS = {
    "gemini-3.1-flash-lite-preview",
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite",
}

SUPPORTED_LANGS = ["de", "en", "es", "fr", "it", "ja", "ko", "pt", "pt-PT", "ru"]
LANG_ALIASES = {
    "kr": "ko",
    "jp": "ja",
    "pt_BR": "pt",
    "pt-BR": "pt",
    "pt_PT": "pt-PT",
}

PLUGIN_FALLBACK_TEXT = {
    "google_packages_missing": "Google API Python packages are not installed. Install requirements.txt first.",
    "credentials_missing": "credentials.json is missing. Create a Google OAuth Desktop credential and place it next to plugin.py.",
    "google_not_connected": "Google account is not connected. Use the Google account connection button in settings.",
    "gemini_key_empty": "Gemini API Key is empty. Enter your AI Studio API key.",
    "oauth_prompt": "A Google login page will open in your browser. Return here after authentication.",
    "oauth_success": "ActionBOX Gmail plugin is connected. You may close this browser window.",
    "no_mail_to_summarize": "There are no emails to summarize for the selected Gmail search query.",
    "ai_popup_title": "ActionBOX AI Mail Briefing",
    "ai_popup_note": "Test popup. This briefing is based on sender, subject, date and snippet for the selected range.",
}

AI_STYLE_TEXTS = {
    "ko": {
        "brief": "핵심만 3줄 이내로 간결하게 브리핑하세요.",
        "priority": "오늘 바로 확인해야 할 메일과 답장이 필요한 메일을 우선순위 중심으로 정리하세요.",
        "friendly": "친절한 개인 비서처럼 자연스럽게 요약하세요.",
        "urgent": "긴급하거나 중요한 메일만 강조하고, 광고성/자동 알림은 낮은 우선순위로 보세요.",
    },
    "en": {
        "brief": "Brief the key points in no more than 3 lines.",
        "priority": "Prioritize emails that need action today or require a reply.",
        "friendly": "Summarize naturally like a friendly personal assistant.",
        "urgent": "Emphasize only urgent or important emails and treat ads/automated notifications as low priority.",
    },
    "ja": {
        "brief": "要点だけを3行以内で簡潔に要約してください。",
        "priority": "今日確認すべきメールや返信が必要なメールを優先順位中心に整理してください。",
        "friendly": "親切な個人アシスタントのように自然に要約してください。",
        "urgent": "緊急または重要なメールだけを強調し、広告や自動通知は低い優先度として扱ってください。",
    },
    "de": {
        "brief": "Fasse die wichtigsten Punkte in höchstens 3 Zeilen kurz zusammen.",
        "priority": "Ordne E-Mails nach Priorität, besonders wenn sie heute bearbeitet oder beantwortet werden müssen.",
        "friendly": "Fasse sie natürlich wie ein freundlicher persönlicher Assistent zusammen.",
        "urgent": "Hebe nur dringende oder wichtige E-Mails hervor und bewerte Werbung/automatische Benachrichtigungen niedrig.",
    },
    "es": {
        "brief": "Resume los puntos clave en no más de 3 líneas.",
        "priority": "Prioriza los correos que deben revisarse hoy o requieren respuesta.",
        "friendly": "Resume de forma natural como un asistente personal amable.",
        "urgent": "Destaca solo correos urgentes o importantes y considera publicidad/notificaciones automáticas como baja prioridad.",
    },
    "fr": {
        "brief": "Résume les points clés en 3 lignes maximum.",
        "priority": "Priorise les e-mails à traiter aujourd'hui ou nécessitant une réponse.",
        "friendly": "Résume naturellement comme un assistant personnel sympathique.",
        "urgent": "Mets en avant uniquement les e-mails urgents ou importants et classe les publicités/notifications automatiques en faible priorité.",
    },
    "it": {
        "brief": "Riassumi i punti principali in non più di 3 righe.",
        "priority": "Dai priorità alle email da controllare oggi o che richiedono risposta.",
        "friendly": "Riassumi in modo naturale come un assistente personale gentile.",
        "urgent": "Evidenzia solo email urgenti o importanti e considera pubblicità/notifiche automatiche a bassa priorità.",
    },
    "pt": {
        "brief": "Resuma os pontos principais em no máximo 3 linhas.",
        "priority": "Priorize e-mails que devem ser verificados hoje ou exigem resposta.",
        "friendly": "Resuma naturalmente como um assistente pessoal amigável.",
        "urgent": "Destaque apenas e-mails urgentes ou importantes e trate publicidade/notificações automáticas como baixa prioridade.",
    },
    "ru": {
        "brief": "Кратко изложите главное не более чем в 3 строках.",
        "priority": "Расставьте приоритеты: что нужно проверить сегодня и на что нужно ответить.",
        "friendly": "Сделайте естественное резюме в стиле дружелюбного личного ассистента.",
        "urgent": "Выделяйте только срочные или важные письма, а рекламу/автоуведомления считайте низким приоритетом.",
    },
}

AI_LANGUAGE_NAMES = {
    "ko": "Korean",
    "en": "English",
    "ja": "Japanese",
    "de": "German",
    "es": "Spanish",
    "fr": "French",
    "it": "Italian",
    "pt": "Portuguese",
    "pt-PT": "Portuguese",
    "ru": "Russian",
}


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.active_buttons = {}
        self.loop_started = False
        self.default_icon_name = "ACTION_GMAIL"
        self.log_file = str(self._appdata_dir() / "gmail_debug_log.txt")

    # -----------------------------
    # Common helpers
    # -----------------------------
    def _log(self, msg):
        try:
            ts = time.strftime("%Y-%m-%d %H:%M:%S")
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(f"[{ts}] {msg}\n")
        except Exception:
            pass
    def _normalize_lang(self, lang):
        raw = str(lang or "en")
        raw = LANG_ALIASES.get(raw, raw)
        if raw in SUPPORTED_LANGS:
            return raw
        short = raw.split("-")[0]
        if short in SUPPORTED_LANGS:
            return short
        return "en"

    def _settings_lang(self, settings):
        return self._normalize_lang((settings or {}).get("_lang") or "en")

    def _load_locale_data(self, lang):
        lang = self._normalize_lang(lang)
        paths = [
            Path(self.plugin_dir) / "locales" / f"{lang}.json",
            Path(self.plugin_dir) / "locales" / "en.json",
        ]
        if lang == "pt":
            paths.insert(1, Path(self.plugin_dir) / "locales" / "pt-PT.json")
        for path in paths:
            try:
                if path.exists():
                    return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
        return {}

    def _tr(self, key, lang="en", **params):
        data = self._load_locale_data(lang)
        text = data.get(key) or PLUGIN_FALLBACK_TEXT.get(key) or key
        for k, v in params.items():
            text = text.replace("{" + k + "}", str(v))
        return text

    def _ai_output_lang(self, settings):
        settings = settings or {}
        choice = settings.get("ai_language") or "auto"
        if choice == "auto":
            return self._settings_lang(settings)
        if choice == "source":
            return "source"
        return self._normalize_lang(choice)


    def _get_icon_path(self):
        return os.path.join(self.plugin_dir, "icon", f"{self.default_icon_name}.png")

    def _appdata_dir(self):
        if sys.platform.startswith("win"):
            base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        elif sys.platform == "darwin":
            base = str(Path.home() / "Library" / "Application Support")
        else:
            base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
        p = Path(base) / "CookieDeck" / "com_cookie_gmail"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def _token_path(self):
        return self._appdata_dir() / "token.json"

    def _credentials_path(self):
        # Prefer user-writable app data. Fall back to plugin folder for test/development builds.
        user_path = self._appdata_dir() / "credentials.json"
        plugin_path = Path(self.plugin_dir) / "credentials.json"
        if user_path.exists():
            return user_path
        return plugin_path

    def _maybe_copy_credentials_to_appdata(self):
        user_path = self._appdata_dir() / "credentials.json"
        plugin_path = Path(self.plugin_dir) / "credentials.json"
        try:
            if not user_path.exists() and plugin_path.exists():
                user_path.write_bytes(plugin_path.read_bytes())
        except Exception:
            pass

    def _has_credentials_file(self):
        self._maybe_copy_credentials_to_appdata()
        return self._credentials_path().exists()

    def _has_token_file(self):
        return self._token_path().exists()

    async def _send_builtin_icon(self, context):
        icon_path = self._get_icon_path()
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _set_title(self, context, title):
        if context:
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": title or ""}
            })

    async def _set_image(self, context, b64_image, page=None):
        if context and b64_image:
            payload = {"image": b64_image}
            if page is not None:
                payload["page"] = page
            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": payload
            })

    async def _send_to_pi(self, context, payload):
        if context:
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": payload or {}
            })

    def _normalize_settings(self, settings):
        s = dict(settings or {})
        s.setdefault("mode", "count_search")
        s.setdefault("query", DEFAULT_QUERY)
        s.setdefault("title_format", DEFAULT_TITLE_FORMAT)
        s.setdefault("auto_update_title", True)
        s.setdefault("refresh_interval", 60)
        s.setdefault("open_on_press", True)
        s.setdefault("to", "")
        s.setdefault("subject", "")
        s.setdefault("body", "")
        s.setdefault("gemini_api_key", "")
        s.setdefault("gemini_model", DEFAULT_GEMINI_MODEL)
        s.setdefault("gemini_model_preset", DEFAULT_GEMINI_MODEL)
        s.setdefault("gemini_model_custom", "")
        if s.get("gemini_model") in DEPRECATED_GEMINI_MODELS:
            s["gemini_model"] = DEFAULT_GEMINI_MODEL
        if s.get("gemini_model_preset") in DEPRECATED_GEMINI_MODELS:
            s["gemini_model_preset"] = DEFAULT_GEMINI_MODEL
        if s.get("gemini_model_custom") in DEPRECATED_GEMINI_MODELS:
            s["gemini_model_custom"] = ""
        s.setdefault("ai_mail_limit", 5)
        s.setdefault("ai_query", "is:unread")
        s.setdefault("ai_query_mode", "current")
        s.setdefault("ai_style", "brief")
        s.setdefault("ai_popup", True)
        s.setdefault("ai_language", "auto")
        s.setdefault("_lang", "en")
        s.setdefault("builtin_icon_name", self.default_icon_name)
        s.setdefault("default_visuals_initialized", True)
        return s

    # -----------------------------
    # Gmail OAuth / API
    # -----------------------------
    def _load_credentials(self):
        if not GOOGLE_AVAILABLE:
            raise RuntimeError(self._tr("google_packages_missing", "en"))
        if not self._has_credentials_file():
            raise RuntimeError(self._tr("credentials_missing", "en"))

        token_path = self._token_path()
        creds = None
        if token_path.exists():
            creds = Credentials.from_authorized_user_file(str(token_path), SCOPES)

        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
            token_path.write_text(creds.to_json(), encoding="utf-8")

        if not creds or not creds.valid:
            raise RuntimeError(self._tr("google_not_connected", "en"))
        return creds

    def _authenticate_blocking(self):
        if not GOOGLE_AVAILABLE:
            raise RuntimeError(self._tr("google_packages_missing", "en"))
        if not self._has_credentials_file():
            raise RuntimeError(self._tr("credentials_missing", "en"))

        flow = InstalledAppFlow.from_client_secrets_file(str(self._credentials_path()), SCOPES)
        creds = flow.run_local_server(
            port=0,
            open_browser=True,
            authorization_prompt_message=self._tr("oauth_prompt", "en"),
            success_message=self._tr("oauth_success", "en")
        )
        self._token_path().write_text(creds.to_json(), encoding="utf-8")
        return True

    def _build_gmail_service(self):
        creds = self._load_credentials()
        return build("gmail", "v1", credentials=creds, cache_discovery=False)

    def _get_profile_email_blocking(self):
        service = self._build_gmail_service()
        profile = service.users().getProfile(userId="me").execute()
        return profile.get("emailAddress", "")

    def _count_query_blocking(self, query):
        service = self._build_gmail_service()
        q = (query or DEFAULT_QUERY).strip() or DEFAULT_QUERY
        res = service.users().messages().list(userId="me", q=q, maxResults=1).execute()
        # Gmail resultSizeEstimate is enough for button status/count display.
        return int(res.get("resultSizeEstimate", 0))

    def _get_header(self, headers, name):
        target = (name or "").lower()
        for h in headers or []:
            if str(h.get("name", "")).lower() == target:
                return h.get("value", "")
        return ""

    def _get_recent_mail_summaries_blocking(self, query, limit):
        service = self._build_gmail_service()
        q = (query or DEFAULT_QUERY).strip() or DEFAULT_QUERY
        try:
            limit = int(limit or 5)
        except Exception:
            limit = 5
        limit = max(1, min(limit, 10))
        res = service.users().messages().list(userId="me", q=q, maxResults=limit).execute()
        messages = res.get("messages", []) or []
        items = []
        for msg in messages:
            msg_id = msg.get("id")
            if not msg_id:
                continue
            m = service.users().messages().get(
                userId="me",
                id=msg_id,
                format="metadata",
                metadataHeaders=["From", "Subject", "Date"]
            ).execute()
            headers = (m.get("payload", {}) or {}).get("headers", [])
            items.append({
                "id": msg_id,
                "from": self._get_header(headers, "From"),
                "subject": self._get_header(headers, "Subject"),
                "date": self._get_header(headers, "Date"),
                "snippet": m.get("snippet", "")
            })
        return items

    def _build_ai_prompt(self, mails, style, output_lang="en"):
        style = style or "brief"
        output_lang = output_lang or "en"
        if output_lang == "source":
            target_instruction = "Detect the main language of the emails and brief them in that same language. If multiple languages are mixed, use the user's UI language if it is clear; otherwise use English."
            style_text = AI_STYLE_TEXTS.get("en", {}).get(style, AI_STYLE_TEXTS["en"]["brief"])
        else:
            lang = self._normalize_lang(output_lang)
            target_name = AI_LANGUAGE_NAMES.get(lang, "English")
            style_text = AI_STYLE_TEXTS.get(lang) or AI_STYLE_TEXTS.get(lang.split("-")[0]) or AI_STYLE_TEXTS["en"]
            style_text = style_text.get(style, style_text.get("brief", AI_STYLE_TEXTS["en"]["brief"]))
            target_instruction = f"Brief the emails in {target_name}."

        lines = []
        for i, m in enumerate(mails, 1):
            lines.append(
                f"[{i}] From: {m.get('from','')}\n"
                f"Subject: {m.get('subject','')}\n"
                f"Date: {m.get('date','')}\n"
                f"Snippet: {m.get('snippet','')}"
            )
        mail_text = "\n\n".join(lines) if lines else "No mail"

        return (
            "You are the user's private email assistant for ActionBOX.\n"
            f"{target_instruction}\n\n"
            "Rules:\n"
            "1. Do not guess information that is not present.\n"
            "2. Treat advertisements, marketing messages and automated notifications as lower priority.\n"
            "3. Mark emails that appear to require a reply or same-day action.\n"
            "4. The data may contain personal information, so do not repeat unnecessary original text.\n"
            f"5. Style instruction: {style_text}\n\n"
            f"Email list:\n{mail_text}"
        )

    def _call_gemini_blocking(self, api_key, model, prompt, lang="en"):
        api_key = (api_key or "").strip()
        if not api_key:
            raise RuntimeError(self._tr("gemini_key_empty", lang))
        model = (model or DEFAULT_GEMINI_MODEL).strip() or DEFAULT_GEMINI_MODEL
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(model)}:generateContent"
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": 0.2,
                "maxOutputTokens": 700
            }
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "x-goog-api-key": api_key
            },
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=45) as resp:
                body = resp.read().decode("utf-8")
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Gemini API HTTP {e.code}: {detail[:600]}")
        result = json.loads(body)
        candidates = result.get("candidates") or []
        if not candidates:
            raise RuntimeError(f"Gemini API returned no candidates: {body[:600]}")
        parts = ((candidates[0].get("content") or {}).get("parts") or [])
        text = "".join(part.get("text", "") for part in parts).strip()
        if not text:
            raise RuntimeError(f"Gemini API returned empty text: {body[:600]}")
        return text

    def _open_ai_popup(self, text, lang="en"):
        safe = html.escape(text or "")
        title = html.escape(self._tr("ai_popup_title", lang))
        note = html.escape(self._tr("ai_popup_note", lang))
        html_lang = html.escape(self._normalize_lang(lang if lang != "source" else "en"))
        page = f"""<!doctype html><html lang="{html_lang}"><head><meta charset="utf-8"><title>{title}</title>
<style>body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Apple SD Gothic Neo','Malgun Gothic',Arial,sans-serif;background:#111827;color:#e5e7eb;margin:0;padding:24px;}}
.card{{max-width:780px;margin:0 auto;background:#1f2937;border:1px solid #374151;border-radius:16px;padding:22px;box-shadow:0 12px 40px rgba(0,0,0,.35)}}
h1{{font-size:20px;margin:0 0 14px;color:#fff}}pre{{white-space:pre-wrap;line-height:1.55;font-size:15px;background:#111827;border-radius:12px;padding:16px;border:1px solid #374151}}
.note{{color:#9ca3af;font-size:12px;margin-top:12px}}</style></head><body><div class="card"><h1>{title}</h1><pre>{safe}</pre><div class="note">{note}</div></div></body></html>"""
        path = Path(tempfile.gettempdir()) / "actionbox_gmail_ai_briefing.html"
        path.write_text(page, encoding="utf-8")
        webbrowser.open(path.as_uri())

    def _disconnect_blocking(self):
        p = self._token_path()
        if p.exists():
            p.unlink()
        return True

    # -----------------------------
    # Gmail URL actions
    # -----------------------------
    def _open_gmail_search(self, query):
        q = urllib.parse.quote((query or DEFAULT_QUERY).strip() or DEFAULT_QUERY)
        url = f"https://mail.google.com/mail/u/0/#search/{q}"
        webbrowser.open(url)

    def _open_gmail_compose(self, to="", subject="", body=""):
        params = {}
        if to:
            params["to"] = to
        if subject:
            params["su"] = subject
        if body:
            params["body"] = body
        query = urllib.parse.urlencode(params)
        url = "https://mail.google.com/mail/u/0/#inbox?compose=new"
        if query:
            # Gmail web compose accepts query fields inconsistently, but this is useful for testing.
            url += "&" + query
        webbrowser.open(url)

    # -----------------------------
    # Button image generation
    # -----------------------------
    def _font_paths(self, names):
        paths = []
        if sys.platform.startswith("win"):
            font_dirs = [Path(r"C:\Windows\Fonts")]
        elif sys.platform == "darwin":
            font_dirs = [
                Path("/System/Library/Fonts"),
                Path("/System/Library/Fonts/Supplemental"),
                Path("/Library/Fonts"),
                Path.home() / "Library" / "Fonts",
            ]
        else:
            font_dirs = [
                Path("/usr/share/fonts"),
                Path("/usr/local/share/fonts"),
                Path.home() / ".fonts",
                Path.home() / ".local" / "share" / "fonts",
            ]

        for name in names:
            paths.append(str(Path(self.plugin_dir) / name))
            for d in font_dirs:
                paths.append(str(d / name))
            paths.append(name)
        return paths

    def _load_font(self, names, size):
        if not PIL_AVAILABLE:
            return None
        for path in self._font_paths(names):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
        return ImageFont.load_default()

    def _make_count_image(self, count, label="Gmail"):
        if not PIL_AVAILABLE:
            return None
        img = Image.new("RGB", (128, 128), (210, 55, 45))
        d = ImageDraw.Draw(img)
        # Card background
        d.rounded_rectangle([8, 8, 120, 120], radius=18, fill=(255, 255, 255), outline=(190, 25, 25), width=3)
        # simple envelope
        d.rounded_rectangle([24, 28, 104, 72], radius=7, outline=(220, 55, 45), width=5)
        d.line([28, 32, 64, 58, 100, 32], fill=(220, 55, 45), width=4)
        bold = [
            "malgunbd.ttf", "arialbd.ttf", "segoeuib.ttf",
            "AppleSDGothicNeo.ttc", "AppleGothic.ttf", "Helvetica.ttc",
            "NotoSansCJK-Bold.ttc", "NotoSansKR-Bold.otf", "DejaVuSans-Bold.ttf",
            "arial.ttf"
        ]
        reg = [
            "malgun.ttf", "arial.ttf", "segoeui.ttf",
            "AppleSDGothicNeo.ttc", "AppleGothic.ttf", "Helvetica.ttc",
            "NotoSansCJK-Regular.ttc", "NotoSansKR-Regular.otf", "DejaVuSans.ttf"
        ]
        font_count = self._load_font(bold, 34)
        font_label = self._load_font(reg, 14)
        count_str = str(count)
        bbox = d.textbbox((0, 0), count_str, font=font_count)
        d.text(((128 - (bbox[2]-bbox[0]))/2, 76), count_str, font=font_count, fill=(20, 20, 20))
        label = (label or "Gmail")[:12]
        bbox = d.textbbox((0, 0), label, font=font_label)
        d.text(((128 - (bbox[2]-bbox[0]))/2, 108), label, font=font_label, fill=(90, 90, 90))
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return base64.b64encode(buf.getvalue()).decode("utf-8")

    async def update_count_action(self, context, settings):
        settings = self._normalize_settings(settings)
        query = settings.get("query") or DEFAULT_QUERY
        title_format = settings.get("title_format") or DEFAULT_TITLE_FORMAT

        try:
            count = await asyncio.to_thread(self._count_query_blocking, query)
            title = title_format.replace("{count}", str(count)).replace("\\n", "\n")
            if settings.get("auto_update_title", True):
                await self._set_title(context, title)
            img = await asyncio.to_thread(self._make_count_image, count, "Gmail")
            if img:
                await self._set_image(context, img, settings.get("_target_page"))
            return count, None
        except Exception as e:
            self._log(f"update_count_action error: {e}")
            await self._send_builtin_icon(context)
            if settings.get("auto_update_title", True):
                await self._set_title(context, "Gmail\nError")
            return None, str(e)

    async def run_ai_briefing(self, context, settings):
        settings = self._normalize_settings(settings)
        query = settings.get("query") or DEFAULT_QUERY
        if settings.get("ai_query_mode") == "custom":
            query = settings.get("ai_query") or query
        limit = int(settings.get("ai_mail_limit") or 5)
        try:
            if settings.get("auto_update_title", True):
                await self._set_title(context, "AI\nBriefing")
            mails = await asyncio.to_thread(self._get_recent_mail_summaries_blocking, query, limit)
            if not mails:
                result_text = self._tr("no_mail_to_summarize", self._settings_lang(settings))
            else:
                output_lang = self._ai_output_lang(settings)
                prompt = self._build_ai_prompt(mails, settings.get("ai_style"), output_lang)
                result_text = await asyncio.to_thread(
                    self._call_gemini_blocking,
                    settings.get("gemini_api_key", ""),
                    settings.get("gemini_model", DEFAULT_GEMINI_MODEL),
                    prompt,
                    self._settings_lang(settings)
                )
            await self._send_to_pi(context, {
                "command": "ai_result",
                "ok": True,
                "text": result_text,
                "mail_count": len(mails),
                "query": query
            })
            if settings.get("ai_popup", True):
                await asyncio.to_thread(self._open_ai_popup, result_text, self._ai_output_lang(settings))
            if settings.get("auto_update_title", True):
                await self._set_title(context, "AI\nDone")
            return result_text, None
        except Exception as e:
            self._log(f"ai_briefing error: {e}")
            await self._send_to_pi(context, {"command": "ai_result", "ok": False, "text": "", "message": str(e)})
            if settings.get("auto_update_title", True):
                await self._set_title(context, "AI\nError")
            return None, str(e)

    async def auto_update_loop(self):
        while True:
            await asyncio.sleep(5)
            now = time.time()
            for context, settings in list(self.active_buttons.items()):
                settings = self._normalize_settings(settings)
                if settings.get("mode") != "count_search":
                    continue
                interval = int(settings.get("refresh_interval") or 60)
                if interval < 15:
                    interval = 15
                last = float(settings.get("_last_update", 0) or 0)
                if now - last >= interval:
                    settings["_last_update"] = now
                    self.active_buttons[context] = settings
                    await self.update_count_action(context, settings)

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return
        settings = self._normalize_settings(settings)
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "mode", "query", "title_format", "auto_update_title", "refresh_interval", "to", "subject", "body",
            "default_visuals_initialized"
        ])
        if not meaningful:
            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": settings
            })
        self.active_buttons[context] = settings
        await self._send_builtin_icon(context)
        if settings.get("mode") == "count_search" and self._has_token_file():
            await self.update_count_action(context, settings)
        else:
            await self._set_title(context, "Gmail")

    # -----------------------------
    # CookieDeck message entrypoint
    # -----------------------------
    async def handle_message(self, data):
        try:
            event = data.get("event")
            payload = data.get("payload", {}) or {}
            command = payload.get("command") or data.get("command")
            context = payload.get("context") or data.get("context")
            settings = payload.get("settings") or data.get("settings", {}) or {}

            if not self.loop_started:
                self.loop_started = True
                asyncio.create_task(self.auto_update_loop())

            if event and ("disappear" in event.lower() or "delete" in event.lower() or "remove" in event.lower() or "clear" in event.lower()):
                self.active_buttons.pop(context, None)
                return

            if event in ["willAppear", "keyDidAppear"]:
                settings["_target_page"] = payload.get("page")
                await self._initialize_default_visuals_if_new(context, settings)
                return

            if event == "didReceiveSettings":
                if context:
                    merged = dict(self.active_buttons.get(context, {}))
                    merged.update(self._normalize_settings(settings))
                    merged["_target_page"] = payload.get("page", merged.get("_target_page"))
                    self.active_buttons[context] = merged
                return

            if event == "keyDown":
                settings = self._normalize_settings(self.active_buttons.get(context) or settings)
                mode = settings.get("mode")
                if mode == "count_search":
                    if settings.get("open_on_press", True):
                        await asyncio.to_thread(self._open_gmail_search, settings.get("query") or DEFAULT_QUERY)
                    await self.update_count_action(context, settings)
                elif mode == "open_search":
                    await asyncio.to_thread(self._open_gmail_search, settings.get("query") or DEFAULT_QUERY)
                elif mode == "compose":
                    await asyncio.to_thread(self._open_gmail_compose, settings.get("to", ""), settings.get("subject", ""), settings.get("body", ""))
                elif mode == "ai_briefing":
                    await self.run_ai_briefing(context, settings)
                else:
                    await asyncio.to_thread(self._open_gmail_search, DEFAULT_QUERY)
                return

            if event == "sendToPlugin" or command:
                if command == "apply_builtin_icon":
                    await self._send_builtin_icon(context)
                    return

                if command == "connect_google":
                    try:
                        if self._normalize_settings(settings).get("auto_update_title", True):
                            await self._set_title(context, "Google\nLogin")
                        await asyncio.to_thread(self._authenticate_blocking)
                        email = await asyncio.to_thread(self._get_profile_email_blocking)
                        await self._send_to_pi(context, {"command": "oauth_status", "ok": True, "email": email, "message": "connected"})
                        if context:
                            s = self._normalize_settings(settings)
                            self.active_buttons[context] = s
                            await self.update_count_action(context, s)
                    except Exception as e:
                        self._log(f"connect_google error: {e}")
                        await self._send_to_pi(context, {"command": "oauth_status", "ok": False, "message": str(e)})
                        if self._normalize_settings(settings).get("auto_update_title", True):
                            await self._set_title(context, "Login\nError")
                    return

                if command == "disconnect_google":
                    try:
                        await asyncio.to_thread(self._disconnect_blocking)
                        await self._send_to_pi(context, {"command": "oauth_status", "ok": True, "email": "", "message": "disconnected"})
                        await self._send_builtin_icon(context)
                        if self._normalize_settings(settings).get("auto_update_title", True):
                            await self._set_title(context, "Gmail")
                    except Exception as e:
                        await self._send_to_pi(context, {"command": "oauth_status", "ok": False, "message": str(e)})
                    return

                if command == "get_oauth_status":
                    email = ""
                    ok = False
                    msg = "not connected"
                    try:
                        if self._has_token_file():
                            email = await asyncio.to_thread(self._get_profile_email_blocking)
                            ok = True
                            msg = "connected"
                        elif not self._has_credentials_file():
                            msg = "credentials.json missing"
                    except Exception as e:
                        msg = str(e)
                    await self._send_to_pi(context, {"command": "oauth_status", "ok": ok, "email": email, "message": msg})
                    return

                if command == "test_ai_briefing" or command == "ai_briefing":
                    s = self._normalize_settings(settings)
                    if context:
                        self.active_buttons[context] = s
                    await self.run_ai_briefing(context, s)
                    return

                if command == "force_update" or command == "test_count":
                    s = self._normalize_settings(settings)
                    if context:
                        self.active_buttons[context] = s
                    count, err = await self.update_count_action(context, s)
                    await self._send_to_pi(context, {"command": "count_result", "ok": err is None, "count": count, "message": err or "ok"})
                    return

        except Exception as e:
            self._log(f"handle_message fatal: {e}")
            print(f"❌ [Gmail] Internal error: {e}")
