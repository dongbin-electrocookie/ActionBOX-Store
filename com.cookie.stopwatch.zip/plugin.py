import asyncio
import time
import os

class Plugin:
    SETTINGS_SCHEMA_VERSION = 2

    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get('UUID', 'com.cookie.stopwatch')
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.watches = {}
        self.i18n = {
            "en": {"STATUS_RUN": "[RUN]", "STATUS_STOP": "[STOP]", "STATUS_READY": "[READY]"},
            "ko": {"STATUS_RUN": "[실행]", "STATUS_STOP": "[정지]", "STATUS_READY": "[준비]"},
            "ja": {"STATUS_RUN": "[実行]", "STATUS_STOP": "[停止]", "STATUS_READY": "[準備]"},
            "de": {"STATUS_RUN": "[LAUF]", "STATUS_STOP": "[STOP]", "STATUS_READY": "[BEREIT]"},
            "es": {"STATUS_RUN": "[RUN]", "STATUS_STOP": "[STOP]", "STATUS_READY": "[READY]"},
            "fr": {"STATUS_RUN": "[MARCHE]", "STATUS_STOP": "[STOP]", "STATUS_READY": "[PRÊT]"},
            "ru": {"STATUS_RUN": "[ХОД]", "STATUS_STOP": "[СТОП]", "STATUS_READY": "[ГОТОВ]"},
            "it": {"STATUS_RUN": "[RUN]", "STATUS_STOP": "[STOP]", "STATUS_READY": "[READY]"},
            "pt-PT": {"STATUS_RUN": "[RUN]", "STATUS_STOP": "[STOP]", "STATUS_READY": "[READY]"}
        }
        asyncio.create_task(self.update_loop())

    def _lang(self, watch):
        code = ((watch or {}).get("lang") or "en").lower()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        code = alias.get(code, code)
        return code if code in self.i18n else "en"

    def _t(self, watch, key):
        lang = self._lang(watch)
        return self.i18n.get(lang, self.i18n["en"]).get(key, key)

    def _get_icon_path(self):
        return os.path.join(self.plugin_dir, "icon", "ACTION_STOPWATCH.png")

    async def _send_builtin_icon(self, context):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path()
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    def _build_default_settings(self):
        return {
            "_lang": "en",
            "show_stopwatch_on_title": True,
            "builtin_icon_name": "ACTION_STOPWATCH",
            "default_visuals_initialized": True,
            "_timer_settings_version": self.SETTINGS_SCHEMA_VERSION
        }

    @staticmethod
    def _page_from_context(context):
        if isinstance(context, str) and context.startswith("p") and ":" in context:
            page_part = context.split(":", 1)[0][1:]
            if page_part.isdigit():
                return int(page_part)
        return None

    def _ensure_watch(self, context, settings=None, page=None):
        if context not in self.watches:
            self.watches[context] = {
                "is_running": False,
                "elapsed": 0.0,
                "last_tick": 0.0,
                "last_press": 0.0,
                "lang": "en",
                "show_stopwatch_on_title": False,
                "page": self._page_from_context(context)
            }
        if page is not None:
            self.watches[context]["page"] = int(page)
        if isinstance(settings, dict):
            if settings.get("_lang"):
                self.watches[context]["lang"] = settings.get("_lang")
            if "show_stopwatch_on_title" in settings:
                self.watches[context]["show_stopwatch_on_title"] = bool(settings.get("show_stopwatch_on_title"))
        return self.watches[context]

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return {}

        settings = dict(settings or {})
        try:
            settings_version = int(settings.get("_timer_settings_version", 0) or 0)
        except (TypeError, ValueError):
            settings_version = 0

        # Older assignments counted normally but hid every title update by
        # default, making the stopwatch look completely unresponsive.
        # Migrate each assignment once and preserve later user choices.
        if settings_version < self.SETTINGS_SCHEMA_VERSION:
            migrated = self._build_default_settings()
            migrated.update(settings)
            migrated["show_stopwatch_on_title"] = True
            migrated["_timer_settings_version"] = self.SETTINGS_SCHEMA_VERSION
            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": migrated
            })
            settings = migrated

        self._ensure_watch(context, settings)
        if settings.get("show_stopwatch_on_title"):
            await self._update_display(context)
        else:
            await self._send_builtin_icon(context)
        return settings

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        settings = payload.get("settings", {}) if isinstance(payload, dict) else {}
        command = payload.get("command")

        if not context:
            return

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            self._ensure_watch(context, page=payload.get("page"))
            return

        if event in ["willDisappear", "keyDidDisappear"]:
            if context in self.watches:
                del self.watches[context]
            return

        if event == "didReceiveSettings":
            if context in self.watches and settings:
                self._ensure_watch(context, settings)
                if self.watches[context]["show_stopwatch_on_title"]:
                    await self._update_display(context)
            return

        if event == "sendToPlugin":
            if command == "update_lang":
                watch = self._ensure_watch(context)
                watch["lang"] = payload.get("lang", "en")
                if watch["show_stopwatch_on_title"]:
                    await self._update_display(context)
            elif command == "refresh_display":
                watch = self._ensure_watch(context, payload.get("settings", {}))
                if watch["show_stopwatch_on_title"]:
                    await self._update_display(context)
            elif command == "apply_builtin_icon":
                await self._send_builtin_icon(context)
            return

        if event == "keyDown":
            watch = self._ensure_watch(context, settings)
            now = time.time()

            if now - watch["last_press"] < 0.4:
                watch["is_running"] = False
                watch["elapsed"] = 0.0
                watch["last_press"] = 0.0
            else:
                watch["is_running"] = not watch["is_running"]
                if watch["is_running"]:
                    watch["last_tick"] = now
                watch["last_press"] = now

            if watch["show_stopwatch_on_title"]:
                await self._update_display(context)

    async def update_loop(self):
        while True:
            for context, watch in list(self.watches.items()):
                if watch["is_running"]:
                    now = time.time()
                    watch["elapsed"] += (now - watch["last_tick"])
                    watch["last_tick"] = now
                    if watch["show_stopwatch_on_title"]:
                        await self._update_display(context)
            await asyncio.sleep(0.1)

    def _build_display_text(self, watch):
        total_seconds = watch["elapsed"]
        mins = int(total_seconds // 60)
        secs = int(total_seconds % 60)
        dec = int((total_seconds * 10) % 10)

        time_str = f"{mins:02d}:{secs:02d}.{dec}"

        status_text = self._t(watch, "STATUS_RUN") if watch["is_running"] else self._t(watch, "STATUS_STOP")
        if watch["elapsed"] == 0.0:
            status_text = self._t(watch, "STATUS_READY")

        return f"{status_text}\n{time_str}"

    async def _update_display(self, context):
        watch = self.watches.get(context)
        if not watch:
            return

        display_text = self._build_display_text(watch)

        await self.runner.send_message({
            "event": "setTitle",
            "context": context,
            "payload": {
                "title": display_text,
                "page": watch.get("page")
            }
        })
