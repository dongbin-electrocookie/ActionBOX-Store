import asyncio
import urllib.request
import json
import base64
import io
import os
import sys
import glob

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    pass

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get('UUID', 'com.cookie.stock')
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.active_buttons = {}
        self.loop_started = False
        self.default_icon_name = "ACTION_STOCK"
        self.i18n = {
            "en": {"TITLE_QUERY_FAIL": "Query\nFailed"},
            "ko": {"TITLE_QUERY_FAIL": "조회\n실패"},
            "ja": {"TITLE_QUERY_FAIL": "取得\n失敗"},
            "de": {"TITLE_QUERY_FAIL": "Abfrage\nFehlgeschlagen"},
            "es": {"TITLE_QUERY_FAIL": "Consulta\nfallida"},
            "fr": {"TITLE_QUERY_FAIL": "Échec\nde requête"},
            "ru": {"TITLE_QUERY_FAIL": "Ошибка\nзапроса"},
            "it": {"TITLE_QUERY_FAIL": "Richiesta\nfallita"},
            "pt-PT": {"TITLE_QUERY_FAIL": "Consulta\nfalhou"}
        }

        print(f"[{self.uuid}] Stock plugin loaded.")

    def _lang(self, settings):
        code = (settings.get("_lang") or "en").lower()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        code = alias.get(code, code)
        return code if code in self.i18n else "en"

    def _t(self, settings, key):
        lang = self._lang(settings)
        return self.i18n.get(lang, self.i18n["en"]).get(key, key)

    def _get_icon_path(self):
        return os.path.join(self.plugin_dir, "icon", f"{self.default_icon_name}.png")

    def _target_page_for(self, context, settings=None):
        if isinstance(settings, dict) and settings.get("_target_page") is not None:
            return settings.get("_target_page")
        active = self.active_buttons.get(context, {})
        if isinstance(active, dict):
            return active.get("_target_page")
        return None

    async def _send_builtin_icon(self, context, settings=None):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path()
        if os.path.exists(icon_path):
            target_page = self._target_page_for(context, settings)
            image_payload = {"image": None}
            icon_payload = {"icon_path": icon_path}
            if target_page is not None:
                image_payload["page"] = target_page
                icon_payload["page"] = target_page
            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": image_payload
            })
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": icon_payload
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "ticker", "display_name", "builtin_icon_name",
            "default_visuals_initialized", "sync_title_on_ticker_change", "title"
        ])

        if meaningful:
            if settings.get("ticker"):
                self.active_buttons[context] = settings
                await self.update_stock(context, settings)
            else:
                await self._send_builtin_icon(context, settings)
            return

        new_settings = {
            "ticker": "",
            "display_name": "",
            "_lang": "en",
            "sync_title_on_ticker_change": False,
            "builtin_icon_name": self.default_icon_name,
            "default_visuals_initialized": True
        }
        visual_settings = {**new_settings, "_target_page": settings.get("_target_page")}

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })
        await self._send_builtin_icon(context, visual_settings)

    async def handle_message(self, data):
        if not self.loop_started:
            self.loop_started = True
            asyncio.create_task(self.update_loop())

        event = data.get("event", "")
        context = data.get("context")
        payload = data.get("payload") or {}

        if not context:
            return

        if "disappear" in event.lower() or "delete" in event.lower() or "remove" in event.lower() or "clear" in event.lower():
            if context in self.active_buttons:
                del self.active_buttons[context]
                print(f"[{context}] Stock button disabled - update stopped")
            return

        settings = payload.get("settings") if isinstance(payload, dict) and "settings" in payload else payload
        if isinstance(settings, dict):
            settings["_target_page"] = payload.get("page", self._target_page_for(context, settings))

        if event in ["willAppear", "keyDidAppear", "didReceiveSettings"]:
            await self._initialize_default_visuals_if_new(context, settings if isinstance(settings, dict) else {})
            return

        if event in ["button_press", "keyDown"]:
            if context in self.active_buttons:
                await self.update_stock(context, self.active_buttons[context])
            elif isinstance(settings, dict) and settings.get("ticker"):
                self.active_buttons[context] = settings
                await self.update_stock(context, settings)
            else:
                await self._send_builtin_icon(context, settings if isinstance(settings, dict) else None)
            return

        if event == "sendToPlugin":
            command = payload.get("command")
            if command == "force_update":
                new_settings = payload.get("settings", {}) or {}
                if isinstance(new_settings, dict):
                    new_settings["_target_page"] = payload.get("page", self._target_page_for(context, new_settings))
                if new_settings.get("ticker"):
                    self.active_buttons[context] = new_settings
                    await self.update_stock(context, new_settings)
                else:
                    if context in self.active_buttons:
                        del self.active_buttons[context]
                    await self.runner.send_message({
                        "event": "setTitle",
                        "context": context,
                        "payload": {
                            "title": new_settings.get("title", ""),
                            "page": self._target_page_for(context, new_settings)
                        }
                    })
                    await self._send_builtin_icon(context, new_settings)
            elif command == "apply_builtin_icon":
                await self._send_builtin_icon(context, settings if isinstance(settings, dict) else None)

    async def update_loop(self):
        while True:
            for context, settings in list(self.active_buttons.items()):
                await self.update_stock(context, settings)
                await asyncio.sleep(0.5)
            await asyncio.sleep(60)

    async def update_stock(self, context, settings):
        ticker = settings.get("ticker")
        if not ticker:
            await self._send_builtin_icon(context, settings)
            return

        b64_image = await asyncio.to_thread(self.get_stock_image_base64, ticker, settings)

        current_active = self.active_buttons.get(context)
        if not current_active or current_active.get("ticker") != ticker:
            return

        if b64_image and self.runner:
            target_page = settings.get("_target_page")
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": "", "page": target_page}
            })
            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": {"image": b64_image, "page": target_page}
            })
        else:
            if self.runner:
                await self._send_builtin_icon(context, settings)
                await self.runner.send_message({
                    "event": "setTitle",
                    "context": context,
                    "payload": {
                        "title": self._t(settings, "TITLE_QUERY_FAIL"),
                        "page": settings.get("_target_page")
                    }
                })

    def _font_candidates(self, font_name):
        candidates = [os.path.join(self.plugin_dir, font_name)]

        if sys.platform.startswith("win"):
            candidates.extend([
                f"C:\\Windows\\Fonts\\{font_name}",
                "C:\\Windows\\Fonts\\malgunbd.ttf",
                "C:\\Windows\\Fonts\\malgun.ttf",
                "C:\\Windows\\Fonts\\arialbd.ttf",
                "C:\\Windows\\Fonts\\arial.ttf",
            ])
        elif sys.platform == "darwin":
            candidates.extend([
                "/System/Library/Fonts/AppleSDGothicNeo.ttc",
                "/System/Library/Fonts/Supplemental/AppleGothic.ttf",
                "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
                "/System/Library/Fonts/Supplemental/Arial.ttf",
                "/System/Library/Fonts/SFNS.ttf",
                "/System/Library/Fonts/SFNSDisplay.ttf",
                "/Library/Fonts/Arial Unicode.ttf",
            ])
            candidates.extend(glob.glob("/System/Library/Fonts/*Gothic*.ttf"))
            candidates.extend(glob.glob("/System/Library/Fonts/Supplemental/*Gothic*.ttf"))
        else:
            candidates.extend([
                "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc",
                "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
                "/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf",
                "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            ])

        candidates.append(font_name)
        seen = set()
        result = []
        for path in candidates:
            if path and path not in seen:
                seen.add(path)
                result.append(path)
        return result

    def get_fit_font(self, draw, text, font_name, max_width, start_size, min_size=12):
        font_paths = self._font_candidates(font_name)

        size = start_size
        last_font = None
        while size > min_size:
            font = None
            for fp in font_paths:
                try:
                    font = ImageFont.truetype(fp, size)
                    break
                except Exception:
                    pass

            if not font:
                return ImageFont.load_default()

            last_font = font
            try:
                w = draw.textlength(text, font=font)
            except Exception:
                w = draw.textbbox((0, 0), text, font=font)[2]

            if w <= max_width:
                return font
            size -= 2
        return last_font or ImageFont.load_default()

    def get_stock_image_base64(self, ticker, settings):
        try:
            url = f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}?interval=1d&range=2d"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as res:
                data = json.loads(res.read().decode('utf-8'))

            meta = data['chart']['result'][0]['meta']
            current_price = float(meta['regularMarketPrice'])
            prev_close = float(meta['chartPreviousClose'])
            change_percent = ((current_price - prev_close) / prev_close) * 100

            if current_price > prev_close:
                bg_color = (194, 53, 49)
            elif current_price < prev_close:
                bg_color = (44, 98, 181)
            else:
                bg_color = (80, 80, 80)

            img = Image.new('RGB', (112, 112), color=bg_color)
            draw = ImageDraw.Draw(img)

            display_name = settings.get("display_name", "").strip()
            if not display_name:
                display_name = ticker

            price_str = f"{current_price:,.2f}" if current_price < 1000 else f"{current_price:,.0f}"
            sign = "+" if change_percent > 0 else ""
            change_str = f"{sign}{change_percent:.2f}%"

            font_name = self.get_fit_font(draw, display_name, "malgunbd.ttf", 104, 21)
            font_price = self.get_fit_font(draw, price_str, "malgunbd.ttf", 108, 26)
            font_change = self.get_fit_font(draw, change_str, "malgunbd.ttf", 104, 19)

            def draw_centered(y, text, font, fill):
                try:
                    w = draw.textlength(text, font=font)
                except:
                    w = draw.textbbox((0, 0), text, font=font)[2]
                draw.text(((112 - w) / 2, y), text, font=font, fill=fill)

            draw_centered(9, display_name, font_name, (255, 255, 255))
            draw_centered(42, price_str, font_price, (255, 255, 255))
            draw_centered(79, change_str, font_change, (255, 255, 0))

            buffered = io.BytesIO()
            img.save(buffered, format="PNG")
            return f"data:image/png;base64,{base64.b64encode(buffered.getvalue()).decode('utf-8')}"

        except Exception as e:
            print(f"[{self.uuid}] API error ({ticker}): {e}")
            return None
