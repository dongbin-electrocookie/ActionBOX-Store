# Window layout worker

Windows runs window_layout_service.py with the application's bundled Python.
It uses only the standard library and Win32 APIs; C# compilation and a separate
Windows EXE are no longer used. The ten layout presets, 5 px zone inset,
click-through overlay, activation chord, held device button and delayed window
placement are retained.

On macOS the same Python worker supervises the existing native Swift helper
so its accessibility permission identity does not change. Window movement
and rendering still belong to that native helper.

layout_runtime.py owns the worker's stdin and process handle. Its working
directory is an individual ComboX-hp-layout-* temporary directory outside the
plugin. Quit, stdin EOF, runner exit or main-app exit shuts the worker down.
The macOS supervisor also stops and waits for its native child.

Plugin shutdown sends quit, waits, and escalates to terminate/kill only for its
owned worker when necessary. Legacy executables are identified by their exact
absolute plugin paths, not by a process name or an unverified PID file. The
shared runner reports unload success only after cleanup succeeds. The app waits
for that acknowledgement before removing the plugin directory.

After upgrading, restart ComboX so both the app and shared runner use the new
unload protocol. On macOS, verify a held-button drag, release, uninstall and app
exit on a Mac with accessibility permission granted; native macOS execution
cannot be validated on Windows.
