#target photoshop

if (app.documents.length === 0) {
  alert("❌ 열린 문서가 없습니다.");
} else {
  try {
    var doc = app.activeDocument;

    // 선택 영역 존재 확인
    try {
      var bounds = doc.selection.bounds;
    } catch (e) {
      alert("⚠ 먼저 영역을 선택해주세요.");
      throw e;
    }

    // 원본 보호: 레이어 복제
    var copyLayer = doc.activeLayer.duplicate();
    copyLayer.name = "Mosaic Layer";

    // 복제 레이어 선택
    doc.activeLayer = copyLayer;

    // 선택 영역 반전
    doc.selection.invert();

    // Mosaic 필터 적용 (ActionManager)
    var mosaicSize = 12; // 원하는 블록 크기
    var idMsc = charIDToTypeID("Msc ");
    var desc = new ActionDescriptor();
    desc.putInteger(charIDToTypeID("Sz  "), mosaicSize);
    executeAction(idMsc, desc, DialogModes.NO);

    // 선택 해제
    doc.selection.deselect();

    alert("✅ 선택한 영역을 제외한 부분에 모자이크가 적용되었습니다!");

  } catch (e) {
    // alert("⚠ 오류: " + e.message);
  }
}
