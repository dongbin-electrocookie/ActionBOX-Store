import asyncio
import urllib.request
import urllib.parse

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        # 🚀 [추가] 멀티액션을 위해 마지막으로 유효했던 Key와 Event를 기억합니다.
        self.last_valid_settings = {}

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    def send_ifttt(self, event_name, webhook_key):
        if not event_name or not webhook_key:
            print(f"[{self.uuid}] ⚠️ Event Name 또는 Webhook Key가 부족합니다.")
            return

        safe_event = urllib.parse.quote(event_name)
        url = f"https://maker.ifttt.com/trigger/{safe_event}/with/key/{webhook_key}"

        try:
            req = urllib.request.Request(url, method='POST')
            with urllib.request.urlopen(req, timeout=3) as response:
                print(f"[{self.uuid}] ✅ IFTTT 전송 성공: {event_name}")
        except Exception as e:
            print(f"[{self.uuid}] ❌ IFTTT 전송 실패: {e}")

    async def on_key_down(self, data):
        incoming_settings = data.get("payload", {}).get("settings", {})
        
        # 🚀 [핵심] 유효한 설정(Key 등)이 들어오면 기억해둡니다.
        if incoming_settings.get("ifttt_key"):
            self.last_valid_settings.update(incoming_settings)
            
        # 🚀 [표준화] 마지막 설정과 현재 명령을 병합합니다. (멀티액션 대응)
        # 멀티액션에서 #my_event 라고 오면 command 키에 담기게 됩니다.
        final_settings = {**self.last_valid_settings, **incoming_settings}
        
        # 'command'를 우선 확인하고, 없으면 기존 'ifttt_event'를 확인합니다.
        event_name = final_settings.get("command") or final_settings.get("ifttt_event", "").strip()
        webhook_key = final_settings.get("ifttt_key", "").strip()

        if event_name and webhook_key:
            await asyncio.to_thread(self.send_ifttt, event_name, webhook_key)
        else:
            print(f"[{self.uuid}] ⚠️ 실행을 위한 데이터가 부족합니다.")