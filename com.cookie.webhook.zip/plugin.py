import asyncio
import urllib.request
import urllib.error
import os

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.last_valid_settings = {}
        self.icon_map = {
            "GET": "METHOD_GET",
            "POST": "METHOD_POST",
            "PUT": "METHOD_PUT",
            "DELETE": "METHOD_DELETE"
        }

    def _get_icon_path(self, method):
        icon_name = self.icon_map.get((method or "GET").upper(), "METHOD_GET")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, method):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(method)
        if context and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "webhook_url", "webhook_method", "webhook_payload", "command",
            "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_request_change", "title"
        ])

        if meaningful:
            await self._send_builtin_icon(context, settings.get("webhook_method", "GET"))
            return

        new_settings = {
            "webhook_url": "",
            "webhook_method": "GET",
            "webhook_payload": "",
            "command": "",
            "_lang": "en",
            "sync_title_on_request_change": False,
            "builtin_icon_name": self.icon_map["GET"],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })
        await self._send_builtin_icon(context, "GET")

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        command = data.get("command") or payload.get("command")
        context = data.get("context") or payload.get("context")
        settings = payload.get("settings") if isinstance(payload.get("settings"), dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if command == "apply_builtin_icon":
            method = payload.get("method") or settings.get("webhook_method") or "GET"
            await self._send_builtin_icon(context, method)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    def send_webhook(self, url, method, payload):
        if not url:
            print(f"[{self.uuid}] URL is empty.")
            return

        try:
            req_data = payload.encode('utf-8') if payload and method in ['POST', 'PUT'] else None
            req = urllib.request.Request(url, data=req_data, method=method)
            if req_data:
                req.add_header('Content-Type', 'application/json')

            with urllib.request.urlopen(req, timeout=3) as response:
                print(f"[{self.uuid}] Webhook sent successfully ({response.status}): {url}")

        except Exception as e:
            print(f"[{self.uuid}] Webhook send failed: {e}")

    async def on_key_down(self, data):
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}

        if incoming_settings:
            filtered = {k: v for k, v in incoming_settings.items() if v not in ("", None)}
            self.last_valid_settings.update(filtered)

        final_settings = {**self.last_valid_settings, **incoming_settings}

        url = (final_settings.get("command") or final_settings.get("webhook_url") or "").strip()
        method = (final_settings.get("webhook_method") or "GET").upper()
        payload = (final_settings.get("webhook_payload") or "").strip()

        if url:
            await asyncio.to_thread(self.send_webhook, url, method, payload)
        else:
            print(f"[{self.uuid}] No URL to request.")
