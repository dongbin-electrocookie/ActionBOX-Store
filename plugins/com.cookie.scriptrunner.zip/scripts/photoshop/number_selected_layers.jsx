#target photoshop

var prefix = "Layer_";
var startNum = 1;

function getSelectedLayerIndices() {
    var selectedLayers = [];
    var ref = new ActionReference();
    ref.putProperty(stringIDToTypeID("property"), stringIDToTypeID("targetLayers"));
    ref.putEnumerated(stringIDToTypeID("document"), stringIDToTypeID("ordinal"), stringIDToTypeID("targetEnum"));
    try {
        var desc = executeActionGet(ref);
        if (desc.hasKey(stringIDToTypeID("targetLayers"))) {
            var selLayers = desc.getList(stringIDToTypeID("targetLayers"));
            for (var i = 0; i < selLayers.count; i++) {
                var idx = selLayers.getReference(i).getIndex();
                selectedLayers.push(idx);
            }
        }
    } catch (e) {
        alert("선택된 레이어가 없습니다.");
    }
    return selectedLayers;
}

function setLayerNameByIndex(idx, name) {
    try {
        var ref = new ActionReference();
        ref.putIndex(charIDToTypeID("Lyr "), idx);
        var desc = new ActionDescriptor();
        var nameDesc = new ActionDescriptor();
        nameDesc.putString(charIDToTypeID("Nm  "), name);
        desc.putReference(charIDToTypeID("null"), ref);
        desc.putObject(charIDToTypeID("T   "), charIDToTypeID("Lyr "), nameDesc);
        executeAction(charIDToTypeID("setd"), desc, DialogModes.NO);
        return true;
    } catch (e) {
        // 이름 변경 실패 (잠김, 배경, 고정 레이어 등)
        return false;
    }
}

function renameSelectedLayers() {
    if (app.documents.length === 0) {
        alert("열린 문서가 없습니다.");
        return;
    }

    var indices = getSelectedLayerIndices();
    if (!indices || indices.length === 0) {
        try {
            indices = [app.activeDocument.activeLayer.itemIndex];
        } catch (e) {
            alert("선택된 레이어가 없습니다.");
            return;
        }
    }
    indices.sort(function(a, b) { return b - a });

    var successCount = 0;
    for (var i = 0; i < indices.length; i++) {
        var renamed = setLayerNameByIndex(indices[i], prefix + (startNum + successCount));
        if (renamed) successCount++;
    }

    var skipped = indices.length - successCount;
    alert(successCount + "개 레이어 이름 변경 완료" + (skipped ? ", " + skipped + "개 건너뜀." : "."));
}

renameSelectedLayers();
