import asyncio
import ctypes
from contextlib import contextmanager
from functools import wraps
import os
import sys
import threading
import time

IS_WINDOWS = sys.platform.startswith("win")

try:
    import pyautogui
    PYAUTOGUI_OK = True
    pyautogui.FAILSAFE = True
except ImportError:
    pyautogui = None
    PYAUTOGUI_OK = False


class _WinPoint(ctypes.Structure):
    _fields_ = [("x", ctypes.c_int32), ("y", ctypes.c_int32)]


class _WinMouseInput(ctypes.Structure):
    _fields_ = [
        ("dx", ctypes.c_int32), ("dy", ctypes.c_int32),
        ("mouseData", ctypes.c_uint32), ("dwFlags", ctypes.c_uint32),
        ("time", ctypes.c_uint32), ("dwExtraInfo", ctypes.c_size_t),
    ]


class _WinInputUnion(ctypes.Union):
    # MOUSEINPUT is the largest INPUT union member on both Win32 and Win64.
    _fields_ = [("mi", _WinMouseInput)]


class _WinInput(ctypes.Structure):
    _anonymous_ = ("data",)
    _fields_ = [("type", ctypes.c_uint32), ("data", _WinInputUnion)]


def _per_monitor_coordinates(method):
    @wraps(method)
    def scoped(self, *args, **kwargs):
        with self._physical_coordinate_context():
            return method(self, *args, **kwargs)
    return scoped


class WindowsPhysicalMouse:
    """Use physical desktop pixels regardless of the shared runner's DPI mode."""

    def __init__(self, user32=None):
        self.user32 = user32 if user32 is not None else ctypes.WinDLL("user32", use_last_error=True)
        self.user32.GetPhysicalCursorPos.argtypes = [ctypes.POINTER(_WinPoint)]
        self.user32.GetPhysicalCursorPos.restype = ctypes.c_int
        self.user32.SetPhysicalCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
        self.user32.SetPhysicalCursorPos.restype = ctypes.c_int
        self.user32.SendInput.argtypes = [ctypes.c_uint, ctypes.POINTER(_WinInput), ctypes.c_int]
        self.user32.SendInput.restype = ctypes.c_uint
        self.user32.SetThreadDpiAwarenessContext.argtypes = [ctypes.c_void_p]
        self.user32.SetThreadDpiAwarenessContext.restype = ctypes.c_void_p

    @contextmanager
    def _physical_coordinate_context(self):
        # GetPhysicalCursorPos also returned scaled coordinates in the shared
        # system-DPI-aware runner on mixed 125%/100% monitors. Scope both capture
        # and execution to per-monitor DPI, without changing any process mode.
        set_context = self.user32.SetThreadDpiAwarenessContext
        previous = set_context(ctypes.c_void_p(-4))  # PER_MONITOR_AWARE_V2
        if not previous:
            previous = set_context(ctypes.c_void_p(-3))  # PER_MONITOR_AWARE
        if not previous:
            raise OSError("Cannot select a per-monitor mouse coordinate context")
        try:
            yield
        finally:
            if not set_context(ctypes.c_void_p(previous)):
                raise OSError("Cannot restore the mouse thread DPI context")

    @_per_monitor_coordinates
    def position(self):
        point = _WinPoint()
        if not self.user32.GetPhysicalCursorPos(ctypes.byref(point)):
            raise OSError("GetPhysicalCursorPos failed")
        return int(point.x), int(point.y)

    def check_fail_safe(self):
        if pyautogui.FAILSAFE and self.position() in pyautogui.FAILSAFE_POINTS:
            raise pyautogui.FailSafeException("Mouse Simulator stopped at a fail-safe corner")

    @_per_monitor_coordinates
    def move_to(self, x, y, duration=0.2):
        self.check_fail_safe()
        start_x, start_y = self.position()
        steps = max(1, round(duration / 0.01))
        for step in range(1, steps + 1):
            self.check_fail_safe()
            target_x = round(start_x + (x - start_x) * step / steps)
            target_y = round(start_y + (y - start_y) * step / steps)
            if not self.user32.SetPhysicalCursorPos(target_x, target_y):
                raise OSError("SetPhysicalCursorPos failed; click cancelled")
            if duration:
                time.sleep(duration / steps)
        actual = self.position()
        if actual != (x, y):
            raise OSError(f"Requested position {(x, y)} reached {actual}; click cancelled")

    @_per_monitor_coordinates
    def click(self, action, expected_position=None):
        self.check_fail_safe()
        if expected_position is not None and self.position() != expected_position:
            raise OSError("Cursor left the requested position; click cancelled")
        down, up = (0x0008, 0x0010) if action == "right_click" else (0x0002, 0x0004)
        flags = [down, up] * (2 if action == "double_click" else 1)
        inputs = (_WinInput * len(flags))()
        for item, flag in zip(inputs, flags):
            item.type = 0  # INPUT_MOUSE; no movement or coordinate rescaling.
            item.mi.dwFlags = flag
        sent = self.user32.SendInput(len(inputs), inputs, ctypes.sizeof(_WinInput))
        if sent != len(inputs):
            # A partial batch might have delivered button-down without button-up.
            if sent % 2:
                release = _WinInput()
                release.mi.dwFlags = up
                self.user32.SendInput(1, ctypes.byref(release), ctypes.sizeof(_WinInput))
            raise OSError(f"SendInput delivered {sent}/{len(inputs)} mouse events")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}
        self._windows_mouse = None
        self._mouse_action_lock = threading.Lock()

        self.icon_map = {
            "click": "left click",
            "double_click": "double click",
            "right_click": "right click",
            "move_only": "move only",
        }

    def _default_action(self):
        return "click"

    def _default_settings(self):
        action = self._default_action()
        return {
            "mouse_action": action,
            "pos_x": "",
            "pos_y": "",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("mouse_action") or self._default_action()
        if action not in self.icon_map:
            action = self._default_action()
        merged["mouse_action"] = action
        merged["builtin_icon_name"] = self.icon_map[action]
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("mouse_action"),
            s.get("pos_x") is not None and str(s.get("pos_x")).strip() != "",
            s.get("pos_y") is not None and str(s.get("pos_y")).strip() != "",
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False),
            s.get("_lang")
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        path = os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")
        if os.path.exists(path):
            return path
        fallback = os.path.join(self.plugin_dir, "icon", "pluginIcon.png")
        return fallback if os.path.exists(fallback) else None

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if context and icon_path:
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["mouse_action"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            action_name = data.get("action_command") or payload.get("action_command") or settings.get("mouse_action") or cached.get("mouse_action") or self._default_action()
            await self._send_builtin_icon(context, action_name)
            return

        if event == "sendToPlugin":
            if payload.get("command") == "capturePosition":
                await self.capture_position(context)
            return

        if event == "keyDown":
            await self.on_key_down(context, settings)

    async def capture_position(self, context):
        if not PYAUTOGUI_OK or not context:
            return
        await asyncio.sleep(3)
        try:
            x, y = await asyncio.to_thread(self._capture_cursor_position)
        except Exception as error:
            print(f"[Mouse Simulator Capture Error] {error}")
            return
        print(f"[Mouse Simulator Capture] pid={os.getpid()} position={(int(x), int(y))} "
              f"coordinates={'per-monitor-physical' if IS_WINDOWS else 'native'}", flush=True)
        await self.runner.send_message({
            "event": "sendToPropertyInspector",
            "context": context,
            "payload": {
                "command": "positionCaptured",
                "x": int(x),
                "y": int(y)
            }
        })

    async def on_key_down(self, context, incoming_settings):
        if not PYAUTOGUI_OK:
            return

        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **(incoming_settings or {})})
        if context:
            self.context_settings[context] = settings

        action = settings.get("mouse_action", self._default_action())

        x_raw = settings.get("pos_x")
        y_raw = settings.get("pos_y")
        try:
            x = self._parse_coordinate(x_raw)
            y = self._parse_coordinate(y_raw)
            if (x is None) != (y is None):
                raise ValueError("Both X and Y are required for a saved position")
        except (ValueError, TypeError) as error:
            print(f"[Mouse Simulator Error] Invalid position: {error}")
            return

        await asyncio.to_thread(self._execute_mouse_action, action, x, y)

    @staticmethod
    def _parse_coordinate(value):
        if value is None or str(value).strip() == "":
            return None
        coordinate = int(str(value).strip())
        if not -(2 ** 31) <= coordinate < 2 ** 31:
            raise ValueError("Position exceeds the supported coordinate range")
        return coordinate

    def _get_windows_mouse(self):
        if self._windows_mouse is None:
            self._windows_mouse = WindowsPhysicalMouse()
        return self._windows_mouse

    def _capture_cursor_position(self):
        if IS_WINDOWS:
            return self._get_windows_mouse().position()
        return pyautogui.position()

    def _execute_mouse_action(self, action, x, y):
        try:
            with self._mouse_action_lock:
                self._execute_mouse_action_locked(action, x, y)
        except Exception as e:
            print(f"[Mouse Simulator Error] {e}")

    def _execute_mouse_action_locked(self, action, x, y):
        if IS_WINDOWS:
            mouse = self._get_windows_mouse()
            mouse.check_fail_safe()
            position = (x, y) if x is not None and y is not None else None
            if position is not None:
                mouse.move_to(x, y, duration=0.2)
                print(f"[Mouse Simulator Move] pid={os.getpid()} target={position} "
                      f"actual={mouse.position()} coordinates=per-monitor-physical", flush=True)
            if action in ("click", "double_click", "right_click"):
                mouse.click(action, expected_position=position)
            return

        # macOS/Linux retain their native PyAutoGUI coordinate conventions.
        if x is not None and y is not None:
            pyautogui.moveTo(x, y, duration=0.2)

        if action == "click":
            pyautogui.click()
        elif action == "double_click":
            pyautogui.doubleClick()
        elif action == "right_click":
            pyautogui.rightClick()
