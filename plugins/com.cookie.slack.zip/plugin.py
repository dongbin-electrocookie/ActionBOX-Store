import sys
import os
import asyncio
import subprocess
import time

lib_path = os.path.join(os.path.dirname(__file__), 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

try:
    import pyautogui
    DEPENDENCIES_OK = True
except ImportError:
    pyautogui = None
    DEPENDENCIES_OK = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.last_valid_settings = {}

        self.windows_shortcuts_db = {
            "quick_switcher": ['ctrl', 'k'],
            "focus_search": ['ctrl', 'f'],
            "next_unread": ['alt', 'shift', 'down'],
            "mark_read": ['esc'],
            "workspace_1": ['ctrl', '1'],
            "all_unreads": ['ctrl', 'shift', 'a'],
            "threads": ['ctrl', 'shift', 't'],
            "history_back": ['alt', 'left'],
            "history_forward": ['alt', 'right'],
            "huddle_mute": ['ctrl', 'shift', 'space'],
            "huddle_video": ['ctrl', 'shift', 'v'],
            "mark_all_read": ['shift', 'esc'],
            "edit_last": ['up'],
            "preferences": ['ctrl', ',']
        }

        self.macos_shortcuts_db = {
            "quick_switcher": ['command', 'k'],
            "focus_search": ['command', 'f'],
            "next_unread": ['option', 'shift', 'down'],
            "mark_read": ['esc'],
            "workspace_1": ['command', '1'],
            "all_unreads": ['command', 'shift', 'a'],
            "threads": ['command', 'shift', 't'],
            "history_back": ['command', '['],
            "history_forward": ['command', ']'],
            "huddle_mute": ['command', 'shift', 'space'],
            "huddle_video": ['command', 'shift', 'v'],
            "mark_all_read": ['shift', 'esc'],
            "edit_last": ['up'],
            "preferences": ['command', ',']
        }

        self.linux_shortcuts_db = self.windows_shortcuts_db
        if IS_MACOS:
            self.shortcuts_db = self.macos_shortcuts_db
        elif IS_LINUX:
            self.shortcuts_db = self.linux_shortcuts_db
        else:
            self.shortcuts_db = self.windows_shortcuts_db

        self.shortcut_icon_map = {
            "quick_switcher": "STATE_QUICK_SWITCHER",
            "focus_search": "STATE_FOCUS_SEARCH",
            "next_unread": "STATE_NEXT_UNREAD",
            "mark_read": "STATE_MARK_READ",
            "workspace_1": "STATE_WORKSPACE_1",
            "all_unreads": "STATE_ALL_UNREADS",
            "threads": "STATE_THREADS",
            "history_back": "STATE_HISTORY_BACK",
            "history_forward": "STATE_HISTORY_FORWARD",
            "huddle_mute": "STATE_HUDDLE_MUTE",
            "huddle_video": "STATE_HUDDLE_VIDEO",
            "mark_all_read": "STATE_MARK_ALL_READ",
            "edit_last": "STATE_EDIT_LAST",
            "preferences": "STATE_PREFERENCES"
        }

        self.action_icon_map = {
            "quicksend": "ACTION_QUICKSEND",
            "shortcuts": "ACTION_SHORTCUTS"
        }

    def _get_action_key(self, action_id):
        action_id = (action_id or "").lower()
        if "quicksend" in action_id:
            return "quicksend"
        if "shortcuts" in action_id:
            return "shortcuts"
        return "quicksend"

    def _get_icon_path(self, action_id, shortcut_id=None):
        action_key = self._get_action_key(action_id)
        if action_key == "shortcuts":
            icon_name = self.shortcut_icon_map.get(shortcut_id or "quick_switcher", "STATE_QUICK_SWITCHER")
        else:
            icon_name = self.action_icon_map["quicksend"]
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id, shortcut_id=None):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_id, shortcut_id)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return

        settings = dict(settings or {})
        action_key = self._get_action_key(action_id)

        if action_key == "quicksend":
            meaningful_keys = [
                "slack_token", "channel_id", "default_message", "command",
                "builtin_icon_name", "default_visuals_initialized",
                "sync_title_on_message_change", "title"
            ]
            default_settings = {
                "_lang": "en",
                "builtin_icon_name": self.action_icon_map["quicksend"],
                "default_visuals_initialized": True
            }
            if any(settings.get(k) not in ("", None, False) for k in meaningful_keys):
                return
            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": default_settings
            })
            await self._send_builtin_icon(context, action_id)
            return

        meaningful_keys = [
            "command", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ]
        if any(settings.get(k) not in ("", None, False) for k in meaningful_keys):
            return

        default_shortcut = "quick_switcher"
        default_settings = {
            "command": default_shortcut,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.shortcut_icon_map[default_shortcut],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": default_settings
        })
        await self._send_builtin_icon(context, action_id, default_shortcut)

    def _activate_slack_if_possible(self):
        if not IS_MACOS:
            return
        # Slack 단축키 액션은 현재 포커스된 Slack/브라우저에서도 동작할 수 있지만,
        # 데스크톱 앱 사용 시 안정성을 위해 Slack 앱 활성화를 시도합니다.
        script = '''
        tell application "System Events"
            set appNames to name of every process
        end tell
        if appNames contains "Slack" then
            tell application "Slack" to activate
        end if
        '''
        try:
            subprocess.run(["osascript", "-e", script], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=1)
        except Exception:
            pass

    def _send_shortcut_sync(self, keys):
        if not DEPENDENCIES_OK or not keys:
            return
        self._activate_slack_if_possible()
        norm = []
        for key in keys:
            k = str(key).strip().lower()
            if IS_MACOS:
                if k in ("alt", "option"):
                    k = "option"
                elif k in ("cmd", "win", "windows"):
                    k = "command"
            norm.append(k)
        if len(norm) == 1:
            pyautogui.press(norm[0])
        else:
            pyautogui.hotkey(*norm)

    async def handle_message(self, data):
        event = data.get("event")
        action_id = data.get("action", "")
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        settings = payload.get("settings", {}) or {}
        command = payload.get("command")
        action_command = payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if event == "sendToPlugin" and command == "apply_builtin_icon":
            if "shortcuts" in (action_id or ""):
                await self._send_builtin_icon(context, action_id, action_command or settings.get("command") or "quick_switcher")
            else:
                await self._send_builtin_icon(context, action_id)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    def _edit_last_message_sync(self, mode="up_then_e"):
        """Open editing, not just message selection; never submit or delete."""
        if not DEPENDENCIES_OK:
            return
        self._activate_slack_if_possible()
        pyautogui.press('up')
        if mode == 'up_then_e':
            # Let Slack move focus before sending its focused-message shortcut.
            # These are separate presses, never a simultaneous Up+E hotkey.
            time.sleep(0.2)
            pyautogui.press('e')

    async def on_key_down(self, data):
        context = data.get("context")
        action = data.get("action")
        incoming_settings = data.get("payload", {}).get("settings", {})

        if context not in self.last_valid_settings:
            self.last_valid_settings[context] = {}
        if incoming_settings:
            filtered = {k: v for k, v in incoming_settings.items() if v}
            self.last_valid_settings[context].update(filtered)

        final_settings = {**self.last_valid_settings.get(context, {}), **incoming_settings}

        if "quicksend" in (action or ""):
            # Legacy saved API settings remain untouched, but never issue an API
            # request or type their stored message. This action now presses Enter.
            await asyncio.to_thread(self._send_shortcut_sync, ['enter'])

        elif "shortcuts" in (action or ""):
            shortcut_id = final_settings.get("command")
            if shortcut_id in self.shortcuts_db:
                if shortcut_id == "edit_last":
                    await asyncio.to_thread(self._edit_last_message_sync,
                                            final_settings.get("edit_last_mode", "up_then_e"))
                else:
                    keys = self.shortcuts_db[shortcut_id]
                    await asyncio.to_thread(self._send_shortcut_sync, keys)
