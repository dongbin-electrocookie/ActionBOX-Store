import keyboard
import asyncio
# json, websockets 임포트 필요 없음

class Plugin:
    # 1. 초기화 함수 수정: runner와 manifest를 받아야 합니다.
    def __init__(self, runner, manifest):
        self.runner = runner  # 관리자 저장
        self.uuid = manifest['UUID']
        
        # [핵심 로직] 기존 코드 그대로 유지
        self.action_map = {
            "volume_up": lambda: keyboard.send("volume up"),
            "volume_down": lambda: keyboard.send("volume down"),
            "mute": lambda: keyboard.send("volume mute"),
            "play_pause": lambda: keyboard.send("play/pause media"),
            "next_track": lambda: keyboard.send("next track"),
            "prev_track": lambda: keyboard.send("previous track"),
        }

    # 2. 핸들러 추가: 관리자(Runner)가 주는 메시지를 여기서 받아서 분배합니다.
    async def handle_message(self, data):
        event = data.get("event")
        
        if event == "keyDown":
            await self.on_key_down(data)
        elif event == "keyDidAppear":
            await self.on_key_did_appear(data)

    # 3. 기능 구현 (기존 로직 유지)
    # plugin.py 의 on_key_down 부분
    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        
        # 🚀 [표준화] 'selected_action' 대신 'command'에서 데이터를 가져옵니다.
        # 기존 저장된 데이터가 있을 수 있으므로 settings.get("selected_action")을 백업으로 둡니다.
        selected_action = settings.get("command") or settings.get("selected_action")
        
        action_func = self.action_map.get(selected_action)
        if action_func:
            action_func() # 미디어 키 전송은 thread 분리 없이도 즉시 실행 가능
        else:
            print(f"[{self.uuid}] Unknown action: {selected_action}")

    async def on_key_did_appear(self, data):
        # 필요하다면 여기에 초기화 로직 작성
        context = data.get("context")
        # print(f"[{self.uuid}] Key {context} appeared.")