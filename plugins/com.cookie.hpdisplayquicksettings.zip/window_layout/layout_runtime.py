"""Owned layout worker processes. No monitor APIs are called in this module."""
import ctypes
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import threading
import time


def stop_legacy_helpers(plugin_dir, timeout=3):
    """Stop only executables whose full path belongs to this plugin copy."""
    root = Path(plugin_dir).resolve() / "window_layout"
    expected = {os.path.normcase(str(root / name)) for name in (
        "window_layout_service.exe", "window_layout_service_v2.exe",
        "window_layout_service_macos")}
    if sys.platform == "win32":
        from ctypes import wintypes as w
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        psapi = ctypes.WinDLL("psapi", use_last_error=True)
        psapi.EnumProcesses.argtypes = [ctypes.POINTER(w.DWORD), w.DWORD, ctypes.POINTER(w.DWORD)]
        kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
        kernel.OpenProcess.restype = w.HANDLE
        kernel.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, ctypes.POINTER(w.DWORD)]
        kernel.TerminateProcess.argtypes = [w.HANDLE, w.UINT]
        kernel.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]
        kernel.CloseHandle.argtypes = [w.HANDLE]
        pids, count = (w.DWORD * 16384)(), w.DWORD()
        if not psapi.EnumProcesses(pids, ctypes.sizeof(pids), ctypes.byref(count)):
            raise ctypes.WinError(ctypes.get_last_error())
        for pid in pids[:count.value // ctypes.sizeof(w.DWORD)]:
            if not pid or pid == os.getpid():
                continue
            handle = kernel.OpenProcess(0x1000 | 0x100000 | 1, False, pid)
            if not handle:
                continue
            try:
                name, size = ctypes.create_unicode_buffer(32768), w.DWORD(32768)
                if not kernel.QueryFullProcessImageNameW(handle, 0, name, ctypes.byref(size)):
                    continue
                if os.path.normcase(os.path.realpath(name.value)) not in expected:
                    continue
                if not kernel.TerminateProcess(handle, 0) or kernel.WaitForSingleObject(handle, int(timeout * 1000)) != 0:
                    raise RuntimeError("The previous HP layout service could not be stopped")
            finally:
                kernel.CloseHandle(handle)
    elif sys.platform == "darwin":
        result = subprocess.run(["/bin/ps", "-axww", "-o", "pid=,comm="],
                                capture_output=True, text=True, timeout=3, check=True)
        for line in result.stdout.splitlines():
            parts = line.strip().split(None, 1)
            if len(parts) != 2 or not parts[0].isdigit():
                continue
            pid = int(parts[0])
            if pid == os.getpid() or os.path.normcase(os.path.realpath(parts[1])) not in expected:
                continue
            def still_same():
                check = subprocess.run(["/bin/ps", "-ww", "-p", str(pid), "-o", "comm="],
                                       capture_output=True, text=True, timeout=2)
                return check.returncode == 0 and os.path.normcase(os.path.realpath(check.stdout.strip())) in expected
            try:
                os.kill(pid, signal.SIGTERM)
                deadline = time.monotonic() + timeout
                while still_same() and time.monotonic() < deadline:
                    time.sleep(0.05)
                if still_same():
                    os.kill(pid, signal.SIGKILL)
                    deadline = time.monotonic() + timeout
                    while still_same() and time.monotonic() < deadline:
                        time.sleep(0.05)
                if still_same():
                    raise RuntimeError("The previous HP layout service could not be stopped")
            except ProcessLookupError:
                pass
        # The old Swift helper trusts this PID file. Remove our stale record
        # before launch so PID reuse cannot make it signal an unrelated process.
        record = Path("/tmp/com.cookie.hpdisplayquicksettings.layout.pid")
        try:
            if not record.is_symlink() and record.stat().st_uid == os.getuid():
                record.unlink()
        except FileNotFoundError:
            pass


class LayoutService:
    def __init__(self, plugin_dir):
        self.plugin_dir = Path(plugin_dir).resolve()
        self.process = None
        self.work_dir = None
        self.lock = threading.RLock()
        self.closed = False
        self.migrated = False

    def _python(self):
        # In the shared runner this is the bundled interpreter, not Combo-X.exe.
        if not getattr(sys, "frozen", False):
            return sys.executable
        base = Path(os.environ.get("ACTIONBOX_BASE_PATH", Path(sys.executable).parent))
        candidates = (base / "utility/python-embedded/python.exe",
                      base / "utility/python-macos-embedded/bin/python3.13")
        for path in candidates:
            if path.is_file():
                return str(path)
        raise RuntimeError("The bundled Python interpreter was not found")

    def command(self, layout="halves", active=False, preview=False):
        with self.lock:
            if self.closed:
                return False
            if not self.migrated:
                stop_legacy_helpers(self.plugin_dir)
                self.migrated = True
            if self.process is None or self.process.poll() is not None:
                self._start()
            self.process.stdin.write(json.dumps({
                "layout": layout, "active": bool(active), "preview": bool(preview)}) + "\n")
            self.process.stdin.flush()
            return True

    def _start(self):
        if self.process is not None and self.process.stdin:
            self.process.stdin.close()
        if self.work_dir is None:
            self.work_dir = tempfile.mkdtemp(prefix="ComboX-hp-layout-")
        script = self.plugin_dir / "window_layout/window_layout_service.py"
        args = [self._python(), "-B", "-u", str(script), "--parent-pid", str(os.getpid())]
        try:
            app_pid = int(os.environ.get("COMBOX_PARENT_PID", "0"))
        except ValueError:
            app_pid = 0
        if app_pid > 1:
            args += ["--app-pid", str(app_pid)]
        if sys.platform == "darwin":
            native = self.plugin_dir / "window_layout/window_layout_service_macos"
            if not native.is_file():
                raise RuntimeError("The macOS window layout helper was not found")
            native.chmod(native.stat().st_mode | 0o111)
            args += ["--mac-helper", str(native)]
        self.process = subprocess.Popen(
            args, cwd=self.work_dir, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL, text=True, encoding="utf-8", close_fds=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0,
            start_new_session=sys.platform != "win32",
        )

    def stop(self):
        with self.lock:
            self.closed = True
            child = self.process
            if child is not None:
                try:
                    if child.poll() is None:
                        try:
                            child.stdin.write('{"quit": true}\n')
                            child.stdin.flush()
                        except (OSError, ValueError):
                            pass
                        try:
                            child.wait(timeout=3)
                        except subprocess.TimeoutExpired:
                            child.terminate()
                            try:
                                child.wait(timeout=2)
                            except subprocess.TimeoutExpired:
                                child.kill()
                                child.wait(timeout=2)
                finally:
                    if child.stdin:
                        child.stdin.close()
                if child.poll() is None:
                    raise RuntimeError("HP layout service is still running")
                self.process = None
            # Also covers an old EXE and a native macOS worker whose supervisor
            # was interrupted. Match exact paths, never all python/OBS processes.
            stop_legacy_helpers(self.plugin_dir)
            if self.work_dir:
                try:
                    os.rmdir(self.work_dir)
                except OSError:
                    # Optional temp cleanup must not prevent removing a plugin
                    # after its workers have all been confirmed stopped.
                    pass
                self.work_dir = None
