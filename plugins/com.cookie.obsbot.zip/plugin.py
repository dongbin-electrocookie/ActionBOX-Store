import asyncio
import os
import socket
import struct
import time
import traceback

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get("UUID", "com.cookie.obsbot")
        self.plugin_dir = manifest.get("_folder_path", "")
        self.context_settings = {}
        
        # PTZ Watchdog
        self.ptz_timeout_task = None
        self.last_ptz_time = 0
        self.current_ptz_direction = None
        self.last_axis_send_time = 0
        self.current_axis_tuple = None
        self.active_ptz_addresses = set()
        self._axis_missing_settings_logged = False
        
        self.log_file = os.path.join(os.getcwd(), "obsbot_debug.log")
        if self.plugin_dir and os.path.exists(self.plugin_dir):
            self.log_file = os.path.join(self.plugin_dir, "obsbot_control_log.txt")

        self._log("===================================")
        self._log("OBSBOT Plugin Booted (Shotgun Edition)!")
        self._log("===================================")

        self.icon_map = {
            "analog_ptz": "ANALOG_PTZ", "track_lock": "TRACKING", "track_unlock": "TRACKING",
            "preset_1": "PRESET", "preset_2": "PRESET", "preset_3": "PRESET",
            "sleep": "SLEEP", "wake": "WAKE", "gimbal_reset": "RESET",
            "ai_mode_normal": "AI_MODE", "ai_mode_upper_body": "AI_MODE", "ai_mode_closeup": "AI_MODE", "ai_mode_group": "AI_MODE",
            "tracking_mode_standard": "TRACKING_MODE", "tracking_mode_motion": "TRACKING_MODE",
            "zoom_0": "ZOOM", "zoom_50": "ZOOM", "zoom_100": "ZOOM"
        }
        
        # OBSBOT command addresses and integer values.
        self.command_specs = {
            "track_lock": ("/obsbot/WebCam/Tiny/ToggleAILock", 1),
            "track_unlock": ("/obsbot/WebCam/Tiny/ToggleAILock", 0),
            "preset_1": ("/obsbot/WebCam/Tiny/TriggerPreset", 0),
            "preset_2": ("/obsbot/WebCam/Tiny/TriggerPreset", 1),
            "preset_3": ("/obsbot/WebCam/Tiny/TriggerPreset", 2),
            "sleep": ("/obsbot/WebCam/General/WakeSleep", 0),
            "wake": ("/obsbot/WebCam/General/WakeSleep", 1),
            "gimbal_reset": ("/obsbot/WebCam/General/ResetGimbal", 1),
            "ai_mode_normal": ("/obsbot/WebCam/Tiny/SetAiMode", 1),
            "ai_mode_upper_body": ("/obsbot/WebCam/Tiny/SetAiMode", 2),
            "ai_mode_closeup": ("/obsbot/WebCam/Tiny/SetAiMode", 3),
            "ai_mode_group": ("/obsbot/WebCam/Tiny/SetAiMode", 9),
            "tracking_mode_standard": ("/obsbot/WebCam/Tiny/SetTrackingMode", 1),
            "tracking_mode_motion": ("/obsbot/WebCam/Tiny/SetTrackingMode", 2),
            "zoom_0": ("/obsbot/WebCam/General/SetZoom", 0),
            "zoom_50": ("/obsbot/WebCam/General/SetZoom", 50),
            "zoom_100": ("/obsbot/WebCam/General/SetZoom", 100),
        }

    def _log(self, msg):
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{ts}] {msg}"
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass
        print(line)

    def _default_action(self):
        return "wake"

    def _default_settings(self):
        action = self._default_action()
        return {
            "osc_ip": "127.0.0.1",
            "osc_port": "16284",
            "device_index": "0",
            "command": action,
            "write_arg_mode": "single",
            "select_before_write": True,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or self._default_action()
        if action not in self.icon_map:
            action = self._default_action()
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map[action]
        arg_mode = (merged.get("write_arg_mode") or "single").strip().lower()
        if arg_mode not in ("pair", "single", "both"):
            arg_mode = "single"
        merged["write_arg_mode"] = arg_mode
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([s.get("osc_ip"), s.get("osc_port"), s.get("device_index"), s.get("command"),
                    s.get("write_arg_mode"), s.get("select_before_write", False), s.get("title")])

    def _osc_pad(self, b):
        b = b + b"\x00"
        pad_len = (4 - (len(b) % 4)) % 4
        return b + (b"\x00" * pad_len)

    def _build_osc_message(self, address, *args):
        msg = self._osc_pad(address.encode("utf-8"))
        type_tag = ","
        encoded_args = b""
        for arg in args:
            if isinstance(arg, int):
                type_tag += "i"
                encoded_args += struct.pack(">i", int(arg))
            elif isinstance(arg, float):
                type_tag += "f"
                encoded_args += struct.pack(">f", float(arg))
            elif isinstance(arg, str):
                type_tag += "s"
                encoded_args += self._osc_pad(arg.encode("utf-8"))
        msg += self._osc_pad(type_tag.encode("utf-8"))
        msg += encoded_args
        return msg

    def _send_udp(self, ip, port, address, *args):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            msg = self._build_osc_message(address, *args)
            sock.sendto(msg, (ip, port))
            sock.close()
            # 로그 도배를 막기 위해 성공 로그는 주석 처리 (원하시면 주석 해제)
            # self._log(f"UDP: {address} {args}")
        except Exception as e:
            self._log(f"UDP ERROR: {e}")

    # 🌟 [수정 2] 대/소문자 모두 쏘는 샷건 발사기
    def _send_udp_dual(self, ip, port, address, *args):
        if address.startswith("/obsbot/"):
            address = address.replace("/obsbot/", "/OBSBOT/", 1)
        self._send_udp(ip, port, address, *args)

    # Send OBSBOT values as OSC int arguments.
    def _send_write_with_mode(self, ip, port, device_index, address, value, arg_mode):
        v_int = self._osc_int(value)
        d_int = self._osc_int(device_index)
        
        if arg_mode == "pair":
            self._send_udp_dual(ip, port, address, d_int, v_int)
        elif arg_mode == "single":
            self._send_udp_dual(ip, port, address, v_int)
        else:
            self._send_udp_dual(ip, port, address, d_int, v_int)
            self._send_udp_dual(ip, port, address, v_int)
            
        # OBSBOT Center commands expect typed values, so avoid no-argument duplicates.

    def _send_write_value_only(self, ip, port, device_index, address, value, arg_mode):
        v_int = self._osc_int(value)
        d_int = self._osc_int(device_index)

        if arg_mode == "pair":
            self._send_udp_dual(ip, port, address, d_int, v_int)
        elif arg_mode == "single":
            self._send_udp_dual(ip, port, address, v_int)
        else:
            self._send_udp_dual(ip, port, address, d_int, v_int)
            self._send_udp_dual(ip, port, address, v_int)

    def _osc_int(self, value):
        try:
            return int(round(float(value)))
        except Exception:
            return 0

    def _send_select_device(self, ip, port, device_index):
        self._send_udp_dual(ip, port, "/obsbot/WebCam/General/SelectDevice", self._osc_int(device_index))

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        p = os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")
        if os.path.exists(p):
            return p
        p = os.path.join(self.plugin_dir, "icon", "pluginIcon.png")
        return p if os.path.exists(p) else None

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if context and icon_path:
            await self.runner.send_message({"event": "setIcon", "context": context, "payload": {"icon_path": icon_path}})

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False
        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()
            await self.runner.send_message({"event": "setSettings", "context": context, "payload": defaults})
            await self._send_builtin_icon(context, defaults["command"])
            return False
        self.context_settings[context] = self._merge_with_defaults(incoming_settings)
        return True

    def _get_device_index(self, settings):
        try:
            return int(str(settings.get("device_index", "0")).strip())
        except Exception:
            return 0

    def _get_osc_ip(self, settings):
        return (settings.get("osc_ip") or "127.0.0.1").strip() or "127.0.0.1"

    def _get_osc_port(self, settings):
        try:
            return int(str(settings.get("osc_port", "16284")).strip())
        except Exception:
            return 16284

    def _get_write_arg_mode(self, settings):
        return (settings.get("write_arg_mode") or "single").strip().lower()

    def _get_select_before_write(self, settings):
        return bool(settings.get("select_before_write", True))

    def _find_analog_ptz_settings(self):
        preferred_contexts = [
            "joystick_analog",
            "joystick_up",
            "joystick_down",
            "joystick_left",
            "joystick_right",
            "joystick_press",
        ]
        for context in preferred_contexts:
            settings = self.context_settings.get(context)
            if settings and settings.get("command") == "analog_ptz":
                return self._merge_with_defaults(settings)

        for settings in self.context_settings.values():
            if settings and settings.get("command") == "analog_ptz":
                return self._merge_with_defaults(settings)

        return None

    def _axis_to_speed(self, value, deadzone=18):
        try:
            value = int(value)
        except Exception:
            return 0.0
        if abs(value) <= deadzone:
            return 0.0
        return round(min(100.0, abs(value) * 100.0 / 127.0), 1)

    async def _send_ptz_speeds(self, settings, up, down, left, right):
        device_index = self._get_device_index(settings)
        osc_ip = self._get_osc_ip(settings)
        osc_port = self._get_osc_port(settings)
        arg_mode = "single"
        select_before = self._get_select_before_write(settings)

        if select_before:
            self._send_select_device(osc_ip, osc_port, device_index)
            await asyncio.sleep(0.02)

        speeds = {
            "/obsbot/WebCam/General/SetGimbalUp": up,
            "/obsbot/WebCam/General/SetGimbalDown": down,
            "/obsbot/WebCam/General/SetGimbalLeft": left,
            "/obsbot/WebCam/General/SetGimbalRight": right,
        }
        active = {address for address, speed in speeds.items() if speed > 0}

        for address in self.active_ptz_addresses - active:
            self._send_write_value_only(osc_ip, osc_port, device_index, address, 0, arg_mode)

        for address, speed in speeds.items():
            if speed > 0:
                self._send_write_value_only(osc_ip, osc_port, device_index, address, speed, arg_mode)

        self.active_ptz_addresses = active

    async def _ptz_watchdog(self, settings):
        while True:
            await asyncio.sleep(0.1) 
            
            if time.time() - self.last_ptz_time > 0.3:
                await self._send_ptz_speeds(settings, 0.0, 0.0, 0.0, 0.0)
                
                self._log("PTZ Stopped (Watchdog Triggered)")
                self.current_ptz_direction = None
                self.current_axis_tuple = None
                self.ptz_timeout_task = None
                break

    async def handle_message(self, data):
        try:
            event = data.get("event")
            payload = data.get("payload", {}) or {}
            context = data.get("context") or payload.get("context")
            payload_settings = payload.get("settings")
            settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}
            control_command = data.get("command") or payload.get("command")
            
            if event in["willAppear", "keyDidAppear"]:
                await self._initialize_default_visuals_if_new(context, settings)
                return
            if event == "didReceiveSettings":
                if context:
                    cached = self.context_settings.get(context, {})
                    self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
                return
            if event in ["keyDidDisappear", "willDisappear"]:
                if context in self.context_settings:
                    self.context_settings.pop(context, None)
                return
            if control_command == "apply_builtin_icon":
                cached = self.context_settings.get(context, {})
                action_name = data.get("action_command") or payload.get("action_command") or settings.get("command") or cached.get("command") or self._default_action()
                await self._send_builtin_icon(context, action_name)
                return

            if event == "axisMoved":
                await self.on_axis_moved(payload, settings)
                return
                
            if event == "keyDown":
                await self.on_key_down(context, settings)

        except Exception as e:
            self._log(f"CRASH in handle_message:\n{traceback.format_exc()}")

    async def on_axis_moved(self, payload, incoming_settings):
        try:
            settings = None
            if incoming_settings and incoming_settings.get("command") == "analog_ptz":
                settings = self._merge_with_defaults(incoming_settings)
            if not settings:
                settings = self._find_analog_ptz_settings()

            if not settings:
                if not self._axis_missing_settings_logged:
                    self._log("axisMoved ignored: assign OBSBOT Analog PTZ to a joystick control first.")
                    self._axis_missing_settings_logged = True
                return

            x = int(payload.get("x", 0))
            y = int(payload.get("y", 0))
            up = self._axis_to_speed(-y) if y < 0 else 0.0
            down = self._axis_to_speed(y) if y > 0 else 0.0
            left = self._axis_to_speed(-x) if x < 0 else 0.0
            right = self._axis_to_speed(x) if x > 0 else 0.0
            axis_tuple = (up, down, left, right)
            now = time.time()

            if axis_tuple == self.current_axis_tuple and (now - self.last_axis_send_time) < 0.05:
                return

            self.current_axis_tuple = axis_tuple
            self.current_ptz_direction = axis_tuple
            self.last_axis_send_time = now
            self.last_ptz_time = now

            await self._send_ptz_speeds(settings, up, down, left, right)

            if any(axis_tuple):
                self._log(f"PTZ Axis x={x} y={y} -> up={up} down={down} left={left} right={right}")

            if not self.ptz_timeout_task:
                self.ptz_timeout_task = asyncio.create_task(self._ptz_watchdog(settings))

        except Exception:
            self._log(f"CRASH in on_axis_moved:\n{traceback.format_exc()}")

    async def on_key_down(self, context, incoming_settings):
        try:
            cached = self.context_settings.get(context, {})
            settings = self._merge_with_defaults({**cached, **(incoming_settings or {})})
            if context:
                self.context_settings[context] = settings
                
            command = settings.get("command")
            
            device_index = self._get_device_index(settings)
            osc_ip = self._get_osc_ip(settings)
            osc_port = self._get_osc_port(settings)
            select_before = self._get_select_before_write(settings)

            # 🎮 조이스틱 아날로그 PTZ 처리
            if command == "analog_ptz":
                if time.time() - self.last_axis_send_time < 0.15:
                    return

                if not context or not context.startswith("joystick_"):
                    self._log("analog_ptz mapped to non-joystick key. Ignoring.")
                    return

                direction = context.replace("joystick_", "") 
                speed = 50.0 # 🌟 속도도 Float으로!
                
                speeds = {
                    "up": (speed, 0.0, 0.0, 0.0),
                    "down": (0.0, speed, 0.0, 0.0),
                    "left": (0.0, 0.0, speed, 0.0),
                    "right": (0.0, 0.0, 0.0, speed),
                }
                
                if direction in speeds:
                    self.last_ptz_time = time.time() 
                    
                    if self.current_ptz_direction != direction:
                        self.current_ptz_direction = direction
                        await self._send_ptz_speeds(settings, *speeds[direction])
                        self._log(f"PTZ Moving {direction}...")

                    if not self.ptz_timeout_task:
                        self.ptz_timeout_task = asyncio.create_task(self._ptz_watchdog(settings))
                        
                return 

            # 🔘 일반 버튼 처리
            spec = self.command_specs.get(command)
            if not spec:
                self._log(f"Unknown command: {command}")
                return
                
            address, value = spec
            self._log(f"EXEC: {command} address={address} value={self._osc_int(value)} mode=single")
            
            if select_before:
                self._send_select_device(osc_ip, osc_port, device_index)
                await asyncio.sleep(0.05)
                
            self._send_write_value_only(osc_ip, osc_port, device_index, address, value, "single")
            
        except Exception as e:
            self._log(f"CRASH in on_key_down:\n{traceback.format_exc()}")
