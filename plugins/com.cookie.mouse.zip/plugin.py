import asyncio
import json
import os
import sys
import time
from pathlib import Path

try:
    from pynput.mouse import Button, Controller
    pynput_available = True
except ImportError:
    Button = None
    Controller = None
    pynput_available = False

try:
    import pyautogui
    pyautogui.PAUSE = 0
    pyautogui.MINIMUM_DURATION = 0
    pyautogui.MINIMUM_SLEEP = 0
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")
ANALOG_MOUSE = "analog_mouse"
ANALOG_MODE_SETTING = "joy_analog_enable"
PREVIOUS_MODE_SETTING = "mouse_control_previous_analog_mode"
ANALOG_MODE_COMMAND = 0x6E


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.mouse = Controller() if pynput_available else None
        self.is_dragging = False
        self.NORMAL_STEP = 10
        self.SLOW_STEP = 1
        self.SCROLL_STEP = 1
        self.context_settings = {}
        self.analog_context = None
        self.previous_analog_mode = None
        self.analog_mode_lock = asyncio.Lock()

        # 소수점 픽셀 누적용 변수. 아날로그 마우스를 부드럽게 움직이기 위해 사용합니다.
        self.analog_remainder_x = 0.0
        self.analog_remainder_y = 0.0

        self.action_map = {
            "click_left": self.click_left,
            "click_right": self.click_right,
            "click_middle": self.click_middle,
            "click_back": self.click_back,
            "click_forward": self.click_forward,
            "double_click": self.double_click,
            "toggle_drag": self.handle_drag_toggle,
            "scroll_up": lambda: self.scroll(0, self.SCROLL_STEP),
            "scroll_down": lambda: self.scroll(0, -self.SCROLL_STEP),
            "scroll_left": lambda: self.scroll(-self.SCROLL_STEP, 0),
            "scroll_right": lambda: self.scroll(self.SCROLL_STEP, 0),
            "move_up": lambda: self.move(0, -self.NORMAL_STEP),
            "move_down": lambda: self.move(0, self.NORMAL_STEP),
            "move_left": lambda: self.move(-self.NORMAL_STEP, 0),
            "move_right": lambda: self.move(self.NORMAL_STEP, 0),
            "move_up_slow": lambda: self.move(0, -self.SLOW_STEP),
            "move_down_slow": lambda: self.move(0, self.SLOW_STEP),
            "move_left_slow": lambda: self.move(-self.SLOW_STEP, 0),
            "move_right_slow": lambda: self.move(self.SLOW_STEP, 0),
        }

        self.icon_map = {
            ANALOG_MOUSE: "move up",
            "click_left": "left click",
            "click_right": "right click",
            "double_click": "double click",
            "toggle_drag": "drag toggle",
            "click_middle": "middle click",
            "click_back": "back",
            "click_forward": "forward",
            "scroll_up": "scroll up",
            "scroll_down": "scroll down",
            "scroll_left": "scroll left",
            "scroll_right": "scroll right",
            "move_up": "move up",
            "move_down": "move down",
            "move_left": "move left",
            "move_right": "move right",
            "move_up_slow": "fine move up",
            "move_down_slow": "fine move down",
            "move_left_slow": "fine move left",
            "move_right_slow": "fine move right",
        }

    def _default_action(self):
        return "click_left"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "scroll_amount": self.SCROLL_STEP,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or self._default_action()
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    def _pynput_button(self, name):
        if not pynput_available:
            return None
        return getattr(Button, name, None)

    def move(self, dx, dy):
        if self.mouse:
            self.mouse.move(dx, dy)
        elif pyautogui_available:
            pyautogui.moveRel(dx, dy)

    def scroll(self, dx, dy):
        dx = int(dx)
        dy = int(dy)
        steps = max(abs(dx), abs(dy))
        if steps <= 0:
            return

        unit_x = 0 if dx == 0 else (1 if dx > 0 else -1)
        unit_y = 0 if dy == 0 else (1 if dy > 0 else -1)

        # Some applications clamp one large wheel delta to a single scroll.
        # Emit one wheel notch per configured step so 1 and 100 always have
        # observably different strengths across browsers and desktop apps.
        for _ in range(steps):
            if self.mouse:
                self.mouse.scroll(unit_x, unit_y)
            elif pyautogui_available:
                # pyautogui는 세로 스크롤만 안정적입니다. horizontal scroll은 환경별 차이가 큽니다.
                if unit_y:
                    pyautogui.scroll(unit_y)
                elif unit_x:
                    pyautogui.hscroll(unit_x)
            else:
                return

            if steps > 1:
                time.sleep(0.002)

    def _scroll_amount(self, settings):
        try:
            amount = int(settings.get("scroll_amount", self.SCROLL_STEP))
        except (TypeError, ValueError):
            amount = self.SCROLL_STEP
        return max(1, min(100, amount))

    def click_button(self, button_name, count=1):
        button = self._pynput_button(button_name)
        if self.mouse and button:
            self.mouse.click(button, count)
            return

        if not pyautogui_available:
            return

        if button_name == "left":
            pyautogui.click(clicks=count, button="left")
        elif button_name == "right":
            pyautogui.click(clicks=count, button="right")
        elif button_name == "middle":
            pyautogui.click(clicks=count, button="middle")
        elif button_name == "x1":
            # macOS에서는 백/앞 버튼이 마우스 드라이버별로 달라서 표준 처리 보장이 어렵습니다.
            pyautogui.hotkey("command", "[") if IS_MACOS else pyautogui.hotkey("alt", "left")
        elif button_name == "x2":
            pyautogui.hotkey("command", "]") if IS_MACOS else pyautogui.hotkey("alt", "right")

    def click_left(self):
        self.click_button("left", 1)

    def click_right(self):
        self.click_button("right", 1)

    def click_middle(self):
        self.click_button("middle", 1)

    def click_back(self):
        self.click_button("x1", 1)

    def click_forward(self):
        self.click_button("x2", 1)

    def double_click(self):
        self.click_button("left", 2)

    def _saved_global_settings(self):
        base_path = Path(os.environ.get("ACTIONBOX_BASE_PATH") or Path(self.plugin_dir).parents[1])
        try:
            settings = json.loads((base_path / "keymap.json").read_text(encoding="utf-8-sig"))
        except (OSError, ValueError):
            return {}
        global_settings = settings.get("global_settings") if isinstance(settings, dict) else None
        return global_settings if isinstance(global_settings, dict) else {}

    async def _save_analog_mode(self, enabled, previous_mode):
        # The host reuses this setting whenever it resynchronizes the device.
        await self.runner.send_message({
            "event": "setGlobalSettings",
            "payload": {ANALOG_MODE_SETTING: enabled, PREVIOUS_MODE_SETTING: previous_mode},
        })

    async def _send_analog_mode(self, context, enabled):
        if context:
            await self.runner.send_message({
                "event": "sendToPlugin",
                "context": context,
                "payload": {
                    "command": "direct_serial",
                    "serial_cmd": ANALOG_MODE_COMMAND,
                    "serial_data": [int(enabled)],
                },
            })

    async def startup(self):
        async with self.analog_mode_lock:
            saved_mode = self._saved_global_settings().get(PREVIOUS_MODE_SETTING)
            if self.analog_context is None and isinstance(saved_mode, bool):
                await self._save_analog_mode(saved_mode, None)

    async def shutdown(self):
        async with self.analog_mode_lock:
            await self._restore_analog_mode(self.analog_context)

    async def _restore_analog_mode(self, context):
        previous_mode = self.previous_analog_mode
        if previous_mode is None:
            return
        self.analog_context = None
        self.previous_analog_mode = None
        self.analog_remainder_x = 0.0
        self.analog_remainder_y = 0.0
        await self._save_analog_mode(previous_mode, None)
        await self._send_analog_mode(context, previous_mode)

    async def _sync_analog_mode(self, changed_context, *, reapply=False):
        async with self.analog_mode_lock:
            context = next((key for key, settings in self.context_settings.items()
                            if settings.get("command") == ANALOG_MOUSE), None)
            if context is None:
                # A removed binding may no longer be accepted by the host.
                # Prefer another live Mouse Control binding for the serial command.
                await self._restore_analog_mode(next(iter(self.context_settings), changed_context))
                return

            if self.analog_context is None:
                saved = self._saved_global_settings()
                previous_mode = saved.get(PREVIOUS_MODE_SETTING)
                if not isinstance(previous_mode, bool):
                    previous_mode = bool(saved.get(ANALOG_MODE_SETTING, False))
                self.previous_analog_mode = previous_mode
                await self._save_analog_mode(True, previous_mode)

            if context != self.analog_context or (reapply and context == changed_context):
                self.analog_context = context
                await self._send_analog_mode(context, True)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event == "axisMoved":
            if self.analog_context is not None:
                await self.on_axis_moved(data)
            return

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            await self._sync_analog_mode(context, reapply=True)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
                await self._sync_analog_mode(context)
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
                await self._sync_analog_mode(context)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            await self._send_builtin_icon(context, action_command or settings.get("command") or cached.get("command") or self._default_action())
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        final_settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = final_settings

        selected_action = final_settings.get("command") or self._default_action()

        scroll_vectors = {
            "scroll_up": (0, 1),
            "scroll_down": (0, -1),
            "scroll_left": (-1, 0),
            "scroll_right": (1, 0),
        }
        if selected_action in scroll_vectors:
            amount = self._scroll_amount(final_settings)
            dx, dy = scroll_vectors[selected_action]
            await asyncio.to_thread(self.scroll, dx * amount, dy * amount)
            return

        action_func = self.action_map.get(selected_action)

        if action_func:
            await asyncio.to_thread(action_func)

    async def on_axis_moved(self, data):
        payload = data.get("payload", {})
        x_val = payload.get("x", 0)
        y_val = payload.get("y", 0)

        if x_val == 0 and y_val == 0:
            self.analog_remainder_x = 0.0
            self.analog_remainder_y = 0.0
            return

        def calc_speed(val):
            if val == 0:
                return 0.0
            sign = 1 if val > 0 else -1
            norm = abs(val) / 127.0
            return sign * (norm ** 2) * 35.0

        dx_float = calc_speed(x_val) + self.analog_remainder_x
        dy_float = calc_speed(y_val) + self.analog_remainder_y

        dx_int = int(dx_float)
        dy_int = int(dy_float)

        self.analog_remainder_x = dx_float - dx_int
        self.analog_remainder_y = dy_float - dy_int

        if dx_int != 0 or dy_int != 0:
            self.move(dx_int, dy_int)

    def handle_drag_toggle(self):
        left_button = self._pynput_button("left")

        if self.is_dragging:
            if self.mouse and left_button:
                self.mouse.release(left_button)
            elif pyautogui_available:
                pyautogui.mouseUp(button="left")
            self.is_dragging = False
            print(f"[{self.uuid}] Drag Released")
        else:
            if self.mouse and left_button:
                self.mouse.press(left_button)
            elif pyautogui_available:
                pyautogui.mouseDown(button="left")
            self.is_dragging = True
            print(f"[{self.uuid}] Drag Started")
