import asyncio
import os
import sys

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

try:
    import keyboard
except ImportError:
    keyboard = None

try:
    import pyautogui
except ImportError:
    pyautogui = None


def _normalize_key_token(token):
    token = (token or "").strip().lower()
    aliases = {
        "cmd": "command",
        "command": "command",
        "ctrl": "ctrl",
        "control": "ctrl",
        "alt": "option" if IS_MACOS else "alt",
        "option": "option" if IS_MACOS else "alt",
        "win": "command" if IS_MACOS else "windows",
        "windows": "command" if IS_MACOS else "windows",
        "page up": "pageup",
        "page down": "pagedown",
        "pgup": "pageup",
        "pgdn": "pagedown",
        "esc": "escape",
    }
    return aliases.get(token, token)


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        self.windows_hotkey_map = {
            "play_pause": "space",
            "record": "r",
            "pat_song_toggle": "l",
            "metronome": "m",
            "wait_for_input": "ctrl+i",
            "win_playlist": "f5",
            "win_channel_rack": "f6",
            "win_piano_roll": "f7",
            "win_plugin_picker": "f8",
            "win_mixer": "f9",
            "close_all": "f12",
            "tool_draw": "p",
            "tool_paint": "b",
            "tool_slice": "c",
            "tool_delete": "d",
            "tool_mute": "t",
            "tool_select": "e",
            "undo": "ctrl+alt+z",
            "quantize": "ctrl+q",
            "clone": "ctrl+b",
            "save": "ctrl+s"
        }

        # FL Studio officially treats Ctrl as Cmd and Alt as Option on macOS.
        # Exception note: newer FL Studio macOS builds changed Quick Quantize
        # away from plain Cmd+Q, but the plugin's original action maps to
        # Ctrl+Q, so we use Cmd+Opt+Q to avoid the universal macOS Quit shortcut.
        self.macos_hotkey_map = {
            "play_pause": "space",
            "record": "r",
            "pat_song_toggle": "l",
            "metronome": "m",
            "wait_for_input": "command+i",
            "win_playlist": "f5",
            "win_channel_rack": "f6",
            "win_piano_roll": "f7",
            "win_plugin_picker": "f8",
            "win_mixer": "f9",
            "close_all": "f12",
            "tool_draw": "p",
            "tool_paint": "b",
            "tool_slice": "c",
            "tool_delete": "d",
            "tool_mute": "t",
            "tool_select": "e",
            "undo": "command+option+z",
            "quantize": "command+option+q",
            "clone": "command+b",
            "save": "command+s"
        }

        self.hotkey_map = self.macos_hotkey_map if IS_MACOS else self.windows_hotkey_map

        self.icon_map = {
            "play_pause": "PLAY_PAUSE",
            "record": "RECORD",
            "pat_song_toggle": "PAT_SONG_TOGGLE",
            "metronome": "METRONOME",
            "wait_for_input": "WAIT_FOR_INPUT",
            "win_playlist": "WIN_PLAYLIST",
            "win_channel_rack": "WIN_CHANNEL_RACK",
            "win_piano_roll": "WIN_PIANO_ROLL",
            "win_plugin_picker": "WIN_PLUGIN_PICKER",
            "win_mixer": "WIN_MIXER",
            "close_all": "CLOSE_ALL",
            "tool_draw": "TOOL_DRAW",
            "tool_paint": "TOOL_PAINT",
            "tool_slice": "TOOL_SLICE",
            "tool_delete": "TOOL_DELETE",
            "tool_mute": "TOOL_MUTE",
            "tool_select": "TOOL_SELECT",
            "undo": "UNDO",
            "quantize": "QUANTIZE",
            "clone": "CLONE",
            "save": "SAVE",
            "midi": "MIDI_CC",
        }

    def _default_hotkey(self):
        return "play_pause"

    def _default_settings(self):
        default_action = self._default_hotkey()
        return {
            "control_mode": "hotkey",
            "fl_hotkey": default_action,
            "command": default_action,
            "midi_channel": "1",
            "midi_cc": "10",
            "midi_val": "127",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})

        mode = merged.get("control_mode", "hotkey")
        if mode == "midi":
            merged["command"] = "midi"
            merged["builtin_icon_name"] = self.icon_map["midi"]
        else:
            action = merged.get("command") or merged.get("fl_hotkey") or self._default_hotkey()
            merged["control_mode"] = "hotkey"
            merged["fl_hotkey"] = action
            merged["command"] = action
            merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_hotkey()])

        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("control_mode"),
            s.get("command"),
            s.get("fl_hotkey"),
            s.get("midi_channel"),
            s.get("midi_cc"),
            s.get("midi_val"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_hotkey(), self.icon_map[self._default_hotkey()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")
        action_mode = data.get("action_mode") or payload.get("action_mode")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            if action_mode == "midi":
                action_name = "midi"
            else:
                action_name = action_command or settings.get("command") or settings.get("fl_hotkey") or cached.get("command") or self._default_hotkey()
            await self._send_builtin_icon(context, action_name)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    def _send_hotkey(self, hotkey):
        if not hotkey:
            return

        if IS_WINDOWS and keyboard:
            keyboard.send(hotkey)
            return

        if pyautogui is None:
            print(f"[{self.uuid}] pyautogui is not installed; hotkey skipped: {hotkey}")
            return

        parts = [_normalize_key_token(part) for part in str(hotkey).split("+")]
        parts = [part for part in parts if part]
        if not parts:
            return

        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = settings

        mode = settings.get("control_mode", "hotkey")

        if mode == "hotkey":
            action = settings.get("command") or settings.get("fl_hotkey") or self._default_hotkey()
            if action in self.hotkey_map:
                hotkey = self.hotkey_map[action]
                await asyncio.to_thread(self._send_hotkey, hotkey)

        elif mode == "midi":
            try:
                channel = int(settings.get("midi_channel", 1)) - 1
                cc_num = int(settings.get("midi_cc", 10))
                cc_val = int(settings.get("midi_val", 127))

                status = 0xB0 | channel
                payload = {
                    "event": "sendToPlugin",
                    "context": context,
                    "payload": {
                        "command": "direct_serial",
                        "serial_cmd": 0x70,
                        "serial_data": [status, cc_num, cc_val]
                    }
                }
                await self.runner.send_message(payload)
                print(f"[{self.uuid}] FL Studio MIDI Sent: CC {cc_num}, Val {cc_val}")

            except Exception as e:
                print(f"[{self.uuid}] MIDI send error: {e}")
