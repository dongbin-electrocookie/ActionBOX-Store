import asyncio
import json
import struct
import uuid
import platform
import os

IS_WINDOWS = (platform.system() == "Windows")

class DiscordIPC:
    """Direct local IPC client for Discord."""
    def __init__(self, client_id):
        self.client_id = client_id
        self.pipe = None
        self.connected = False

    def connect(self):
        if not IS_WINDOWS:
            return False
        try:
            self.pipe = open(r'\\.\pipe\discord-ipc-0', 'w+b')
            self.handshake()
            self.connected = True
            return True
        except Exception as e:
            print(f"[Discord Pro] IPC connection failed (is Discord running?): {e}")
            self.connected = False
            return False

    def send(self, op, payload):
        if not self.pipe:
            return
        payload_json = json.dumps(payload).encode('utf-8')
        header = struct.pack('<II', op, len(payload_json))
        try:
            self.pipe.write(header + payload_json)
            self.pipe.flush()
        except Exception:
            self.connected = False

    def recv(self):
        if not self.pipe:
            return None, None
        try:
            header = self.pipe.read(8)
            if not header:
                return None, None
            op, length = struct.unpack('<II', header)
            payload = self.pipe.read(length)
            return op, json.loads(payload.decode('utf-8'))
        except Exception:
            self.connected = False
            return None, None

    def handshake(self):
        self.send(0, {'v': 1, 'client_id': self.client_id})
        self.recv()


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.ipc = None
        self.current_client_id = ""
        self.context_settings = {}

        self.icon_map = {
            "mute_on": "STATE_MUTE_ON",
            "mute_off": "STATE_MUTE_OFF",
            "deafen_on": "STATE_DEAFEN_ON",
            "deafen_off": "STATE_DEAFEN_OFF",
        }

    def _default_action(self):
        return "mute_on"

    def _default_settings(self):
        action = self._default_action()
        return {
            "client_id": "",
            "command": action,
            "discord_action": action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or merged.get("discord_action") or self._default_action()
        merged["command"] = action
        merged["discord_action"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("client_id"),
            s.get("command"),
            s.get("discord_action"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            current_action = action_command or settings.get("command") or settings.get("discord_action") or cached.get("command") or self._default_action()
            await self._send_builtin_icon(context, current_action)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = settings

        client_id = settings.get("client_id", "").strip()
        action = settings.get("command") or settings.get("discord_action") or self._default_action()

        if not client_id:
            print(f"[{self.uuid}] Client ID is not set.")
            return

        if not self.ipc or not self.ipc.connected or self.current_client_id != client_id:
            self.ipc = DiscordIPC(client_id)
            success = await asyncio.to_thread(self.ipc.connect)
            if success:
                self.current_client_id = client_id
            else:
                return

        is_mute = (action == "mute_on")
        is_deafen = (action == "deafen_on")

        args = {}
        if "mute" in action:
            args["mute"] = is_mute
        if "deafen" in action:
            args["deafen"] = is_deafen

        payload = {
            "cmd": "SET_VOICE_SETTINGS",
            "args": args,
            "nonce": str(uuid.uuid4())
        }

        await asyncio.to_thread(self.ipc.send, 1, payload)
        print(f"[{self.uuid}] Discord IPC command sent: {action}")
