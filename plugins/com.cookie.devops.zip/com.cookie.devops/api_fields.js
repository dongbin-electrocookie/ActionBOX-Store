/* Shared by the API inspectors. This never sends network requests or actions. */
(() => {
    const fields = () => [...document.querySelectorAll('[data-devops-setting]')];
    window.ComboXDevOpsFields = {
        restore(settings) {
            for (const field of fields()) {
                field.value = settings[field.id] ?? field.dataset.devopsDefault ?? '';
            }
        },
        save(settings) {
            for (const field of fields()) settings[field.id] = field.value;
        },
        update(type) {
            for (const node of document.querySelectorAll('[data-devops-legacy]')) {
                const input = node.querySelector('input');
                node.style.display = type === 'redeploy' && input?.value ? 'block' : 'none';
            }
            const urls = document.getElementById('purge_urls_row');
            if (urls) urls.style.display = document.getElementById('purge_scope').value === 'all' ? 'none' : 'block';
        }
    };
})();
