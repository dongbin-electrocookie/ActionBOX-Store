"""Shared, literal keyboard engine and binding resolver. No input on import.

Application defaults live in each manifest, separately for Windows/macOS.
Custom chords never undergo Control -> Command or application preset mapping.
Only explicitly opted-in shortcut actions use this engine; APIs are untouched.
"""
import asyncio
import contextlib
import json
from pathlib import Path
import sys
import threading
import time

API_VERSION = 1
FIELD = 'shared_shortcut'
_input_lock = threading.RLock()
_record_lock = threading.Lock()

ALIASES = {'control':'ctrl', 'cmd':'command', 'meta':'command', 'windows':'win',
           'option':'alt', 'return':'enter', 'escape':'esc', 'page up':'pageup',
           'page down':'pagedown', 'page_up':'pageup', 'page_down':'pagedown',
           'numpadenter':'numenter', 'numpaddecimal':'decimal', 'numpadplus':'add',
           'numpadminus':'subtract'}
MODIFIERS = {'ctrl','shift','alt','win','command'}


def tokens(value):
    raw = value if isinstance(value, (list, tuple)) else str(value or '').split('+')
    result = []
    for part in raw:
        part = str(part).strip().lower()
        side, space, base = part.partition(' ')
        if space and side in ('left','right'):
            part = side + ' ' + ALIASES.get(base, base)
        else:
            part = ALIASES.get(part, part)
        if part.startswith('numpad') and part[6:].isdigit():
            part = 'num' + part[6:]
        if part and part not in result:
            result.append(part)
    return result


def platform_name(platform=None):
    platform = platform or sys.platform
    return 'windows' if platform.startswith('win') else 'darwin' if platform == 'darwin' else 'linux'


def action_config(manifest, action_id):
    action_id = str(action_id or '').split('#', 1)[0]
    return next((a.get('SharedShortcut') for a in manifest.get('Actions', [])
                 if a.get('UUID') == action_id), None)


def selection(config, settings):
    for key in config.get('SelectionKeys', ['command']):
        value = settings.get(key)
        if value not in (None, ''):
            return str(value)
    return str(config.get('Default', ''))


def scope(config, settings):
    value = selection(config, settings)
    value = config.get('Aliases', {}).get(value, value)
    return json.dumps([value, settings.get('control_mode') or 'hotkey',
                       settings.get('execution_environment') or 'desktop'], ensure_ascii=False, separators=(',', ':'))


def applicable(config, settings):
    return bool(config) and (not config.get('HotkeyModeOnly')
                            or settings.get('control_mode', 'hotkey') == 'hotkey')


def resolve(manifest, action_id, settings, platform=None):
    config = action_config(manifest, action_id)
    if not applicable(config, settings):
        return None  # Not a keyboard action; retain API/MIDI/OSC behavior.
    os_name = platform_name(platform)
    if os_name not in config.get('Defaults', {}):
        return None
    # Some old Unity buttons stored only key_val. Let the original, explicit
    # legacy resolver handle those rather than defaulting them to Play.
    legacy_key = config.get('LegacyPassthroughField')
    if legacy_key and settings.get(legacy_key) and not any(
            settings.get(key) not in (None, '') for key in config.get('SelectionKeys', [])):
        return None
    selected = selection(config, settings)
    selected = config.get('Aliases', {}).get(selected, selected)
    entry = settings.get(FIELD, {})
    if isinstance(entry, dict) and entry.get('version') == API_VERSION and entry.get('scope') == scope(config, settings):
        override = entry.get('platforms', {}).get(os_name)
        if isinstance(override, dict) and override.get('enabled'):
            steps = override.get('steps')
            if not isinstance(steps, list) or not 1 <= len(steps) <= 32:
                raise ValueError('Invalid custom shortcut sequence')
            return {'steps': [tokens(step) for step in steps], 'custom': True, 'config': config}
    # Preserve pre-shared-editor user settings; never rewrite them on load.
    legacy = config.get('LegacyCustomField')
    if legacy and settings.get(legacy):
        return {'steps': [tokens(settings[legacy])], 'custom': True, 'config': config}
    defaults = config.get('Defaults', {}).get(os_name, {})
    if config.get('EnvironmentProfiles'):
        defaults = defaults.get(settings.get('execution_environment', 'desktop'), {})
    steps = defaults.get(selected)
    if selected not in defaults and config.get('LiteralSelection'):
        steps = [tokens(selected)]
    if config.get('EditLastSequence') and selected == 'edit_last':
        steps = [['up'], ['e']] if settings.get('edit_last_mode', 'up_then_e') == 'up_then_e' else [['up']]
    return {'steps': steps, 'custom': False, 'config': config}


WIN_MODIFIERS = {'ctrl':0x11, 'shift':0x10, 'alt':0x12, 'win':0x5B, 'command':0x5B,
    'left ctrl':0xA2, 'right ctrl':0xA3, 'left shift':0xA0, 'right shift':0xA1,
    'left alt':0xA4, 'right alt':0xA5, 'left win':0x5B, 'right win':0x5C,
    'left command':0x5B, 'right command':0x5C}
WIN_KEYS = {'enter':0x0D,'numenter':0x0D,'tab':0x09,'space':0x20,'esc':0x1B,
    'backspace':0x08,'delete':0x2E,'forwarddelete':0x2E,'insert':0x2D,'home':0x24,'end':0x23,
    'pageup':0x21,'pagedown':0x22,'left':0x25,'up':0x26,'right':0x27,'down':0x28,
    'capslock':0x14,'numlock':0x90,'scrolllock':0x91,'pause':0x13,'printscreen':0x2C,
    'add':0x6B,'subtract':0x6D,'decimal':0x6E,'multiply':0x6A,'divide':0x6F,
    ';':0xBA,'=':0xBB,',':0xBC,'-':0xBD,'.':0xBE,'/':0xBF,'`':0xC0,
    '[':0xDB,'\\':0xDC,']':0xDD,"'":0xDE}
WIN_KEYS.update({f'num{i}':0x60+i for i in range(10)})
WIN_KEYS.update({f'f{i}':0x6F+i for i in range(1,25)})
WIN_EXTENDED = {0xA3,0xA5,0x5B,0x5C,0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x2D,0x2E,0x6F,0x90,0x2C}


def windows_keys(keys, backend=None, sleep=time.sleep):
    """Validate the whole chord before any input; always release partial input."""
    if backend is None:
        import ctypes as backend
    keys = tokens(keys)
    codes = []
    # Character aliases represent the physical shifted key, not keypad keys.
    shifted = {'>':'.', '<':',', '+':'=', '*':'8'}
    expanded = []
    for key in keys:
        if key in shifted:
            if 'shift' not in expanded: expanded.append('shift')
            key = shifted[key]
        expanded.append(key)
    keys = tokens(expanded)
    if not keys: return False
    for key in keys:
        vk = WIN_MODIFIERS.get(key, WIN_KEYS.get(key))
        if vk is None and len(key) == 1 and key.isascii() and key.isalnum(): vk = ord(key.upper())
        if vk is None: return False
        codes.append(vk)
    user32 = backend.windll.user32
    scans = [user32.MapVirtualKeyW(vk, 0) for vk in codes]
    if any(not scan for scan in scans): raise RuntimeError('Missing physical key scan code')
    def emit(i, up):
        vk = codes[i]
        event_vk = {0xA0:0x10,0xA1:0x10,0xA2:0x11,0xA3:0x11,0xA4:0x12,0xA5:0x12}.get(vk,vk)
        flags = (1 if vk in WIN_EXTENDED or keys[i] == 'numenter' else 0) | (2 if up else 0)
        user32.keybd_event(event_vk, scans[i], flags, 0)
    with _input_lock:
        pressed = []
        try:
            for i in range(len(keys)):
                pressed.append(i); emit(i, False); sleep(0.04)
            sleep(0.04)
        finally:
            first_error = None
            for i in reversed(pressed):
                try: emit(i, True)
                except Exception as error: first_error = first_error or error
                sleep(0.02)
            if first_error: raise first_error
    return True


MAC_KEYS = dict(zip('asdfhgzxcvbqweryt123465=97-80]ou[ip l j\'k;\\,/nm.`'.replace(' ', ''),
    [0,1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,37,38,39,40,41,42,43,44,45,46,47,50]))
MAC_KEYS.update({'enter':36,'numenter':76,'tab':48,'space':49,'backspace':51,'esc':53,
    'forwarddelete':117,'delete':117,'left':123,'right':124,'down':125,'up':126,'home':115,'end':119,
    'pageup':116,'pagedown':121,'decimal':65,'multiply':67,'add':69,'divide':75,'subtract':78,
    'clear':71,'insert':114,
    'numequal':81,'num0':82,'num1':83,'num2':84,'num3':85,'num4':86,'num5':87,'num6':88,
    'num7':89,'num8':91,'num9':92})
MAC_KEYS.update(dict(zip([f'f{i}' for i in range(1,21)],
    [122,120,99,118,96,97,98,100,101,109,103,111,105,107,113,106,64,79,80,90])))


def mac_keys(keys, quartz=None, sleep=time.sleep, hold=0.04, release_delay=0):
    if quartz is None: import Quartz as quartz
    keys = tokens(keys)
    modifier_codes = {'ctrl':59,'shift':56,'alt':58,'command':55,'win':55,
        'left ctrl':59,'right ctrl':62,'left shift':56,'right shift':60,'left alt':58,'right alt':61,
        'left command':55,'right command':54,'left win':55,'right win':54}
    flags_by_base = {'ctrl':quartz.kCGEventFlagMaskControl,'shift':quartz.kCGEventFlagMaskShift,
        'alt':quartz.kCGEventFlagMaskAlternate,'command':quartz.kCGEventFlagMaskCommand,
        'win':quartz.kCGEventFlagMaskCommand}
    shifted={'>':'.','<':',','+':'=','*':'8','!':'1','@':'2','#':'3','$':'4','%':'5','^':'6','&':'7','(':'9',')':'0','_':'-','?':'/','~':'`',':':';','"':"'",'{':'[','}':']','|':'\\'}
    keys = tokens([part for key in keys for part in (['shift',shifted[key]] if key in shifted else [key])])
    if not keys or any(key not in modifier_codes and key not in MAC_KEYS for key in keys): return False
    source = quartz.CGEventSourceCreate(quartz.kCGEventSourceStatePrivate)
    if source is None: return False
    base_flags = quartz.kCGEventFlagMaskNonCoalesced
    modifiers = [key for key in keys if key in modifier_codes]
    normal = [key for key in keys if key not in modifier_codes]
    def flags(held, key=None):
        value = base_flags
        for mod in held: value |= flags_by_base[mod.removeprefix('left ').removeprefix('right ')]
        if key and (key.startswith('num') or key in ('decimal','add','subtract','multiply','divide','left','right','up','down','home','end','pageup','pagedown','forwarddelete')):
            value |= getattr(quartz, 'kCGEventFlagMaskNumericPad', 0)
        return value
    def event(key, up, held):
        ev = quartz.CGEventCreateKeyboardEvent(source, modifier_codes.get(key, MAC_KEYS.get(key)), not up)
        if ev is None: raise RuntimeError('Could not create macOS key event')
        quartz.CGEventSetFlags(ev, flags(held, key))
        quartz.CGEventPost(quartz.kCGSessionEventTap, ev)
    with _input_lock:
        pressed = []
        try:
            for key in modifiers + normal:
                pressed.append(key); event(key, False, modifiers); sleep(0.01)
            sleep(hold)
        finally:
            first_error = None
            for key in reversed(pressed):
                pressed.remove(key)
                try: event(key, True, [k for k in pressed if k in modifier_codes])
                except Exception as error: first_error = first_error or error
                sleep(0.01)
                if key in normal and release_delay: sleep(release_delay)
            if first_error: raise first_error
    return True


def execute(steps, platform=None, step_delay=0.06):
    """Steps are arrays of physical key tokens. Commas/+ keys are unambiguous."""
    if not isinstance(steps, list) or not steps: return False
    if len(steps) > 32: raise ValueError('Too many shortcut steps')
    chords = [tokens(step) for step in steps]
    os_name = platform_name(platform)
    # Preflight every step, so an invalid tail cannot leave a partial macro.
    allowed = set(WIN_KEYS) | set(WIN_MODIFIERS) if os_name == 'windows' else set(MAC_KEYS) | MODIFIERS | {side+' '+mod for side in ('left','right') for mod in MODIFIERS}
    allowed |= set('abcdefghijklmnopqrstuvwxyz0123456789') | {'<','>','+','*'}
    if any(not chord or any(key not in allowed for key in chord) for chord in chords):
        raise ValueError('Unsupported shortcut key')
    with _input_lock:
        for chord in chords:
            if os_name == 'windows': ok = windows_keys(chord)
            elif os_name == 'darwin': ok = mac_keys(chord)
            else:
                import pyautogui
                pyautogui.hotkey(*chord, interval=0.04); ok = True
            if not ok: raise RuntimeError('Shortcut input unavailable')
            if len(chords) > 1: time.sleep(float(step_delay))
    return True


def record_windows(distinguish_sides=False, timeout=10.0, clock=time):
    """Suppressed, explicit recording; keypad identity survives Num Lock."""
    from pynput import keyboard
    if not _record_lock.acquire(blocking=False): raise RuntimeError('recorder-busy')
    active, captured, physical = set(), [], {}
    released = [None]
    keypad = {0x52:'num0',0x4F:'num1',0x50:'num2',0x51:'num3',0x4B:'num4',
              0x4C:'num5',0x4D:'num6',0x47:'num7',0x48:'num8',0x49:'num9',0x53:'decimal'}
    def filter_event(message, data):
        vk, scan, extended = int(data.vkCode), int(data.scanCode), bool(data.flags & 1)
        if data.flags & 0x10 or vk in (0x11,0xA2) and scan & 0x200:
            return False  # Injected input / AltGr's artificial Control.
        value = None
        if scan in keypad and not extended: value = keypad[scan]
        elif vk == 0x0D and extended: value = 'numenter'
        elif vk in (0x10,0x11,0x12,0xA0,0xA1,0xA2,0xA3,0xA4,0xA5,0x5B,0x5C):
            base={0x10:'shift',0x11:'ctrl',0x12:'alt',0xA0:'shift',0xA1:'shift',0xA2:'ctrl',0xA3:'ctrl',0xA4:'alt',0xA5:'alt',0x5B:'win',0x5C:'win'}[vk]
            right=vk in (0xA1,0xA3,0xA5,0x5C) or vk==0x10 and scan==0x36 or vk in (0x11,0x12) and extended
            value=(('right ' if right else 'left ') if distinguish_sides else '')+base
            physical[{'shift':0xA0,'ctrl':0xA2,'alt':0xA4,'win':0x5B}[base]+int(right)]=value
        else:
            value=next((k for k,v in WIN_KEYS.items() if v==vk and k not in ('numenter','forwarddelete')),None)
            if value is None and (0x30<=vk<=0x39 or 0x41<=vk<=0x5A): value=chr(vk).lower()
        if value: physical[vk]=value
        return True
    def name(key):
        vk=getattr(key,'vk',None) or getattr(getattr(key,'value',None),'vk',None)
        known={getattr(keyboard.Key,k,None):v for k,v in {
            'ctrl_l':'left ctrl','ctrl_r':'right ctrl','shift_l':'left shift','shift_r':'right shift',
            'alt_l':'left alt','alt_r':'right alt','cmd_l':'left win','cmd_r':'right win',
            'ctrl':'ctrl','shift':'shift','alt':'alt','cmd':'win'}.items()}
        value=physical.get(vk) or known.get(key) or (chr(vk).lower() if vk is not None and (0x30<=vk<=0x39 or 0x41<=vk<=0x5A) else None) or getattr(key,'char',None) or str(key).removeprefix('Key.')
        suffix={'ctrl_l':'left ctrl','ctrl_r':'right ctrl','alt_l':'left alt','alt_r':'right alt',
                'shift_l':'left shift','shift_r':'right shift','cmd_l':'left win','cmd_r':'right win'}
        value=suffix.get(value,value)
        if not distinguish_sides: value=value.removeprefix('left ').removeprefix('right ')
        return tokens([value])[0] if value else ''
    def press(key):
        value=name(key)
        if not value: return
        active.add(value);released[0]=None
        if value not in captured: captured.append(value)
    def release(key):
        active.discard(name(key))
        if captured and not active: released[0]=clock.monotonic()
    try:
        stopped_early = False
        with keyboard.Listener(on_press=press,on_release=release,suppress=True,win32_event_filter=filter_event) as listener:
            deadline=clock.monotonic()+timeout
            while clock.monotonic()<deadline:
                if released[0] is not None and clock.monotonic()-released[0]>=0.12: break
                if not listener.running:
                    stopped_early = True
                    break
                clock.sleep(0.01)
            listener.stop()
        # pynput stores callback errors for join(); stopping the listener alone
        # can turn an immediate backend failure into a misleading "timeout".
        listener.join(timeout=1.0)
        if stopped_early and (active or released[0] is None):
            raise RuntimeError('recorder-stopped')
        if active or released[0] is None: return []
        mods=[k for k in captured if k.removeprefix('left ').removeprefix('right ') in MODIFIERS]
        mods.sort(key=lambda k:{'ctrl':0,'shift':1,'alt':2,'win':3,'command':3}[k.removeprefix('left ').removeprefix('right ')])
        return mods+[k for k in captured if k not in mods]
    finally: _record_lock.release()


@contextlib.contextmanager
def application_focus(plugin, config):
    """Preserve Discord's previous focus/restore behavior for custom AND default."""
    if config.get('Focus') == 'slack':
        plugin._activate_slack_if_possible()
        yield; return
    if config.get('Focus') != 'discord':
        yield; return
    if sys.platform == 'darwin':
        previous = plugin._mac_get_frontmost_app()
        try:
            plugin._mac_activate_discord(); time.sleep(0.18); yield
        finally:
            plugin._mac_restore_app(previous)
    elif sys.platform.startswith('win'):
        import win32gui, win32con
        previous = win32gui.GetForegroundWindow(); found = []
        win32gui.EnumWindows(lambda hwnd, _: found.append(hwnd) if 'Discord' in win32gui.GetWindowText(hwnd) and win32gui.GetClassName(hwnd) == 'Chrome_WidgetWin_1' else None, None)
        try:
            if found:
                win32gui.ShowWindow(found[0], win32con.SW_RESTORE)
                win32gui.SetForegroundWindow(found[0]); time.sleep(0.15)
            yield
        finally:
            if found: win32gui.SetForegroundWindow(previous)
    else: yield


def attach(plugin, manifest):
    """One runner adapter, not copies of override logic in 26 plugins."""
    supported = [a for a in manifest.get('Actions', []) if a.get('SharedShortcut')]
    if not supported or getattr(plugin, '_shared_shortcut_attached', False): return
    original = plugin.handle_message
    cache = {}
    async def handler(data):
        payload = data.get('payload') or {}
        context = data.get('context') or payload.get('context')
        event = data.get('event')
        previous_action, previous_settings = cache.get(context, (None, {}))
        incoming = payload.get('settings') if isinstance(payload.get('settings'), dict) else data.get('settings', {})
        settings = {**previous_settings, **(incoming if isinstance(incoming, dict) else {})}
        action = data.get('action') or settings.get('action_uuid') or previous_action
        if not action and len(manifest.get('Actions', [])) == 1: action = supported[0]['UUID']
        if event in ('willAppear','keyDidAppear','didReceiveSettings','keyDown'):
            cache[context] = (action, settings)
        if event in ('willDisappear','keyDidDisappear'):
            cache.pop(context, None)
        if event == 'keyDown':
            try:
                binding = resolve(manifest, action, settings)
                if binding is not None:
                    async def transmit():
                        def send():
                            with application_focus(plugin, binding['config']):
                                execute(binding['steps'], step_delay=0.2 if binding['config'].get('EditLastSequence') else 0.06)
                        await asyncio.to_thread(send)
                    feedback = getattr(plugin, 'on_shared_shortcut', None)
                    if callable(feedback):
                        # Opt-in only: retain the same resolver, overrides and
                        # sender. Other plugins keep their original dispatch.
                        await feedback({**data, 'action': action, 'context': context,
                            'payload': {**payload, 'settings': settings}}, transmit if binding['steps'] else None)
                    elif binding['steps']:
                        await transmit()
                    return  # Unknown/unsupported defaults never become another action.
            except Exception as error:
                print(f"[Shared Shortcuts] {manifest.get('UUID')}: {type(error).__name__}: {error}")
                feedback = getattr(plugin, 'on_shared_shortcut', None)
                if callable(feedback):
                    async def invalid_shortcut():
                        raise ValueError('Invalid shortcut binding')
                    await feedback({**data, 'action': action, 'context': context,
                        'payload': {**payload, 'settings': settings}}, invalid_shortcut)
                return  # A partial chord must never fall back and execute twice.
        await original(data)
    plugin.handle_message = handler
    plugin._shared_shortcut_attached = True
