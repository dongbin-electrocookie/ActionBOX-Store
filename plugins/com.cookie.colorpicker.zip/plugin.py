import asyncio
import base64
import io
import os
import sys

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


def _enable_windows_dpi_awareness():
    """Select Per-Monitor V2 before pyautogui can select legacy System DPI."""
    if not IS_WINDOWS:
        return
    try:
        import ctypes

        user32 = ctypes.WinDLL("user32", use_last_error=True)
        set_context = user32.SetProcessDpiAwarenessContext
        set_context.argtypes = [ctypes.c_void_p]
        set_context.restype = ctypes.c_bool
        if set_context(ctypes.c_void_p(-4)):
            return
    except Exception:
        pass
    try:
        import ctypes

        shcore = ctypes.WinDLL("shcore", use_last_error=True)
        set_awareness = shcore.SetProcessDpiAwareness
        set_awareness.argtypes = [ctypes.c_int]
        set_awareness.restype = ctypes.c_long
        if set_awareness(2) == 0:
            return
    except Exception:
        pass
    try:
        import ctypes

        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


_enable_windows_dpi_awareness()

try:
    from PIL import Image, ImageGrab
    import pyautogui
    PIL_OK = True
except ImportError:
    Image = None
    ImageGrab = None
    pyautogui = None
    PIL_OK = False

# Windows 전용: 화면 DC에서 픽셀을 직접 읽기
user32 = None
gdi32 = None
if IS_WINDOWS:
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        gdi32 = ctypes.windll.gdi32
    except Exception as e:
        print(f"[ColorPicker Warning] Windows ctypes init failed: {e}")
        user32 = None
        gdi32 = None


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.default_icon_path = os.path.join(self.plugin_dir, "icon", "PICK_COLOR.png")
        self.context_settings = {}

    def _default_settings(self):
        return {
            "sync_led": False,
            "_lang": "en",
            "sync_title_on_pick": False,
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("sync_led", False),
            s.get("_lang"),
            s.get("title"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_pick", False)
        ])

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self.on_key_did_appear(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if event == "keyDown":
            await self.on_key_down(context, settings)

    async def on_key_did_appear(self, context, incoming_settings):
        if not context:
            return

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            if os.path.exists(self.default_icon_path):
                await self.runner.send_message({
                    "event": "setIcon",
                    "context": context,
                    "payload": {
                        "icon_path": self.default_icon_path,
                        "source": "builtin_plugin_icon"
                    }
                })
            return

        self.context_settings[context] = self._merge_with_defaults(incoming_settings)

    def _normalize_pixel(self, color):
        if isinstance(color, int):
            return color, color, color
        return int(color[0]), int(color[1]), int(color[2])

    def _get_cursor_position(self):
        """Return the cursor position in real screen coordinates.

        pyautogui.position() can be DPI-virtualized on Windows depending on the
        process that launched the plugin.  For color picking this is fatal: the
        sampled point can land somewhere else on the desktop.  Use Win32
        GetCursorPos first and keep pyautogui only as a fallback.
        """
        if IS_WINDOWS and user32 is not None:
            try:
                class POINT(ctypes.Structure):
                    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

                pt = POINT()
                if user32.GetCursorPos(ctypes.byref(pt)):
                    return int(pt.x), int(pt.y)
            except Exception as e:
                print(f"[ColorPicker Warning] GetCursorPos failed, fallback to pyautogui: {e}")

        return pyautogui.position()

    def _colorref_to_rgb(self, pixel):
        if pixel == -1 or pixel == 0xFFFFFFFF:
            raise RuntimeError("GetPixel returned CLR_INVALID")
        r = pixel & 0xFF
        g = (pixel >> 8) & 0xFF
        b = (pixel >> 16) & 0xFF
        return r, g, b

    def _get_monitor_capture_info(self, x, y):
        """Return monitor device name and local coordinates for the cursor point.

        On mixed-resolution desktops, the secondary monitor can have a virtual
        offset or negative coordinates.  Sampling a display-specific DC with
        monitor-local coordinates is more reliable than sampling a global DC or
        an ImageGrab bitmap with guessed offsets.
        """
        if not IS_WINDOWS or user32 is None:
            return None

        class POINT(ctypes.Structure):
            _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

        class RECT(ctypes.Structure):
            _fields_ = [
                ("left", ctypes.c_long),
                ("top", ctypes.c_long),
                ("right", ctypes.c_long),
                ("bottom", ctypes.c_long),
            ]

        class MONITORINFOEXW(ctypes.Structure):
            _fields_ = [
                ("cbSize", ctypes.c_ulong),
                ("rcMonitor", RECT),
                ("rcWork", RECT),
                ("dwFlags", ctypes.c_ulong),
                ("szDevice", ctypes.c_wchar * 32),
            ]

        MONITOR_DEFAULTTONEAREST = 2
        pt = POINT(int(x), int(y))
        hmon = user32.MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST)
        if not hmon:
            return None

        info = MONITORINFOEXW()
        info.cbSize = ctypes.sizeof(MONITORINFOEXW)
        if not user32.GetMonitorInfoW(hmon, ctypes.byref(info)):
            return None

        left = int(info.rcMonitor.left)
        top = int(info.rcMonitor.top)
        right = int(info.rcMonitor.right)
        bottom = int(info.rcMonitor.bottom)
        local_x = int(x) - left
        local_y = int(y) - top
        device = str(info.szDevice).rstrip("\x00")
        return {
            "device": device,
            "left": left,
            "top": top,
            "right": right,
            "bottom": bottom,
            "local_x": local_x,
            "local_y": local_y,
        }

    def _get_pixel_color_monitor_dc(self, x, y):
        if not user32 or not gdi32:
            raise RuntimeError("Windows GDI is not available")

        info = self._get_monitor_capture_info(x, y)
        if not info or not info.get("device"):
            raise RuntimeError("Monitor info is not available")

        # Create a DC for the exact monitor under the cursor, then sample using
        # coordinates relative to that monitor.  This avoids QHD+FHD virtual
        # desktop offset issues.
        try:
            gdi32.CreateDCW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_void_p]
            gdi32.CreateDCW.restype = ctypes.c_void_p
            gdi32.DeleteDC.argtypes = [ctypes.c_void_p]
            gdi32.DeleteDC.restype = ctypes.c_int
            gdi32.GetPixel.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
            gdi32.GetPixel.restype = ctypes.c_uint32
        except Exception:
            pass

        hdc = gdi32.CreateDCW("DISPLAY", info["device"], None, None)
        if not hdc:
            raise RuntimeError(f"CreateDCW failed for {info.get('device')}")

        try:
            pixel = gdi32.GetPixel(hdc, int(info["local_x"]), int(info["local_y"]))
        finally:
            gdi32.DeleteDC(hdc)

        rgb = self._colorref_to_rgb(pixel)
        print(
            f"[ColorPicker Debug] monitor_dc device={info['device']} "
            f"global=({int(x)},{int(y)}) local=({info['local_x']},{info['local_y']}) "
            f"rect=({info['left']},{info['top']},{info['right']},{info['bottom']})"
        )
        return rgb

    def _get_pixel_color_global_dc(self, x, y):
        if not user32 or not gdi32:
            raise RuntimeError("Windows GDI is not available")

        try:
            user32.GetDC.argtypes = [ctypes.c_void_p]
            user32.GetDC.restype = ctypes.c_void_p
            user32.ReleaseDC.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
            user32.ReleaseDC.restype = ctypes.c_int
            gdi32.GetPixel.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
            gdi32.GetPixel.restype = ctypes.c_uint32
        except Exception:
            pass

        hdc = user32.GetDC(None)
        try:
            pixel = gdi32.GetPixel(hdc, int(x), int(y))
        finally:
            user32.ReleaseDC(None, hdc)

        return self._colorref_to_rgb(pixel)

    def _get_pixel_color_imagegrab_virtual(self, x, y):
        if ImageGrab is None:
            raise RuntimeError("ImageGrab is not available")
        if not user32:
            raise RuntimeError("Win32 user32 is not available")

        SM_XVIRTUALSCREEN = 76
        SM_YVIRTUALSCREEN = 77
        vx = int(user32.GetSystemMetrics(SM_XVIRTUALSCREEN))
        vy = int(user32.GetSystemMetrics(SM_YVIRTUALSCREEN))
        img = ImageGrab.grab(all_screens=True)
        px = int(round(x)) - vx
        py = int(round(y)) - vy
        if px < 0 or py < 0 or px >= img.width or py >= img.height:
            raise RuntimeError(
                f"ImageGrab virtual coordinate out of range: cursor=({x},{y}) "
                f"origin=({vx},{vy}) image={img.size} pixel=({px},{py})"
            )
        print(f"[ColorPicker Debug] imagegrab_virtual cursor=({int(x)},{int(y)}) origin=({vx},{vy}) pixel=({px},{py}) image={img.size}")
        return self._normalize_pixel(img.getpixel((px, py)))

    def _get_pixel_color_windows(self, x, y):
        """Windows color capture optimized for mixed-resolution monitors.

        Primary path:
        - Get the monitor under the cursor with MonitorFromPoint.
        - Create a DC for that exact display device.
        - Convert virtual cursor coordinates to monitor-local coordinates.
        - Read the pixel with GetPixel.

        This avoids the FHD secondary monitor offset bug seen in QHD+FHD setups.
        """
        errors = []
        for name, func in (
            ("monitor_dc", self._get_pixel_color_monitor_dc),
            ("global_dc", self._get_pixel_color_global_dc),
            ("imagegrab_virtual", self._get_pixel_color_imagegrab_virtual),
        ):
            try:
                return func(x, y)
            except Exception as e:
                errors.append(f"{name}: {e}")
                print(f"[ColorPicker Warning] {name} failed: {e}")

        raise RuntimeError("Windows color capture failed; " + " | ".join(errors))

    def _get_pixel_color_screenshot(self, x, y):
        """
        macOS/Linux 공통 fallback.
        macOS에서는 시스템 설정 > 개인정보 보호 및 보안 > 화면 기록 권한이 필요할 수 있습니다.
        Retina 환경에서는 pyautogui.position() 좌표와 screenshot 픽셀 좌표 배율이 다를 수 있어서
        전체 스크린샷 크기와 pyautogui.size()를 비교해 좌표를 보정합니다.
        """
        if not PIL_OK or pyautogui is None:
            raise RuntimeError("PIL/pyautogui is not available")

        img = pyautogui.screenshot()
        screen_w, screen_h = pyautogui.size()
        img_w, img_h = img.size

        sx = img_w / screen_w if screen_w else 1
        sy = img_h / screen_h if screen_h else 1

        px = max(0, min(img_w - 1, int(round(x * sx))))
        py = max(0, min(img_h - 1, int(round(y * sy))))

        return self._normalize_pixel(img.getpixel((px, py)))

    def get_pixel_color(self, x, y):
        if IS_WINDOWS:
            try:
                return self._get_pixel_color_windows(x, y)
            except Exception as e:
                print(f"[ColorPicker Warning] Windows capture failed, fallback to screenshot: {e}")

        return self._get_pixel_color_screenshot(x, y)

    async def on_key_down(self, context, incoming_settings):
        if not context or not PIL_OK:
            print("[ColorPicker Error] PIL/pyautogui is not available")
            return

        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **(incoming_settings or {})})
        self.context_settings[context] = settings

        x, y = self._get_cursor_position()

        try:
            r, g, b = self.get_pixel_color(x, y)
            hex_val = f"#{r:02x}{g:02x}{b:02x}".upper()

            color_img = Image.new("RGB", (128, 128), (r, g, b))
            buffer = io.BytesIO()
            color_img.save(buffer, format="PNG")
            b64_str = base64.b64encode(buffer.getvalue()).decode()

            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": {"image": f"data:image/png;base64,{b64_str}"}
            })

            if settings.get("sync_title_on_pick", False):
                settings["title"] = hex_val
                self.context_settings[context] = settings

                await self.runner.send_message({
                    "event": "setSettings",
                    "context": context,
                    "payload": settings
                })

                await self.runner.send_message({
                    "event": "setTitle",
                    "context": context,
                    "payload": {"title": hex_val}
                })

            if settings.get("sync_led", False):
                await self.runner.send_message({
                    "event": "sendToPlugin",
                    "context": context,
                    "payload": {
                        "command": "set_page_led_color",
                        "color": [r, g, b]
                    }
                })

            print(f"[ColorPicker] Picked: {hex_val} at Win32 cursor ({x}, {y}) on {sys.platform}")

        except Exception as e:
            print(f"[ColorPicker Error] {e}")
