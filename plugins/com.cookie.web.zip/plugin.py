import asyncio
import json
import webbrowser
import os
import subprocess
import sys
import io

# --- 라이브러리 임포트 및 예외 처리 ---
libraries_ok = False
requests = None
BeautifulSoup = None
urljoin = None
urlparse = None
winreg = None
Image = None

try:
    import requests
    from bs4 import BeautifulSoup
    from urllib.parse import urljoin, urlparse
    if sys.platform == "win32":
        import winreg
    from PIL import Image
    libraries_ok = True
except ImportError as e:
    print(f"[Web Plugin Error] Missing libraries: {e}")
    # sys.exit(1) <--- 절대 금지 (러너 전체가 죽음)

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        # 🚀 [대통합 규격] 멀티액션 시 누락되는 브라우저 설정 등을 기억합니다.
        self.last_valid_settings = {}
        self.available_browsers = self.find_installed_browsers() if libraries_ok else {}

    async def handle_message(self, data):
        if not libraries_ok:
            return

        event = data.get("event")
        
        if event == "keyDown":
            await self.on_key_down(data)
        elif event == "fetchIcon":
            await self.on_fetch_icon(data)
        elif event == "getAvailableBrowsers":
            await self.on_get_browsers(data)

    async def on_key_down(self, data):
        incoming_settings = data.get("payload", {}).get("settings", {})
        
        # 1. 유효한 설정이 들어오면 기억해둡니다 (브라우저 경로 등)
        if incoming_settings:
            self.last_valid_settings.update(incoming_settings)
            
        # 2. 메모리와 현재 데이터를 합칩니다 (멀티액션 대응)
        final_settings = {**self.last_valid_settings, **incoming_settings}
        
        # 🚀 [표준화] 'command'에 주소가 있으면 그것을 우선 사용하고, 없으면 'url' 필드를 사용합니다.
        url = final_settings.get("command") or final_settings.get("url")
        browser_path = final_settings.get("browser", "default")
        
        if url:
            # 주소 형식이 아니면 https:// 를 붙여주는 센스
            if not url.startswith(('http://', 'https://')): 
                url = 'https://' + url
            
            # 브라우저 실행
            await asyncio.to_thread(self._open_url, url, browser_path)

    def _open_url(self, url, browser_path):
        if browser_path == "default":
            webbrowser.open(url)
        else:
            try: 
                subprocess.Popen([browser_path, url])
            except Exception: 
                webbrowser.open(url)

    async def on_fetch_icon(self, data):
        context = data.get("context")
        url = data.get("payload", {}).get("url")
        
        if context and url:
            # 아이콘 다운로드 및 가공은 무거운 작업이므로 스레드로 분리 (기존 로직 유지)
            icon_path = await asyncio.to_thread(self.fetch_and_save_favicon, url)
            
            if icon_path:
                # 러너를 통해 메인 프로그램으로 아이콘 설정 요청 전송
                await self.runner.send_message({
                    "event": "setIcon", 
                    "context": context, 
                    "payload": {"icon_path": icon_path}
                })

    async def on_get_browsers(self, data):
        context = data.get("context")
        if context:
            # PI(설정창)로 브라우저 목록 전송
            await self.runner.send_message({
                "event": "sendToPropertyInspector", 
                "context": context,
                "payload": { 
                    "event": "didReceiveAvailableBrowsers", 
                    "browsers": self.available_browsers 
                }
            })

    # --- [헬퍼] 브라우저 스캔 기능 (기존 코드 유지) ---
    def find_installed_browsers(self):
        if sys.platform != "win32" or not winreg: return {}
        
        browser_exes = {
            "chrome.exe": "Google Chrome",
            "msedge.exe": "Microsoft Edge",
            "firefox.exe": "Mozilla Firefox",
            "opera.exe": "Opera",
            "vivaldi.exe": "Vivaldi",
            "brave.exe": "Brave",
            "whale.exe": "Naver Whale",
            "Arc.exe": "Arc Browser",
            "DuckDuckGo.exe": "DuckDuckGo Browser",
            "comet.exe": "Comet Browser" 
        }
        
        installed_browsers = {}
        app_paths_key = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"
        
        for exe, name in browser_exes.items():
            try:
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, os.path.join(app_paths_key, exe))
                path, _ = winreg.QueryValueEx(key, None)
                installed_browsers[name] = path
                winreg.CloseKey(key)
            except FileNotFoundError:
                try:
                    key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, os.path.join(app_paths_key, exe))
                    path, _ = winreg.QueryValueEx(key, None)
                    installed_browsers[name] = path
                    winreg.CloseKey(key)
                except FileNotFoundError: pass
        return installed_browsers

    # --- [헬퍼] 아이콘 다운로드 및 가공 기능 (기존 코드 유지) ---

# plugin.py 파일의 fetch_and_save_favicon 함수를 이걸로 교체하세요.

    def fetch_and_save_favicon(self, url):
        # [헬퍼] 기본 이미지 경로 반환 함수
        def get_default_icon_path():
            # 현재 스크립트(plugin.py)가 있는 폴더의 default.png 경로
            default_path = os.path.join(os.path.dirname(__file__), "default.png")
            if os.path.exists(default_path):
                return default_path
            return None

        try:
            if not url.startswith(('http://', 'https://')): url = 'https://' + url
            headers = {'User-Agent': 'Mozilla/5.0'}
            
            # 1. 사이트 접속 시도
            try:
                response = requests.get(url, headers=headers, timeout=3) # 타임아웃 3초로 단축
                response.raise_for_status()
            except Exception:
                # 접속 실패 시 바로 기본 이미지 반환
                print(f"[{self.uuid}] Failed to connect to {url}. Using default.")
                return get_default_icon_path()
            
            # 2. 파비콘 URL 찾기
            soup = BeautifulSoup(response.text, 'html.parser')
            icon_link = soup.find("link", rel=lambda r: r and 'icon' in r.lower())
            icon_url = None
            
            if icon_link and icon_link.get('href'):
                icon_url = urljoin(url, icon_link['href'])
            else:
                # HTML에 없으면 /favicon.ico 시도
                fallback_url = urljoin(url, '/favicon.ico')
                try:
                    if requests.head(fallback_url, headers=headers, timeout=2).ok:
                        icon_url = fallback_url
                except: pass

            # ★ [핵심 수정 1] 아이콘 URL을 못 찾았을 때 -> 기본 이미지 사용
            if not icon_url:
                print(f"[{self.uuid}] Favicon URL not found. Using default.")
                return get_default_icon_path()

            # 3. 아이콘 다운로드
            try:
                icon_response = requests.get(icon_url, headers=headers, timeout=5)
                icon_response.raise_for_status()
                
                # 이미지 처리 (투명도 유지)
                icon_data = io.BytesIO(icon_response.content)
                img = Image.open(icon_data)
                img = img.convert("RGBA") 

                # 캐시 폴더에 저장
                cache_dir = "favicon_cache"
                os.makedirs(cache_dir, exist_ok=True)
                
                domain = urlparse(url).netloc
                safe_filename = "".join(c for c in domain if c.isalnum() or c in ('-', '_')).rstrip()
                save_path = os.path.join(cache_dir, f"{safe_filename}.png")
                
                img.save(save_path, 'PNG')
                return os.path.abspath(save_path)
                
            except Exception:
                # 다운로드나 변환 중 에러 -> 기본 이미지 사용
                print(f"[{self.uuid}] Error processing favicon. Using default.")
                return get_default_icon_path()
            
        except Exception as e:
            # 그 외 모든 에러 -> 기본 이미지 사용
            print(f"[{self.uuid}] Global error in fetch: {e}. Using default.")
            return get_default_icon_path()