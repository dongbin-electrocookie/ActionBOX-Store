import asyncio
import os

try:
    import pyautogui
    PYAUTOGUI_OK = True
except ImportError:
    pyautogui = None
    PYAUTOGUI_OK = False


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.default_full_cmd = 'single|e|TITLE_EXTRUDE'
        self.context_settings = {}

    def _parse_full_cmd(self, full_cmd):
        parts = (full_cmd or '').split('|')
        if len(parts) < 3:
            return None, None, None
        return parts[0], parts[1], parts[2]

    def _default_settings(self):
        cmd_type, key_val, title_key = self._parse_full_cmd(self.default_full_cmd)
        return {
            "full_cmd": self.default_full_cmd,
            "cmd_type": cmd_type,
            "key_val": key_val,
            "builtin_icon_name": title_key,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})

        full_cmd = merged.get("full_cmd") or self.default_full_cmd
        cmd_type, key_val, title_key = self._parse_full_cmd(full_cmd)
        if not cmd_type or not key_val or not title_key:
            full_cmd = self.default_full_cmd
            cmd_type, key_val, title_key = self._parse_full_cmd(full_cmd)

        merged["full_cmd"] = full_cmd
        merged["cmd_type"] = cmd_type
        merged["key_val"] = key_val
        merged["builtin_icon_name"] = title_key
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("full_cmd"),
            s.get("cmd_type"),
            s.get("key_val"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_builtin_icon_path(self, title_key):
        return os.path.join(self.plugin_dir, 'icon', f'{title_key}.png')

    async def _send_builtin_icon(self, context, title_key):
        if not context or not title_key:
            return
        icon_path = self._get_builtin_icon_path(title_key)
        if not os.path.exists(icon_path):
            return
        await self.runner.send_message({
            'event': 'setIcon',
            'context': context,
            'payload': {'icon_path': icon_path}
        })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                'event': 'setSettings',
                'context': context,
                'payload': defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["builtin_icon_name"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get('event')
        payload = data.get('payload', {}) or {}
        context = data.get('context') or payload.get('context')
        payload_settings = payload.get('settings')
        settings = payload_settings if isinstance(payload_settings, dict) else data.get('settings', {}) or {}
        control_command = data.get('command') or payload.get('command')

        if event in ['willAppear', 'keyDidAppear']:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == 'didReceiveSettings':
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ['keyDidDisappear', 'willDisappear']:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == 'apply_builtin_icon':
            cached = self.context_settings.get(context, {})
            full_cmd = data.get('full_cmd') or payload.get('full_cmd') or settings.get('full_cmd') or cached.get('full_cmd') or self.default_full_cmd
            _cmd_type, _key_val, title_key = self._parse_full_cmd(full_cmd)
            if context and title_key:
                await self._send_builtin_icon(context, title_key)
            return

        if event == 'keyDown':
            await self.on_key_down(context, settings)

    async def on_key_down(self, context, incoming_settings):
        if not PYAUTOGUI_OK:
            return

        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **(incoming_settings or {})})
        if context:
            self.context_settings[context] = settings

        full_cmd = settings.get('full_cmd') or self.default_full_cmd
        cmd_type, key_val, _title_key = self._parse_full_cmd(full_cmd)
        if not key_val:
            return

        try:
            if 'num' in key_val:
                key_val = key_val.replace('num', 'numpad')
            if key_val == 'decimal':
                key_val = 'numpaddecimal'

            if cmd_type == 'single':
                await asyncio.to_thread(pyautogui.press, key_val)
            elif cmd_type == 'combo':
                keys = key_val.split('+')
                await asyncio.to_thread(pyautogui.hotkey, *keys)
        except Exception as e:
            print(f'[Blender Error] {e}')
