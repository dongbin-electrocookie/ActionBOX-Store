from __future__ import annotations

import asyncio
import base64
import io
import json
import mmap
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFont


PLUGIN_UUID = "com.cookie.ai_monitor"
LEGACY_PLUGIN_UUID = "com.user.ai_monitor"
CODEX_ACTION = f"{PLUGIN_UUID}.codex"
CLAUDE_ACTION = f"{PLUGIN_UUID}.claude"
CODEX_PTT_ACTION = f"{PLUGIN_UUID}.codex_ptt"
CODEX_VOICE_TOGGLE_ACTION = f"{PLUGIN_UUID}.codex_voice_toggle"
CLAUDE_VOICE_ACTION = f"{PLUGIN_UUID}.claude_voice"
CODEX_REASONING_DOWN_ACTION = f"{PLUGIN_UUID}.codex_reasoning_down"
CODEX_REASONING_UP_ACTION = f"{PLUGIN_UUID}.codex_reasoning_up"
CONFIRM_ACTION = f"{PLUGIN_UUID}.confirm"
CANCEL_ACTION = f"{PLUGIN_UUID}.cancel"
CLAUDE_CONFIRM_ACTION = f"{PLUGIN_UUID}.claude_confirm"
CLAUDE_CANCEL_ACTION = f"{PLUGIN_UUID}.claude_cancel"
MONITOR_ACTIONS = {CODEX_ACTION, CLAUDE_ACTION}
VOICE_ACTIONS = {CODEX_PTT_ACTION, CODEX_VOICE_TOGGLE_ACTION, CLAUDE_VOICE_ACTION}
REASONING_ACTIONS = {CODEX_REASONING_DOWN_ACTION, CODEX_REASONING_UP_ACTION}
GENERIC_KEY_SHORTCUTS = {
    CONFIRM_ACTION: "Enter",
    CANCEL_ACTION: "Esc",
    CLAUDE_CONFIRM_ACTION: "Enter",
    CLAUDE_CANCEL_ACTION: "Esc",
}
GENERIC_KEY_ACTIONS = set(GENERIC_KEY_SHORTCUTS)
SHORTCUT_ACTIONS = VOICE_ACTIONS | REASONING_ACTIONS | GENERIC_KEY_ACTIONS
ENABLED_PROVIDERS = {"codex"}
CODEX_VOICE_COMMANDS = {
    # Do not use globalDictationHold/globalDictationToggle here. Those commands
    # are registered through Codex/Electron's global-hotkey controller and an
    # external keybindings.json edit does not synchronously register them in an
    # already-running Codex process. The app-scoped composer command receives
    # ordinary focused keyDown/keyUp events and is therefore reliable with the
    # same synthetic-key path that Claude Code Voice uses.
    CODEX_PTT_ACTION: "composer.startDictation",
    CODEX_VOICE_TOGGLE_ACTION: "composer.startDictation",
}
CODEX_REASONING_COMMANDS = {
    CODEX_REASONING_DOWN_ACTION: "composer.decreaseReasoningEffort",
    CODEX_REASONING_UP_ACTION: "composer.increaseReasoningEffort",
}
HOOK_MARKER = "COMBO-X AI Monitor"
BASE_MONITORED_EVENTS = ("SessionStart", "UserPromptSubmit", "Stop", "SessionEnd")
MONITORED_EVENTS_BY_PROVIDER = {
    "codex": BASE_MONITORED_EVENTS + ("PermissionRequest", "PostToolUse", "Interrupt"),
    "claude": BASE_MONITORED_EVENTS + (
        "PermissionRequest", "PostToolUse", "PostToolUseFailure",
        "PermissionDenied", "StopFailure", "Elicitation", "ElicitationResult",
    ),
}
VALID_MONITOR_STATES = {"idle", "running", "done", "approval", "error"}
STARTUP_TRANSCRIPT_RECOVERY_SECONDS = 15 * 60
# Designer assets use presentation names that differ from the monitor's
# internal state names.  Frame counts and delays mirror the source GIFs.
STATUS_ANIMATION_ASSETS = {
    "idle": {"folder": "Idle", "frame_count": 8, "delay": 0.130},
    "running": {"folder": "Thinking", "frame_count": 16, "delay": 0.070},
    "done": {"folder": "Complete", "frame_count": 10, "delay": 0.090},
    "approval": {"folder": "Permission", "frame_count": 17, "delay": 0.150},
    "error": {"folder": "Error", "frame_count": 10, "delay": 0.090},
}
ANIMATED_MONITOR_STATES = set(STATUS_ANIMATION_ASSETS)
STATUS_LED_COLORS = {
    "idle": [255, 255, 255],
    "running": [3, 91, 255],
    "done": [8, 255, 0],
    "approval": [255, 144, 0],
    "error": [255, 0, 0],
}
STATE_BY_EVENT = {
    "SessionStart": "idle",
    "UserPromptSubmit": "running",
    "Stop": "done",
    "SessionEnd": "idle",
    "PermissionRequest": "approval",
    "Elicitation": "approval",
    "PostToolUse": "running",
    "PermissionDenied": "running",
    "ElicitationResult": "running",
    "PostToolUseFailure": "error",
    "StopFailure": "error",
    "Interrupt": "done",
}

CODEX_ROLLOUT_STATE_BY_EVENT = {
    "task_started": "running",
    "turn_started": "running",
    # A submitted user message is also a reliable sign that this session has
    # entered a new turn.  Recent Codex Desktop builds can write task_started
    # using a top-level rollout record instead of event_msg, so this provides a
    # second start signal without depending on one serialization shape.
    "user_message": "running",
    "task_complete": "done",
    "turn_complete": "done",
    "turn_aborted": "error",
    "task_failed": "error",
    "turn_failed": "error",
    "stream_error": "error",
    "error": "error",
}
CODEX_SESSION_ID_RE = re.compile(
    r"([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\.jsonl$"
)
CLAUDE_SESSION_ID_RE = re.compile(
    r"([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\.jsonl$"
)


def user_data_dir(plugin_uuid: str) -> Path:
    safe_uuid = plugin_uuid.replace(".", "_")
    if sys.platform.startswith("win"):
        root = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
    elif sys.platform == "darwin":
        root = Path.home() / "Library" / "Application Support"
    else:
        root = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")
    path = root / "CookieDeck" / safe_uuid
    path.mkdir(parents=True, exist_ok=True)
    # Keep existing AI Monitor state and managed hook metadata when upgrading
    # from the former user-plugin namespace to the official built-in ID.
    if plugin_uuid in {PLUGIN_UUID, "com.cookie.codex", "com.cookie.claude_code"}:
        for legacy_uuid in (LEGACY_PLUGIN_UUID, PLUGIN_UUID):
            legacy_path = root / "CookieDeck" / legacy_uuid.replace(".", "_")
            if not legacy_path.is_dir() or legacy_path == path:
                continue
            try:
                for child in legacy_path.iterdir():
                    target = path / child.name
                    if target.exists():
                        continue
                    if child.is_dir():
                        shutil.copytree(child, target)
                    else:
                        shutil.copy2(child, target)
            except OSError as exc:
                print(f"[AI Monitor] Legacy data migration warning: {exc}", flush=True)
    return path


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.manifest = manifest
        self.plugin_uuid = str(manifest.get("UUID") or PLUGIN_UUID)
        self.plugin_dir = Path(__file__).resolve().parent
        self.locale_dir = self.plugin_dir / "locales"
        self.locale_cache: dict[str, dict[str, str]] = {}
        self.data_dir = user_data_dir(self.plugin_uuid)
        self.events_dir = self.data_dir / "events"
        self.backup_dir = self.data_dir / "backups"
        self.events_dir.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(parents=True, exist_ok=True)

        self.contexts: dict[str, dict[str, Any]] = {}
        self.animation_tasks: dict[str, asyncio.Task] = {}
        self.poll_task: asyncio.Task | None = None
        self._scan_lock = asyncio.Lock()
        self._jsonl_file_ids: dict[str, tuple[int, int]] = {}
        self._jsonl_discarding: set[str] = set()
        self._monitor_errors: dict[str, str] = {}
        self._state_dirty = False
        self._image_cache: dict[tuple[str, str, int], str] = {}
        self._sent_image_cache: dict[str, str] = {}
        self._sent_preview_image_cache: dict[str, str] = {}
        self._led_cache: dict[str, tuple[int, int, int]] = {}
        # Hook setup is self-healing for status actions. keyDidAppear/willAppear
        # can arrive once per page and context, so guard the check by provider
        # and serialize it to avoid rewriting the same config more than once.
        self._hook_setup_lock = asyncio.Lock()
        self._auto_hook_checked: set[str] = set()
        self._auto_hook_results: dict[str, tuple[bool, str, str, bool]] = {}
        self.state_path = self.data_dir / "state.json"
        self.monitor_state = self._load_state()
        self._ensure_provider_state("codex")
        self._ensure_provider_state("claude")
        # Codex Desktop on Windows has had lifecycle-command-hook regressions.
        # Keep the official hook path, but also tail Codex's local rollout JSONL
        # as a read-only fallback so GUI turns can still be observed.
        self._codex_rollout_offsets: dict[str, int] = {}
        self._codex_rollout_scan_counter = 0
        # Claude Code CLI/Desktop transcripts are also tailed read-only.  This is
        # a fallback for Desktop builds where command hooks are configured but do
        # not execute.  The primary Desktop Code transcript store is the same
        # ~/.claude/projects tree used by Claude Code; legacy/Cowork sandboxes may
        # expose nested .claude/projects trees under the Claude app-data folder.
        self._claude_transcript_offsets: dict[str, int] = {}
        self._claude_transcript_scan_counter = 0
        self._claude_project_roots_cache: list[Path] = []
        self._claude_roots_last_scan = 0.0
        self._runtime_started_at = time.time()
        self._reset_running_states_at_startup()
        self._prime_existing_transcript_offsets_sync()
        if "codex" in ENABLED_PROVIDERS:
            self._recover_recent_codex_state_at_startup_sync()
        if "claude" in ENABLED_PROVIDERS:
            self._recover_recent_claude_state_at_startup_sync()

        # Voice actions are intentionally separate from the monitor poller.
        # Codex voice shortcuts are read from ~/.codex/keybindings.json and are
        # auto-created only when the requested command is genuinely unassigned.
        self._voice_config_lock = asyncio.Lock()
        self._voice_shortcut_cache: dict[str, dict[str, Any]] = {}
        self._voice_held: dict[str, dict[str, Any]] = {}
        self._voice_hold_watchdogs: dict[str, asyncio.Task] = {}
        # Codex Voice Toggle is emulated on the app-scoped hold-to-dictate
        # command: first COMBO-X press keeps the shortcut logically down, and
        # the next press releases it. This avoids Codex's globalShortcut path.
        self._voice_toggle_held: dict[str, dict[str, Any]] = {}
        self._voice_tap_down: set[str] = set()
        self._reasoning_tap_down: set[str] = set()
        self._generic_key_tap_down: set[str] = set()
        self.voice_binding_state_path = self.data_dir / "voice_bindings.json"
        self._managed_voice_bindings = self._load_managed_voice_bindings()
        self._write_hook_helpers()

    # ------------------------------------------------------------------
    # Localization
    # ------------------------------------------------------------------
    def _language(self, settings: dict[str, Any] | None) -> str:
        value = str((settings or {}).get("_lang") or "en").replace("_", "-").strip()
        lowered = value.lower()
        aliases = {"kr": "ko", "jp": "ja"}
        candidates = [aliases.get(lowered, lowered), lowered.split("-", 1)[0]]
        for candidate in candidates:
            if candidate and (self.locale_dir / f"{candidate}.json").is_file():
                return candidate
        return "en"

    def _locale(self, settings: dict[str, Any] | None) -> dict[str, str]:
        language = self._language(settings)
        cached = self.locale_cache.get(language)
        if cached is not None:
            return cached

        def load(code: str) -> dict[str, str]:
            try:
                value = json.loads((self.locale_dir / f"{code}.json").read_text(encoding="utf-8"))
                return value if isinstance(value, dict) else {}
            except (OSError, json.JSONDecodeError):
                return {}

        english = self.locale_cache.get("en") or load("en")
        self.locale_cache["en"] = english
        translated = english if language == "en" else {**english, **load(language)}
        self.locale_cache[language] = translated
        return translated

    def _t(self, settings: dict[str, Any] | None, key: str, fallback: str = "", **values: Any) -> str:
        text = str(self._locale(settings).get(key) or fallback or key)
        try:
            return text.format(**values)
        except (KeyError, IndexError, ValueError):
            return text

    # ------------------------------------------------------------------
    # Context/settings helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _settings(data: dict[str, Any]) -> dict[str, Any]:
        payload = data.get("payload", {}) or {}
        if not isinstance(payload, dict):
            return {}
        nested = payload.get("settings")
        source = nested if isinstance(nested, dict) else payload
        known = {
            "provider", "monitor_mode", "session_id", "title", "_lang",
            "action_kind", "shortcut", "shortcut_source",
            "shortcut_command", "shortcut_config_path", "show_led",
        }
        return {key: value for key, value in source.items() if key in known}

    @staticmethod
    def _provider_for_action(action: str, settings: dict[str, Any] | None = None) -> str:
        action = str(action or "").split("#", 1)[0]
        if action in {
            CLAUDE_ACTION, CLAUDE_VOICE_ACTION,
            CLAUDE_CONFIRM_ACTION, CLAUDE_CANCEL_ACTION,
        }:
            return "claude"
        if action in {
            CODEX_ACTION, CODEX_PTT_ACTION, CODEX_VOICE_TOGGLE_ACTION,
            CODEX_REASONING_DOWN_ACTION, CODEX_REASONING_UP_ACTION,
        }:
            return "codex"
        provider = str((settings or {}).get("provider") or "codex").lower()
        return "claude" if provider == "claude" else "codex"

    @staticmethod
    def _action_kind_for_action(action: str) -> str:
        action = str(action or "").split("#", 1)[0]
        return {
            CODEX_ACTION: "status_codex",
            CLAUDE_ACTION: "status_claude",
            CODEX_PTT_ACTION: "voice_codex_ptt",
            CODEX_VOICE_TOGGLE_ACTION: "voice_codex_toggle",
            CLAUDE_VOICE_ACTION: "voice_claude",
            CODEX_REASONING_DOWN_ACTION: "reasoning_codex_down",
            CODEX_REASONING_UP_ACTION: "reasoning_codex_up",
            CONFIRM_ACTION: "key_confirm",
            CANCEL_ACTION: "key_cancel",
            CLAUDE_CONFIRM_ACTION: "key_confirm",
            CLAUDE_CANCEL_ACTION: "key_cancel",
        }.get(action, "")

    @staticmethod
    def _is_monitor_action(action: str) -> bool:
        return str(action or "").split("#", 1)[0] in MONITOR_ACTIONS

    @staticmethod
    def _is_voice_action(action: str) -> bool:
        return str(action or "").split("#", 1)[0] in VOICE_ACTIONS

    @staticmethod
    def _is_reasoning_action(action: str) -> bool:
        return str(action or "").split("#", 1)[0] in REASONING_ACTIONS

    @staticmethod
    def _is_shortcut_action(action: str) -> bool:
        return str(action or "").split("#", 1)[0] in SHORTCUT_ACTIONS

    @staticmethod
    def _is_generic_key_action(action: str) -> bool:
        return str(action or "").split("#", 1)[0] in GENERIC_KEY_ACTIONS

    def _remember(self, data: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        context = str(data.get("context") or "")
        payload = data.get("payload", {}) or {}
        if not isinstance(payload, dict):
            payload = {}
        state = self.contexts.setdefault(
            context,
            {"action": "", "settings": {}, "page": None},
        )
        action = str(data.get("action") or "").split("#", 1)[0]
        if action == LEGACY_PLUGIN_UUID or action.startswith(f"{LEGACY_PLUGIN_UUID}."):
            action = PLUGIN_UUID + action[len(LEGACY_PLUGIN_UUID):]
        if action:
            state["action"] = action
        incoming = self._settings(data)
        state["settings"].update(incoming)
        provider = self._provider_for_action(state.get("action", ""), state.get("settings"))
        state["settings"]["provider"] = provider
        action_kind = self._action_kind_for_action(state.get("action", ""))
        if action_kind:
            state["settings"]["action_kind"] = action_kind
        if payload.get("page") is not None:
            try:
                state["page"] = int(payload["page"])
            except (TypeError, ValueError):
                pass
        return context, state

    @staticmethod
    def _manual_title(state: dict[str, Any], fallback: str) -> str:
        return str(state.get("settings", {}).get("title") or fallback).strip() or fallback

    async def _title(self, context: str, title: str) -> None:
        state = self.contexts.get(context, {})
        await self.runner.send_message({
            "event": "setTitle",
            "context": context,
            "payload": {"title": title, "page": state.get("page")},
        })

    async def _send_to_pi(self, context: str, payload: dict[str, Any]) -> None:
        await self.runner.send_message({
            "event": "sendToPropertyInspector",
            "context": context,
            "payload": payload,
        })

    async def _persist_context_settings(self, context: str, updates: dict[str, Any]) -> None:
        state = self.contexts.get(context)
        if not state:
            return
        settings = state.setdefault("settings", {})
        changed = False
        for key, value in updates.items():
            if settings.get(key) != value:
                settings[key] = value
                changed = True
        if not changed:
            return
        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": dict(settings),
        })

    # ------------------------------------------------------------------
    # Persistent monitor state
    # ------------------------------------------------------------------
    def _default_state(self) -> dict[str, Any]:
        return {
            "schema_version": 2,
            "providers": {
                "codex": {"latest_session_id": "", "latest_updated_at": 0, "sessions": {}},
                "claude": {"latest_session_id": "", "latest_updated_at": 0, "sessions": {}},
            },
        }

    def _load_state(self) -> dict[str, Any]:
        try:
            value = json.loads(self.state_path.read_text(encoding="utf-8"))
            if isinstance(value, dict) and isinstance(value.get("providers"), dict):
                return value
        except (OSError, json.JSONDecodeError):
            pass
        return self._default_state()

    def _ensure_provider_state(self, provider: str) -> dict[str, Any]:
        providers = self.monitor_state.setdefault("providers", {})
        value = providers.setdefault(
            provider,
            {"latest_session_id": "", "latest_updated_at": 0, "sessions": {}},
        )
        if not isinstance(value.get("sessions"), dict):
            value["sessions"] = {}
        value.setdefault("latest_session_id", "")
        value.setdefault("latest_updated_at", 0)
        if not float(value.get("latest_updated_at") or 0):
            latest_id = str(value.get("latest_session_id") or "")
            latest_session = value.get("sessions", {}).get(latest_id, {}) if latest_id else {}
            if isinstance(latest_session, dict):
                value["latest_updated_at"] = float(latest_session.get("updated_at") or 0)
        return value

    def _reset_running_states_at_startup(self) -> None:
        """Start idle unless a separate live-transcript check proves RUNNING.

        Done/error/approval records belong to the previous COMBO-X run and must
        not become the initial button state. Running is reset here too, then the
        latest transcript lifecycle is inspected below and restored only when
        the newest real record is still RUNNING.
        """
        changed = False
        for provider in ENABLED_PROVIDERS:
            pstate = self._ensure_provider_state(provider)
            latest_id = str(pstate.get("latest_session_id") or "")
            for session_id, session in pstate.get("sessions", {}).items():
                if not isinstance(session, dict) or session.get("state") == "idle":
                    continue
                session.update({
                    "state": "idle",
                    "last_event": "startup_reset",
                    "updated_at": self._runtime_started_at,
                    "source": "startup",
                })
                if str(session_id) == latest_id:
                    pstate["latest_updated_at"] = self._runtime_started_at
                changed = True
        self._state_dirty = self._state_dirty or changed

    def _prime_existing_transcript_offsets_sync(self) -> None:
        """Start existing files at EOF; targeted recovery handles live work."""
        paths: list[Path] = []
        if "codex" in ENABLED_PROVIDERS:
            root = self._codex_home() / "sessions"
            if root.is_dir():
                try:
                    paths.extend(root.rglob("rollout-*.jsonl"))
                except OSError:
                    pass
        if "claude" in ENABLED_PROVIDERS:
            initial_claude_roots = self._discover_claude_project_roots_sync()
            # Priming is a point-in-time snapshot, not the regular discovery
            # cache. Claude may create its first project root after startup.
            self._claude_roots_last_scan = 0.0
            self._claude_apps_last_scan = -60.0
            for root in initial_claude_roots:
                try:
                    paths.extend(
                        path for path in root.rglob("*.jsonl")
                        if "subagents" not in path.parts and not path.name.startswith("agent-")
                    )
                except OSError:
                    continue

        for path in paths:
            try:
                stat = path.stat()
            except OSError:
                continue
            key = str(path)
            offsets = (
                self._codex_rollout_offsets
                if path.name.startswith("rollout-")
                else self._claude_transcript_offsets
            )
            offsets[key] = stat.st_size
            self._jsonl_file_ids[key] = (stat.st_dev, stat.st_ino)

    def _save_state_sync(self) -> None:
        temp = self.state_path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.monitor_state, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temp, self.state_path)

    def _prune_sessions(self, provider: str, limit: int = 100) -> None:
        pstate = self._ensure_provider_state(provider)
        sessions = pstate["sessions"]
        if len(sessions) <= limit:
            return
        ordered = sorted(
            sessions.items(),
            key=lambda item: float((item[1] or {}).get("updated_at") or 0),
            reverse=True,
        )
        keep = dict(ordered[:limit])
        latest = str(pstate.get("latest_session_id") or "")
        if latest and latest in sessions:
            keep[latest] = sessions[latest]
        pstate["sessions"] = keep

    def _apply_state_event(
        self,
        provider: str,
        session_id: str,
        state_value: str,
        event_name: str,
        mtime: float,
        *,
        cwd: str = "",
        turn_id: str = "",
        source: str = "hook",
        transcript_path: str = "",
    ) -> bool:
        session_id = str(session_id or "").strip()
        if provider not in {"codex", "claude"} or not session_id:
            return False
        if state_value not in VALID_MONITOR_STATES:
            return False

        pstate = self._ensure_provider_state(provider)
        session = pstate["sessions"].setdefault(session_id, {})
        event_time = float(mtime or time.time())
        previous_time = float(session.get("updated_at") or 0)
        # Hook inbox files and transcript/rollout files are scanned independently.
        # Never let an older fallback record overwrite a newer live event.
        startup_recovery = (
            str(session.get("source") or "") == "startup"
            and str(session.get("last_event") or "") == "startup_reset"
            and source in {"rollout", "claude_transcript"}
        )
        if previous_time and event_time + 0.001 < previous_time and not startup_recovery:
            return False

        update = {
            "state": state_value,
            "last_event": str(event_name or ""),
            "updated_at": event_time,
            "source": str(source or ""),
        }
        if cwd:
            update["cwd"] = str(cwd)
        else:
            update.setdefault("cwd", str(session.get("cwd") or ""))
        if turn_id:
            update["turn_id"] = str(turn_id)
        if transcript_path:
            update["transcript_path"] = str(transcript_path)
        session.update(update)

        latest_time = float(pstate.get("latest_updated_at") or 0)
        if event_time + 0.001 >= latest_time:
            pstate["latest_session_id"] = session_id
            pstate["latest_updated_at"] = event_time
        self._prune_sessions(provider)
        return True

    def _append_diagnostic_event(
        self,
        provider: str,
        session_id: str,
        event_name: str,
        event_time: float,
        *,
        transcript_path: str = "",
    ) -> bool:
        session_id = str(session_id or "").strip()
        event_name = str(event_name or "").strip()
        if provider not in {"codex", "claude"} or not session_id or not event_name:
            return False
        pstate = self._ensure_provider_state(provider)
        session = pstate["sessions"].setdefault(session_id, {})
        items = session.setdefault("diagnostic_events", [])
        if not isinstance(items, list):
            items = []
            session["diagnostic_events"] = items
        stamp = float(event_time or time.time())
        item = {"event": event_name, "timestamp": stamp}
        if transcript_path:
            item["path"] = str(transcript_path)
            session["transcript_path"] = str(transcript_path)
        if items and items[-1].get("event") == event_name and abs(float(items[-1].get("timestamp") or 0) - stamp) < 0.001:
            return False
        items.append(item)
        del items[:-10]
        return True

    def _apply_hook_event(self, provider: str, event: dict[str, Any], mtime: float) -> bool:
        event_name = str(event.get("hook_event_name") or "")
        state_value = STATE_BY_EVENT.get(event_name)
        session_id = str(event.get("session_id") or "").strip()
        if not state_value or not session_id:
            return False

        changed = self._apply_state_event(
            provider,
            session_id,
            state_value,
            event_name,
            mtime,
            cwd=str(event.get("cwd") or ""),
            turn_id=str(event.get("turn_id") or ""),
            source="hook",
        )
        if changed and event.get("prompt_id") is not None:
            self._ensure_provider_state(provider)["sessions"][session_id]["prompt_id"] = str(
                event.get("prompt_id") or ""
            )
        return changed

    @staticmethod
    def _codex_response_item_transition(payload: dict[str, Any], approval_pending: bool) -> tuple[str, str, bool]:
        item_type = str(payload.get("type") or "").strip().lower()
        if item_type in {"function_call", "custom_tool_call"}:
            name = str(payload.get("name") or "").strip().lower()
            raw_input = " ".join(
                str(payload.get(key) or "") for key in ("arguments", "input")
            ).lower()
            asks_user = (
                name in {"request_user_input", "request_user_input_async", "askuserquestion"}
                or "request_user_input" in raw_input
                or "askuserquestion" in raw_input
            )
            if asks_user:
                return "approval", "user_approval_requested", True
        elif item_type in {"function_call_output", "custom_tool_call_output"} and approval_pending:
            return "running", "user_approval_resolved", False
        elif item_type in {"error", "tool_error"}:
            return "error", item_type, False
        return "", "", approval_pending

    def _resolve_status(self, state: dict[str, Any]) -> dict[str, Any]:
        settings = state.get("settings", {})
        provider = self._provider_for_action(state.get("action", ""), settings)
        pstate = self._ensure_provider_state(provider)
        monitor_mode = str(settings.get("monitor_mode") or "recent")
        requested_session = str(settings.get("session_id") or "").strip()
        if monitor_mode == "session":
            session_id = requested_session
        else:
            session_id = str(pstate.get("latest_session_id") or "")

        session = pstate.get("sessions", {}).get(session_id, {}) if session_id else {}
        status = str(session.get("state") or "idle")
        if status not in VALID_MONITOR_STATES:
            status = "idle"
        return {
            "provider": provider,
            "monitor_mode": monitor_mode,
            "session_id": session_id,
            "state": status,
            "last_event": str(session.get("last_event") or ""),
            "cwd": str(session.get("cwd") or ""),
            "source": str(session.get("source") or ""),
            "updated_at": session.get("updated_at"),
            "latest_session_id": str(pstate.get("latest_session_id") or ""),
            "transcript_path": str(session.get("transcript_path") or ""),
            "diagnostic_events": list(session.get("diagnostic_events") or [])[-10:],
        }

    async def _acknowledge_completed_state(self, context: str) -> str:
        """Turn the displayed DONE session back to IDLE after a key press.

        The scan lock keeps a concurrent hook/transcript update from being
        overwritten. The provider name is returned when an acknowledgement was
        applied so every visible key following that session can be refreshed.
        """
        state = self.contexts.get(context)
        if not state:
            return ""

        async with self._scan_lock:
            info = self._resolve_status(state)
            session_id = str(info.get("session_id") or "")
            if info.get("state") != "done" or not session_id:
                return ""

            provider = str(info.get("provider") or "")
            changed = self._apply_state_event(
                provider,
                session_id,
                "idle",
                "manual_acknowledge",
                time.time(),
                source="manual",
            )
            if not changed:
                return ""

            self._state_dirty = True
            try:
                await asyncio.to_thread(self._save_state_sync)
                self._state_dirty = False
                self._monitor_errors.pop("save", None)
            except Exception as exc:
                self._report_monitor_error("save", exc)
            return provider

    # ------------------------------------------------------------------
    # Dynamic status images
    # ------------------------------------------------------------------
    def _load_status_asset(self, status: str, frame: int) -> str | None:
        """Load a designer-provided status frame without recompositing it."""
        asset = STATUS_ANIMATION_ASSETS.get(status)
        if not asset:
            return None
        frame_number = (int(frame) % int(asset["frame_count"])) + 1
        folder = self.plugin_dir / "icon" / str(asset["folder"])
        candidates = (
            (folder / f"frame_{frame_number:04d}.jpg", "image/jpeg"),
            (folder / f"frame_{frame_number:04d}.jpeg", "image/jpeg"),
            (folder / f"frame_{frame_number:04d}.png", "image/png"),
            # Keep the original idle naming convention compatible with older
            # development copies of the plugin.
            (folder / f"{status}-{frame_number}.jpg", "image/jpeg"),
            (folder / f"{status}-{frame_number}.png", "image/png"),
        )
        for path, mime in candidates:
            if path.is_file():
                try:
                    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
                    return f"data:{mime};base64,{encoded}"
                except OSError:
                    return None
        return None

    @staticmethod
    def _draw_status_image(provider: str, status: str, frame: int) -> str:
        size = 112
        cyan = "#0CC7D5"
        muted = "#A5B1B6"
        image = Image.new("RGB", (size, size), "white")
        draw = ImageDraw.Draw(image)
        font_small = ImageFont.load_default(size=12)
        font_state = ImageFont.load_default(size=11)
        provider_label = "CODEX" if provider == "codex" else "CLAUDE"

        pbox = draw.textbbox((0, 0), provider_label, font=font_small)
        draw.text(((size - (pbox[2] - pbox[0])) / 2, 7), provider_label, fill=cyan, font=font_small)

        cx, cy = 56, 55
        if status == "running":
            import math
            for idx in range(8):
                angle = math.radians(idx * 45 - 90)
                x = cx + int(math.cos(angle) * 25)
                y = cy + int(math.sin(angle) * 25)
                phase = (idx - frame) % 8
                radius = 5 if phase == 0 else (4 if phase in (1, 7) else 3)
                color = cyan if phase <= 2 or phase >= 7 else muted
                draw.ellipse((x - radius, y - radius, x + radius, y + radius), outline=color, width=2)
            label = "RUNNING"
        elif status == "done":
            accent = "#08FF00"
            draw.ellipse((30, 29, 82, 81), outline=accent, width=4)
            draw.line((40, 56, 51, 67, 73, 43), fill=accent, width=6, joint="curve")
            label = "DONE"
        elif status == "approval":
            accent = "#FF9000"
            draw.ellipse((30, 29, 82, 81), outline=accent, width=4)
            draw.line((56, 40, 56, 61), fill=accent, width=5)
            draw.ellipse((53, 68, 59, 74), fill=accent)
            label = "APPROVAL"
        elif status == "error":
            accent = "#FF0000"
            draw.ellipse((30, 29, 82, 81), outline=accent, width=4)
            draw.line((42, 42, 70, 70), fill=accent, width=6)
            draw.line((70, 42, 42, 70), fill=accent, width=6)
            label = "ERROR"
        else:
            draw.ellipse((30, 29, 82, 81), outline=muted, width=4)
            for x in (45, 56, 67):
                draw.ellipse((x - 3, cy - 3, x + 3, cy + 3), fill=cyan)
            label = "IDLE"

        sbox = draw.textbbox((0, 0), label, font=font_state)
        label_color = {
            "idle": "#FFFFFF",
            "running": "#035BFF",
            "done": "#08FF00",
            "approval": "#FF9000",
            "error": "#FF0000",
        }.get(status, cyan)
        draw.text(((size - (sbox[2] - sbox[0])) / 2, 91), label, fill=label_color, font=font_state)

        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
        return f"data:image/png;base64,{encoded}"

    async def _status_image(self, provider: str, status: str, frame: int = 0) -> str:
        asset = STATUS_ANIMATION_ASSETS.get(status)
        frame_count = int(asset["frame_count"]) if asset else 1
        frame = int(frame) % frame_count
        key = (provider, status, frame)
        cached = self._image_cache.get(key)
        if cached is not None:
            return cached
        value = await asyncio.to_thread(self._load_status_asset, status, frame)
        if value is None:
            value = await asyncio.to_thread(self._draw_status_image, provider, status, frame)
        self._image_cache[key] = value
        return value

    async def _set_image(self, context: str, image: str, *, device_only: bool = False) -> None:
        hardware_is_current = self._sent_image_cache.get(context) == image
        preview_is_current = self._sent_preview_image_cache.get(context) == image
        if hardware_is_current and (device_only or preview_is_current):
            return
        state = self.contexts.get(context, {})
        payload = {"image": image, "page": state.get("page")}
        if device_only:
            payload["deviceOnly"] = True
        await self.runner.send_message({
            "event": "setImage",
            "action": str(state.get("action") or "").split("#", 1)[0],
            "context": context,
            "payload": payload,
        })
        self._sent_image_cache[context] = image
        if not device_only:
            self._sent_preview_image_cache[context] = image

    async def _set_status_led(self, context: str, status: str, enabled: bool) -> None:
        rgb = tuple(STATUS_LED_COLORS.get(status, STATUS_LED_COLORS["idle"])) if enabled else (0, 0, 0)
        if self._led_cache.get(context) == rgb:
            return
        # Identify the exact action that owns this context.  On macOS a
        # delayed keyDidDisappear/keyDidAppear pair can leave a stale status
        # context alive briefly after the slot has been reassigned.  The host
        # uses this action id to reject an LED update for a slot that no longer
        # contains this status action.
        action = str(self.contexts.get(context, {}).get("action") or "").split("#", 1)[0]
        await self.runner.send_message({
            "event": "sendToPlugin",
            "action": action,
            "context": context,
            "payload": {"command": "set_key_led_color", "color": list(rgb)},
        })
        self._led_cache[context] = rgb

    async def _animation_loop(self, context: str) -> None:
        frame = 0
        try:
            while context in self.contexts:
                info = self._resolve_status(self.contexts[context])
                if info["state"] not in ANIMATED_MONITOR_STATES:
                    return
                image = await self._status_image(info["provider"], info["state"], frame)
                # The first frame is sent to both surfaces by _refresh_context.
                # Animation frames only need to update the physical key; keeping
                # the desktop preview static avoids needless UI repaints.
                await self._set_image(context, image, device_only=True)
                self._monitor_errors.pop(f"animation:{context}", None)
                asset = STATUS_ANIMATION_ASSETS.get(info["state"], {})
                frame_count = max(1, int(asset.get("frame_count", 1)))
                frame = (frame + 1) % frame_count
                await asyncio.sleep(float(asset.get("delay", 0.1)))
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self._report_monitor_error(f"animation:{context}", exc)
        finally:
            if self.animation_tasks.get(context) is asyncio.current_task():
                self.animation_tasks.pop(context, None)

    def _start_animation(self, context: str) -> None:
        task = self.animation_tasks.get(context)
        if task and not task.done():
            return
        self.animation_tasks[context] = asyncio.create_task(self._animation_loop(context))

    def _stop_animation(self, context: str) -> None:
        task = self.animation_tasks.pop(context, None)
        if task and not task.done():
            task.cancel()

    async def _refresh_context(self, context: str, notify_pi: bool = True) -> None:
        state = self.contexts.get(context)
        if not state:
            return
        action = str(state.get("action") or "").split("#", 1)[0]
        if self._is_voice_action(action):
            await self._refresh_voice_context(context, notify_pi=notify_pi)
            return
        if not self._is_monitor_action(action):
            return

        info = self._resolve_status(state)
        # AI Monitor is image-first. Do not emit a redundant empty setTitle on
        # every refresh: the host used to clear the cached dynamic artwork when
        # processing it, briefly exposing the manifest icon before setImage.
        # New/default titles are already empty in the manifest and inspector.
        await self._set_status_led(context, info["state"], bool(state.get("settings", {}).get("show_led", True)))

        if info["state"] in ANIMATED_MONITOR_STATES:
            # Apply frame 1 synchronously so the manifest placeholder never
            # flashes before the animation task gets its first timeslice.
            image = await self._status_image(info["provider"], info["state"], 0)
            await self._set_image(context, image)
            self._start_animation(context)
        else:
            self._stop_animation(context)
            image = await self._status_image(info["provider"], info["state"])
            await self._set_image(context, image)

        if notify_pi:
            await self._send_monitor_status(context, info)

    async def _refresh_provider_contexts(self, provider: str) -> None:
        for context, state in list(self.contexts.items()):
            if not self._is_monitor_action(state.get("action", "")):
                continue
            if self._provider_for_action(state.get("action", ""), state.get("settings")) == provider:
                try:
                    await self._refresh_context(context)
                    self._monitor_errors.pop(f"display:{context}", None)
                except Exception as exc:
                    self._report_monitor_error(f"display:{context}", exc)

    # ------------------------------------------------------------------
    # Voice actions
    # ------------------------------------------------------------------
    def _load_managed_voice_bindings(self) -> dict[str, str]:
        try:
            value = json.loads(self.voice_binding_state_path.read_text(encoding="utf-8"))
            if isinstance(value, dict):
                bindings = value.get("codex")
                if isinstance(bindings, dict):
                    return {
                        str(command): str(key)
                        for command, key in bindings.items()
                        if command and isinstance(key, str) and key
                    }
        except (OSError, json.JSONDecodeError):
            pass
        return {}

    def _save_managed_voice_bindings(self) -> None:
        payload = {"schema_version": 1, "codex": dict(self._managed_voice_bindings)}
        self._atomic_write_json_value(self.voice_binding_state_path, payload, ".ai-monitor-voice.tmp")

    @staticmethod
    def _atomic_write_json_value(path: Path, data: Any, suffix: str = ".ai-monitor.tmp") -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_name(path.name + suffix)
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temp, path)

    def _codex_keybindings_path(self) -> Path:
        return self._codex_home() / "keybindings.json"

    @staticmethod
    def _load_codex_keybindings(path: Path) -> list[Any]:
        if not path.exists():
            return []
        try:
            value = json.loads(path.read_text(encoding="utf-8-sig"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in {path}: {exc}") from exc
        if not isinstance(value, list):
            raise ValueError(f"Expected a JSON array in {path}")
        return value

    @staticmethod
    def _normalized_shortcut(value: str) -> str:
        return re.sub(r"\s+", "", str(value or "")).lower()

    def _codex_shortcut_candidates(self, command: str) -> list[str]:
        # Preserve an existing user binding. For unassigned commands, use a
        # modified COMBO-X-reserved chord so macOS system F-keys are never used
        # as bare keys. Reasoning commands get mnemonic/arrow candidates first.
        if sys.platform == "darwin":
            prefix = "Command+Option+Shift+"
        else:
            prefix = "Ctrl+Alt+Shift+"
        preferred_primary = {
            "composer.decreaseReasoningEffort": "Down",
            "composer.increaseReasoningEffort": "Up",
        }.get(command)
        candidates = [f"{prefix}{preferred_primary}"] if preferred_primary else []
        candidates.extend(f"{prefix}F{number}" for number in range(13, 25))
        return candidates

    def _migrate_old_global_voice_bindings_sync(self, path: Path, entries: list[Any]) -> list[Any]:
        """Remove only v1.0.7/1.0.8 global bindings that COMBO-X itself created.

        Older AI Monitor builds wrote globalDictationHold/globalDictationToggle.
        They are no longer used because their Electron global-hotkey registration
        is not reliably refreshed by an external JSON edit. Never remove an
        unknown/user binding: command and shortcut must exactly match our saved
        managed state.
        """
        old_commands = ("globalDictationHold", "globalDictationToggle")
        managed_pairs = {
            (cmd, self._managed_voice_bindings.get(cmd, ""))
            for cmd in old_commands
            if self._managed_voice_bindings.get(cmd)
        }
        if not managed_pairs:
            return entries
        filtered = []
        removed = False
        for item in entries:
            if isinstance(item, dict):
                pair = (str(item.get("command") or ""), str(item.get("key") or ""))
                if pair in managed_pairs:
                    removed = True
                    continue
            filtered.append(item)
        if removed:
            self._backup_config(path, "codex-keybindings-v108")
            self._atomic_write_json_value(path, filtered, ".ai-monitor-migrate.tmp")
        for cmd in old_commands:
            self._managed_voice_bindings.pop(cmd, None)
        self._save_managed_voice_bindings()
        return filtered

    def _ensure_codex_shortcut_sync(self, command: str) -> dict[str, Any]:
        path = self._codex_keybindings_path()
        try:
            entries = self._load_codex_keybindings(path)
            entries = self._migrate_old_global_voice_bindings_sync(path, entries)
            assigned: list[str] = []
            for item in entries:
                if not isinstance(item, dict) or str(item.get("command") or "") != command:
                    continue
                key = item.get("key")
                if isinstance(key, str) and key.strip():
                    assigned.append(key.strip())
            if assigned:
                shortcut = assigned[0]
                managed = self._managed_voice_bindings.get(command) == shortcut
                return {
                    "ok": True,
                    "shortcut": shortcut,
                    "source": "combox" if managed else "user",
                    "created": False,
                    "path": str(path),
                    "command": command,
                }

            used = {
                self._normalized_shortcut(str(item.get("key") or ""))
                for item in entries
                if isinstance(item, dict) and isinstance(item.get("key"), str) and item.get("key")
            }
            shortcut = next(
                (candidate for candidate in self._codex_shortcut_candidates(command)
                 if self._normalized_shortcut(candidate) not in used),
                "",
            )
            if not shortcut:
                raise ValueError("No unused COMBO-X shortcut candidate is available")

            updated = False
            new_entries = list(entries)
            for index, item in enumerate(new_entries):
                if not isinstance(item, dict) or str(item.get("command") or "") != command:
                    continue
                key = item.get("key")
                if key is None or (isinstance(key, str) and not key.strip()):
                    replacement = dict(item)
                    replacement["key"] = shortcut
                    new_entries[index] = replacement
                    updated = True
                    break
            if not updated:
                new_entries.append({"command": command, "key": shortcut})

            self._backup_config(path, "codex-keybindings")
            self._atomic_write_json_value(path, new_entries, ".ai-monitor-keybindings.tmp")
            self._managed_voice_bindings[command] = shortcut
            self._save_managed_voice_bindings()
            return {
                "ok": True,
                "shortcut": shortcut,
                "source": "combox",
                "created": True,
                "path": str(path),
                "command": command,
            }
        except (OSError, ValueError) as exc:
            return {
                "ok": False,
                "shortcut": "",
                "source": "",
                "created": False,
                "path": str(path),
                "command": command,
                "error": str(exc),
            }

    @staticmethod
    def _claude_voice_shortcut() -> str:
        if sys.platform == "darwin":
            return "Command+D"
        if sys.platform.startswith("win"):
            return "Ctrl+D"
        return ""

    @staticmethod
    def _parse_shortcut_for_pynput(shortcut: str):
        # Imported lazily so normal status monitoring remains usable even in a
        # stripped test runtime. pynput is part of the COMBO-X Windows/macOS
        # embedded runtime documented by SDK 1.1.0.
        from pynput.keyboard import Key

        tokens = [part.strip() for part in str(shortcut or "").split("+") if part.strip()]
        if not tokens:
            raise ValueError("empty shortcut")
        modifiers = []
        primary = None
        modifier_map = {
            "ctrl": Key.ctrl, "control": Key.ctrl,
            "alt": Key.alt, "option": Key.alt,
            "shift": Key.shift,
            "command": Key.cmd, "cmd": Key.cmd, "meta": Key.cmd, "super": Key.cmd,
            "commandorcontrol": Key.cmd if sys.platform == "darwin" else Key.ctrl,
            "cmdorctrl": Key.cmd if sys.platform == "darwin" else Key.ctrl,
            "leftcontrol": getattr(Key, "ctrl_l", Key.ctrl),
            "rightcontrol": getattr(Key, "ctrl_r", Key.ctrl),
            "leftalt": getattr(Key, "alt_l", Key.alt),
            "rightalt": getattr(Key, "alt_r", Key.alt),
            "leftshift": getattr(Key, "shift_l", Key.shift),
            "rightshift": getattr(Key, "shift_r", Key.shift),
            "leftcommand": getattr(Key, "cmd_l", Key.cmd),
            "rightcommand": getattr(Key, "cmd_r", Key.cmd),
        }
        named_map = {
            "space": Key.space,
            "enter": Key.enter, "return": Key.enter,
            "tab": Key.tab,
            "esc": Key.esc, "escape": Key.esc,
            "backspace": Key.backspace,
            "delete": Key.delete,
            "home": Key.home,
            "end": Key.end,
            "pageup": Key.page_up,
            "pagedown": Key.page_down,
            "up": Key.up, "down": Key.down, "left": Key.left, "right": Key.right,
        }
        for raw in tokens:
            token = raw.replace(" ", "")
            lowered = token.lower()
            if lowered in modifier_map:
                modifiers.append(modifier_map[lowered])
                continue
            if primary is not None:
                raise ValueError(f"unsupported multi-key shortcut: {shortcut}")
            if lowered in named_map:
                primary = named_map[lowered]
            elif re.fullmatch(r"f(?:[1-9]|1[0-9]|2[0-4])", lowered):
                primary = getattr(Key, lowered)
            elif len(token) == 1:
                primary = token.lower()
            else:
                raise ValueError(f"unsupported shortcut key: {raw}")
        if primary is None:
            raise ValueError(f"shortcut has no primary key: {shortcut}")
        return [*modifiers, primary]

    @classmethod
    def _press_shortcut_sync(cls, shortcut: str) -> None:
        from pynput.keyboard import Controller
        controller = Controller()
        keys = cls._parse_shortcut_for_pynput(shortcut)
        pressed = []
        try:
            for key in keys:
                controller.press(key)
                pressed.append(key)
        except Exception:
            for key in reversed(pressed):
                try:
                    controller.release(key)
                except Exception:
                    pass
            raise

    @classmethod
    def _release_shortcut_sync(cls, shortcut: str) -> None:
        from pynput.keyboard import Controller
        controller = Controller()
        keys = cls._parse_shortcut_for_pynput(shortcut)
        first_error = None
        for key in reversed(keys):
            try:
                controller.release(key)
            except Exception as exc:
                if first_error is None:
                    first_error = exc
        if first_error is not None:
            raise first_error

    @classmethod
    def _tap_shortcut_sync(cls, shortcut: str) -> None:
        cls._press_shortcut_sync(shortcut)
        try:
            time.sleep(0.04)
        finally:
            cls._release_shortcut_sync(shortcut)

    @staticmethod
    def _windows_window_identity(hwnd) -> tuple[str, str, str]:
        import win32gui
        import win32process

        title = str(win32gui.GetWindowText(hwnd) or "")
        process_name = ""
        executable = ""
        try:
            _thread_id, process_id = win32process.GetWindowThreadProcessId(hwnd)
            try:
                import psutil
                process = psutil.Process(process_id)
                process_name = str(process.name() or "")
                executable = str(process.exe() or "")
            except Exception:
                import win32api
                import win32con
                process_handle = win32api.OpenProcess(
                    win32con.PROCESS_QUERY_INFORMATION | win32con.PROCESS_VM_READ,
                    False,
                    process_id,
                )
                try:
                    executable = str(win32process.GetModuleFileNameEx(process_handle, 0) or "")
                    process_name = Path(executable).name
                finally:
                    process_handle.Close()
        except Exception:
            pass
        return title, process_name, executable

    @staticmethod
    def _activate_windows_window_sync(hwnd: int) -> None:
        """Bring a window to the foreground and verify Windows accepted it."""
        import ctypes
        import win32con
        import win32gui

        hwnd = int(hwnd or 0)
        if not hwnd or not win32gui.IsWindow(hwnd):
            raise RuntimeError("target window is no longer available")

        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32

        if win32gui.IsIconic(hwnd):
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
        else:
            win32gui.ShowWindow(hwnd, win32con.SW_SHOW)

        def is_foreground(wait_seconds: float) -> bool:
            deadline = time.monotonic() + wait_seconds
            while time.monotonic() < deadline:
                if int(win32gui.GetForegroundWindow() or 0) == hwnd:
                    return True
                time.sleep(0.02)
            return int(win32gui.GetForegroundWindow() or 0) == hwnd

        if int(win32gui.GetForegroundWindow() or 0) == hwnd:
            return

        # A background process may be denied by SetForegroundWindow and Windows
        # merely flashes its taskbar icon. Joining the relevant input queues
        # temporarily gives the activation request the same input context.
        current_thread = int(kernel32.GetCurrentThreadId() or 0)
        foreground = int(win32gui.GetForegroundWindow() or 0)
        foreground_thread = int(user32.GetWindowThreadProcessId(foreground, None) or 0)
        target_thread = int(user32.GetWindowThreadProcessId(hwnd, None) or 0)
        attached: list[int] = []
        try:
            for thread_id in (foreground_thread, target_thread):
                if thread_id and thread_id != current_thread and thread_id not in attached:
                    if user32.AttachThreadInput(current_thread, thread_id, True):
                        attached.append(thread_id)
            win32gui.BringWindowToTop(hwnd)
            win32gui.SetForegroundWindow(hwnd)
            user32.SetActiveWindow(hwnd)
            user32.SetFocus(hwnd)
        except Exception:
            pass
        finally:
            for thread_id in reversed(attached):
                user32.AttachThreadInput(current_thread, thread_id, False)

        if is_foreground(0.25):
            return

        # Pressing and releasing Alt opens the foreground gate for this process
        # on Windows versions that still reject the attached-thread attempt.
        vk_menu = 0x12
        keyeventf_keyup = 0x0002
        try:
            user32.keybd_event(vk_menu, 0, 0, 0)
            user32.keybd_event(vk_menu, 0, keyeventf_keyup, 0)
            win32gui.SetForegroundWindow(hwnd)
        except Exception:
            pass
        if is_foreground(0.30):
            return

        try:
            user32.SwitchToThisWindow(hwnd, True)
        except Exception:
            pass
        if not is_foreground(0.25):
            raise RuntimeError("Windows blocked the target app from receiving focus")

    @classmethod
    def _focus_target_app_sync(cls, provider: str) -> dict[str, Any]:
        """Activate the requested desktop app and leave it in the foreground."""
        provider = "claude" if str(provider).lower() == "claude" else "codex"
        if sys.platform.startswith("win"):
            import win32con
            import win32gui

            candidates: list[tuple[int, int]] = []

            def collect(hwnd, _extra):
                if not win32gui.IsWindowVisible(hwnd):
                    return
                title, process_name, executable = cls._windows_window_identity(hwnd)
                lowered_title = title.lower()
                lowered_name = process_name.lower()
                lowered_executable = executable.lower()
                class_name = str(win32gui.GetClassName(hwnd) or "")
                score = 0
                if provider == "codex":
                    if "openai.codex_" in lowered_executable:
                        score = 400
                    elif "codex" in lowered_name or "codex" in lowered_executable:
                        score = 300
                    elif "codex" in lowered_title and class_name == "Chrome_WidgetWin_1":
                        score = 150
                else:
                    if "claude" in lowered_name or "claude" in lowered_executable:
                        score = 400
                    elif "claude" in lowered_title and class_name == "Chrome_WidgetWin_1":
                        score = 150
                if score:
                    candidates.append((score, int(hwnd)))

            win32gui.EnumWindows(collect, None)
            if not candidates:
                raise RuntimeError(f"{provider.title()} desktop window was not found")
            target = max(candidates, key=lambda item: item[0])[1]
            cls._activate_windows_window_sync(target)
            time.sleep(0.08)
            return {"platform": "windows", "target": target}

        if sys.platform == "darwin":
            app_names = ["Claude", "Claude Code"] if provider == "claude" else ["Codex", "ChatGPT"]
            apple_list = "{" + ", ".join(json.dumps(name) for name in app_names) + "}"
            activate_script = f'''
tell application "System Events"
    repeat with candidateName in {apple_list}
        set appName to candidateName as text
        if exists application process appName then
            set frontmost of application process appName to true
            return appName
        end if
    end repeat
    error "{provider.title()} desktop window was not found"
end tell
'''
            result = subprocess.run(
                ["osascript", "-e", activate_script],
                capture_output=True,
                text=True,
                timeout=3,
            )
            if result.returncode != 0:
                raise RuntimeError(result.stderr.strip() or f"{provider.title()} desktop window was not found")
            time.sleep(0.18)
            return {
                "platform": "macos",
                "target": result.stdout.strip(),
            }

        raise RuntimeError("Automatic app focus is supported only on Windows and macOS")

    @classmethod
    def _run_shortcut_with_focus_sync(cls, provider: str, operation, shortcut: str) -> None:
        cls._focus_target_app_sync(provider)
        operation(shortcut)

    @classmethod
    def _tap_shortcut_with_focus_sync(cls, provider: str, shortcut: str) -> None:
        cls._run_shortcut_with_focus_sync(provider, cls._tap_shortcut_sync, shortcut)

    @classmethod
    def _press_shortcut_with_focus_sync(cls, provider: str, shortcut: str) -> None:
        cls._run_shortcut_with_focus_sync(provider, cls._press_shortcut_sync, shortcut)

    @classmethod
    def _release_shortcut_with_focus_sync(cls, provider: str, shortcut: str) -> None:
        cls._run_shortcut_with_focus_sync(provider, cls._release_shortcut_sync, shortcut)

    @staticmethod
    def _joystick_direction(context: str) -> str:
        suffix = str(context or "").split(":", 1)[-1]
        return suffix if suffix in {"joystick_up", "joystick_down", "joystick_left", "joystick_right"} else ""

    @classmethod
    def _opposite_joystick_context(cls, context: str) -> str | None:
        direction = cls._joystick_direction(context)
        opposite = {
            "joystick_up": "joystick_down",
            "joystick_down": "joystick_up",
            "joystick_left": "joystick_right",
            "joystick_right": "joystick_left",
        }.get(direction)
        if not opposite:
            return None
        prefix = str(context).split(":", 1)[0] if ":" in str(context) else ""
        return f"{prefix}:{opposite}" if prefix else opposite

    @staticmethod
    def _draw_voice_image(provider: str, mode: str, active: bool = False) -> str:
        size = 112
        cyan = "#0CC7D5"
        muted = "#A5B1B6"
        image = Image.new("RGB", (size, size), "white")
        draw = ImageDraw.Draw(image)
        font_small = ImageFont.load_default(size=12)
        font_mode = ImageFont.load_default(size=11)
        provider_label = "CODEX" if provider == "codex" else "CLAUDE"
        pbox = draw.textbbox((0, 0), provider_label, font=font_small)
        draw.text(((size - (pbox[2] - pbox[0])) / 2, 7), provider_label, fill=cyan, font=font_small)

        outline = cyan if active else muted
        fill = "#E9FCFD" if active else "white"
        draw.rounded_rectangle((44, 28, 68, 62), radius=11, outline=outline, fill=fill, width=4)
        draw.arc((36, 43, 76, 75), 0, 180, fill=cyan, width=4)
        draw.line((56, 74, 56, 83), fill=cyan, width=4)
        draw.line((46, 83, 66, 83), fill=cyan, width=4)
        label = {"ptt": "PTT", "toggle": "VOICE", "claude": "VOICE"}.get(mode, "VOICE")
        if active and mode == "ptt":
            label = "TALK"
        box = draw.textbbox((0, 0), label, font=font_mode)
        draw.text(((size - (box[2] - box[0])) / 2, 92), label, fill=cyan, font=font_mode)
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
        return f"data:image/png;base64,{encoded}"

    async def _voice_image(self, provider: str, mode: str, active: bool = False) -> str:
        key = (f"voice:{provider}:{mode}", "active" if active else "idle", 0)
        cached = self._image_cache.get(key)
        if cached is not None:
            return cached
        value = await asyncio.to_thread(self._draw_voice_image, provider, mode, active)
        self._image_cache[key] = value
        return value

    def _voice_mode_for_action(self, action: str) -> str:
        action = str(action or "").split("#", 1)[0]
        if action == CODEX_PTT_ACTION:
            return "ptt"
        if action == CODEX_VOICE_TOGGLE_ACTION:
            return "toggle"
        return "claude"

    async def _resolve_voice_action(self, state: dict[str, Any]) -> dict[str, Any]:
        action = str(state.get("action") or "").split("#", 1)[0]
        provider = self._provider_for_action(action, state.get("settings"))
        if action in CODEX_VOICE_COMMANDS:
            command = CODEX_VOICE_COMMANDS[action]
            async with self._voice_config_lock:
                result = await asyncio.to_thread(self._ensure_codex_shortcut_sync, command)
            return {**result, "provider": provider, "action_kind": self._action_kind_for_action(action)}
        if action == CLAUDE_VOICE_ACTION:
            shortcut = self._claude_voice_shortcut()
            if not shortcut:
                return {
                    "ok": False,
                    "shortcut": "",
                    "source": "builtin",
                    "created": False,
                    "path": "",
                    "command": "claudeDesktopDictation",
                    "provider": "claude",
                    "action_kind": self._action_kind_for_action(action),
                    "error": "Unsupported platform",
                }
            return {
                "ok": True,
                "shortcut": shortcut,
                "source": "builtin",
                "created": False,
                "path": "",
                "command": "claudeDesktopDictation",
                "provider": "claude",
                "action_kind": self._action_kind_for_action(action),
            }
        return {"ok": False, "error": "Unknown voice action", "provider": provider, "action_kind": ""}

    async def _resolve_reasoning_action(self, state: dict[str, Any]) -> dict[str, Any]:
        action = str(state.get("action") or "").split("#", 1)[0]
        command = CODEX_REASONING_COMMANDS.get(action, "")
        if not command:
            return {"ok": False, "error": "Unknown reasoning action", "provider": "codex", "action_kind": ""}
        async with self._voice_config_lock:
            result = await asyncio.to_thread(self._ensure_codex_shortcut_sync, command)
        return {**result, "provider": "codex", "action_kind": self._action_kind_for_action(action)}

    async def _send_voice_status(self, context: str, result: dict[str, Any]) -> None:
        state = self.contexts.get(context, {})
        settings = state.get("settings", {})
        source = str(result.get("source") or "")
        shortcut = str(result.get("shortcut") or "")
        if result.get("ok"):
            if source == "builtin":
                message = self._t(settings, "VOICE_SHORTCUT_BUILTIN", "Using built-in shortcut {shortcut}.", shortcut=shortcut)
            elif result.get("created"):
                message = self._t(
                    settings,
                    "VOICE_SHORTCUT_CREATED",
                    "COMBO-X added {shortcut} to {path}.",
                    shortcut=shortcut,
                    path=str(result.get("path") or ""),
                )
            else:
                message = self._t(settings, "VOICE_SHORTCUT_EXISTING", "Using shortcut {shortcut}.", shortcut=shortcut)
        else:
            message = self._t(
                settings,
                "VOICE_CONFIG_ERROR",
                "Voice shortcut setup failed: {error}",
                error=str(result.get("error") or "Unknown error"),
            )
        await self._send_to_pi(context, {
            "command": "voice_status",
            "ok": bool(result.get("ok")),
            "provider": str(result.get("provider") or ""),
            "action_kind": str(result.get("action_kind") or ""),
            "shortcut": shortcut,
            "source": source,
            "shortcut_command": str(result.get("command") or ""),
            "config_path": str(result.get("path") or ""),
            "created": bool(result.get("created")),
            "message": message,
        })

    async def _send_reasoning_status(self, context: str, result: dict[str, Any]) -> None:
        state = self.contexts.get(context, {})
        settings = state.get("settings", {})
        source = str(result.get("source") or "")
        shortcut = str(result.get("shortcut") or "")
        if result.get("ok"):
            if result.get("created"):
                message = self._t(
                    settings,
                    "REASONING_SHORTCUT_CREATED",
                    "COMBO-X added {shortcut} to {path}.",
                    shortcut=shortcut,
                    path=str(result.get("path") or ""),
                )
            else:
                message = self._t(
                    settings,
                    "REASONING_SHORTCUT_EXISTING",
                    "Using existing Codex shortcut {shortcut}.",
                    shortcut=shortcut,
                )
        else:
            message = self._t(
                settings,
                "REASONING_CONFIG_ERROR",
                "Reasoning shortcut setup failed: {error}",
                error=str(result.get("error") or "Unknown error"),
            )
        await self._send_to_pi(context, {
            "command": "reasoning_status",
            "ok": bool(result.get("ok")),
            "provider": "codex",
            "action_kind": str(result.get("action_kind") or ""),
            "shortcut": shortcut,
            "source": source,
            "shortcut_command": str(result.get("command") or ""),
            "config_path": str(result.get("path") or ""),
            "created": bool(result.get("created")),
            "message": message,
        })

    async def _refresh_reasoning_context(self, context: str, notify_pi: bool = True) -> dict[str, Any] | None:
        state = self.contexts.get(context)
        if not state or not self._is_reasoning_action(state.get("action", "")):
            return None
        self._stop_animation(context)
        result = await self._resolve_reasoning_action(state)
        self._voice_shortcut_cache[context] = dict(result)
        if notify_pi:
            await self._send_reasoning_status(context, result)
        return result

    async def _refresh_voice_context(self, context: str, notify_pi: bool = True) -> dict[str, Any] | None:
        """Resolve/cache a Voice shortcut without touching COMBO-X visuals.

        Voice actions use their manifest action icon.  In v1.0.8 they also sent
        setTitle/setImage (and persisted derived settings) whenever a placement
        appeared or received settings.  During the host's full device sync those
        visual messages were deferred while the 0xAB background transfer was
        waiting for its ACK, which could destabilize the initial sync.

        Keep Voice configuration completely off the device-visual/USB path:
        only inspect/prepare the desktop shortcut and optionally report it to
        Property Inspector.  Status actions retain the proven v1.0.6 dynamic
        artwork behavior.
        """
        state = self.contexts.get(context)
        if not state or not self._is_voice_action(state.get("action", "")):
            return None
        self._stop_animation(context)
        result = await self._resolve_voice_action(state)
        self._voice_shortcut_cache[context] = dict(result)
        if notify_pi:
            await self._send_voice_status(context, result)
        return result

    async def _voice_hold_watchdog(self, context: str) -> None:
        try:
            while context in self._voice_held:
                runtime = self._voice_held[context]
                timeout = 0.18 if runtime.get("repeat_seen") else 0.65
                remaining = timeout - (time.monotonic() - float(runtime.get("last_down") or 0))
                if remaining <= 0:
                    await self._release_voice_hold(context, "heartbeat_timeout")
                    return
                await asyncio.sleep(min(0.05, remaining))
        except asyncio.CancelledError:
            pass

    async def _release_voice_hold(self, context: str, reason: str) -> None:
        runtime = self._voice_held.pop(context, None)
        task = self._voice_hold_watchdogs.pop(context, None)
        current = asyncio.current_task()
        if task and task is not current and not task.done():
            task.cancel()
        if not runtime:
            return
        shortcut = str(runtime.get("shortcut") or "")
        provider = str(runtime.get("provider") or "codex")
        try:
            if shortcut:
                await asyncio.to_thread(self._release_shortcut_with_focus_sync, provider, shortcut)
        except Exception as exc:
            state = self.contexts.get(context, {})
            settings = state.get("settings", {})
            await self._send_to_pi(context, {
                "command": "voice_error",
                "message": self._t(settings, "VOICE_SEND_ERROR", "Could not send voice shortcut: {error}", error=str(exc)),
            })
        # Voice actions intentionally do not send setImage/setTitle here.
        # Their static manifest icon remains on the button, keeping PTT release
        # independent from device synchronization and dynamic-icon transfers.

    async def _release_voice_toggle(self, context: str, reason: str) -> None:
        runtime = self._voice_toggle_held.pop(context, None)
        if not runtime:
            return
        shortcut = str(runtime.get("shortcut") or "")
        provider = str(runtime.get("provider") or "codex")
        try:
            if shortcut:
                await asyncio.to_thread(self._release_shortcut_with_focus_sync, provider, shortcut)
        except Exception as exc:
            state = self.contexts.get(context, {})
            settings = state.get("settings", {})
            await self._send_to_pi(context, {
                "command": "voice_error",
                "message": self._t(settings, "VOICE_SEND_ERROR", "Could not send voice shortcut: {error}", error=str(exc)),
            })

    async def _handle_voice_down(self, context: str, state: dict[str, Any]) -> None:
        action = str(state.get("action") or "").split("#", 1)[0]
        if action == CODEX_PTT_ACTION:
            opposite_context = self._opposite_joystick_context(context)
            if opposite_context and opposite_context in self._voice_held:
                await self._release_voice_hold(opposite_context, "opposite_direction")

            now = time.monotonic()
            runtime = self._voice_held.get(context)
            if runtime:
                runtime["repeat_seen"] = True
                runtime["last_down"] = now
                return

            result = self._voice_shortcut_cache.get(context)
            if not result or not result.get("ok"):
                result = await self._resolve_voice_action(state)
                self._voice_shortcut_cache[context] = dict(result)
            if not result.get("ok"):
                await self._send_voice_status(context, result)
                return
            shortcut = str(result.get("shortcut") or "")
            provider = str(result.get("provider") or "codex")
            try:
                await asyncio.to_thread(self._press_shortcut_with_focus_sync, provider, shortcut)
            except Exception as exc:
                result = dict(result)
                result.update({"ok": False, "error": str(exc)})
                await self._send_voice_status(context, result)
                return

            self._voice_held[context] = {
                "shortcut": shortcut,
                "provider": provider,
                "last_down": now,
                "repeat_seen": False,
                "reason": "keyDown",
            }
            if self._joystick_direction(context):
                self._voice_hold_watchdogs[context] = asyncio.create_task(self._voice_hold_watchdog(context))
            # No dynamic setImage on press: the Voice actions deliberately stay
            # off the device visual-transfer path.
            return

        if action == CODEX_VOICE_TOGGLE_ACTION:
            # Codex's app-scoped composer.startDictation is hold-to-dictate in
            # current builds. Emulate a toggle by keeping that key logically down
            # after the first COMBO-X click and releasing it on the next click.
            # Hardware key repeat is suppressed until the physical keyUp arrives.
            if context in self._voice_tap_down:
                return
            self._voice_tap_down.add(context)
            if context in self._voice_toggle_held:
                await self._release_voice_toggle(context, "toggle_off")
                return
            result = self._voice_shortcut_cache.get(context)
            if not result or not result.get("ok"):
                result = await self._resolve_voice_action(state)
                self._voice_shortcut_cache[context] = dict(result)
            if not result.get("ok"):
                await self._send_voice_status(context, result)
                return
            shortcut = str(result.get("shortcut") or "")
            provider = str(result.get("provider") or "codex")
            try:
                await asyncio.to_thread(self._press_shortcut_with_focus_sync, provider, shortcut)
            except Exception as exc:
                result = dict(result)
                result.update({"ok": False, "error": str(exc)})
                await self._send_voice_status(context, result)
                return
            self._voice_toggle_held[context] = {
                "shortcut": shortcut, "provider": provider, "started": time.monotonic()
            }
            return

        if action == CLAUDE_VOICE_ACTION:
            if context in self._voice_tap_down:
                return
            self._voice_tap_down.add(context)
            result = self._voice_shortcut_cache.get(context)
            if not result or not result.get("ok"):
                result = await self._resolve_voice_action(state)
                self._voice_shortcut_cache[context] = dict(result)
            if not result.get("ok"):
                await self._send_voice_status(context, result)
                return
            shortcut = str(result.get("shortcut") or "")
            provider = str(result.get("provider") or "claude")
            try:
                await asyncio.to_thread(self._tap_shortcut_with_focus_sync, provider, shortcut)
            except Exception as exc:
                result = dict(result)
                result.update({"ok": False, "error": str(exc)})
                await self._send_voice_status(context, result)
                return

    async def _handle_voice_up(self, context: str, state: dict[str, Any]) -> None:
        action = str(state.get("action") or "").split("#", 1)[0]
        if action == CODEX_PTT_ACTION:
            await self._release_voice_hold(context, "keyUp")
        self._voice_tap_down.discard(context)

    async def _handle_reasoning_down(self, context: str, state: dict[str, Any]) -> None:
        # Reasoning changes are one-shot actions. Suppress firmware/key-repeat
        # keyDown events until the matching physical keyUp arrives.
        if context in self._reasoning_tap_down:
            return
        self._reasoning_tap_down.add(context)
        result = self._voice_shortcut_cache.get(context)
        if not result or not result.get("ok"):
            result = await self._resolve_reasoning_action(state)
            self._voice_shortcut_cache[context] = dict(result)
        if not result.get("ok"):
            await self._send_reasoning_status(context, result)
            return
        shortcut = str(result.get("shortcut") or "")
        provider = str(result.get("provider") or "codex")
        try:
            await asyncio.to_thread(self._tap_shortcut_with_focus_sync, provider, shortcut)
        except Exception as exc:
            result = dict(result)
            result.update({"ok": False, "error": str(exc)})
            await self._send_reasoning_status(context, result)

    async def _handle_reasoning_up(self, context: str) -> None:
        self._reasoning_tap_down.discard(context)

    async def _handle_generic_key_down(self, context: str, state: dict[str, Any]) -> None:
        # Confirm/Cancel are one-shot keys sent to this action's provider.
        # Suppress repeats until the matching physical keyUp arrives.
        if context in self._generic_key_tap_down:
            return
        action = str(state.get("action") or "").split("#", 1)[0]
        shortcut = GENERIC_KEY_SHORTCUTS.get(action, "")
        if not shortcut:
            return
        self._generic_key_tap_down.add(context)
        provider = self._provider_for_action(action, state.get("settings", {}))
        try:
            await asyncio.to_thread(self._tap_shortcut_with_focus_sync, provider, shortcut)
        except Exception as exc:
            print(f"[AI Monitor] Could not send {shortcut}: {exc}", file=sys.stderr, flush=True)

    async def _handle_generic_key_up(self, context: str) -> None:
        self._generic_key_tap_down.discard(context)

    # ------------------------------------------------------------------
    # Hook event inbox
    # ------------------------------------------------------------------
    def _write_hook_helpers(self) -> None:
        ps1 = self.data_dir / "ai_monitor_hook.ps1"
        ps1.write_text(
            r'''param([Parameter(Mandatory=$true)][string]$Provider)
$ErrorActionPreference = "SilentlyContinue"
$base = Join-Path $PSScriptRoot "events"
$dir = Join-Path $base $Provider
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$raw = [Console]::In.ReadToEnd()
if ([string]::IsNullOrWhiteSpace($raw)) { exit 0 }
$name = ('{0}_{1}' -f ([DateTime]::UtcNow.Ticks), ([Guid]::NewGuid().ToString("N")))
$tmp = Join-Path $dir ($name + ".tmp")
$final = Join-Path $dir ($name + ".json")
[IO.File]::WriteAllText($tmp, $raw, (New-Object Text.UTF8Encoding($false)))
Move-Item -LiteralPath $tmp -Destination $final -Force
exit 0
''',
            encoding="utf-8",
        )
        sh = self.data_dir / "ai_monitor_hook.sh"
        sh.write_text(
            '''#!/bin/sh
set +e
provider="$1"
script_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)" || exit 0
root="$script_dir/events/$provider"
mkdir -p "$root" || exit 0
tmp="$(mktemp "$root/event.XXXXXX")" || exit 0
cat > "$tmp"
mv "$tmp" "$tmp.json"
exit 0
''',
            encoding="utf-8",
        )
        try:
            sh.chmod(0o700)
        except OSError:
            pass

    def _event_folder(self, provider: str) -> Path:
        folder = self.events_dir / provider
        folder.mkdir(parents=True, exist_ok=True)
        return folder

    def _read_event_batch_sync(self) -> list[tuple[str, dict[str, Any], float]]:
        batch: list[tuple[str, dict[str, Any], float]] = []
        inboxes = [(provider, self._event_folder(provider)) for provider in ENABLED_PROVIDERS]
        # Store-installed Claude can redirect its subprocess AppData writes into
        # the package cache. Read that inbox as well as the ordinary host inbox.
        for app_root in self._claude_app_roots():
            if "LocalCache" in app_root.parts:
                folder = app_root.parent / "CookieDeck" / "com_user_ai_monitor" / "events" / "claude"
                if folder.is_dir():
                    inboxes.append(("claude", folder))
        for provider, folder in inboxes:
            candidates = []
            try:
                candidates = sorted(folder.glob("*.json"), key=lambda p: p.stat().st_mtime)
            except OSError:
                continue
            for path in candidates[:200]:
                try:
                    mtime = path.stat().st_mtime
                    event = json.loads(path.read_text(encoding="utf-8-sig"))
                    # Files left in the hook inbox by an earlier COMBO-X process
                    # are historical. Consume them, but never revive RUNNING on
                    # a fresh launch from their stale contents.
                    if isinstance(event, dict) and mtime + 1.0 >= self._runtime_started_at:
                        batch.append((provider, event, mtime))
                    path.unlink(missing_ok=True)
                except (OSError, json.JSONDecodeError):
                    try:
                        bad = path.with_suffix(path.suffix + ".bad")
                        os.replace(path, bad)
                    except OSError:
                        pass
        batch.sort(key=lambda item: item[2])
        return batch

    def _codex_home(self) -> Path:
        return Path(os.environ.get("CODEX_HOME") or (Path.home() / ".codex"))

    def _read_jsonl_lines(self, path: Path, offsets: dict[str, int], tail_bytes: int):
        """Tail complete records only; never commit the offset of a partial write.

        Also bound work for large tool/document records and resume at the next
        newline after an oversized record. Both providers use this same reader.
        """
        key = str(path)
        stat = path.stat()
        size = stat.st_size
        identity = (stat.st_dev, stat.st_ino)
        previous = offsets.get(key)
        replaced = key in self._jsonl_file_ids and self._jsonl_file_ids[key] != identity
        self._jsonl_file_ids[key] = identity
        if replaced or (previous is not None and previous > size):
            previous = 0
            self._jsonl_discarding.discard(key)
        first_seen = previous is None
        if first_seen:
            previous = max(0, size - tail_bytes)
            self._jsonl_discarding.discard(key)
        offsets[key] = previous
        lines = []
        limit = 2 * 1024 * 1024
        budget = 4 * 1024 * 1024
        with path.open("rb") as handle:
            if first_seen and previous:
                handle.seek(previous - 1)
                if handle.read(1) != b"\n":
                    self._jsonl_discarding.add(key)
            handle.seek(previous)
            consumed = 0
            while handle.tell() < size and consumed < budget:
                start = handle.tell()
                raw = handle.readline(min(limit + 1, size - start))
                if not raw:
                    break
                consumed += len(raw)
                complete = raw.endswith(b"\n")
                if key in self._jsonl_discarding or len(raw) > limit:
                    offsets[key] = handle.tell()
                    if complete:
                        self._jsonl_discarding.discard(key)
                    else:
                        self._jsonl_discarding.add(key)
                    continue
                if not complete:
                    # Retry this record from its start on the next poll, including
                    # UTF-8 characters split between two writes.
                    offsets[key] = start
                    break
                offsets[key] = handle.tell()
                lines.append(raw)
        return stat, lines

    @staticmethod
    def _codex_session_id_from_rollout(path: Path) -> str:
        match = CODEX_SESSION_ID_RE.search(path.name)
        return match.group(1) if match else ""

    @staticmethod
    def _rollout_timestamp(record: dict[str, Any], payload: dict[str, Any], fallback: float) -> float:
        """Return a sortable timestamp for one rollout lifecycle record.

        Newer Codex builds include started_at/completed_at Unix seconds on lifecycle
        records. Older builds reliably include an ISO-8601 top-level timestamp.
        File mtime is only a final fallback because every record in a file shares it.
        """
        for key in ("completed_at", "started_at"):
            value = payload.get(key)
            if isinstance(value, (int, float)) and value > 0:
                return float(value)

        raw = record.get("timestamp")
        if isinstance(raw, (int, float)) and raw > 0:
            return float(raw)
        if isinstance(raw, str) and raw.strip():
            text = raw.strip()
            if text.endswith("Z"):
                text = text[:-1] + "+00:00"
            try:
                return datetime.fromisoformat(text).timestamp()
            except ValueError:
                pass
        return float(fallback)

    def _latest_codex_lifecycle_from_rollout_sync(
        self, path: Path, max_scan_bytes: int = 64 * 1024 * 1024
    ) -> tuple[dict[str, Any], float] | None:
        """Find the newest status transition without replaying a huge rollout.

        Long-lived Codex Desktop tasks can produce rollout files hundreds of
        megabytes large. Reading forward from a small tail misses task_started
        whenever large tool outputs follow it. A read-only mmap lets us walk
        complete JSONL records backwards and stop at the first lifecycle event.
        """
        try:
            stat = path.stat()
            if stat.st_size <= 0:
                return None
            session_id = self._codex_session_id_from_rollout(path)
            if not session_id:
                return None
            with path.open("rb") as handle, mmap.mmap(
                handle.fileno(), 0, access=mmap.ACCESS_READ
            ) as mapped:
                position = len(mapped)
                lower_bound = max(0, position - int(max_scan_bytes))
                while position > lower_bound:
                    # Ignore the newline immediately before the current record.
                    end = position
                    while end > lower_bound and mapped[end - 1] in (10, 13):
                        end -= 1
                    if end <= lower_bound:
                        break
                    newline = mapped.rfind(b"\n", lower_bound, end)
                    start = newline + 1
                    position = newline if newline >= 0 else lower_bound
                    if end - start > 2 * 1024 * 1024:
                        continue
                    raw = mapped[start:end]
                    if not any(marker in raw for marker in (
                        b'"task_started"', b'"turn_started"',
                        b'"task_complete"', b'"turn_complete"',
                        b'"turn_aborted"', b'"task_failed"',
                        b'"turn_failed"', b'"stream_error"',
                        b'"function_call"', b'"custom_tool_call"',
                        b'"function_call_output"', b'"custom_tool_call_output"',
                    )):
                        continue
                    try:
                        record = json.loads(raw.decode("utf-8", errors="replace"))
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        continue
                    if not isinstance(record, dict):
                        continue
                    record_type = str(record.get("type") or "")
                    payload = record.get("payload")
                    if not isinstance(payload, dict):
                        continue
                    state_value = ""
                    event_type = ""
                    if record_type == "response_item":
                        state_value, event_type, _pending = self._codex_response_item_transition(
                            payload, False
                        )
                    else:
                        event_type = (
                            str(payload.get("type") or "")
                            if record_type == "event_msg"
                            else record_type
                        )
                        state_value = CODEX_ROLLOUT_STATE_BY_EVENT.get(event_type, "")
                    if not state_value:
                        continue
                    timestamp = self._rollout_timestamp(record, payload, stat.st_mtime)
                    return ({
                        "session_id": session_id,
                        "state": state_value,
                        "event_name": event_type,
                        "turn_id": str(payload.get("turn_id") or ""),
                    }, timestamp)
        except (OSError, ValueError):
            return None
        return None

    def _recover_recent_codex_state_at_startup_sync(self) -> None:
        """Recover an in-flight turn that started while the runner was loading."""
        root = self._codex_home() / "sessions"
        if not root.is_dir():
            return
        try:
            paths = list(root.rglob("rollout-*.jsonl"))
            paths.sort(key=lambda item: item.stat().st_mtime, reverse=True)
        except OSError:
            return
        cutoff = self._runtime_started_at - STARTUP_TRANSCRIPT_RECOVERY_SECONDS
        recovered: list[tuple[dict[str, Any], float, Path]] = []
        for path in paths[:20]:
            try:
                if path.stat().st_mtime < cutoff:
                    break
            except OSError:
                continue
            item = self._latest_codex_lifecycle_from_rollout_sync(path)
            if item is not None:
                recovered.append((item[0], item[1], path))
        if not recovered:
            return
        event, event_time, path = max(recovered, key=lambda item: item[1])
        if str(event.get("state") or "") != "running":
            return
        if self._apply_state_event(
            "codex",
            str(event.get("session_id") or ""),
            str(event.get("state") or ""),
            str(event.get("event_name") or ""),
            event_time,
            turn_id=str(event.get("turn_id") or ""),
            source="rollout",
            transcript_path=str(path),
        ):
            self._state_dirty = True

    def _read_codex_rollout_events_sync(self) -> list[tuple[dict[str, Any], float]]:
        """Read new Codex rollout lifecycle records as a Desktop/CLI fallback.

        Codex's public hook API remains the preferred path. The local rollout files
        are read-only and are used because current Windows Desktop builds can
        discover/trust a command hook yet fail to launch its command process.
        """
        root = self._codex_home() / "sessions"
        if not root.is_dir():
            return []

        try:
            paths = list(root.rglob("rollout-*.jsonl"))
        except OSError:
            return []

        # Process recently touched files first. Limit work per polling pass while
        # still retaining offsets for resumed older sessions.
        try:
            paths.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        except OSError:
            pass
        paths = paths[:200]

        events: list[tuple[dict[str, Any], float]] = []
        for path in paths:
            session_id = self._codex_session_id_from_rollout(path)
            if not session_id:
                continue
            key = str(path)
            try:
                stat, lines = self._read_jsonl_lines(path, self._codex_rollout_offsets, 512 * 1024)
            except OSError:
                continue

            current_session = self._ensure_provider_state("codex")["sessions"].get(session_id, {})
            approval_pending = str((current_session or {}).get("state") or "") == "approval"

            for raw_line in lines:
                if not raw_line.strip():
                    continue
                try:
                    record = json.loads(raw_line.decode("utf-8", errors="replace"))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    continue
                if not isinstance(record, dict):
                    continue

                record_type = str(record.get("type") or "")
                payload = record.get("payload")
                if record_type == "session_meta" and isinstance(payload, dict):
                    # Some builds expose cwd here. Keep it as metadata even though
                    # it is not itself a status transition.
                    pstate = self._ensure_provider_state("codex")
                    sess = pstate["sessions"].setdefault(session_id, {})
                    cwd = str(payload.get("cwd") or "")
                    if cwd:
                        sess["cwd"] = cwd
                    continue
                if not isinstance(payload, dict):
                    continue

                if record_type == "response_item":
                    state_value, event_type, approval_pending = self._codex_response_item_transition(
                        payload, approval_pending
                    )
                    if state_value:
                        timestamp = self._rollout_timestamp(record, payload, stat.st_mtime)
                        events.append(({
                            "session_id": session_id,
                            "state": state_value,
                            "event_name": event_type,
                            "turn_id": str(payload.get("turn_id") or ""),
                            "timestamp_text": str(record.get("timestamp") or ""),
                        }, timestamp))
                    continue

                # Codex rollout serialization is not identical across Desktop/CLI
                # versions.  Older/common files wrap lifecycle records as:
                #   {type:event_msg, payload:{type:task_started,...}}
                # while recent Desktop/parent-rollout records can be:
                #   {type:task_started, payload:{turn_id:...}}
                # Accept both so a new turn cannot be hidden behind the previous
                # task_complete event.
                if record_type == "event_msg":
                    event_type = str(payload.get("type") or "")
                elif record_type in CODEX_ROLLOUT_STATE_BY_EVENT:
                    event_type = record_type
                elif record_type in {"error", "stream_error"}:
                    event_type = record_type
                else:
                    continue

                state_value = CODEX_ROLLOUT_STATE_BY_EVENT.get(event_type)
                if not state_value:
                    continue
                timestamp = self._rollout_timestamp(record, payload, stat.st_mtime)
                raw_ts = record.get("timestamp")
                normalized = {
                    "session_id": session_id,
                    "state": state_value,
                    "event_name": event_type,
                    "turn_id": str(payload.get("turn_id") or ""),
                    "timestamp_text": str(raw_ts or ""),
                }
                events.append((normalized, timestamp))

        # Multiple rollout files are scanned in file-mtime order, which is not a
        # reliable global event order. Apply lifecycle transitions chronologically
        # so an older completed session cannot overwrite a newer running session.
        events.sort(key=lambda item: item[1])

        # Remove offsets for files no longer present in the bounded active set only
        # occasionally, avoiding unbounded growth without breaking resumed sessions.
        self._codex_rollout_scan_counter += 1
        if self._codex_rollout_scan_counter % 240 == 0:
            existing = {str(p) for p in paths}
            self._codex_rollout_offsets = {
                key: value for key, value in self._codex_rollout_offsets.items()
                if key in existing
            }
        return events

    async def _scan_codex_rollouts_once(self) -> bool:
        batch = await asyncio.to_thread(self._read_codex_rollout_events_sync)
        changed = False
        for event, mtime in batch:
            if self._apply_state_event(
                "codex",
                str(event.get("session_id") or ""),
                str(event.get("state") or ""),
                str(event.get("event_name") or ""),
                mtime,
                turn_id=str(event.get("turn_id") or ""),
                source="rollout",
            ):
                changed = True
        return changed

    # ------------------------------------------------------------------
    # Claude Code transcript fallback
    # ------------------------------------------------------------------
    def _claude_config_dir(self) -> Path:
        return Path(os.environ.get("CLAUDE_CONFIG_DIR") or (Path.home() / ".claude"))

    def _claude_app_roots(self) -> list[Path]:
        now = time.monotonic()
        watch_paths = []
        if sys.platform.startswith("win"):
            if os.environ.get("APPDATA"):
                watch_paths.append(Path(os.environ["APPDATA"]))
            if os.environ.get("LOCALAPPDATA"):
                watch_paths.append(Path(os.environ["LOCALAPPDATA"]) / "Packages")
        watch_signature = []
        for watch_path in watch_paths:
            try:
                watch_signature.append((str(watch_path), watch_path.stat().st_mtime_ns))
            except OSError:
                watch_signature.append((str(watch_path), None))
        cached_roots = getattr(self, "_claude_apps_cache", [])
        if (
            cached_roots
            and watch_signature == getattr(self, "_claude_apps_watch_signature", None)
            and now - getattr(self, "_claude_apps_last_scan", -60.0) < 30.0
        ):
            return list(cached_roots)
        roots = []
        if sys.platform.startswith("win"):
            if os.environ.get("APPDATA"):
                roots.append(Path(os.environ["APPDATA"]) / "Claude")
            if os.environ.get("LOCALAPPDATA"):
                packages = Path(os.environ["LOCALAPPDATA"]) / "Packages"
                try:
                    roots.extend(package / "LocalCache" / "Roaming" / "Claude"
                                 for package in packages.glob("Claude_*") if package.is_dir())
                except OSError:
                    pass
        elif sys.platform == "darwin":
            roots.append(Path.home() / "Library" / "Application Support" / "Claude")
        else:
            roots.append(Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config")) / "Claude")
        self._claude_apps_cache = list(dict.fromkeys(roots))
        self._claude_apps_watch_signature = watch_signature
        self._claude_apps_last_scan = now
        return list(self._claude_apps_cache)

    def _discover_claude_project_roots_sync(self) -> list[Path]:
        now = time.monotonic()
        if self._claude_project_roots_cache and now - self._claude_roots_last_scan < 30.0:
            return list(self._claude_project_roots_cache)

        roots: list[Path] = []
        primary = self._claude_config_dir() / "projects"
        if primary.is_dir():
            roots.append(primary)

        # Claude Desktop Code normally points at ~/.claude/projects too. Older
        # local-agent/Cowork containers can keep a nested .claude/projects tree
        # below the Desktop application-data store, so discover those as a
        # compatibility fallback without scanning the user's whole profile.
        app_roots = self._claude_app_roots()

        for app_root in app_roots:
            for store_name in ("claude-code-sessions", "local-agent-mode-sessions"):
                base = app_root / store_name
                if not base.is_dir():
                    continue
                try:
                    for candidate in base.rglob("projects"):
                        try:
                            if candidate.is_dir() and candidate.parent.name == ".claude":
                                roots.append(candidate)
                        except OSError:
                            continue
                except OSError:
                    continue

        unique: list[Path] = []
        seen: set[str] = set()
        for root in roots:
            try:
                key = str(root.resolve())
            except OSError:
                key = str(root)
            if key in seen:
                continue
            seen.add(key)
            unique.append(root)
        self._claude_project_roots_cache = unique
        self._claude_roots_last_scan = now
        return list(unique)

    @staticmethod
    def _claude_session_id(path: Path, record: dict[str, Any]) -> str:
        value = str(record.get("sessionId") or record.get("session_id") or "").strip()
        if value:
            return value
        match = CLAUDE_SESSION_ID_RE.search(path.name)
        return match.group(1) if match else ""

    @staticmethod
    def _claude_record_timestamp(record: dict[str, Any], fallback: float) -> float:
        raw = record.get("timestamp")
        if isinstance(raw, (int, float)) and raw > 0:
            value = float(raw)
            return value / 1000.0 if value > 10_000_000_000 else value
        if isinstance(raw, str) and raw.strip():
            text = raw.strip()
            if text.endswith("Z"):
                text = text[:-1] + "+00:00"
            try:
                return datetime.fromisoformat(text).timestamp()
            except ValueError:
                pass
        return float(fallback)

    @staticmethod
    def _claude_content_types(record: dict[str, Any]) -> list[str]:
        message = record.get("message")
        if not isinstance(message, dict):
            return []
        content = message.get("content")
        if not isinstance(content, list):
            return []
        return [
            str(block.get("type") or "")
            for block in content
            if isinstance(block, dict) and block.get("type")
        ]

    def _normalize_claude_transcript_record(
        self,
        path: Path,
        record: dict[str, Any],
        fallback_time: float,
    ) -> dict[str, Any] | None:
        if bool(record.get("isSidechain")):
            return None
        session_id = self._claude_session_id(path, record)
        if not session_id:
            return None
        record_type = str(record.get("type") or "").strip()
        timestamp = self._claude_record_timestamp(record, fallback_time)
        cwd = str(record.get("cwd") or "")
        state_value = ""
        event_name = ""
        message = record.get("message")

        if record_type == "user":
            # Claude persists tool results as user-role records too. Only an
            # external user message starts a new turn; tool results merely keep
            # the current turn Running. Synthetic/meta user records are ignored.
            if bool(record.get("isMeta")):
                return None
            content_types = self._claude_content_types(record)
            is_tool_result = (
                record.get("toolUseResult") is not None
                or (content_types and all(value == "tool_result" for value in content_types))
            )
            tool_result_error = False
            if is_tool_result and isinstance(message, dict) and isinstance(message.get("content"), list):
                tool_result_error = any(
                    isinstance(block, dict)
                    and str(block.get("type") or "") == "tool_result"
                    and bool(block.get("is_error"))
                    for block in message["content"]
                )
            state_value = "error" if tool_result_error else "running"
            event_name = "tool_result_error" if tool_result_error else ("tool_result" if is_tool_result else "user_message")
        elif record_type == "assistant":
            content_types = self._claude_content_types(record)
            stop_reason = ""
            if isinstance(message, dict):
                stop_reason = str(message.get("stop_reason") or "").strip().lower()
            if not stop_reason:
                stop_reason = str(record.get("stop_reason") or "").strip().lower()

            # Claude transcript assistant entries can already be terminal.
            # v1.0.4 treated every assistant record as RUNNING, which left
            # Desktop sessions stuck on RUNNING after the visible response had
            # actually finished.  end_turn is a completed assistant turn.
            tool_names = []
            if isinstance(message, dict) and isinstance(message.get("content"), list):
                tool_names = [
                    str(block.get("name") or "").lower()
                    for block in message["content"]
                    if isinstance(block, dict) and str(block.get("type") or "") == "tool_use"
                ]
            if any(name in {"askuserquestion", "request_user_input", "request_user_input_async"} for name in tool_names):
                state_value = "approval"
                event_name = "user_approval_requested"
            elif stop_reason == "end_turn":
                state_value = "done"
                event_name = "assistant_end_turn"
            elif stop_reason in {"error", "refusal", "tool_deferred_unavailable"}:
                state_value = "error"
                event_name = f"assistant_{stop_reason}"
            else:
                state_value = "running"
                if "thinking" in content_types:
                    event_name = "assistant_thinking"
                elif "tool_use" in content_types:
                    event_name = "assistant_tool_use"
                elif "text" in content_types:
                    event_name = "assistant_message"
                else:
                    event_name = "assistant"
        elif record_type == "system":
            subtype = str(record.get("subtype") or "").strip()
            if subtype == "turn_duration":
                # This is written after the turn's assistant/tool activity and is
                # a much safer DONE boundary than Stop-hook invocation itself.
                state_value = "done"
                event_name = "turn_duration"
            elif subtype == "stop_hook_summary":
                # Keep for diagnostics only. Some builds emit Stop-related data
                # before the UI has fully settled, so it must not force DONE.
                event_name = "stop_hook_summary"
            else:
                return None
        elif record_type in {"error", "result"} and (
            bool(record.get("is_error")) or str(record.get("subtype") or "").lower() in {"error", "failed"}
        ):
            state_value = "error"
            event_name = str(record.get("subtype") or record_type)
        else:
            return None

        return {
            "session_id": session_id,
            "state": state_value,
            "event_name": event_name,
            "cwd": cwd,
            "timestamp": timestamp,
            "transcript_path": str(path),
        }

    def _latest_claude_lifecycle_from_transcript_sync(
        self,
        path: Path,
        max_scan_bytes: int = 4 * 1024 * 1024,
    ) -> tuple[dict[str, Any], float] | None:
        """Read the newest meaningful Claude lifecycle record."""
        try:
            stat = path.stat()
            if stat.st_size <= 0:
                return None
            with path.open("rb") as handle, mmap.mmap(
                handle.fileno(), 0, access=mmap.ACCESS_READ
            ) as mapped:
                position = len(mapped)
                lower_bound = max(0, position - int(max_scan_bytes))
                while position > lower_bound:
                    end = position
                    while end > lower_bound and mapped[end - 1] in (10, 13):
                        end -= 1
                    if end <= lower_bound:
                        break
                    newline = mapped.rfind(b"\n", lower_bound, end)
                    start = newline + 1
                    position = newline if newline >= 0 else lower_bound
                    if end - start > 2 * 1024 * 1024:
                        continue
                    try:
                        record = json.loads(mapped[start:end].decode("utf-8", errors="replace"))
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        continue
                    if not isinstance(record, dict):
                        continue
                    normalized = self._normalize_claude_transcript_record(path, record, stat.st_mtime)
                    if normalized is not None and normalized.get("state"):
                        return normalized, float(normalized["timestamp"])
        except (OSError, ValueError):
            return None
        return None

    def _recover_recent_claude_state_at_startup_sync(self) -> None:
        """Restore only a genuinely in-flight Claude turn at startup."""
        paths: list[Path] = []
        for root in self._discover_claude_project_roots_sync():
            try:
                paths.extend(
                    path for path in root.rglob("*.jsonl")
                    if "subagents" not in path.parts and not path.name.startswith("agent-")
                )
            except OSError:
                continue
        try:
            paths.sort(key=lambda item: item.stat().st_mtime, reverse=True)
        except OSError:
            return
        cutoff = self._runtime_started_at - STARTUP_TRANSCRIPT_RECOVERY_SECONDS
        recovered: list[tuple[dict[str, Any], float, Path]] = []
        for path in paths[:20]:
            try:
                if path.stat().st_mtime < cutoff:
                    break
            except OSError:
                continue
            item = self._latest_claude_lifecycle_from_transcript_sync(path)
            if item is not None:
                recovered.append((item[0], item[1], path))
        if not recovered:
            return
        event, event_time, path = max(recovered, key=lambda item: item[1])
        if str(event.get("state") or "") != "running":
            return
        if self._apply_state_event(
            "claude",
            str(event.get("session_id") or ""),
            "running",
            str(event.get("event_name") or ""),
            event_time,
            cwd=str(event.get("cwd") or ""),
            source="claude_transcript",
            transcript_path=str(path),
        ):
            self._state_dirty = True

    def _read_claude_transcript_events_sync(self) -> list[tuple[dict[str, Any], float]]:
        roots = self._discover_claude_project_roots_sync()
        if not roots:
            return []

        paths: list[Path] = []
        seen_paths: set[str] = set()
        for root in roots:
            try:
                candidates = root.rglob("*.jsonl")
                for path in candidates:
                    # Subagent transcripts carry their own sidechain lifecycle and
                    # must not become the main Claude Status session.
                    if "subagents" in path.parts or path.name.startswith("agent-"):
                        continue
                    key = str(path)
                    if key in seen_paths:
                        continue
                    seen_paths.add(key)
                    paths.append(path)
            except OSError:
                continue

        try:
            paths.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        except OSError:
            pass
        paths = paths[:200]

        events: list[tuple[dict[str, Any], float]] = []
        for path in paths:
            key = str(path)
            try:
                stat, lines = self._read_jsonl_lines(path, self._claude_transcript_offsets, 1024 * 1024)
            except OSError:
                continue

            for raw_line in lines:
                if not raw_line.strip():
                    continue
                # Binary/document tool results can create multi-megabyte JSONL
                # lines. They are not needed for lifecycle inference and parsing
                # them would stall the shared plugin process.
                if len(raw_line) > (2 * 1024 * 1024):
                    continue
                try:
                    record = json.loads(raw_line.decode("utf-8", errors="replace"))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    continue
                if not isinstance(record, dict):
                    continue
                normalized = self._normalize_claude_transcript_record(path, record, stat.st_mtime)
                if normalized is None:
                    continue
                events.append((normalized, float(normalized["timestamp"])))

        events.sort(key=lambda item: item[1])
        self._claude_transcript_scan_counter += 1
        if self._claude_transcript_scan_counter % 240 == 0:
            existing = {str(p) for p in paths}
            self._claude_transcript_offsets = {
                key: value for key, value in self._claude_transcript_offsets.items()
                if key in existing
            }
        return events

    async def _scan_claude_transcripts_once(self) -> bool:
        batch = await asyncio.to_thread(self._read_claude_transcript_events_sync)
        changed = False
        for event, event_time in batch:
            session_id = str(event.get("session_id") or "")
            event_name = str(event.get("event_name") or "")
            transcript_path = str(event.get("transcript_path") or "")
            if self._append_diagnostic_event(
                "claude",
                session_id,
                event_name,
                event_time,
                transcript_path=transcript_path,
            ):
                changed = True
            state_value = str(event.get("state") or "")
            if state_value and self._apply_state_event(
                "claude",
                session_id,
                state_value,
                event_name,
                event_time,
                cwd=str(event.get("cwd") or ""),
                source="claude_transcript",
                transcript_path=transcript_path,
            ):
                changed = True
        return changed

    async def _scan_events_once(self) -> set[str]:
        # Lifecycle messages and the poller can arrive together. Serializing the
        # complete scan prevents two worker threads racing over offsets/inboxes
        # and prevents concurrent replacements of the same state .tmp file.
        async with self._scan_lock:
            changed: set[str] = set()
            try:
                batch = await asyncio.to_thread(self._read_event_batch_sync)
                self._monitor_errors.pop("hooks", None)
            except Exception as exc:
                self._report_monitor_error("hooks", exc)
                batch = []
            for provider, event, mtime in batch:
                if provider not in ENABLED_PROVIDERS:
                    continue
                try:
                    if self._apply_hook_event(provider, event, mtime):
                        changed.add(provider)
                except (TypeError, ValueError, AttributeError) as exc:
                    self._report_monitor_error("hook_event", exc)

            for provider, scan in (("codex", self._scan_codex_rollouts_once),
                                   ("claude", self._scan_claude_transcripts_once)):
                if provider not in ENABLED_PROVIDERS:
                    continue
                try:
                    if await scan():
                        changed.add(provider)
                    self._monitor_errors.pop(provider, None)
                except Exception as exc:
                    # One provider's transient file/parse error must not stop the
                    # other provider, or terminate monitoring permanently.
                    self._report_monitor_error(provider, exc)

            self._state_dirty = self._state_dirty or bool(changed)
            if self._state_dirty:
                try:
                    await asyncio.to_thread(self._save_state_sync)
                    self._state_dirty = False
                    self._monitor_errors.pop("save", None)
                except Exception as exc:
                    self._report_monitor_error("save", exc)
            return changed

    def _report_monitor_error(self, source: str, exc: Exception) -> None:
        message = f"{type(exc).__name__}: {exc}"
        if self._monitor_errors.get(source) != message:
            print(f"[AI Monitor] {source}: {message}", file=sys.stderr, flush=True)
        self._monitor_errors[source] = message

    async def _poll_loop(self) -> None:
        next_refresh = 0.0
        try:
            while True:
                try:
                    changed = await self._scan_events_once()
                    self._monitor_errors.pop("poll", None)
                except Exception as exc:
                    self._report_monitor_error("poll", exc)
                    changed = set()
                if time.monotonic() >= next_refresh:
                    # Retry failed image delivery even when no new event arrives.
                    changed.update(ENABLED_PROVIDERS)
                    next_refresh = time.monotonic() + 2.0
                for provider in changed:
                    try:
                        await self._refresh_provider_contexts(provider)
                        self._monitor_errors.pop(f"{provider}_display", None)
                    except Exception as exc:
                        self._report_monitor_error(f"{provider}_display", exc)
                await asyncio.sleep(0.25)
        except asyncio.CancelledError:
            pass

    def _ensure_poller(self) -> None:
        if self.poll_task and not self.poll_task.done():
            return
        self.poll_task = asyncio.create_task(self._poll_loop())

    async def startup(self) -> None:
        """Begin state collection before any page containing this plugin appears."""
        self._ensure_poller()

    # ------------------------------------------------------------------
    # Hook installer / remover
    # ------------------------------------------------------------------
    @staticmethod
    def _atomic_write_json(path: Path, data: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_name(path.name + ".ai-monitor.tmp")
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temp, path)

    def _backup_config(self, path: Path, provider: str) -> None:
        if not path.is_file():
            return
        stamp = time.strftime("%Y%m%d-%H%M%S")
        target = self.backup_dir / f"{provider}-{path.name}-{stamp}.bak"
        try:
            shutil.copy2(path, target)
        except OSError:
            pass

    @staticmethod
    def _load_json_config(path: Path) -> dict[str, Any]:
        if not path.exists():
            return {}
        try:
            value = json.loads(path.read_text(encoding="utf-8-sig"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in {path}: {exc}") from exc
        if not isinstance(value, dict):
            raise ValueError(f"Expected a JSON object in {path}")
        return value

    @staticmethod
    def _handler_text(handler: dict[str, Any]) -> str:
        command = str(handler.get("command") or "")
        args = handler.get("args")
        if isinstance(args, list):
            command += " " + " ".join(str(value) for value in args)
        return command

    def _is_our_handler(self, handler: Any) -> bool:
        if not isinstance(handler, dict):
            return False
        text = self._handler_text(handler).lower()
        return (
            "ai_monitor_hook" in text
            and (
                "com_cookie_ai_monitor" in text
                or "com.cookie.ai_monitor" in text
                or "com_user_ai_monitor" in text
                or "com.user.ai_monitor" in text
            )
        ) or str(handler.get("statusMessage") or "") == HOOK_MARKER

    def _remove_our_groups(self, root: dict[str, Any]) -> bool:
        hooks = root.get("hooks")
        if not isinstance(hooks, dict):
            return False
        changed = False
        for event_name in list(hooks.keys()):
            groups = hooks.get(event_name)
            if not isinstance(groups, list):
                continue
            kept_groups = []
            for group in groups:
                if not isinstance(group, dict):
                    kept_groups.append(group)
                    continue
                handlers = group.get("hooks")
                if not isinstance(handlers, list):
                    kept_groups.append(group)
                    continue
                kept_handlers = [handler for handler in handlers if not self._is_our_handler(handler)]
                if len(kept_handlers) != len(handlers):
                    changed = True
                if kept_handlers:
                    new_group = dict(group)
                    new_group["hooks"] = kept_handlers
                    kept_groups.append(new_group)
            if kept_groups:
                hooks[event_name] = kept_groups
            else:
                hooks.pop(event_name, None)
        if not hooks:
            root.pop("hooks", None)
        return changed

    def _hook_script_path(self) -> Path:
        if sys.platform.startswith("win"):
            return self.data_dir / "ai_monitor_hook.ps1"
        return self.data_dir / "ai_monitor_hook.sh"

    def _codex_handler(self) -> dict[str, Any]:
        script = self._hook_script_path()
        if sys.platform.startswith("win"):
            command = (
                'powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass '
                f'-File "{script}" -Provider codex'
            )
        else:
            escaped = str(script).replace("'", "'\\''")
            command = f"/bin/sh '{escaped}' codex"
        handler = {
            "type": "command",
            "command": command,
            "timeout": 3,
            "statusMessage": HOOK_MARKER,
        }
        if sys.platform.startswith("win"):
            # Explicit Windows override is supported by current Codex hooks and
            # avoids ambiguity in command dispatch across Desktop/CLI builds.
            handler["commandWindows"] = command
        return handler

    def _claude_handler(self) -> dict[str, Any]:
        script = self._hook_script_path()
        if sys.platform.startswith("win"):
            return {
                "type": "command",
                "command": "powershell.exe",
                "args": [
                    "-NoProfile",
                    "-NonInteractive",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(script),
                    "-Provider",
                    "claude",
                ],
                "timeout": 3,
                "statusMessage": HOOK_MARKER,
            }
        return {
            "type": "command",
            "command": "/bin/sh",
            "args": [str(script), "claude"],
            "timeout": 3,
            "statusMessage": HOOK_MARKER,
        }

    @staticmethod
    def _append_event_group(hooks: dict[str, Any], event_name: str, handler: dict[str, Any], matcher: str | None = None) -> None:
        group: dict[str, Any] = {"hooks": [handler]}
        if matcher:
            group["matcher"] = matcher
        hooks.setdefault(event_name, []).append(group)

    def _config_path(self, provider: str) -> Path:
        if provider == "claude":
            return self._claude_config_dir() / "settings.json"
        return self._codex_home() / "hooks.json"

    def _install_hooks_sync(self, provider: str) -> tuple[bool, str, str]:
        self._write_hook_helpers()
        path = self._config_path(provider)
        try:
            root = self._load_json_config(path)
            self._backup_config(path, provider)
            self._remove_our_groups(root)
            hooks = root.setdefault("hooks", {})
            if not isinstance(hooks, dict):
                return False, "invalid_hooks", str(path)

            handler = self._claude_handler() if provider == "claude" else self._codex_handler()
            start_matcher = "startup|resume|clear|fork" if provider == "claude" else "startup|resume|clear"
            self._append_event_group(hooks, "SessionStart", dict(handler), start_matcher)
            self._append_event_group(hooks, "UserPromptSubmit", dict(handler))
            self._append_event_group(hooks, "Stop", dict(handler))
            self._append_event_group(hooks, "SessionEnd", dict(handler))
            self._append_event_group(hooks, "PermissionRequest", dict(handler))
            self._append_event_group(hooks, "PostToolUse", dict(handler))
            if provider == "codex":
                self._append_event_group(hooks, "Interrupt", dict(handler))
            else:
                for event_name in (
                    "PostToolUseFailure", "PermissionDenied", "StopFailure",
                    "Elicitation", "ElicitationResult",
                ):
                    self._append_event_group(hooks, event_name, dict(handler))
            self._atomic_write_json(path, root)
            return True, "installed", str(path)
        except (OSError, ValueError) as exc:
            return False, str(exc), str(path)

    def _remove_hooks_sync(self, provider: str) -> tuple[bool, str, str]:
        path = self._config_path(provider)
        try:
            if not path.exists():
                return True, "not_installed", str(path)
            root = self._load_json_config(path)
            self._backup_config(path, provider)
            changed = self._remove_our_groups(root)
            if changed:
                self._atomic_write_json(path, root)
                return True, "removed", str(path)
            return True, "not_installed", str(path)
        except (OSError, ValueError) as exc:
            return False, str(exc), str(path)

    def _hooks_installed_sync(self, provider: str) -> tuple[bool, str]:
        path = self._config_path(provider)
        try:
            root = self._load_json_config(path)
        except (OSError, ValueError):
            return False, str(path)
        hooks = root.get("hooks")
        if not isinstance(hooks, dict):
            return False, str(path)
        monitored_events = set(MONITORED_EVENTS_BY_PROVIDER.get(provider, BASE_MONITORED_EVENTS))
        expected_handler = self._claude_handler() if provider == "claude" else self._codex_handler()
        expected_start_matcher = "startup|resume|clear|fork" if provider == "claude" else "startup|resume|clear"
        found: set[str] = set()
        handler_count = 0

        for event_name, groups in hooks.items():
            if not isinstance(groups, list):
                continue
            for group in groups:
                handlers = group.get("hooks") if isinstance(group, dict) else None
                if not isinstance(handlers, list):
                    continue
                our_handlers = [handler for handler in handlers if self._is_our_handler(handler)]
                for handler in our_handlers:
                    handler_count += 1
                    expected_matcher = expected_start_matcher if event_name == "SessionStart" else None
                    actual_matcher = group.get("matcher") if isinstance(group, dict) else None
                    if (
                        event_name not in monitored_events
                        or handler != expected_handler
                        or actual_matcher != expected_matcher
                    ):
                        return False, str(path)
                    found.add(event_name)

        installed = found == monitored_events and handler_count == len(monitored_events)
        return installed, str(path)

    async def _ensure_hooks_ready(self, provider: str) -> tuple[bool, str, str, bool]:
        """Check once per app process and repair only when required.

        Returns (ok, code, config_path, changed). Manual install/remove remains
        available in the Property Inspector even after this automatic check.
        """
        provider = "claude" if provider == "claude" else "codex"
        if provider in self._auto_hook_checked:
            return self._auto_hook_results.get(
                provider,
                (False, "not_installed", str(self._config_path(provider)), False),
            )

        async with self._hook_setup_lock:
            if provider in self._auto_hook_checked:
                return self._auto_hook_results.get(
                    provider,
                    (False, "not_installed", str(self._config_path(provider)), False),
                )

            installed, path = await asyncio.to_thread(self._hooks_installed_sync, provider)
            if installed:
                self._monitor_errors.pop(f"auto_hook:{provider}", None)
                result = (True, "installed", path, False)
                self._auto_hook_checked.add(provider)
                self._auto_hook_results[provider] = result
                return result

            ok, code, path = await asyncio.to_thread(self._install_hooks_sync, provider)
            if ok:
                self._monitor_errors.pop(f"auto_hook:{provider}", None)
                print(f"[AI Monitor] Automatically installed/repaired {provider} hooks: {path}", flush=True)
            else:
                self._report_monitor_error(f"auto_hook:{provider}", RuntimeError(code))
            result = (ok, code, path, ok)
            # Mark completed failures too, so multiple assigned keys do not
            # repeatedly touch a broken or locked external configuration file.
            self._auto_hook_checked.add(provider)
            self._auto_hook_results[provider] = result
            return result

    async def _send_monitor_status(self, context: str, info: dict[str, Any] | None = None) -> None:
        state = self.contexts.get(context)
        if not state:
            return
        info = info or self._resolve_status(state)
        installed, config_path = await asyncio.to_thread(self._hooks_installed_sync, info["provider"])
        settings = state.get("settings", {})
        await self._send_to_pi(context, {
            "command": "monitor_status",
            "provider": info["provider"],
            "state": info["state"],
            "session_id": info["session_id"],
            "latest_session_id": info["latest_session_id"],
            "last_event": info["last_event"],
            "cwd": info["cwd"],
            "source": info.get("source", ""),
            "transcript_path": info.get("transcript_path", ""),
            "diagnostic_events": info.get("diagnostic_events", []),
            "monitor_errors": dict(self._monitor_errors),
            "hooks_installed": installed,
            "config_path": config_path,
            "message": self._t(settings, "STATUS_READY", "Status refreshed."),
        })

    async def _handle_pi_command(self, context: str, state: dict[str, Any], command: str) -> None:
        settings = state.get("settings", {})
        if command in {"refresh_voice", "check_voice", "refresh_shortcut", "check_shortcut"}:
            if self._is_voice_action(state.get("action", "")):
                await self._refresh_voice_context(context, notify_pi=True)
                return
            if self._is_reasoning_action(state.get("action", "")):
                await self._refresh_reasoning_context(context, notify_pi=True)
                return
        provider = self._provider_for_action(state.get("action", ""), settings)
        if command == "install_hooks":
            ok, code, path = await asyncio.to_thread(self._install_hooks_sync, provider)
            self._auto_hook_checked.add(provider)
            self._auto_hook_results[provider] = (ok, code, path, ok)
            if ok:
                key = "HOOK_INSTALLED_CODEX" if provider == "codex" else "HOOK_INSTALLED_CLAUDE"
                message = self._t(settings, key, "Hooks installed.", path=path)
            else:
                message = self._t(settings, "HOOK_ERROR", "Hook setup failed: {error}", error=code)
            await self._send_to_pi(context, {
                "command": "hook_result",
                "ok": ok,
                "message": message,
                "config_path": path,
            })
            await self._send_monitor_status(context)
            return

        if command == "remove_hooks":
            ok, code, path = await asyncio.to_thread(self._remove_hooks_sync, provider)
            # Do not immediately undo an explicit removal in this process. If
            # the action remains assigned, the next launch checks it again.
            self._auto_hook_checked.add(provider)
            self._auto_hook_results[provider] = (False, code, path, False)
            if ok:
                message = self._t(settings, "HOOK_REMOVED", "AI Monitor hooks removed.")
            else:
                message = self._t(settings, "HOOK_ERROR", "Hook setup failed: {error}", error=code)
            await self._send_to_pi(context, {
                "command": "hook_result",
                "ok": ok,
                "message": message,
                "config_path": path,
            })
            await self._send_monitor_status(context)
            return

        if command in {"check_hooks", "refresh_status"}:
            changed = await self._scan_events_once()
            for changed_provider in changed:
                await self._refresh_provider_contexts(changed_provider)
            await self._send_monitor_status(context)
            return

        if command == "use_latest_session":
            info = self._resolve_status(state)
            latest = str(info.get("latest_session_id") or "")
            await self._send_to_pi(context, {
                "command": "latest_session",
                "session_id": latest,
                "message": (
                    self._t(settings, "LATEST_SESSION_FOUND", "Latest session ID loaded.")
                    if latest
                    else self._t(settings, "LATEST_SESSION_EMPTY", "No session has been detected yet.")
                ),
            })

    # ------------------------------------------------------------------
    # COMBO-X lifecycle
    # ------------------------------------------------------------------
    def _stop_context(self, context: str) -> None:
        self._stop_animation(context)
        self._voice_tap_down.discard(context)
        self._reasoning_tap_down.discard(context)
        self._generic_key_tap_down.discard(context)
        self._voice_shortcut_cache.pop(context, None)
        self._sent_image_cache.pop(context, None)
        self._sent_preview_image_cache.pop(context, None)
        self._led_cache.pop(context, None)
        self.contexts.pop(context, None)
        self._monitor_errors.pop(f"display:{context}", None)
        self._monitor_errors.pop(f"animation:{context}", None)

    async def handle_message(self, data):
        event = data.get("event")
        context = str(data.get("context") or "")
        if not context:
            return
        payload = data.get("payload", {}) or {}

        if event in ("keyDidAppear", "willAppear"):
            context, state = self._remember(data)
            if self._is_monitor_action(state.get("action", "")):
                self._ensure_poller()
                # The host shows the manifest icon until the first runtime
                # image arrives. Re-send the persisted status immediately,
                # before hook verification and transcript scans, to minimize
                # the cold-start placeholder frame.
                self._sent_image_cache.pop(context, None)
                self._sent_preview_image_cache.pop(context, None)
                await self._refresh_context(context, notify_pi=False)
                provider = self._provider_for_action(state.get("action", ""), state.get("settings", {}))
                await self._ensure_hooks_ready(provider)
                changed = await self._scan_events_once()
                for provider in changed:
                    await self._refresh_provider_contexts(provider)
                await self._refresh_context(context)
            elif self._is_voice_action(state.get("action", "")):
                # Prepare/read the desktop shortcut as soon as the action is
                # assigned, but emit no setTitle/setImage/setSettings traffic.
                await self._refresh_voice_context(context, notify_pi=False)
            elif self._is_reasoning_action(state.get("action", "")):
                # Same safe keybinding flow as Voice: preserve user bindings,
                # auto-create only when unassigned, and never touch visuals.
                await self._refresh_reasoning_context(context, notify_pi=False)
            return

        if event == "didReceiveSettings":
            context, state = self._remember(data)
            if self._is_monitor_action(state.get("action", "")):
                self._ensure_poller()
                await self._refresh_context(context)
            elif self._is_voice_action(state.get("action", "")):
                # Never keep an old configured key logically held while the
                # placement is being refreshed/reconfigured.
                await self._release_voice_hold(context, "settings_changed")
                await self._release_voice_toggle(context, "settings_changed")
                self._voice_shortcut_cache.pop(context, None)
                await self._refresh_voice_context(context, notify_pi=False)
            elif self._is_reasoning_action(state.get("action", "")):
                self._reasoning_tap_down.discard(context)
                self._voice_shortcut_cache.pop(context, None)
                await self._refresh_reasoning_context(context, notify_pi=False)
            elif self._is_generic_key_action(state.get("action", "")):
                self._generic_key_tap_down.discard(context)
            return

        if event == "keyDown":
            context, state = self._remember(data)
            if self._is_voice_action(state.get("action", "")):
                await self._handle_voice_down(context, state)
                return
            if self._is_reasoning_action(state.get("action", "")):
                await self._handle_reasoning_down(context, state)
                return
            if self._is_generic_key_action(state.get("action", "")):
                await self._handle_generic_key_down(context, state)
                return
            if self._is_monitor_action(state.get("action", "")):
                self._ensure_poller()
                acknowledged_provider = await self._acknowledge_completed_state(context)
                if acknowledged_provider:
                    await self._refresh_provider_contexts(acknowledged_provider)
                    return
                changed = await self._scan_events_once()
                for provider in changed:
                    await self._refresh_provider_contexts(provider)
                await self._refresh_context(context)
            return

        if event == "keyUp":
            context, state = self._remember(data)
            if self._is_voice_action(state.get("action", "")):
                await self._handle_voice_up(context, state)
            elif self._is_reasoning_action(state.get("action", "")):
                await self._handle_reasoning_up(context)
            elif self._is_generic_key_action(state.get("action", "")):
                await self._handle_generic_key_up(context)
            return

        if event == "sendToPlugin":
            context, state = self._remember(data)
            if self._is_monitor_action(state.get("action", "")):
                self._ensure_poller()
            command = str(payload.get("command") or "")
            await self._handle_pi_command(context, state, command)
            return

        if event in ("keyDidDisappear", "willDisappear"):
            await self._release_voice_hold(context, event)
            await self._release_voice_toggle(context, event)
            self._reasoning_tap_down.discard(context)
            self._voice_tap_down.discard(context)
            self._generic_key_tap_down.discard(context)
            # set_key_led_color is persisted by the host. Sending black while a
            # page is changing overwrites the status color and races the next
            # keyDidAppear refresh, so disappearing contexts only drop caches.
            self._stop_context(context)

    async def shutdown(self):
        # Release any synthetic held shortcut before tearing down tasks. This is
        # mandatory for PTT so no modifier or function key can remain latched.
        for context in list(self._voice_held):
            await self._release_voice_hold(context, "shutdown")
        for context in list(self._voice_toggle_held):
            await self._release_voice_toggle(context, "shutdown")
        voice_watchdogs = list(self._voice_hold_watchdogs.values())
        self._voice_hold_watchdogs.clear()
        for task in voice_watchdogs:
            if not task.done():
                task.cancel()

        animation_tasks = [
            task for task in self.animation_tasks.values()
            if task and not task.done()
        ]
        for task in animation_tasks:
            task.cancel()
        self.animation_tasks.clear()

        poll_task = self.poll_task
        self.poll_task = None
        if poll_task and not poll_task.done():
            poll_task.cancel()

        tasks = list(voice_watchdogs) + list(animation_tasks)
        if poll_task:
            tasks.append(poll_task)
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        self.contexts.clear()
        self._voice_toggle_held.clear()
        self._voice_tap_down.clear()
        self._reasoning_tap_down.clear()
        self._generic_key_tap_down.clear()
        self._voice_shortcut_cache.clear()
        self._auto_hook_checked.clear()
        self._auto_hook_results.clear()
        self.locale_cache.clear()
        self._image_cache.clear()
        self._sent_image_cache.clear()
        self._sent_preview_image_cache.clear()
