import asyncio
import platform

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 피그마 실무용 꿀 단축키 매핑 (Windows 기준)
        self.action_map = {
            # 1. 도구 (Tools)
            "tool_move": "v",
            "tool_frame": "f",
            "tool_pen": "p",
            "tool_text": "t",
            "tool_rect": "r",
            "tool_ellipse": "o",
            "tool_hand": "h",

            # 2. 오토 레이아웃 (Auto Layout) - 피그마의 꽃 🌸
            "action_add_autolayout": "shift+a",
            "action_remove_autolayout": "alt+shift+a",

            # 3. 컴포넌트 (Components)
            "action_create_component": "ctrl+alt+k",
            "action_detach_instance": "ctrl+alt+b",

            # 4. 속성 복사/붙여넣기 (엄청 자주 씀)
            "action_copy_props": "ctrl+alt+c",
            "action_paste_props": "ctrl+alt+v",

            # 5. 그룹 및 프레임 (Grouping & Framing)
            "action_group": "ctrl+g",
            "action_ungroup": "ctrl+shift+g",
            "action_frame_selection": "ctrl+alt+g",

            # 6. 레이어 순서 (Arrangement)
            "arrange_front": "ctrl+shift+]",
            "arrange_forward": "ctrl+]",
            "arrange_back": "ctrl+shift+[",
            "arrange_backward": "ctrl+[",

            # 7. 뷰 및 줌 (View & Zoom)
            "view_zoom_in": "ctrl+=",
            "view_zoom_out": "ctrl+-",
            "view_zoom_100": "shift+0",
            "view_zoom_fit": "shift+1",
            "view_zoom_selection": "shift+2",
            "view_toggle_ui": "ctrl+\\" # 양쪽 패널 다 숨기고 디자인만 보기
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("figma_action", "tool_move")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)