from enum import IntFlag

import comtypes.gen._C866CA3A_32F7_11D2_9602_00C04F8EE628_0_5_4 as __wrapper_module__
from comtypes.gen._C866CA3A_32F7_11D2_9602_00C04F8EE628_0_5_4 import (
    SDA_No_Trailing_Space, DISPID_SDKGetBinaryValue, SRADynamic,
    SpStream, SPSInterjection, eLEXTYPE_RESERVED10, ISpeechLexicon,
    SpeechCategoryAppLexicons, SPRST_NUM_STATES,
    SAFTCCITT_uLaw_11kHzStereo, SDTAlternates,
    DISPID_SRSCurrentStreamPosition, SPEI_PHONEME, SpCustomStream,
    DISPID_SPIRule, eLEXTYPE_PRIVATE5, SpeechAudioProperties,
    SAFT8kHz8BitMono, __MIDL___MIDL_itf_sapi_0000_0020_0001,
    SAFTCCITT_ALaw_22kHzStereo, DISPID_SGRsAdd, DISPID_SOTsCount,
    SPLO_DYNAMIC, SP_VISEME_15, SVEBookmark, SRTEmulated,
    DISPID_SVGetAudioOutputs, SVP_0, SVP_19, SPAS_RUN,
    DISPID_SLPLangId, SASPause, DISPID_SRCResume, SVF_Stressed,
    SPFM_CREATE, SPINTERFERENCE_TOOSLOW, eLEXTYPE_PRIVATE17,
    DISPID_SVVolume, ISpXMLRecoResult, DISPID_SPEAudioStreamOffset,
    GUID, SVSFNLPSpeakPunc, DISPID_SWFEFormatTag, _LARGE_INTEGER,
    DISPID_SPRules_NewEnum, STSF_FlagCreate, STCAll,
    DISPID_SRCEHypothesis, DISPID_SGRSTPropertyName,
    SpNotifyTranslator, SPPS_Function, SP_VISEME_9,
    DISPID_SPIGrammarId, SVEPhoneme, SPEI_INTERFERENCE,
    SPBINARYGRAMMAR, SRAExport, SDA_Consume_Leading_Spaces,
    SP_VISEME_14, SINone, DISPID_SVSInputSentencePosition, SRARoot,
    DISPID_SGRSTPropertyId, SPWP_UNKNOWN_WORD_PRONOUNCEABLE, SVP_7,
    SDTAudio, SPGS_DISABLED, DISPID_SPRuleId,
    SpeechGrammarTagUnlimitedDictation, DISPID_SASFreeBufferSpace,
    DISPID_SLGenerationId, DISPID_SBSWrite,
    DISPID_SLGetGenerationChange, DISPID_SOTIsUISupported, SVEPrivate,
    SPSHT_EMAIL, DISPID_SRGetPropertyNumber, ISpeechGrammarRule,
    DISPID_SPERequiredConfidence, VARIANT_BOOL, ISpLexicon,
    SpeechVoiceSkipTypeSentence, SFTSREngine, DISPID_SPILanguageId,
    SpeechMicTraining, SpeechCategoryVoices, SDTAll,
    DISPID_SRSNumberOfActiveRules, ISpGrammarBuilder, DISPID_SRStatus,
    SPEI_PROPERTY_NUM_CHANGE, SDKLLocalMachine,
    DISPID_SVWaitUntilDone, SPWF_SRENGINE,
    SPSMF_SRGS_SEMANTICINTERPRETATION_W3C, ISpRecoResult,
    DISPID_SPIAudioStreamPosition, ISpeechGrammarRuleState,
    WAVEFORMATEX, typelib_path, SPPS_RESERVED3, DISPID_SABIBufferSize,
    SPEI_WORD_BOUNDARY, SPEI_MIN_SR, DISPID_SVSpeakCompleteEvent,
    DISPID_SASState, SAFTCCITT_uLaw_8kHzMono,
    SWPUnknownWordUnpronounceable, SSTTWildcard, DISPID_SGRId,
    IEnumString, SAFTExtendedAudioFormat, SREPrivate,
    DISPID_SREmulateRecognition, DISPID_SPRuleFirstElement, BSTR,
    SVSFPersistXML, SWPUnknownWordPronounceable, DISPID_SRDisplayUI,
    SpInProcRecoContext, eLEXTYPE_PRIVATE9, SINoSignal, DISPID_SRGId,
    SpeechTokenKeyUI, SVP_12, DISPID_SASetState,
    DISPID_SGRSAddRuleTransition, SPEI_RESERVED6, ISpStream,
    SREPhraseStart, SPEI_VISEME, SECFIgnoreWidth,
    DISPID_SPIReplacements, SVEAllEvents, SAFTADPCM_22kHzStereo,
    ISpeechDataKey, tagSPPROPERTYINFO, SAFT48kHz16BitStereo,
    SpeechCategoryAudioOut, SPEI_MIN_TTS, SAFT44kHz16BitMono,
    DISPID_SRCreateRecoContext, DISPID_SPIGetDisplayAttributes,
    SWTAdded, DISPID_SVEStreamStart, DISPID_SRGCmdLoadFromObject,
    SAFT11kHz8BitMono, SPAUDIOBUFFERINFO, DISPID_SPIGetText,
    eLEXTYPE_LETTERTOSOUND, SAFTGSM610_8kHzMono,
    SPINTERFERENCE_TOOFAST, STSF_AppData, SDA_Two_Trailing_Spaces,
    ISpeechObjectTokenCategory, ISpeechLexiconPronunciations, IStream,
    SREHypothesis, ISpObjectToken, DISPID_SPPId,
    DISPID_SRGCmdSetRuleIdState, SVESentenceBoundary,
    DISPID_SVPriority, DISPID_SOTs_NewEnum, DISPID_SGRsCommitAndSave,
    DISPID_SABufferInfo, DISPID_SRCERecognition, eLEXTYPE_PRIVATE12,
    SRTAutopause, SRTSMLTimeout, SAFT22kHz16BitMono,
    __MIDL_IWinTypes_0009, DISPID_SDKEnumValues, DISPID_SRRTTickCount,
    DISPID_SASCurrentSeekPosition, SRERecognition, SPEI_RESERVED5,
    DISPID_SDKCreateKey, ISpeechLexiconPronunciation,
    DISPID_SOTMatchesAttributes, SPEI_TTS_PRIVATE, SAFT48kHz8BitMono,
    SpeechCategoryAudioIn, DISPID_SGRsCount, SP_VISEME_8,
    SAFT12kHz16BitMono, SFTInput, SGSEnabled,
    DISPID_SGRSTPropertyValue, SRTStandard, SPDKL_DefaultLocation,
    IInternetSecurityManager, DISPID_SPARecoResult, SVF_Emphasis,
    DISPID_SVIsUISupported, DISPID_SAFGuid, DISPID_SRAudioInput,
    DISPID_SVGetVoices, SPBO_AHEAD, DISPID_SRSSupportedLanguages,
    _ULARGE_INTEGER, SpeechPropertyNormalConfidenceThreshold,
    SAFTGSM610_11kHzMono, SAFTCCITT_uLaw_22kHzMono,
    DISPID_SRCEPropertyStringChange, DISPID_SGRSTText,
    ISpeechVoiceStatus, DISPID_SDKSetStringValue, SBOPause,
    SP_VISEME_3, SAFTADPCM_44kHzStereo, SpSharedRecognizer,
    DISPID_SRSClsidEngine, SPINTERFERENCE_NONE,
    Speech_Max_Word_Length, SAFTADPCM_22kHzMono, SPSFunction,
    SGDisplay, SAFT12kHz8BitMono, ISpeechAudioFormat,
    SpeechAddRemoveWord, DISPID_SOTSetId, DISPID_SPIProperties,
    HRESULT, SGRSTTEpsilon, ISpeechXMLRecoResult,
    DISPID_SVAlertBoundary, SASClosed, SAFTNoAssignedFormat,
    SECFDefault, DISPID_SPAPhraseInfo,
    ISpeechGrammarRuleStateTransition,
    ISpeechGrammarRuleStateTransitions, SAFTNonStandardFormat,
    DISPID_SPPNumberOfElements, DISPID_SABIMinNotification,
    SVSFParseSapi, SPINTERFERENCE_TOOLOUD, DISPID_SRGetRecognizers,
    SPFM_OPEN_READONLY, DISPID_SPPChildren, STCLocalServer, SASRun,
    DISPID_SRRTLength, DISPID_SMSALineId, DISPID_SAFSetWaveFormatEx,
    SPCT_SUB_COMMAND, SPCS_DISABLED, SVF_None, DISPID_SOTGetAttribute,
    SAFTCCITT_ALaw_8kHzStereo, eLEXTYPE_PRIVATE3, eLEXTYPE_PRIVATE1,
    SAFTCCITT_ALaw_22kHzMono, SPSMF_SRGS_SEMANTICINTERPRETATION_MS,
    SAFTDefault, Speech_StreamPos_Asap, SVSFIsNotXML, SRSEIsSpeaking,
    ISpeechTextSelectionInformation, DISPID_SOTId,
    DISPID_SVSInputWordLength, SVPOver, DISPID_SRGState,
    IEnumSpObjectTokens, SVSFIsFilename, DISPID_SOTCategory,
    SPPS_Noncontent, SpMemoryStream, SPEI_END_INPUT_STREAM, SPSNoun,
    DISPID_SLPPartOfSpeech, DISPID_SAFGetWaveFormatEx,
    SSSPTRelativeToStart, SVSFVoiceMask, ISpeechObjectToken,
    SVEAudioLevel, SAFT32kHz8BitStereo,
    DISPID_SLAddPronunciationByPhoneIds, SPAS_CLOSED,
    DISPID_SMSADeviceId, DISPID_SVEViseme, SpeechAllElements,
    DISPID_SRGCmdLoadFromFile, SVSFDefault, DISPID_SCSBaseStream,
    _ISpeechVoiceEvents, SSSPTRelativeToCurrentPosition,
    SPWORDPRONUNCIATIONLIST, ISpeechAudioBufferInfo, SSFMOpenForRead,
    SpObjectTokenCategory, DISPIDSPTSI_ActiveLength, SVP_1,
    SAFTTrueSpeech_8kHz1BitMono, DISPID_SPCIdToPhone, SITooSlow,
    DISPID_SVEventInterests, DISPID_SRGIsPronounceable,
    DISPID_SFSOpen, ISpeechPhraseAlternate, SPPS_RESERVED1,
    ISpeechBaseStream, ISpeechRecognizer, SP_VISEME_20, SPSMF_UPS,
    SAFTCCITT_ALaw_8kHzMono, DISPID_SRState, SVP_8, SVP_11,
    SPGS_ENABLED, SPAO_RETAIN_AUDIO, SPEI_HYPOTHESIS,
    DISPID_SVAudioOutputStream, ISpeechResourceLoader, SVP_13,
    SPFM_OPEN_READWRITE, SPSMF_SRGS_SAPIPROPERTIES,
    DISPID_SVEVoiceChange, DISPID_SRCEFalseRecognition,
    SpResourceManager, DISPID_SLPPhoneIds, DISPID_SRCRequestedUIType,
    DISPID_SPCLangId, SAFT16kHz8BitMono, DISPID_SDKSetBinaryValue,
    ISpRecoGrammar2, DISPID_SAStatus,
    SpeechPropertyLowConfidenceThreshold, DISPID_SRIsShared,
    eLEXTYPE_PRIVATE15, DISPID_SOTCreateInstance,
    DISPID_SRGCmdLoadFromResource, DISPID_SRCVoice,
    SREFalseRecognition, SPPROPERTYINFO, SpeechAudioVolume,
    DISPID_SRCESoundStart, DISPID_SRCCmdMaxAlternates,
    ISpResourceManager, DISPID_SVSRunningState, ISpRecoContext2,
    DISPID_SLWsCount, SP_VISEME_13, DISPID_SGRsFindRule,
    SPPS_RESERVED2, SECFIgnoreKanaType, SPINTERFERENCE_NOISE,
    eLEXTYPE_PRIVATE16, SRESoundEnd, SITooLoud, DISPID_SGRAddState,
    SPFM_CREATE_ALWAYS, SpUnCompressedLexicon, eLEXTYPE_RESERVED9,
    SPEVENTSOURCEINFO, SECFIgnoreCase, SAFT44kHz8BitMono,
    SpeechPropertyAdaptationOn, SPEI_RESERVED3, SPSHT_Unknown,
    UINT_PTR, SPEI_END_SR_STREAM, SP_VISEME_17, DISPID_SGRAddResource,
    DISPID_SLWsItem, SpMMAudioEnum, SPPHRASE,
    ISpeechPhraseReplacement, DISPID_SVSLastStreamNumberQueued,
    SDKLCurrentUser, Speech_Max_Pron_Length, SPEI_RESERVED1,
    DISPID_SVSkip, DISPID_SWFEExtraData, DISPID_SPPName, SASStop,
    SPEI_SR_BOOKMARK, ISpSerializeState, SVSFPurgeBeforeSpeak,
    DISPID_SVSpeak, DISPID_SGRAttributes, SREStreamStart,
    DISPID_SVSInputWordPosition, _ISpeechRecoContextEvents,
    DISPID_SPRulesItem, SPBO_PAUSE, DISPID_SVPause,
    DISPID_SPEDisplayAttributes, SpeechCategoryRecognizers,
    DISPID_SOTsItem, SPBO_TIME_UNITS, LONG_PTR, SGLexical, _FILETIME,
    DISPID_SASNonBlockingIO, DISPID_SRCEAdaptation,
    SPSMF_SAPI_PROPERTIES, DISPID_SRCEEnginePrivate,
    DISPID_SABIEventBias, Speech_StreamPos_RealTime,
    SPEI_PROPERTY_STRING_CHANGE, SAFTCCITT_ALaw_44kHzStereo, SPEVENT,
    SWPKnownWordPronounceable, SDTLexicalForm, DISPID_SPRs_NewEnum,
    SAFT22kHz16BitStereo, DISPID_SRRAlternates, DISPID_SPAsCount,
    DISPIDSPTSI_SelectionLength, SVSFUnusedFlags, SPTEXTSELECTIONINFO,
    SPAR_Low, SpLexicon, SpeechVoiceCategoryTTSRate, SP_VISEME_16,
    SpeechCategoryRecoProfiles, SVP_5, SPEI_RECO_OTHER_CONTEXT,
    SVEStartInputStream, SpShortcut, SRTExtendableParse,
    ISpNotifySource, DISPID_SLPsCount, DISPID_SRRTimes,
    DISPID_SRCERecognitionForOtherContext, SpeechTokenIdUserLexicon,
    eLEXTYPE_PRIVATE7, SRAORetainAudio, SVEVoiceChange, SPPS_Unknown,
    DISPID_SRRSetTextFeedback, DISPID_SVVoice, SDTRule,
    SPSEMANTICERRORINFO, SVP_2, DISPID_SVSLastBookmark,
    DISPID_SRCEPhraseStart, DISPID_SPPValue, ISpVoice, SGSDisabled,
    SVSFParseSsml, ISpeechRecoResultTimes, DISPID_SRGDictationUnload,
    DISPID_SAFType, SpeechGrammarTagDictation, DISPID_SRCESoundEnd,
    SGPronounciation, DISPID_SPRNumberOfElements,
    SAFT16kHz16BitStereo, SPDKL_CurrentConfig, DISPID_SMSGetData,
    SAFTCCITT_ALaw_11kHzStereo, DISPID_SPPsItem, SITooQuiet,
    SpeechAudioFormatGUIDText, SPBO_NONE, SpeechTokenValueCLSID,
    SRCS_Disabled, DISPID_SRSetPropertyString, SREStreamEnd,
    DISPID_SRGRules, DISPID_SVAudioOutput, CoClass,
    SAFTGSM610_44kHzMono, DISPID_SRCState,
    DISPID_SPANumberOfElementsInResult, SPAS_STOP,
    SPEI_START_INPUT_STREAM, SRSActiveAlways,
    DISPID_SRSetPropertyNumber, DISPID_SBSFormat,
    SpPhoneticAlphabetConverter, helpstring, SVP_9, SP_VISEME_21,
    DISPID_SGRSAddSpecialTransition, SVP_10, SVP_16,
    ISpeechPhraseRules, DISPID_SLWLangId, SREStateChange,
    SPPS_RESERVED4, eLEXTYPE_MORPHOLOGY, SAFT11kHz16BitMono,
    ISpeechObjectTokens, DISPID_SPELexicalForm, SPPHRASEELEMENT,
    SP_VISEME_7, DISPID_SADefaultFormat, COMMETHOD, ULONG_PTR,
    DISPID_SDKOpenKey, DISPID_SPIRetainedSizeBytes, SPCT_COMMAND,
    DISPID_SRGetPropertyString, DISPID_SRSCurrentStreamNumber,
    DISPID_SPRulesCount, SPEI_SENTENCE_BOUNDARY,
    DISPID_SPRuleNumberOfElements, DISPID_SPIEngineId, SpMMAudioOut,
    SPSERIALIZEDPHRASE, SPPS_LMA, SpeechTokenKeyAttributes,
    DISPID_SRRSaveToMemory, DISPID_SPEActualConfidence,
    DISPID_SPERetainedStreamOffset, ISpRecoGrammar,
    DISPID_SRCEStartStream, ISpeechFileStream, SPCS_ENABLED,
    DISPID_SWFEAvgBytesPerSec, DISPID_SVSCurrentStreamNumber,
    SAFT24kHz8BitStereo, SVP_18, DISPID_SOTCDefault, DISPID_SBSRead,
    DISPID_SRRPhraseInfo, SPFM_NUM_MODES,
    DISPID_SRAllowAudioInputFormatChangesOnNextSet, ISpPhrase,
    SAFTGSM610_22kHzMono, ISpeechAudioStatus,
    DISPID_SPERetainedSizeBytes, DISPID_SPIAudioSizeBytes,
    ISpeechGrammarRules, DISPID_SABufferNotifySize,
    __MIDL___MIDL_itf_sapi_0000_0020_0002, DISPID_SPPFirstElement,
    SECNormalConfidence, DISPID_SVSLastResult, DISPID_SAEventHandle,
    ISpAudio, DISPID_SRGRecoContext, SPEI_SOUND_END,
    DISPID_SRGetFormat, DISPID_SRCEPropertyNumberChange,
    SpeechPropertyResponseSpeed, eLEXTYPE_PRIVATE11,
    DISPID_SRCRetainedAudio, DISPID_SRRTOffsetFromStart,
    SDKLDefaultLocation, SECHighConfidence, DISPID_SLWs_NewEnum,
    DISPID_SLPsItem, SPSLMA, eLEXTYPE_PRIVATE20,
    DISPID_SRGCmdSetRuleState, SP_VISEME_12, DISPID_SRCEAudioLevel,
    SPSERIALIZEDRESULT, SVPAlert, DISPID_SPACommit,
    DISPID_SPPBRestorePhraseFromMemory, DISPID_SRCEBookmark,
    DISPID_SPIAudioSizeTime, SVP_21, SPEI_UNDEFINED,
    SPWT_LEXICAL_NO_SPECIAL_CHARS, DISPID_SGRSTWeight,
    ISpPhoneticAlphabetSelection, ISpeechPhraseAlternates,
    DISPID_SOTRemove, DISPID_SGRSTs_NewEnum, DISPID_SGRSTNextState,
    SVP_20, DISPID_SPEs_NewEnum, DISPID_SRRAudioFormat,
    SGDSActiveWithAutoPause, SVP_17, SAFT32kHz8BitMono,
    DISPID_SDKGetlongValue, SRCS_Enabled, DISPID_SRRAudio,
    DISPID_SRCEventInterests, DISPID_SPEsCount,
    SpeechPropertyHighConfidenceThreshold, eLEXTYPE_USER_SHORTCUT,
    ISpObjectWithToken, SREInterference, SPSHT_OTHER,
    SpPhraseInfoBuilder, eLEXTYPE_RESERVED4,
    DISPID_SRAudioInputStream, SPINTERFERENCE_LATENCY_WARNING,
    SpStreamFormatConverter, ISpEventSink, SpeechAudioFormatGUIDWave,
    SPEI_FALSE_RECOGNITION, DISPID_SRGReset, SAFT12kHz16BitStereo,
    SP_VISEME_2, SLTUser, SLOStatic, DISPID_SPPConfidence,
    DISPID_SPIStartTime, SRATopLevel, SPEI_SR_PRIVATE,
    eLEXTYPE_PRIVATE10, ISpeechPhraseInfo, ISpEventSource,
    DISPID_SOTCGetDataKey, ISpeechWaveFormatEx, DISPID_SGRSRule,
    DISPID_SPIEnginePrivateData, SBONone,
    SPWP_KNOWN_WORD_PRONOUNCEABLE, DISPID_SPEAudioSizeBytes,
    SPWORDPRONUNCIATION, ISpeechPhraseReplacements,
    SSSPTRelativeToEnd, SPAR_Unknown, SPDKL_LocalMachine, SRAONone,
    DISPID_SPAs_NewEnum, ISpNotifySink, DISPID_SGRSAddWordTransition,
    DISPID_SRCEInterference, ISpeechRecoResult, SREAllEvents,
    DISPID_SLPSymbolic, SAFT24kHz16BitMono, SAFT16kHz16BitMono,
    DISPID_SRRGetXMLErrorInfo, DISPID_SLRemovePronunciation, VARIANT,
    tagSPTEXTSELECTIONINFO, SpWaveFormatEx, SPSHT_NotOverriden,
    DISPID_SPEPronunciation, DISPID_SVStatus, SRSActive,
    STCInprocServer, SPSNotOverriden, SPEI_MAX_SR, SGRSTTWildcard,
    tagSTATSTG, DISPID_SRProfile, SPAO_NONE, SPCT_DICTATION,
    SREBookmark, SECLowConfidence, eLEXTYPE_PRIVATE8,
    eLEXTYPE_PRIVATE13, SpeechPropertyResourceUsage,
    DISPID_SRRGetXMLResult, DISPID_SOTGetDescription, SREAdaptation,
    eWORDTYPE_ADDED, ISpeechLexiconWord, DISPID_SBSSeek,
    DISPID_SGRSTsItem, DISPID_SGRSTType, ISpeechPhoneConverter,
    ISpRecognizer2, ISpNotifyTranslator, DISPID_SVSLastBookmarkId,
    SPWT_DISPLAY, SVP_3, DISPID_SOTRemoveStorageFileName,
    SPGS_EXCLUSIVE, DISPID_SVSInputSentenceLength, ISpPhoneConverter,
    DISPID_SWFEBitsPerSample, SAFTADPCM_44kHzMono,
    DISPID_SGRInitialState, ISpRecognizer3, ISpeechLexiconWords,
    SPRECOGNIZERSTATUS, DISPID_SRGCmdLoadFromProprietaryGrammar,
    DISPID_SVSPhonemeId, SPAS_PAUSE, SAFT44kHz16BitStereo, SRTReSent,
    SPWORDLIST, DISPID_SDKDeleteKey, DISPID_SFSClose,
    SPPHRASEREPLACEMENT, SPINTERFERENCE_TOOQUIET, DISPID_SGRSTsCount,
    SPAR_High, SpAudioFormat, SpInprocRecognizer, SPRS_INACTIVE,
    SVSFParseMask, SRESoundStart, SPEI_SR_AUDIO_LEVEL, dispid,
    DISPID_SPRuleParent, ISpDataKey, SPPS_Interjection,
    SpPhoneConverter, SPPS_NotOverriden,
    DISPID_SASCurrentDevicePosition, SPEI_ACTIVE_CATEGORY_CHANGED,
    SpeechPropertyComplexResponseSpeed, DISPID_SRCVoicePurgeEvent,
    SECFNoSpecialChars, DISPID_SPPsCount, DISPID_SVEAudioLevel,
    SVSFlagsAsync, DISPID_SLAddPronunciation, SRADefaultToActive,
    DISPID_SRCERecognizerStateChange, DISPID_SVResume,
    ISpStreamFormatConverter, IServiceProvider, SVP_14,
    SSFMOpenReadWrite, SVSFNLPMask, SDTPronunciation,
    DISPID_SVAllowAudioOuputFormatChangesOnNextSet,
    DISPID_SOTGetStorageFileName, DISPID_SOTDisplayUI,
    ISpeechRecoResult2, ISpeechPhraseInfoBuilder, SRSInactive,
    IUnknown, SPINTERFERENCE_LATENCY_TRUNCATE_BEGIN,
    SpeechEngineProperties, SpeechRegistryUserRoot, SPPHRASERULE,
    SPLO_STATIC, DISPID_SLGetPronunciations,
    DISPID_SPAStartElementInResult, eLEXTYPE_VENDORLEXICON,
    SPSSuppressWord, SGRSTTDictation, DISPID_SRGDictationSetState,
    ISpPhraseAlt, DISPID_SVGetAudioInputs, DISPID_SGRsCommit,
    DISPID_SMSSetData, ISpObjectTokenCategory, SGDSActive,
    SPRST_ACTIVE_ALWAYS, SAFTCCITT_uLaw_44kHzStereo, SRAInterpreter,
    DISPID_SRCCreateGrammar, DISPID_SWFEChannels, _check_version,
    ISpeechPhraseElements, SAFT24kHz8BitMono, SVPNormal,
    DISPID_SRRSpeakAudio, _RemotableHandle, SAFT22kHz8BitStereo,
    SAFT16kHz8BitStereo, ISpeechCustomStream, SP_VISEME_18,
    DISPID_SPRuleName, DISPID_SVEStreamEnd, SP_VISEME_6,
    SPRECOCONTEXTSTATUS, SAFT8kHz16BitStereo, SPPS_Noun,
    SPWT_PRONUNCIATION, SVEWordBoundary, DISPID_SLWPronunciations,
    Library, DISPID_SGRSTRule, SPAUDIOSTATUS, DISPID_SPEsItem,
    SPCT_SUB_DICTATION, SPPHRASEPROPERTY, SSTTTextBuffer,
    SPEI_RESERVED2, SPCT_SLEEP, SPSHORTCUTPAIR, SPEI_SR_RETAINEDAUDIO,
    SpVoice, SREAudioLevel, _lcid, SSFMCreateForWrite,
    DISPID_SRIsUISupported, SPPS_SuppressWord, DISPID_SPRsCount,
    SpeechUserTraining, ISpeechRecoContext, eLEXTYPE_RESERVED8,
    DISPID_SPEDisplayText, SAFTCCITT_ALaw_44kHzMono, SPVPRI_OVER,
    SP_VISEME_1, DISPID_SPEAudioSizeTime, DISPID_SLPs_NewEnum,
    ISpeechPhraseProperty, SPRECORESULTTIMES, DISPID_SVSVisemeId,
    SAFT22kHz8BitMono, DISPID_SMSAMMHandle, SAFT44kHz8BitStereo,
    SDTDisplayText, SPRST_INACTIVE_WITH_PURGE, SSTTDictation,
    SPAR_Medium, SAFTADPCM_8kHzStereo, DISPID_SPPEngineConfidence,
    STCInprocHandler, DISPID_SRRDiscardResultInfo,
    SpSharedRecoContext, DISPID_SRCRetainedAudioFormat,
    DISPID_SVSpeakStream, SREPropertyNumChange, DISPID_SOTCId,
    SP_VISEME_4, SRERecoOtherContext, SPXRO_Alternates_SML, SPXRO_SML,
    SITooFast, DISPID_SLRemovePronunciationByPhoneIds, SP_VISEME_5,
    SRERequestUI, ISpeechRecoGrammar, SAFT11kHz16BitStereo,
    ISpeechRecoResultDispatch, SpeechGrammarTagWildcard, SP_VISEME_11,
    eLEXTYPE_PRIVATE6, DISPID_SPCPhoneToId, SPEI_SOUND_START,
    SPEI_REQUEST_UI, SPSHORTCUTPAIRLIST, DISPID_SGRsItem,
    DISPID_SRRecognizer, DISPID_SRCERequestUI, SPPS_Verb,
    SPEI_START_SR_STREAM, DISPID_SRRRecoContext,
    SpeechDictationTopicSpelling, SPRS_ACTIVE_WITH_AUTO_PAUSE,
    SAFT48kHz16BitMono, SP_VISEME_10, SPEI_RECO_STATE_CHANGE,
    SGRSTTRule, ISpPhoneticAlphabetConverter, DISPID_SRGCommit,
    SPWP_UNKNOWN_WORD_UNPRONOUNCEABLE, ISpShortcut,
    DISPID_SGRsDynamic, SVSFIsXML, SDA_One_Trailing_Space,
    SAFTCCITT_uLaw_22kHzStereo, DISPID_SPRDisplayAttributes,
    SAFTCCITT_uLaw_8kHzStereo, SAFT24kHz16BitStereo, DISPID_SGRName,
    ISpProperties, DISPID_SDKGetStringValue,
    DISPID_SRGSetTextSelection, DISPID_SGRs_NewEnum, DISPID_SRCPause,
    SPWT_LEXICAL, ISpStreamFormat, SPPS_Modifier,
    SpNullPhoneConverter, DISPID_SRRTStreamTime,
    DISPID_SRGCmdLoadFromMemory, STSF_CommonAppData,
    DISPID_SRGDictationLoad, DISPID_SDKEnumKeys, SDKLCurrentConfig,
    SPSVerb, eLEXTYPE_USER, SPINTERFERENCE_NOSIGNAL, SLODynamic,
    SPVPRI_NORMAL, eLEXTYPE_PRIVATE2, SECFEmulateResult, SVP_6,
    DISPID_SAVolume, SAFTCCITT_uLaw_11kHzMono, DISPID_SPRuleChildren,
    DISPMETHOD, ISpRecoCategory, SpMMAudioIn, DISPID_SDKDeleteValue,
    DISPID_SRCRecognizer, SRSInactiveWithPurge,
    DISPID_SPEEngineConfidence, SpCompressedLexicon,
    DISPID_SVEPhoneme, SAFT11kHz8BitStereo, SRAImport, SPSUnknown,
    SPINTERFERENCE_LATENCY_TRUNCATE_END, SPVPRI_ALERT,
    eLEXTYPE_PRIVATE18, SPDKL_CurrentUser, SPRS_ACTIVE_USER_DELIMITED,
    SGRSTTWord, ISpeechMMSysAudio, DISPID_SLWWord, eLEXTYPE_RESERVED7,
    SLTApp, Speech_Default_Weight, DISPID_SPAsItem, ISequentialStream,
    SpTextSelectionInformation, STCRemoteServer, DISPID_SLGetWords,
    SSFMCreate, wireHWND, DISPID_SGRSTransitions,
    DISPID_SRCSetAdaptationData, SAFT48kHz8BitStereo, SPRST_ACTIVE,
    SWTDeleted, ISpeechMemoryStream, DISPID_SLPType,
    DISPID_SVGetProfiles, SPRST_INACTIVE, ISpeechAudio,
    SPEI_ADAPTATION, SAFT8kHz8BitStereo,
    DISPID_SRCAudioInInterferenceStatus, SAFTText, SAFT32kHz16BitMono,
    SpeechRecoProfileProperties, SAFT32kHz16BitStereo,
    DISPID_SPPParent, DISPID_SDKSetLongValue, SP_VISEME_19, SVP_4,
    SRSEDone, DISPID_SPIElements, SDTReplacement,
    ISpeechPhraseProperties, eLEXTYPE_PRIVATE19, DISPID_SVDisplayUI,
    SGRSTTTextBuffer, eLEXTYPE_PRIVATE14, SAFT8kHz16BitMono,
    ISpeechRecognizerStatus, DISPIDSPTSI_SelectionOffset,
    DISPID_SVSyncronousSpeakTimeout, DISPID_SRGSetWordSequenceData,
    DISPID_SOTDataKey, SpObjectToken, ISpMMSysAudio, SVP_15,
    DISPID_SOTCEnumerateTokens, IInternetSecurityMgrSite,
    SVSFParseAutodetect, DISPID_SRCBookmark, ISpRecognizer,
    ISpRecoContext, DISPID_SVEWord, eLEXTYPE_RESERVED6,
    DISPID_SPRuleConfidence, SPEI_PHRASE_START, SGDSInactive,
    DISPID_SVEEnginePrivate, DISPID_SPRText, DISPIDSPTSI_ActiveOffset,
    SAFTADPCM_11kHzStereo, SPRULE, DISPID_SRSAudioStatus,
    DISPID_SWFESamplesPerSec, SAFT12kHz8BitStereo, SPSModifier,
    eLEXTYPE_APP, DISPID_SPRFirstElement,
    DISPID_SPRuleEngineConfidence, SpeechCategoryPhoneConverters,
    SDTProperty, SPRS_ACTIVE, SAFTCCITT_ALaw_11kHzMono,
    eLEXTYPE_PRIVATE4, ISpeechPhraseElement, SGDSActiveUserDelimited,
    WSTRING, DISPID_SLWType, STSF_LocalAppData,
    SAFTCCITT_uLaw_44kHzMono, DISPID_SPRsItem, SPVOICESTATUS,
    SPEI_TTS_BOOKMARK, SPWORD, DISPID_SGRClear, SPWF_INPUT,
    DISPID_SOTCSetId, DISPID_SRAllowVoiceFormatMatchingOnNextSet,
    DISPID_SVEBookmark, ISpeechPhraseRule, SPEI_TTS_AUDIO_LEVEL,
    SpFileStream, SAFTADPCM_8kHzMono, SGLexicalNoSpecialChars,
    SAFTADPCM_11kHzMono, SPEI_VOICE_CHANGE, DISPID_SVRate,
    eWORDTYPE_DELETED, SVEViseme, ISpeechVoice, SVEEndInputStream,
    SpeechRegistryLocalMachineRoot, DISPID_SPISaveToMemory,
    DISPID_SVESentenceBoundary, SREPropertyStringChange, SP_VISEME_0,
    SINoise, DISPID_SRCEEndStream, DISPID_SRCCreateResultFromMemory,
    DISPID_SWFEBlockAlign, DISPID_SPEAudioTimeOffset,
    SPEI_RECOGNITION, SpeechTokenKeyFiles, SGSExclusive, SPEI_MAX_TTS,
    DISPID_SPPs_NewEnum
)


class _SPAUDIOSTATE(IntFlag):
    SPAS_CLOSED = 0
    SPAS_STOP = 1
    SPAS_PAUSE = 2
    SPAS_RUN = 3


class SpeechRuleAttributes(IntFlag):
    SRATopLevel = 1
    SRADefaultToActive = 2
    SRAExport = 4
    SRAImport = 8
    SRAInterpreter = 16
    SRADynamic = 32
    SRARoot = 64


class SpeechAudioFormatType(IntFlag):
    SAFTDefault = -1
    SAFTNoAssignedFormat = 0
    SAFTText = 1
    SAFTNonStandardFormat = 2
    SAFTExtendedAudioFormat = 3
    SAFT8kHz8BitMono = 4
    SAFT8kHz8BitStereo = 5
    SAFT8kHz16BitMono = 6
    SAFT8kHz16BitStereo = 7
    SAFT11kHz8BitMono = 8
    SAFT11kHz8BitStereo = 9
    SAFT11kHz16BitMono = 10
    SAFT11kHz16BitStereo = 11
    SAFT12kHz8BitMono = 12
    SAFT12kHz8BitStereo = 13
    SAFT12kHz16BitMono = 14
    SAFT12kHz16BitStereo = 15
    SAFT16kHz8BitMono = 16
    SAFT16kHz8BitStereo = 17
    SAFT16kHz16BitMono = 18
    SAFT16kHz16BitStereo = 19
    SAFT22kHz8BitMono = 20
    SAFT22kHz8BitStereo = 21
    SAFT22kHz16BitMono = 22
    SAFT22kHz16BitStereo = 23
    SAFT24kHz8BitMono = 24
    SAFT24kHz8BitStereo = 25
    SAFT24kHz16BitMono = 26
    SAFT24kHz16BitStereo = 27
    SAFT32kHz8BitMono = 28
    SAFT32kHz8BitStereo = 29
    SAFT32kHz16BitMono = 30
    SAFT32kHz16BitStereo = 31
    SAFT44kHz8BitMono = 32
    SAFT44kHz8BitStereo = 33
    SAFT44kHz16BitMono = 34
    SAFT44kHz16BitStereo = 35
    SAFT48kHz8BitMono = 36
    SAFT48kHz8BitStereo = 37
    SAFT48kHz16BitMono = 38
    SAFT48kHz16BitStereo = 39
    SAFTTrueSpeech_8kHz1BitMono = 40
    SAFTCCITT_ALaw_8kHzMono = 41
    SAFTCCITT_ALaw_8kHzStereo = 42
    SAFTCCITT_ALaw_11kHzMono = 43
    SAFTCCITT_ALaw_11kHzStereo = 44
    SAFTCCITT_ALaw_22kHzMono = 45
    SAFTCCITT_ALaw_22kHzStereo = 46
    SAFTCCITT_ALaw_44kHzMono = 47
    SAFTCCITT_ALaw_44kHzStereo = 48
    SAFTCCITT_uLaw_8kHzMono = 49
    SAFTCCITT_uLaw_8kHzStereo = 50
    SAFTCCITT_uLaw_11kHzMono = 51
    SAFTCCITT_uLaw_11kHzStereo = 52
    SAFTCCITT_uLaw_22kHzMono = 53
    SAFTCCITT_uLaw_22kHzStereo = 54
    SAFTCCITT_uLaw_44kHzMono = 55
    SAFTCCITT_uLaw_44kHzStereo = 56
    SAFTADPCM_8kHzMono = 57
    SAFTADPCM_8kHzStereo = 58
    SAFTADPCM_11kHzMono = 59
    SAFTADPCM_11kHzStereo = 60
    SAFTADPCM_22kHzMono = 61
    SAFTADPCM_22kHzStereo = 62
    SAFTADPCM_44kHzMono = 63
    SAFTADPCM_44kHzStereo = 64
    SAFTGSM610_8kHzMono = 65
    SAFTGSM610_11kHzMono = 66
    SAFTGSM610_22kHzMono = 67
    SAFTGSM610_44kHzMono = 68


class SPFILEMODE(IntFlag):
    SPFM_OPEN_READONLY = 0
    SPFM_OPEN_READWRITE = 1
    SPFM_CREATE = 2
    SPFM_CREATE_ALWAYS = 3
    SPFM_NUM_MODES = 4


class SPVPRIORITY(IntFlag):
    SPVPRI_NORMAL = 0
    SPVPRI_ALERT = 1
    SPVPRI_OVER = 2


class SPEVENTENUM(IntFlag):
    SPEI_UNDEFINED = 0
    SPEI_START_INPUT_STREAM = 1
    SPEI_END_INPUT_STREAM = 2
    SPEI_VOICE_CHANGE = 3
    SPEI_TTS_BOOKMARK = 4
    SPEI_WORD_BOUNDARY = 5
    SPEI_PHONEME = 6
    SPEI_SENTENCE_BOUNDARY = 7
    SPEI_VISEME = 8
    SPEI_TTS_AUDIO_LEVEL = 9
    SPEI_TTS_PRIVATE = 15
    SPEI_MIN_TTS = 1
    SPEI_MAX_TTS = 15
    SPEI_END_SR_STREAM = 34
    SPEI_SOUND_START = 35
    SPEI_SOUND_END = 36
    SPEI_PHRASE_START = 37
    SPEI_RECOGNITION = 38
    SPEI_HYPOTHESIS = 39
    SPEI_SR_BOOKMARK = 40
    SPEI_PROPERTY_NUM_CHANGE = 41
    SPEI_PROPERTY_STRING_CHANGE = 42
    SPEI_FALSE_RECOGNITION = 43
    SPEI_INTERFERENCE = 44
    SPEI_REQUEST_UI = 45
    SPEI_RECO_STATE_CHANGE = 46
    SPEI_ADAPTATION = 47
    SPEI_START_SR_STREAM = 48
    SPEI_RECO_OTHER_CONTEXT = 49
    SPEI_SR_AUDIO_LEVEL = 50
    SPEI_SR_RETAINEDAUDIO = 51
    SPEI_SR_PRIVATE = 52
    SPEI_ACTIVE_CATEGORY_CHANGED = 53
    SPEI_RESERVED5 = 54
    SPEI_RESERVED6 = 55
    SPEI_MIN_SR = 34
    SPEI_MAX_SR = 55
    SPEI_RESERVED1 = 30
    SPEI_RESERVED2 = 33
    SPEI_RESERVED3 = 63


class SpeechStreamFileMode(IntFlag):
    SSFMOpenForRead = 0
    SSFMOpenReadWrite = 1
    SSFMCreate = 2
    SSFMCreateForWrite = 3


class SpeechRunState(IntFlag):
    SRSEDone = 1
    SRSEIsSpeaking = 2


class SpeechInterference(IntFlag):
    SINone = 0
    SINoise = 1
    SINoSignal = 2
    SITooLoud = 3
    SITooQuiet = 4
    SITooFast = 5
    SITooSlow = 6


class SpeechRecoEvents(IntFlag):
    SREStreamEnd = 1
    SRESoundStart = 2
    SRESoundEnd = 4
    SREPhraseStart = 8
    SRERecognition = 16
    SREHypothesis = 32
    SREBookmark = 64
    SREPropertyNumChange = 128
    SREPropertyStringChange = 256
    SREFalseRecognition = 512
    SREInterference = 1024
    SRERequestUI = 2048
    SREStateChange = 4096
    SREAdaptation = 8192
    SREStreamStart = 16384
    SRERecoOtherContext = 32768
    SREAudioLevel = 65536
    SREPrivate = 262144
    SREAllEvents = 393215


class SpeechRecoContextState(IntFlag):
    SRCS_Disabled = 0
    SRCS_Enabled = 1


class SpeechRetainedAudioOptions(IntFlag):
    SRAONone = 0
    SRAORetainAudio = 1


class SpeechBookmarkOptions(IntFlag):
    SBONone = 0
    SBOPause = 1


class SpeechGrammarWordType(IntFlag):
    SGDisplay = 0
    SGLexical = 1
    SGPronounciation = 2
    SGLexicalNoSpecialChars = 3


class SpeechSpecialTransitionType(IntFlag):
    SSTTWildcard = 1
    SSTTDictation = 2
    SSTTTextBuffer = 3


class SPAUDIOOPTIONS(IntFlag):
    SPAO_NONE = 0
    SPAO_RETAIN_AUDIO = 1


class SPBOOKMARKOPTIONS(IntFlag):
    SPBO_NONE = 0
    SPBO_PAUSE = 1
    SPBO_AHEAD = 2
    SPBO_TIME_UNITS = 4


class SPCONTEXTSTATE(IntFlag):
    SPCS_DISABLED = 0
    SPCS_ENABLED = 1


class SpeechGrammarRuleStateTransitionType(IntFlag):
    SGRSTTEpsilon = 0
    SGRSTTWord = 1
    SGRSTTRule = 2
    SGRSTTDictation = 3
    SGRSTTWildcard = 4
    SGRSTTTextBuffer = 5


class SPRECOSTATE(IntFlag):
    SPRST_INACTIVE = 0
    SPRST_ACTIVE = 1
    SPRST_ACTIVE_ALWAYS = 2
    SPRST_INACTIVE_WITH_PURGE = 3
    SPRST_NUM_STATES = 4


class SPWAVEFORMATTYPE(IntFlag):
    SPWF_INPUT = 0
    SPWF_SRENGINE = 1


class SpeechGrammarState(IntFlag):
    SGSEnabled = 1
    SGSDisabled = 0
    SGSExclusive = 3


class SpeechVoiceSpeakFlags(IntFlag):
    SVSFDefault = 0
    SVSFlagsAsync = 1
    SVSFPurgeBeforeSpeak = 2
    SVSFIsFilename = 4
    SVSFIsXML = 8
    SVSFIsNotXML = 16
    SVSFPersistXML = 32
    SVSFNLPSpeakPunc = 64
    SVSFParseSapi = 128
    SVSFParseSsml = 256
    SVSFParseAutodetect = 0
    SVSFNLPMask = 64
    SVSFParseMask = 384
    SVSFVoiceMask = 511
    SVSFUnusedFlags = -512


class SpeechDiscardType(IntFlag):
    SDTProperty = 1
    SDTReplacement = 2
    SDTRule = 4
    SDTDisplayText = 8
    SDTLexicalForm = 16
    SDTPronunciation = 32
    SDTAudio = 64
    SDTAlternates = 128
    SDTAll = 255


class SpeechDisplayAttributes(IntFlag):
    SDA_No_Trailing_Space = 0
    SDA_One_Trailing_Space = 2
    SDA_Two_Trailing_Spaces = 4
    SDA_Consume_Leading_Spaces = 8


class SpeechEngineConfidence(IntFlag):
    SECLowConfidence = -1
    SECNormalConfidence = 0
    SECHighConfidence = 1


class SpeechAudioState(IntFlag):
    SASClosed = 0
    SASStop = 1
    SASPause = 2
    SASRun = 3


class SPGRAMMARWORDTYPE(IntFlag):
    SPWT_DISPLAY = 0
    SPWT_LEXICAL = 1
    SPWT_PRONUNCIATION = 2
    SPWT_LEXICAL_NO_SPECIAL_CHARS = 3


class SPLOADOPTIONS(IntFlag):
    SPLO_STATIC = 0
    SPLO_DYNAMIC = 1


class SPRULESTATE(IntFlag):
    SPRS_INACTIVE = 0
    SPRS_ACTIVE = 1
    SPRS_ACTIVE_WITH_AUTO_PAUSE = 3
    SPRS_ACTIVE_USER_DELIMITED = 4


class SPWORDPRONOUNCEABLE(IntFlag):
    SPWP_UNKNOWN_WORD_UNPRONOUNCEABLE = 0
    SPWP_UNKNOWN_WORD_PRONOUNCEABLE = 1
    SPWP_KNOWN_WORD_PRONOUNCEABLE = 2


class SPGRAMMARSTATE(IntFlag):
    SPGS_DISABLED = 0
    SPGS_ENABLED = 1
    SPGS_EXCLUSIVE = 3


class SpeechTokenContext(IntFlag):
    STCInprocServer = 1
    STCInprocHandler = 2
    STCLocalServer = 4
    STCRemoteServer = 16
    STCAll = 23


class SpeechTokenShellFolder(IntFlag):
    STSF_AppData = 26
    STSF_LocalAppData = 28
    STSF_CommonAppData = 35
    STSF_FlagCreate = 32768


class SpeechLexiconType(IntFlag):
    SLTUser = 1
    SLTApp = 2


class SpeechPartOfSpeech(IntFlag):
    SPSNotOverriden = -1
    SPSUnknown = 0
    SPSNoun = 4096
    SPSVerb = 8192
    SPSModifier = 12288
    SPSFunction = 16384
    SPSInterjection = 20480
    SPSLMA = 28672
    SPSSuppressWord = 61440


class SPSEMANTICFORMAT(IntFlag):
    SPSMF_SAPI_PROPERTIES = 0
    SPSMF_SRGS_SEMANTICINTERPRETATION_MS = 1
    SPSMF_SRGS_SAPIPROPERTIES = 2
    SPSMF_UPS = 4
    SPSMF_SRGS_SEMANTICINTERPRETATION_W3C = 8


class SpeechStreamSeekPositionType(IntFlag):
    SSSPTRelativeToStart = 0
    SSSPTRelativeToCurrentPosition = 1
    SSSPTRelativeToEnd = 2


class SpeechWordType(IntFlag):
    SWTAdded = 1
    SWTDeleted = 2


class SPINTERFERENCE(IntFlag):
    SPINTERFERENCE_NONE = 0
    SPINTERFERENCE_NOISE = 1
    SPINTERFERENCE_NOSIGNAL = 2
    SPINTERFERENCE_TOOLOUD = 3
    SPINTERFERENCE_TOOQUIET = 4
    SPINTERFERENCE_TOOFAST = 5
    SPINTERFERENCE_TOOSLOW = 6
    SPINTERFERENCE_LATENCY_WARNING = 7
    SPINTERFERENCE_LATENCY_TRUNCATE_BEGIN = 8
    SPINTERFERENCE_LATENCY_TRUNCATE_END = 9


class SpeechDataKeyLocation(IntFlag):
    SDKLDefaultLocation = 0
    SDKLCurrentUser = 1
    SDKLLocalMachine = 2
    SDKLCurrentConfig = 5


class SPXMLRESULTOPTIONS(IntFlag):
    SPXRO_SML = 0
    SPXRO_Alternates_SML = 1


class SPADAPTATIONRELEVANCE(IntFlag):
    SPAR_Unknown = 0
    SPAR_Low = 1
    SPAR_Medium = 2
    SPAR_High = 3


class SPCATEGORYTYPE(IntFlag):
    SPCT_COMMAND = 0
    SPCT_DICTATION = 1
    SPCT_SLEEP = 2
    SPCT_SUB_COMMAND = 3
    SPCT_SUB_DICTATION = 4


class SPDATAKEYLOCATION(IntFlag):
    SPDKL_DefaultLocation = 0
    SPDKL_CurrentUser = 1
    SPDKL_LocalMachine = 2
    SPDKL_CurrentConfig = 5


class SpeechRecognitionType(IntFlag):
    SRTStandard = 0
    SRTAutopause = 1
    SRTEmulated = 2
    SRTSMLTimeout = 4
    SRTExtendableParse = 8
    SRTReSent = 16


class SpeechRecognizerState(IntFlag):
    SRSInactive = 0
    SRSActive = 1
    SRSActiveAlways = 2
    SRSInactiveWithPurge = 3


class SPPARTOFSPEECH(IntFlag):
    SPPS_NotOverriden = -1
    SPPS_Unknown = 0
    SPPS_Noun = 4096
    SPPS_Verb = 8192
    SPPS_Modifier = 12288
    SPPS_Function = 16384
    SPPS_Interjection = 20480
    SPPS_Noncontent = 24576
    SPPS_LMA = 28672
    SPPS_SuppressWord = 61440


class SPLEXICONTYPE(IntFlag):
    eLEXTYPE_USER = 1
    eLEXTYPE_APP = 2
    eLEXTYPE_VENDORLEXICON = 4
    eLEXTYPE_LETTERTOSOUND = 8
    eLEXTYPE_MORPHOLOGY = 16
    eLEXTYPE_RESERVED4 = 32
    eLEXTYPE_USER_SHORTCUT = 64
    eLEXTYPE_RESERVED6 = 128
    eLEXTYPE_RESERVED7 = 256
    eLEXTYPE_RESERVED8 = 512
    eLEXTYPE_RESERVED9 = 1024
    eLEXTYPE_RESERVED10 = 2048
    eLEXTYPE_PRIVATE1 = 4096
    eLEXTYPE_PRIVATE2 = 8192
    eLEXTYPE_PRIVATE3 = 16384
    eLEXTYPE_PRIVATE4 = 32768
    eLEXTYPE_PRIVATE5 = 65536
    eLEXTYPE_PRIVATE6 = 131072
    eLEXTYPE_PRIVATE7 = 262144
    eLEXTYPE_PRIVATE8 = 524288
    eLEXTYPE_PRIVATE9 = 1048576
    eLEXTYPE_PRIVATE10 = 2097152
    eLEXTYPE_PRIVATE11 = 4194304
    eLEXTYPE_PRIVATE12 = 8388608
    eLEXTYPE_PRIVATE13 = 16777216
    eLEXTYPE_PRIVATE14 = 33554432
    eLEXTYPE_PRIVATE15 = 67108864
    eLEXTYPE_PRIVATE16 = 134217728
    eLEXTYPE_PRIVATE17 = 268435456
    eLEXTYPE_PRIVATE18 = 536870912
    eLEXTYPE_PRIVATE19 = 1073741824
    eLEXTYPE_PRIVATE20 = -2147483648


class SPWORDTYPE(IntFlag):
    eWORDTYPE_ADDED = 1
    eWORDTYPE_DELETED = 2


class SPSHORTCUTTYPE(IntFlag):
    SPSHT_NotOverriden = -1
    SPSHT_Unknown = 0
    SPSHT_EMAIL = 4096
    SPSHT_OTHER = 8192
    SPPS_RESERVED1 = 12288
    SPPS_RESERVED2 = 16384
    SPPS_RESERVED3 = 20480
    SPPS_RESERVED4 = 61440


class SpeechVisemeType(IntFlag):
    SVP_0 = 0
    SVP_1 = 1
    SVP_2 = 2
    SVP_3 = 3
    SVP_4 = 4
    SVP_5 = 5
    SVP_6 = 6
    SVP_7 = 7
    SVP_8 = 8
    SVP_9 = 9
    SVP_10 = 10
    SVP_11 = 11
    SVP_12 = 12
    SVP_13 = 13
    SVP_14 = 14
    SVP_15 = 15
    SVP_16 = 16
    SVP_17 = 17
    SVP_18 = 18
    SVP_19 = 19
    SVP_20 = 20
    SVP_21 = 21


class SPVISEMES(IntFlag):
    SP_VISEME_0 = 0
    SP_VISEME_1 = 1
    SP_VISEME_2 = 2
    SP_VISEME_3 = 3
    SP_VISEME_4 = 4
    SP_VISEME_5 = 5
    SP_VISEME_6 = 6
    SP_VISEME_7 = 7
    SP_VISEME_8 = 8
    SP_VISEME_9 = 9
    SP_VISEME_10 = 10
    SP_VISEME_11 = 11
    SP_VISEME_12 = 12
    SP_VISEME_13 = 13
    SP_VISEME_14 = 14
    SP_VISEME_15 = 15
    SP_VISEME_16 = 16
    SP_VISEME_17 = 17
    SP_VISEME_18 = 18
    SP_VISEME_19 = 19
    SP_VISEME_20 = 20
    SP_VISEME_21 = 21


class SpeechLoadOption(IntFlag):
    SLOStatic = 0
    SLODynamic = 1


class SpeechRuleState(IntFlag):
    SGDSInactive = 0
    SGDSActive = 1
    SGDSActiveWithAutoPause = 3
    SGDSActiveUserDelimited = 4


class SpeechWordPronounceable(IntFlag):
    SWPUnknownWordUnpronounceable = 0
    SWPUnknownWordPronounceable = 1
    SWPKnownWordPronounceable = 2


class DISPID_SpeechDataKey(IntFlag):
    DISPID_SDKSetBinaryValue = 1
    DISPID_SDKGetBinaryValue = 2
    DISPID_SDKSetStringValue = 3
    DISPID_SDKGetStringValue = 4
    DISPID_SDKSetLongValue = 5
    DISPID_SDKGetlongValue = 6
    DISPID_SDKOpenKey = 7
    DISPID_SDKCreateKey = 8
    DISPID_SDKDeleteKey = 9
    DISPID_SDKDeleteValue = 10
    DISPID_SDKEnumKeys = 11
    DISPID_SDKEnumValues = 12


class DISPID_SpeechObjectToken(IntFlag):
    DISPID_SOTId = 1
    DISPID_SOTDataKey = 2
    DISPID_SOTCategory = 3
    DISPID_SOTGetDescription = 4
    DISPID_SOTSetId = 5
    DISPID_SOTGetAttribute = 6
    DISPID_SOTCreateInstance = 7
    DISPID_SOTRemove = 8
    DISPID_SOTGetStorageFileName = 9
    DISPID_SOTRemoveStorageFileName = 10
    DISPID_SOTIsUISupported = 11
    DISPID_SOTDisplayUI = 12
    DISPID_SOTMatchesAttributes = 13


class DISPID_SpeechObjectTokens(IntFlag):
    DISPID_SOTsCount = 1
    DISPID_SOTsItem = 0
    DISPID_SOTs_NewEnum = -4


class DISPID_SpeechObjectTokenCategory(IntFlag):
    DISPID_SOTCId = 1
    DISPID_SOTCDefault = 2
    DISPID_SOTCSetId = 3
    DISPID_SOTCGetDataKey = 4
    DISPID_SOTCEnumerateTokens = 5


class DISPID_SpeechAudioFormat(IntFlag):
    DISPID_SAFType = 1
    DISPID_SAFGuid = 2
    DISPID_SAFGetWaveFormatEx = 3
    DISPID_SAFSetWaveFormatEx = 4


class DISPID_SpeechBaseStream(IntFlag):
    DISPID_SBSFormat = 1
    DISPID_SBSRead = 2
    DISPID_SBSWrite = 3
    DISPID_SBSSeek = 4


class DISPID_SpeechAudio(IntFlag):
    DISPID_SAStatus = 200
    DISPID_SABufferInfo = 201
    DISPID_SADefaultFormat = 202
    DISPID_SAVolume = 203
    DISPID_SABufferNotifySize = 204
    DISPID_SAEventHandle = 205
    DISPID_SASetState = 206


class DISPID_SpeechMMSysAudio(IntFlag):
    DISPID_SMSADeviceId = 300
    DISPID_SMSALineId = 301
    DISPID_SMSAMMHandle = 302


class DISPID_SpeechFileStream(IntFlag):
    DISPID_SFSOpen = 100
    DISPID_SFSClose = 101


class DISPID_SpeechCustomStream(IntFlag):
    DISPID_SCSBaseStream = 100


class DISPID_SpeechMemoryStream(IntFlag):
    DISPID_SMSSetData = 100
    DISPID_SMSGetData = 101


class DISPID_SpeechAudioStatus(IntFlag):
    DISPID_SASFreeBufferSpace = 1
    DISPID_SASNonBlockingIO = 2
    DISPID_SASState = 3
    DISPID_SASCurrentSeekPosition = 4
    DISPID_SASCurrentDevicePosition = 5


class DISPID_SpeechAudioBufferInfo(IntFlag):
    DISPID_SABIMinNotification = 1
    DISPID_SABIBufferSize = 2
    DISPID_SABIEventBias = 3


class DISPID_SpeechWaveFormatEx(IntFlag):
    DISPID_SWFEFormatTag = 1
    DISPID_SWFEChannels = 2
    DISPID_SWFESamplesPerSec = 3
    DISPID_SWFEAvgBytesPerSec = 4
    DISPID_SWFEBlockAlign = 5
    DISPID_SWFEBitsPerSample = 6
    DISPID_SWFEExtraData = 7


class DISPID_SpeechVoice(IntFlag):
    DISPID_SVStatus = 1
    DISPID_SVVoice = 2
    DISPID_SVAudioOutput = 3
    DISPID_SVAudioOutputStream = 4
    DISPID_SVRate = 5
    DISPID_SVVolume = 6
    DISPID_SVAllowAudioOuputFormatChangesOnNextSet = 7
    DISPID_SVEventInterests = 8
    DISPID_SVPriority = 9
    DISPID_SVAlertBoundary = 10
    DISPID_SVSyncronousSpeakTimeout = 11
    DISPID_SVSpeak = 12
    DISPID_SVSpeakStream = 13
    DISPID_SVPause = 14
    DISPID_SVResume = 15
    DISPID_SVSkip = 16
    DISPID_SVGetVoices = 17
    DISPID_SVGetAudioOutputs = 18
    DISPID_SVWaitUntilDone = 19
    DISPID_SVSpeakCompleteEvent = 20
    DISPID_SVIsUISupported = 21
    DISPID_SVDisplayUI = 22


class DISPID_SpeechVoiceStatus(IntFlag):
    DISPID_SVSCurrentStreamNumber = 1
    DISPID_SVSLastStreamNumberQueued = 2
    DISPID_SVSLastResult = 3
    DISPID_SVSRunningState = 4
    DISPID_SVSInputWordPosition = 5
    DISPID_SVSInputWordLength = 6
    DISPID_SVSInputSentencePosition = 7
    DISPID_SVSInputSentenceLength = 8
    DISPID_SVSLastBookmark = 9
    DISPID_SVSLastBookmarkId = 10
    DISPID_SVSPhonemeId = 11
    DISPID_SVSVisemeId = 12


class DISPID_SpeechVoiceEvent(IntFlag):
    DISPID_SVEStreamStart = 1
    DISPID_SVEStreamEnd = 2
    DISPID_SVEVoiceChange = 3
    DISPID_SVEBookmark = 4
    DISPID_SVEWord = 5
    DISPID_SVEPhoneme = 6
    DISPID_SVESentenceBoundary = 7
    DISPID_SVEViseme = 8
    DISPID_SVEAudioLevel = 9
    DISPID_SVEEnginePrivate = 10


class SpeechFormatType(IntFlag):
    SFTInput = 0
    SFTSREngine = 1


class DISPID_SpeechRecognizer(IntFlag):
    DISPID_SRRecognizer = 1
    DISPID_SRAllowAudioInputFormatChangesOnNextSet = 2
    DISPID_SRAudioInput = 3
    DISPID_SRAudioInputStream = 4
    DISPID_SRIsShared = 5
    DISPID_SRState = 6
    DISPID_SRStatus = 7
    DISPID_SRProfile = 8
    DISPID_SREmulateRecognition = 9
    DISPID_SRCreateRecoContext = 10
    DISPID_SRGetFormat = 11
    DISPID_SRSetPropertyNumber = 12
    DISPID_SRGetPropertyNumber = 13
    DISPID_SRSetPropertyString = 14
    DISPID_SRGetPropertyString = 15
    DISPID_SRIsUISupported = 16
    DISPID_SRDisplayUI = 17
    DISPID_SRGetRecognizers = 18
    DISPID_SVGetAudioInputs = 19
    DISPID_SVGetProfiles = 20


class SpeechEmulationCompareFlags(IntFlag):
    SECFIgnoreCase = 1
    SECFIgnoreKanaType = 65536
    SECFIgnoreWidth = 131072
    SECFNoSpecialChars = 536870912
    SECFEmulateResult = 1073741824
    SECFDefault = 196609


class DISPID_SpeechRecognizerStatus(IntFlag):
    DISPID_SRSAudioStatus = 1
    DISPID_SRSCurrentStreamPosition = 2
    DISPID_SRSCurrentStreamNumber = 3
    DISPID_SRSNumberOfActiveRules = 4
    DISPID_SRSClsidEngine = 5
    DISPID_SRSSupportedLanguages = 6


class DISPID_SpeechRecoContext(IntFlag):
    DISPID_SRCRecognizer = 1
    DISPID_SRCAudioInInterferenceStatus = 2
    DISPID_SRCRequestedUIType = 3
    DISPID_SRCVoice = 4
    DISPID_SRAllowVoiceFormatMatchingOnNextSet = 5
    DISPID_SRCVoicePurgeEvent = 6
    DISPID_SRCEventInterests = 7
    DISPID_SRCCmdMaxAlternates = 8
    DISPID_SRCState = 9
    DISPID_SRCRetainedAudio = 10
    DISPID_SRCRetainedAudioFormat = 11
    DISPID_SRCPause = 12
    DISPID_SRCResume = 13
    DISPID_SRCCreateGrammar = 14
    DISPID_SRCCreateResultFromMemory = 15
    DISPID_SRCBookmark = 16
    DISPID_SRCSetAdaptationData = 17


class DISPIDSPRG(IntFlag):
    DISPID_SRGId = 1
    DISPID_SRGRecoContext = 2
    DISPID_SRGState = 3
    DISPID_SRGRules = 4
    DISPID_SRGReset = 5
    DISPID_SRGCommit = 6
    DISPID_SRGCmdLoadFromFile = 7
    DISPID_SRGCmdLoadFromObject = 8
    DISPID_SRGCmdLoadFromResource = 9
    DISPID_SRGCmdLoadFromMemory = 10
    DISPID_SRGCmdLoadFromProprietaryGrammar = 11
    DISPID_SRGCmdSetRuleState = 12
    DISPID_SRGCmdSetRuleIdState = 13
    DISPID_SRGDictationLoad = 14
    DISPID_SRGDictationUnload = 15
    DISPID_SRGDictationSetState = 16
    DISPID_SRGSetWordSequenceData = 17
    DISPID_SRGSetTextSelection = 18
    DISPID_SRGIsPronounceable = 19


class DISPID_SpeechRecoContextEvents(IntFlag):
    DISPID_SRCEStartStream = 1
    DISPID_SRCEEndStream = 2
    DISPID_SRCEBookmark = 3
    DISPID_SRCESoundStart = 4
    DISPID_SRCESoundEnd = 5
    DISPID_SRCEPhraseStart = 6
    DISPID_SRCERecognition = 7
    DISPID_SRCEHypothesis = 8
    DISPID_SRCEPropertyNumberChange = 9
    DISPID_SRCEPropertyStringChange = 10
    DISPID_SRCEFalseRecognition = 11
    DISPID_SRCEInterference = 12
    DISPID_SRCERequestUI = 13
    DISPID_SRCERecognizerStateChange = 14
    DISPID_SRCEAdaptation = 15
    DISPID_SRCERecognitionForOtherContext = 16
    DISPID_SRCEAudioLevel = 17
    DISPID_SRCEEnginePrivate = 18


class DISPID_SpeechGrammarRule(IntFlag):
    DISPID_SGRAttributes = 1
    DISPID_SGRInitialState = 2
    DISPID_SGRName = 3
    DISPID_SGRId = 4
    DISPID_SGRClear = 5
    DISPID_SGRAddResource = 6
    DISPID_SGRAddState = 7


class DISPID_SpeechGrammarRules(IntFlag):
    DISPID_SGRsCount = 1
    DISPID_SGRsDynamic = 2
    DISPID_SGRsAdd = 3
    DISPID_SGRsCommit = 4
    DISPID_SGRsCommitAndSave = 5
    DISPID_SGRsFindRule = 6
    DISPID_SGRsItem = 0
    DISPID_SGRs_NewEnum = -4


class DISPID_SpeechGrammarRuleState(IntFlag):
    DISPID_SGRSRule = 1
    DISPID_SGRSTransitions = 2
    DISPID_SGRSAddWordTransition = 3
    DISPID_SGRSAddRuleTransition = 4
    DISPID_SGRSAddSpecialTransition = 5


class DISPID_SpeechGrammarRuleStateTransitions(IntFlag):
    DISPID_SGRSTsCount = 1
    DISPID_SGRSTsItem = 0
    DISPID_SGRSTs_NewEnum = -4


class DISPID_SpeechGrammarRuleStateTransition(IntFlag):
    DISPID_SGRSTType = 1
    DISPID_SGRSTText = 2
    DISPID_SGRSTRule = 3
    DISPID_SGRSTWeight = 4
    DISPID_SGRSTPropertyName = 5
    DISPID_SGRSTPropertyId = 6
    DISPID_SGRSTPropertyValue = 7
    DISPID_SGRSTNextState = 8


class DISPIDSPTSI(IntFlag):
    DISPIDSPTSI_ActiveOffset = 1
    DISPIDSPTSI_ActiveLength = 2
    DISPIDSPTSI_SelectionOffset = 3
    DISPIDSPTSI_SelectionLength = 4


class DISPID_SpeechRecoResult(IntFlag):
    DISPID_SRRRecoContext = 1
    DISPID_SRRTimes = 2
    DISPID_SRRAudioFormat = 3
    DISPID_SRRPhraseInfo = 4
    DISPID_SRRAlternates = 5
    DISPID_SRRAudio = 6
    DISPID_SRRSpeakAudio = 7
    DISPID_SRRSaveToMemory = 8
    DISPID_SRRDiscardResultInfo = 9


class DISPID_SpeechXMLRecoResult(IntFlag):
    DISPID_SRRGetXMLResult = 10
    DISPID_SRRGetXMLErrorInfo = 11


class DISPID_SpeechRecoResult2(IntFlag):
    DISPID_SRRSetTextFeedback = 12


class DISPID_SpeechPhraseBuilder(IntFlag):
    DISPID_SPPBRestorePhraseFromMemory = 1


class DISPID_SpeechRecoResultTimes(IntFlag):
    DISPID_SRRTStreamTime = 1
    DISPID_SRRTLength = 2
    DISPID_SRRTTickCount = 3
    DISPID_SRRTOffsetFromStart = 4


class DISPID_SpeechPhraseAlternate(IntFlag):
    DISPID_SPARecoResult = 1
    DISPID_SPAStartElementInResult = 2
    DISPID_SPANumberOfElementsInResult = 3
    DISPID_SPAPhraseInfo = 4
    DISPID_SPACommit = 5


class DISPID_SpeechPhraseAlternates(IntFlag):
    DISPID_SPAsCount = 1
    DISPID_SPAsItem = 0
    DISPID_SPAs_NewEnum = -4


class DISPID_SpeechPhraseInfo(IntFlag):
    DISPID_SPILanguageId = 1
    DISPID_SPIGrammarId = 2
    DISPID_SPIStartTime = 3
    DISPID_SPIAudioStreamPosition = 4
    DISPID_SPIAudioSizeBytes = 5
    DISPID_SPIRetainedSizeBytes = 6
    DISPID_SPIAudioSizeTime = 7
    DISPID_SPIRule = 8
    DISPID_SPIProperties = 9
    DISPID_SPIElements = 10
    DISPID_SPIReplacements = 11
    DISPID_SPIEngineId = 12
    DISPID_SPIEnginePrivateData = 13
    DISPID_SPISaveToMemory = 14
    DISPID_SPIGetText = 15
    DISPID_SPIGetDisplayAttributes = 16


class DISPID_SpeechPhraseElement(IntFlag):
    DISPID_SPEAudioTimeOffset = 1
    DISPID_SPEAudioSizeTime = 2
    DISPID_SPEAudioStreamOffset = 3
    DISPID_SPEAudioSizeBytes = 4
    DISPID_SPERetainedStreamOffset = 5
    DISPID_SPERetainedSizeBytes = 6
    DISPID_SPEDisplayText = 7
    DISPID_SPELexicalForm = 8
    DISPID_SPEPronunciation = 9
    DISPID_SPEDisplayAttributes = 10
    DISPID_SPERequiredConfidence = 11
    DISPID_SPEActualConfidence = 12
    DISPID_SPEEngineConfidence = 13


class DISPID_SpeechPhraseElements(IntFlag):
    DISPID_SPEsCount = 1
    DISPID_SPEsItem = 0
    DISPID_SPEs_NewEnum = -4


class DISPID_SpeechPhraseReplacement(IntFlag):
    DISPID_SPRDisplayAttributes = 1
    DISPID_SPRText = 2
    DISPID_SPRFirstElement = 3
    DISPID_SPRNumberOfElements = 4


class DISPID_SpeechPhraseReplacements(IntFlag):
    DISPID_SPRsCount = 1
    DISPID_SPRsItem = 0
    DISPID_SPRs_NewEnum = -4


class DISPID_SpeechPhraseProperty(IntFlag):
    DISPID_SPPName = 1
    DISPID_SPPId = 2
    DISPID_SPPValue = 3
    DISPID_SPPFirstElement = 4
    DISPID_SPPNumberOfElements = 5
    DISPID_SPPEngineConfidence = 6
    DISPID_SPPConfidence = 7
    DISPID_SPPParent = 8
    DISPID_SPPChildren = 9


class DISPID_SpeechPhraseProperties(IntFlag):
    DISPID_SPPsCount = 1
    DISPID_SPPsItem = 0
    DISPID_SPPs_NewEnum = -4


class DISPID_SpeechPhraseRule(IntFlag):
    DISPID_SPRuleName = 1
    DISPID_SPRuleId = 2
    DISPID_SPRuleFirstElement = 3
    DISPID_SPRuleNumberOfElements = 4
    DISPID_SPRuleParent = 5
    DISPID_SPRuleChildren = 6
    DISPID_SPRuleConfidence = 7
    DISPID_SPRuleEngineConfidence = 8


class DISPID_SpeechPhraseRules(IntFlag):
    DISPID_SPRulesCount = 1
    DISPID_SPRulesItem = 0
    DISPID_SPRules_NewEnum = -4


class DISPID_SpeechLexicon(IntFlag):
    DISPID_SLGenerationId = 1
    DISPID_SLGetWords = 2
    DISPID_SLAddPronunciation = 3
    DISPID_SLAddPronunciationByPhoneIds = 4
    DISPID_SLRemovePronunciation = 5
    DISPID_SLRemovePronunciationByPhoneIds = 6
    DISPID_SLGetPronunciations = 7
    DISPID_SLGetGenerationChange = 8


class DISPID_SpeechLexiconWords(IntFlag):
    DISPID_SLWsCount = 1
    DISPID_SLWsItem = 0
    DISPID_SLWs_NewEnum = -4


class DISPID_SpeechLexiconWord(IntFlag):
    DISPID_SLWLangId = 1
    DISPID_SLWType = 2
    DISPID_SLWWord = 3
    DISPID_SLWPronunciations = 4


class DISPID_SpeechLexiconProns(IntFlag):
    DISPID_SLPsCount = 1
    DISPID_SLPsItem = 0
    DISPID_SLPs_NewEnum = -4


class DISPID_SpeechLexiconPronunciation(IntFlag):
    DISPID_SLPType = 1
    DISPID_SLPLangId = 2
    DISPID_SLPPartOfSpeech = 3
    DISPID_SLPPhoneIds = 4
    DISPID_SLPSymbolic = 5


class SpeechVisemeFeature(IntFlag):
    SVF_None = 0
    SVF_Stressed = 1
    SVF_Emphasis = 2


class DISPID_SpeechPhoneConverter(IntFlag):
    DISPID_SPCLangId = 1
    DISPID_SPCPhoneToId = 2
    DISPID_SPCIdToPhone = 3


class SpeechVoiceEvents(IntFlag):
    SVEStartInputStream = 2
    SVEEndInputStream = 4
    SVEVoiceChange = 8
    SVEBookmark = 16
    SVEWordBoundary = 32
    SVEPhoneme = 64
    SVESentenceBoundary = 128
    SVEViseme = 256
    SVEAudioLevel = 512
    SVEPrivate = 32768
    SVEAllEvents = 33790


class SpeechVoicePriority(IntFlag):
    SVPNormal = 0
    SVPAlert = 1
    SVPOver = 2


SPAUDIOSTATE = _SPAUDIOSTATE
SPSTREAMFORMATTYPE = SPWAVEFORMATTYPE


__all__ = [
    '__MIDL___MIDL_itf_sapi_0000_0020_0002', 'SDA_No_Trailing_Space',
    'DISPIDSPRG', 'DISPID_SPPFirstElement',
    'DISPID_SDKGetBinaryValue', 'SECNormalConfidence',
    'SpeechRecognitionType', 'SRADynamic', 'DISPID_SVSLastResult',
    'SpStream', 'DISPID_SAEventHandle', 'SPSInterjection',
    'SpeechAddRemoveWord', 'ISpAudio', 'DISPID_SRGRecoContext',
    'eLEXTYPE_RESERVED10', 'ISpeechLexicon',
    'SpeechStreamSeekPositionType', 'SPEI_SOUND_END',
    'SPRST_NUM_STATES', 'SAFTCCITT_uLaw_11kHzStereo',
    'SpeechCategoryAppLexicons', 'DISPID_SRGetFormat',
    'SDTAlternates', 'DISPID_SRCEPropertyNumberChange',
    'DISPID_SpeechGrammarRuleState', 'DISPID_SpeechPhraseElement',
    'SpeechPropertyResponseSpeed', 'SpeechRuleState',
    'eLEXTYPE_PRIVATE11', 'DISPID_SRSCurrentStreamPosition',
    'SPEI_PHONEME', 'SpCustomStream', 'DISPID_SRCRetainedAudio',
    'DISPID_SPIRule', 'DISPID_SRRTOffsetFromStart',
    'eLEXTYPE_PRIVATE5', 'SDKLDefaultLocation',
    'SpeechEngineConfidence', 'SpeechAudioProperties',
    'SAFT8kHz8BitMono', '__MIDL___MIDL_itf_sapi_0000_0020_0001',
    'SpeechLoadOption', 'DISPID_SpeechRecognizer',
    'SECHighConfidence', 'SpeechRuleAttributes',
    'SAFTCCITT_ALaw_22kHzStereo', 'DISPID_SLWs_NewEnum',
    'DISPID_SLPsItem', 'SPSLMA', 'DISPID_SOTsCount', 'DISPID_SGRsAdd',
    'DISPID_SpeechObjectToken', 'eLEXTYPE_PRIVATE20',
    'SPBOOKMARKOPTIONS', 'SPLO_DYNAMIC', 'DISPID_SRGCmdSetRuleState',
    'SP_VISEME_12', 'DISPID_SRCEAudioLevel', 'SPSERIALIZEDRESULT',
    'SVPAlert', 'SpeechStreamFileMode', 'SP_VISEME_15',
    'DISPID_SpeechPhraseProperties', 'SVEBookmark', 'SRTEmulated',
    'DISPID_SVGetAudioOutputs', 'SVP_0', 'SVP_19', 'DISPID_SPACommit',
    'SPAS_RUN', 'DISPID_SPPBRestorePhraseFromMemory',
    'DISPID_SRCEBookmark', 'SpeechSpecialTransitionType',
    'DISPID_SPIAudioSizeTime', 'SVP_21', 'SPEI_UNDEFINED',
    'DISPID_SLPLangId', 'SPWT_LEXICAL_NO_SPECIAL_CHARS',
    'DISPID_SGRSTWeight', 'ISpPhoneticAlphabetSelection',
    'ISpeechPhraseAlternates', 'DISPID_SOTRemove',
    'DISPID_SGRSTs_NewEnum', 'DISPID_SGRSTNextState', 'SVP_20',
    'DISPID_SPEs_NewEnum', 'DISPID_SRRAudioFormat',
    'SGDSActiveWithAutoPause', 'SpeechRecoContextState',
    'DISPID_SpeechRecoContext', 'SASPause', 'SPCATEGORYTYPE',
    'DISPID_SRCResume', 'SVP_17', 'SVF_Stressed', 'SAFT32kHz8BitMono',
    'SPFM_CREATE', 'SPRULESTATE', 'SPINTERFERENCE_TOOSLOW',
    'SRCS_Enabled', 'eLEXTYPE_PRIVATE17', 'ISpXMLRecoResult',
    'DISPID_SDKGetlongValue', 'DISPID_SpeechDataKey',
    'SVSFNLPSpeakPunc', 'eLEXTYPE_USER_SHORTCUT',
    'ISpObjectWithToken', 'DISPID_SWFEFormatTag', 'SREInterference',
    'SPSHT_OTHER', 'DISPID_SRCEventInterests', 'SpPhraseInfoBuilder',
    'DISPID_SPRules_NewEnum', 'STSF_FlagCreate', 'STCAll',
    'eLEXTYPE_RESERVED4', 'DISPID_SRAudioInputStream',
    'SPINTERFERENCE_LATENCY_WARNING', 'DISPID_SRCEHypothesis',
    'ISpEventSink', 'SpeechAudioFormatGUIDWave',
    'DISPID_SGRSTPropertyName', 'SpStreamFormatConverter',
    'SPEI_FALSE_RECOGNITION', 'SpNotifyTranslator', 'DISPID_SRGReset',
    'SPPS_Function', 'SAFT12kHz16BitStereo', 'SP_VISEME_2', 'SLTUser',
    'SP_VISEME_9', 'DISPID_SPIGrammarId', 'SVEPhoneme',
    'SPEI_INTERFERENCE', 'SPBINARYGRAMMAR', 'SRAExport',
    'SDA_Consume_Leading_Spaces', 'SP_VISEME_14', 'SLOStatic',
    'SINone', 'DISPID_SPPConfidence',
    'DISPID_SVSInputSentencePosition', 'DISPID_SpeechPhraseAlternate',
    'DISPID_SPIStartTime', 'SRATopLevel', 'SRARoot',
    'SPEI_SR_PRIVATE', 'eLEXTYPE_PRIVATE10', 'ISpeechPhraseInfo',
    'DISPID_SpeechVoiceStatus', 'DISPID_SGRSTPropertyId',
    'ISpEventSource', 'DISPID_SOTCGetDataKey', 'ISpeechWaveFormatEx',
    'SPWP_UNKNOWN_WORD_PRONOUNCEABLE', 'DISPID_SpeechRecoResult',
    'SVP_7', 'SDTAudio', 'SPGS_DISABLED', 'DISPID_SGRSRule',
    'DISPID_SPIEnginePrivateData', 'DISPID_SPRuleId', 'SBONone',
    'SPWP_KNOWN_WORD_PRONOUNCEABLE', 'DISPID_SPEAudioSizeBytes',
    'SPWORDPRONUNCIATION', 'SpeechGrammarTagUnlimitedDictation',
    'ISpeechPhraseReplacements', 'SSSPTRelativeToEnd', 'SPAR_Unknown',
    'DISPID_SASFreeBufferSpace', 'DISPID_SLGenerationId',
    'SPDKL_LocalMachine', 'DISPID_SBSWrite', 'SRAONone',
    'DISPID_SPAs_NewEnum', 'DISPID_SLGetGenerationChange',
    'DISPID_SOTIsUISupported', 'SVEPrivate', 'SpeechTokenContext',
    'ISpNotifySink', 'SpeechRecognizerState', 'SPSHT_EMAIL',
    'DISPID_SRGetPropertyNumber', 'DISPID_SRCEInterference',
    'SpeechGrammarRuleStateTransitionType',
    'DISPID_SGRSAddWordTransition', 'ISpeechRecoResult',
    'ISpeechGrammarRule', 'SREAllEvents', 'DISPID_SLPSymbolic',
    'DISPID_SPERequiredConfidence', 'SAFT24kHz16BitMono',
    'SAFT16kHz16BitMono', 'DISPID_SRRGetXMLErrorInfo',
    'DISPID_SLRemovePronunciation', 'ISpLexicon',
    'SpeechVoiceSkipTypeSentence', 'SFTSREngine',
    'DISPID_SPILanguageId', 'SpeechMicTraining',
    'SpeechCategoryVoices', 'tagSPTEXTSELECTIONINFO', 'SDTAll',
    'SpWaveFormatEx', 'SPSHT_NotOverriden',
    'DISPID_SRSNumberOfActiveRules', 'ISpGrammarBuilder',
    'DISPID_SRStatus', 'DISPID_SPEPronunciation',
    'SPEI_PROPERTY_NUM_CHANGE', 'SDKLLocalMachine', 'DISPID_SVStatus',
    'SRSActive', 'STCInprocServer', 'DISPID_SVWaitUntilDone',
    'SPWF_SRENGINE', 'SpeechDataKeyLocation', 'SPSNotOverriden',
    'SPEI_MAX_SR', 'SPSMF_SRGS_SEMANTICINTERPRETATION_W3C',
    'SGRSTTWildcard', 'ISpRecoResult', 'DISPID_SRRAudio',
    'DISPID_SPIAudioStreamPosition', 'tagSTATSTG', 'DISPID_SRProfile',
    'ISpeechGrammarRuleState', 'WAVEFORMATEX', 'typelib_path',
    'SPAO_NONE', 'SPPS_RESERVED3', 'SPCT_DICTATION',
    'DISPID_SABIBufferSize', 'SPEI_WORD_BOUNDARY', 'SPEI_MIN_SR',
    'SPWORDTYPE', 'SREBookmark', 'SECLowConfidence',
    'eLEXTYPE_PRIVATE8', 'DISPID_SVSpeakCompleteEvent',
    'SPINTERFERENCE', 'DISPID_SASState', 'eLEXTYPE_PRIVATE13',
    'SAFTCCITT_uLaw_8kHzMono', 'SpeechPropertyResourceUsage',
    'SpeechGrammarWordType', 'DISPID_SRRGetXMLResult',
    'DISPID_SOTGetDescription', 'SWPUnknownWordUnpronounceable',
    'DISPID_SVVolume', 'DISPID_SpeechGrammarRules', 'SREAdaptation',
    'DISPID_SpeechVoiceEvent', 'eWORDTYPE_ADDED',
    'DISPID_SpeechPhraseInfo', 'ISpeechLexiconWord', 'SSTTWildcard',
    'DISPID_SBSSeek', 'DISPID_SGRId', 'IEnumString',
    'SAFTExtendedAudioFormat', 'DISPID_SGRSTsItem',
    'DISPID_SGRSTType', 'ISpeechPhoneConverter', 'ISpRecognizer2',
    'ISpNotifyTranslator', 'DISPID_SVSLastBookmarkId', 'SREPrivate',
    'DISPID_SREmulateRecognition', 'DISPID_SPRuleFirstElement',
    'SPWT_DISPLAY', 'SVP_3', 'DISPID_SOTRemoveStorageFileName',
    'SVSFPersistXML', 'SPGS_EXCLUSIVE', 'SWPUnknownWordPronounceable',
    'SPSTREAMFORMATTYPE', 'DISPID_SRDisplayUI',
    'DISPID_SVSInputSentenceLength', 'DISPID_SpeechRecoResultTimes',
    'SpInProcRecoContext', 'eLEXTYPE_PRIVATE9', 'SINoSignal',
    'ISpPhoneConverter', 'DISPID_SWFEBitsPerSample', 'DISPID_SRGId',
    'SAFTADPCM_44kHzMono', 'DISPID_SGRInitialState', 'ISpRecognizer3',
    'SpeechTokenKeyUI', 'SVP_12', 'ISpeechLexiconWords',
    'DISPID_SASetState', 'SPAUDIOOPTIONS',
    'DISPID_SGRSAddRuleTransition', 'SpeechVoiceEvents',
    'SpeechGrammarState', 'SPEI_RESERVED6', 'SPRECOGNIZERSTATUS',
    'DISPID_SRGCmdLoadFromProprietaryGrammar', 'DISPID_SVSPhonemeId',
    'SPAS_PAUSE', 'ISpStream', 'SREPhraseStart', 'SPEI_VISEME',
    'SAFT44kHz16BitStereo', 'SECFIgnoreWidth', 'SRTReSent',
    'DISPID_SpeechPhraseRule', 'DISPID_SpeechRecoContextEvents',
    'SPWORDLIST', 'DISPID_SDKDeleteKey', 'DISPID_SFSClose',
    'DISPID_SPIReplacements', 'SVEAllEvents',
    'DISPID_SpeechObjectTokens', 'SAFTADPCM_22kHzStereo',
    'SPPHRASEREPLACEMENT', 'SPINTERFERENCE_TOOQUIET',
    'DISPID_SpeechCustomStream', 'DISPID_SGRSTsCount',
    'tagSPPROPERTYINFO', 'ISpeechDataKey', 'SAFT48kHz16BitStereo',
    'SPAR_High', 'SpeechCategoryAudioOut', 'SPEI_MIN_TTS',
    'SPWAVEFORMATTYPE', 'SAFT44kHz16BitMono',
    'DISPID_SRCreateRecoContext', 'DISPID_SPIGetDisplayAttributes',
    'SPGRAMMARSTATE', 'SWTAdded', 'DISPID_SVEStreamStart',
    'SpAudioFormat', 'DISPID_SRGCmdLoadFromObject', 'SPRS_INACTIVE',
    'SpInprocRecognizer', 'SAFT11kHz8BitMono', 'SPAUDIOBUFFERINFO',
    'SVSFParseMask', 'DISPID_SPIGetText', 'SRESoundStart',
    'SAFTGSM610_8kHzMono', 'SPEI_SR_AUDIO_LEVEL',
    'eLEXTYPE_LETTERTOSOUND', 'SPINTERFERENCE_TOOFAST',
    'STSF_AppData', 'SpeechAudioFormatType',
    'SDA_Two_Trailing_Spaces', 'DISPID_SPRuleParent',
    'ISpeechObjectTokenCategory', 'ISpeechLexiconPronunciations',
    'ISpDataKey', 'SPPS_Interjection', 'IStream', 'SpPhoneConverter',
    'SREHypothesis', 'SPPS_NotOverriden', 'ISpObjectToken',
    'DISPID_SPPId', 'DISPID_SASCurrentDevicePosition',
    'SPEI_ACTIVE_CATEGORY_CHANGED',
    'SpeechPropertyComplexResponseSpeed', 'DISPID_SRCVoicePurgeEvent',
    'DISPID_SRGCmdSetRuleIdState', 'SECFNoSpecialChars',
    'SVESentenceBoundary', 'DISPID_SPPsCount', 'DISPID_SVPriority',
    'SVSFlagsAsync', 'DISPID_SOTs_NewEnum', 'DISPID_SVEAudioLevel',
    'DISPID_SGRsCommitAndSave', 'DISPID_SABufferInfo',
    'DISPID_SLAddPronunciation', 'DISPID_SRCERecognition',
    'SRADefaultToActive', 'eLEXTYPE_PRIVATE12', 'DISPID_SVResume',
    'DISPID_SRCERecognizerStateChange', 'ISpStreamFormatConverter',
    'SpeechWordPronounceable', 'SVP_14', 'SPFILEMODE',
    'SSFMOpenReadWrite', 'SVSFNLPMask', 'SRTAutopause', 'SPEVENTENUM',
    'SRTSMLTimeout', 'DISPID_SpeechPhraseReplacement',
    'SAFT22kHz16BitMono', '__MIDL_IWinTypes_0009', 'SDTPronunciation',
    'DISPID_SVAllowAudioOuputFormatChangesOnNextSet',
    'DISPID_SOTGetStorageFileName', 'DISPID_SOTDisplayUI',
    'ISpeechRecoResult2', 'DISPID_SDKEnumValues',
    'ISpeechPhraseInfoBuilder', 'SRSInactive',
    'DISPID_SASCurrentSeekPosition', 'DISPID_SRRTTickCount',
    'SRERecognition', 'SPEI_RESERVED5',
    'SPINTERFERENCE_LATENCY_TRUNCATE_BEGIN', 'SpeechBookmarkOptions',
    'SpeechEngineProperties', 'SpeechRegistryUserRoot',
    'DISPID_SDKCreateKey', 'ISpeechLexiconPronunciation',
    'DISPID_SOTMatchesAttributes', 'SPEI_TTS_PRIVATE',
    'SAFT48kHz8BitMono', 'SPPHRASERULE', 'SpeechCategoryAudioIn',
    'SPLO_STATIC', 'DISPID_SLGetPronunciations',
    'DISPID_SPAStartElementInResult', 'DISPID_SGRsCount',
    'eLEXTYPE_VENDORLEXICON', 'SP_VISEME_8', 'SAFT12kHz16BitMono',
    'SPSSuppressWord', 'SGRSTTDictation', 'SFTInput', 'SGSEnabled',
    'SpeechFormatType', 'SPDATAKEYLOCATION', 'SRTStandard',
    'SPDKL_DefaultLocation', 'DISPID_SGRSTPropertyValue',
    'DISPID_SRGDictationSetState', 'IInternetSecurityManager',
    'DISPID_SPARecoResult', 'ISpPhraseAlt', 'DISPID_SVGetAudioInputs',
    'SVF_Emphasis', 'DISPID_SVIsUISupported', 'DISPID_SGRsCommit',
    'DISPID_SMSSetData', 'ISpObjectTokenCategory',
    'DISPID_SPIAudioSizeBytes', 'DISPID_SAFGuid',
    'DISPID_SRAudioInput', 'DISPID_SVGetVoices', 'SGDSActive',
    'SPRST_ACTIVE_ALWAYS', 'SPBO_AHEAD',
    'DISPID_SRSSupportedLanguages', 'DISPID_SPEsCount',
    'DISPID_SPRNumberOfElements',
    'SpeechPropertyNormalConfidenceThreshold', 'SAFTGSM610_11kHzMono',
    'SAFTCCITT_uLaw_22kHzMono', 'DISPID_SRCEPropertyStringChange',
    'SAFTCCITT_uLaw_44kHzStereo', 'SRAInterpreter',
    'DISPID_SGRSTText', 'ISpeechVoiceStatus',
    'DISPID_SDKSetStringValue', 'DISPID_SRCCreateGrammar',
    'DISPID_SPEAudioStreamOffset', 'DISPID_SWFEChannels', 'SBOPause',
    'SP_VISEME_3', 'ISpeechPhraseElements', 'SAFTADPCM_44kHzStereo',
    'SAFT24kHz8BitMono', 'SpSharedRecognizer', 'SVPNormal',
    'DISPID_SRRSpeakAudio', '_RemotableHandle',
    'DISPID_SRSClsidEngine', 'SAFT22kHz8BitStereo',
    'SAFT16kHz8BitStereo', 'SPINTERFERENCE_NONE',
    'Speech_Max_Word_Length', 'ISpeechCustomStream',
    'SAFTADPCM_22kHzMono', 'SPSFunction', 'SP_VISEME_18', 'SGDisplay',
    'DISPID_SPRuleName', 'SPWORDPRONOUNCEABLE', 'DISPID_SVEStreamEnd',
    'SP_VISEME_6', 'SAFT12kHz8BitMono', 'ISpeechAudioFormat',
    'SPRECOCONTEXTSTATUS', 'DISPID_SOTSetId', 'SAFT8kHz16BitStereo',
    'SPPS_Noun', 'DISPID_SPIProperties', 'SGRSTTEpsilon',
    'SPWT_PRONUNCIATION', 'ISpeechXMLRecoResult', 'SASClosed',
    'SAFTNoAssignedFormat', 'DISPID_SVAlertBoundary', 'SECFDefault',
    'DISPID_SLWPronunciations', 'DISPID_SPAPhraseInfo',
    'ISpeechGrammarRuleStateTransition', 'Library', 'SVEWordBoundary',
    'ISpeechGrammarRuleStateTransitions', 'SAFTNonStandardFormat',
    'DISPID_SPPNumberOfElements', 'DISPID_SGRSTRule',
    'DISPID_SABIMinNotification', 'SVSFParseSapi',
    'SPINTERFERENCE_TOOLOUD', 'DISPID_SRGetRecognizers',
    'SPAUDIOSTATUS', 'SPFM_OPEN_READONLY', 'DISPID_SPEsItem',
    'SPCT_SUB_DICTATION', 'DISPID_SPPChildren', 'STCLocalServer',
    'SASRun', 'DISPID_SRRTLength', 'SPPHRASEPROPERTY',
    'SSTTTextBuffer', 'SpeechRunState', 'DISPID_SMSALineId',
    'SPEI_RESERVED2', 'SPCT_SUB_COMMAND', 'SPCS_DISABLED',
    'DISPID_SAFSetWaveFormatEx',
    'DISPID_SpeechGrammarRuleStateTransitions', 'SPCT_SLEEP',
    'SVF_None', 'SPSHORTCUTPAIR', 'SPEI_SR_RETAINEDAUDIO',
    'SAFTCCITT_ALaw_8kHzStereo', 'DISPID_SOTGetAttribute', 'SpVoice',
    'eLEXTYPE_PRIVATE3', 'eLEXTYPE_PRIVATE1',
    'SAFTCCITT_ALaw_22kHzMono', 'SREAudioLevel',
    'SPSMF_SRGS_SEMANTICINTERPRETATION_MS',
    'DISPID_SpeechWaveFormatEx', 'SpeechRetainedAudioOptions',
    'SAFTDefault', 'SpeechTokenShellFolder', 'Speech_StreamPos_Asap',
    'SSFMCreateForWrite', 'SVSFIsNotXML', 'DISPID_SRIsUISupported',
    'SRSEIsSpeaking', 'SPPS_SuppressWord', 'DISPID_SPRsCount',
    'ISpeechTextSelectionInformation', 'DISPID_SOTId',
    'SpeechRecoEvents', 'SpeechUserTraining', 'ISpeechRecoContext',
    'SpeechLexiconType', 'eLEXTYPE_RESERVED8',
    'DISPID_SVSInputWordLength', 'SVPOver', 'DISPID_SPEDisplayText',
    'SAFTCCITT_ALaw_44kHzMono', 'SPVPRI_OVER', 'IEnumSpObjectTokens',
    'DISPID_SRGState', 'SVSFIsFilename', 'DISPID_SOTCategory',
    'SPPS_Noncontent', 'SP_VISEME_1', 'SPXMLRESULTOPTIONS',
    'DISPID_SPEAudioSizeTime', 'DISPID_SLPs_NewEnum',
    'ISpeechPhraseProperty', 'SPEI_END_INPUT_STREAM', 'SPSNoun',
    'SPRECORESULTTIMES', 'DISPID_SpeechAudioFormat', 'SpMemoryStream',
    'DISPID_SLPPartOfSpeech', 'DISPID_SAFGetWaveFormatEx',
    'SSSPTRelativeToStart', 'SVSFVoiceMask', 'DISPID_SVSVisemeId',
    'SAFT22kHz8BitMono', 'ISpeechObjectToken', 'DISPID_SMSAMMHandle',
    'SVEAudioLevel', 'SAFT44kHz8BitStereo', 'SDTDisplayText',
    'SAFT32kHz8BitStereo', 'DISPID_SLAddPronunciationByPhoneIds',
    'SPRST_INACTIVE_WITH_PURGE', 'SSTTDictation', 'SPAR_Medium',
    'SPAS_CLOSED', 'DISPID_SMSADeviceId', 'SAFTADPCM_8kHzStereo',
    'DISPID_SVEViseme', 'DISPID_SPPEngineConfidence',
    'DISPID_SpeechRecoResult2', 'SpeechAllElements',
    'DISPID_SRGCmdLoadFromFile', 'STCInprocHandler',
    'DISPID_SRRDiscardResultInfo', 'SPPARTOFSPEECH', 'SVSFDefault',
    'SpSharedRecoContext', 'DISPID_SCSBaseStream',
    'DISPID_SRCRetainedAudioFormat', '_ISpeechVoiceEvents',
    'SSSPTRelativeToCurrentPosition', 'SPWORDPRONUNCIATIONLIST',
    'ISpeechAudioBufferInfo', 'DISPID_SVSpeakStream',
    'SSFMOpenForRead', 'SpObjectTokenCategory',
    'SREPropertyNumChange', 'DISPID_SpeechVoice', 'DISPID_SOTCId',
    'SVP_1', 'DISPIDSPTSI_ActiveLength', 'SP_VISEME_4',
    'SRERecoOtherContext', 'SAFTTrueSpeech_8kHz1BitMono',
    'SPXRO_Alternates_SML', 'SPXRO_SML', 'DISPID_SPCIdToPhone',
    'SITooFast', 'DISPID_SLRemovePronunciationByPhoneIds',
    'SITooSlow', 'DISPID_SVEventInterests',
    'DISPID_SRGIsPronounceable', 'DISPID_SFSOpen',
    'DISPID_SpeechPhraseAlternates', 'ISpeechPhraseAlternate',
    'SP_VISEME_5', 'SPPS_RESERVED1', 'DISPID_SpeechAudio',
    'SRERequestUI', 'ISpeechBaseStream', 'ISpeechRecognizer',
    'ISpeechRecoGrammar', 'SAFT11kHz16BitStereo', 'SP_VISEME_20',
    'SPSMF_UPS', 'ISpeechRecoResultDispatch',
    'SAFTCCITT_ALaw_8kHzMono', 'DISPID_SRState', 'SVP_8', 'SVP_11',
    'SpeechGrammarTagWildcard', 'SPGS_ENABLED', 'SPAO_RETAIN_AUDIO',
    'SPEI_HYPOTHESIS', 'SP_VISEME_11', 'DISPID_SVAudioOutputStream',
    'eLEXTYPE_PRIVATE6', 'DISPID_SPCPhoneToId', '_SPAUDIOSTATE',
    'SPEI_SOUND_START', 'SPEI_REQUEST_UI', 'SPSHORTCUTPAIRLIST',
    'SVP_13', 'ISpeechResourceLoader', 'DISPID_SGRsItem',
    'SPFM_OPEN_READWRITE', 'DISPID_SRRecognizer',
    'SPSMF_SRGS_SAPIPROPERTIES', 'SPPS_Verb', 'SPEI_START_SR_STREAM',
    'DISPID_SVEVoiceChange', 'DISPID_SRCEFalseRecognition',
    'DISPID_SRCERequestUI', 'SpResourceManager',
    'DISPID_SRRRecoContext', 'DISPID_SLPPhoneIds',
    'SpeechVoicePriority', 'SpeechDictationTopicSpelling',
    'DISPID_SRCRequestedUIType', 'SAFT16kHz8BitMono',
    'DISPID_SpeechLexicon', 'DISPID_SDKSetBinaryValue',
    'DISPID_SPCLangId', 'SPRS_ACTIVE_WITH_AUTO_PAUSE',
    'SAFT48kHz16BitMono', 'SP_VISEME_10', 'ISpRecoGrammar2',
    'SpeechDisplayAttributes', 'SPEI_RECO_STATE_CHANGE', 'SGRSTTRule',
    'ISpPhoneticAlphabetConverter', 'DISPID_SAStatus',
    'DISPID_SRGCommit', 'SpeechPropertyLowConfidenceThreshold',
    'DISPID_SRIsShared', 'SPWP_UNKNOWN_WORD_UNPRONOUNCEABLE',
    'ISpShortcut', 'DISPID_SGRsDynamic', 'eLEXTYPE_PRIVATE15',
    'DISPID_SOTCreateInstance', 'SVSFIsXML', 'SDA_One_Trailing_Space',
    'DISPID_SRGCmdLoadFromResource', 'SAFTCCITT_uLaw_22kHzStereo',
    'DISPID_SPRDisplayAttributes', 'DISPID_SRCVoice',
    'SREFalseRecognition', 'SAFTCCITT_uLaw_8kHzStereo',
    'SPPROPERTYINFO', 'SpeechAudioVolume', 'DISPID_SRCESoundStart',
    'DISPID_SRCCmdMaxAlternates', 'ISpResourceManager',
    'SAFT24kHz16BitStereo', 'SpeechDiscardType',
    'DISPID_SVSRunningState', 'ISpRecoContext2', 'DISPID_SGRName',
    'ISpProperties', 'DISPID_SLWsCount', 'SP_VISEME_13',
    'DISPID_SGRsFindRule', 'SPPS_RESERVED2', 'SECFIgnoreKanaType',
    'DISPID_SDKGetStringValue', 'SPINTERFERENCE_NOISE',
    'eLEXTYPE_PRIVATE16', 'SRESoundEnd', 'SITooLoud',
    'DISPID_SRGSetTextSelection', 'DISPID_SGRs_NewEnum',
    'DISPID_SRCPause', 'SPWT_LEXICAL', 'DISPID_SGRAddState',
    'SPFM_CREATE_ALWAYS', 'ISpStreamFormat', 'SPPS_Modifier',
    'SpUnCompressedLexicon', 'SpNullPhoneConverter',
    'DISPID_SRRTStreamTime', 'eLEXTYPE_RESERVED9',
    'SPEVENTSOURCEINFO', 'DISPID_SRGCmdLoadFromMemory',
    'DISPID_SpeechLexiconWords', 'STSF_CommonAppData',
    'SAFT44kHz8BitMono', 'SECFIgnoreCase',
    'SpeechPropertyAdaptationOn', 'DISPID_SRGDictationLoad',
    'DISPID_SDKEnumKeys', 'SPEI_RESERVED3', 'SDKLCurrentConfig',
    'DISPID_SpeechPhraseRules', 'SPSHT_Unknown', 'SPSVerb',
    'eLEXTYPE_USER', 'DISPID_SpeechAudioBufferInfo',
    'SPINTERFERENCE_NOSIGNAL', 'UINT_PTR', 'SPEI_END_SR_STREAM',
    'SpeechPropertyHighConfidenceThreshold',
    'DISPID_SpeechLexiconPronunciation', 'SP_VISEME_17',
    'DISPID_SGRAddResource', 'SLODynamic', 'DISPID_SLWsItem',
    'SPVPRI_NORMAL', 'SPPHRASE', 'ISpeechPhraseReplacement',
    'SpMMAudioEnum', 'eLEXTYPE_PRIVATE2', 'SVP_6', 'DISPID_SAVolume',
    'DISPID_SVSLastStreamNumberQueued', 'SAFTCCITT_uLaw_11kHzMono',
    'SECFEmulateResult', 'SDKLCurrentUser', 'Speech_Max_Pron_Length',
    'SPEI_RESERVED1', 'DISPID_SVSkip', 'DISPID_SWFEExtraData',
    'DISPID_SPPName', 'DISPID_SPRuleChildren', 'SPSEMANTICFORMAT',
    'ISpRecoCategory', 'SASStop', 'SPEI_SR_BOOKMARK', 'SpMMAudioIn',
    'ISpSerializeState', 'DISPID_SpeechObjectTokenCategory',
    'DISPID_SDKDeleteValue', 'DISPID_SRCRecognizer',
    'SRSInactiveWithPurge', 'SpeechEmulationCompareFlags',
    'DISPID_SPEEngineConfidence', 'SVSFPurgeBeforeSpeak',
    'DISPID_SVEPhoneme', 'SpCompressedLexicon', 'DISPID_SVSpeak',
    'SAFT11kHz8BitStereo', 'DISPID_SGRAttributes', 'SREStreamStart',
    'DISPID_SVSInputWordPosition', 'SpeechRecoProfileProperties',
    '_ISpeechRecoContextEvents', 'SpeechWordType',
    'DISPID_SpeechPhraseProperty', 'SRAImport', 'DISPID_SPRulesItem',
    'SPBO_PAUSE', 'DISPID_SVPause', 'SPSUnknown',
    'DISPID_SPEDisplayAttributes', 'SpeechCategoryRecognizers',
    'SPINTERFERENCE_LATENCY_TRUNCATE_END', 'SPVPRI_ALERT',
    'DISPID_SOTsItem', 'eLEXTYPE_PRIVATE18', 'SPDKL_CurrentUser',
    'SPBO_TIME_UNITS', 'LONG_PTR', 'SGLexical',
    'SPRS_ACTIVE_USER_DELIMITED', 'SGRSTTWord', 'ISpeechMMSysAudio',
    'DISPID_SLWWord', 'DISPID_SASNonBlockingIO',
    'DISPID_SRCEAdaptation', 'SPSMF_SAPI_PROPERTIES',
    'eLEXTYPE_RESERVED7', 'DISPID_SRCEEnginePrivate',
    'DISPID_SABIEventBias', 'SLTApp', 'Speech_Default_Weight',
    'SPEI_PROPERTY_STRING_CHANGE', 'Speech_StreamPos_RealTime',
    'DISPID_SPAsItem', 'SAFTCCITT_ALaw_44kHzStereo', 'SPEVENT',
    'SWPKnownWordPronounceable', 'SDTLexicalForm', 'STCRemoteServer',
    'DISPID_SLGetWords', 'SpTextSelectionInformation', 'SSFMCreate',
    'DISPID_SPRs_NewEnum', 'SAFT22kHz16BitStereo',
    'DISPID_SRCSetAdaptationData', 'SAFT48kHz8BitStereo',
    'DISPID_SGRSTransitions', 'DISPID_SRRAlternates',
    'DISPID_SPAsCount', 'DISPIDSPTSI_SelectionLength',
    'SVSFUnusedFlags', 'SPTEXTSELECTIONINFO', 'SPAR_Low', 'SpLexicon',
    'SpeechVoiceCategoryTTSRate', 'SpeechPartOfSpeech',
    'SPRST_ACTIVE', 'SWTDeleted', 'SP_VISEME_16',
    'DISPID_SpeechMMSysAudio', 'ISpeechMemoryStream',
    'SPGRAMMARWORDTYPE', 'DISPID_SVGetProfiles', 'DISPID_SLPType',
    'SpeechCategoryRecoProfiles', 'SPRST_INACTIVE', 'ISpeechAudio',
    'SPEI_RECO_OTHER_CONTEXT', 'SVP_5', 'SpeechVoiceSpeakFlags',
    'SVEStartInputStream', 'SpShortcut', 'SRTExtendableParse',
    'SPEI_ADAPTATION', 'ISpNotifySource', 'DISPID_SLPsCount',
    'SAFT8kHz8BitStereo', 'DISPID_SRCAudioInInterferenceStatus',
    'DISPID_SRRTimes', 'DISPID_SRCERecognitionForOtherContext',
    'SpeechTokenIdUserLexicon', 'eLEXTYPE_PRIVATE7',
    'SRAORetainAudio', 'SAFTText', 'SAFT32kHz16BitMono',
    'SVEVoiceChange', 'SPPS_Unknown', 'DISPID_SRRSetTextFeedback',
    'SAFT32kHz16BitStereo', 'DISPID_SVVoice', 'SDTRule',
    'SPSEMANTICERRORINFO', 'SVP_2', 'DISPID_SVSLastBookmark',
    'DISPID_SRCEPhraseStart', 'DISPID_SDKSetLongValue',
    'DISPID_SPPParent', 'SP_VISEME_19', 'DISPID_SPPValue', 'ISpVoice',
    'SGSDisabled', 'SVSFParseSsml', 'ISpeechRecoResultTimes', 'SVP_4',
    'DISPID_SRGDictationUnload', 'SRSEDone', 'DISPID_SAFType',
    'DISPID_SRCESoundEnd', 'DISPID_SPIElements', 'SDTReplacement',
    'SpeechGrammarTagDictation', 'SGPronounciation',
    'ISpeechPhraseProperties', 'SAFT16kHz16BitStereo',
    'SPDKL_CurrentConfig', 'eLEXTYPE_PRIVATE19', 'DISPID_SVDisplayUI',
    'SGRSTTTextBuffer', 'DISPID_SpeechPhraseBuilder',
    'eLEXTYPE_PRIVATE14', 'SAFT8kHz16BitMono',
    'ISpeechRecognizerStatus',
    'DISPID_SpeechGrammarRuleStateTransition', 'DISPID_SMSGetData',
    'DISPIDSPTSI_SelectionOffset', 'SAFTCCITT_ALaw_11kHzStereo',
    'DISPID_SVSyncronousSpeakTimeout', 'SITooQuiet',
    'SpeechAudioFormatGUIDText', 'DISPID_SRGSetWordSequenceData',
    'DISPID_SPPsItem', 'DISPID_SpeechPhoneConverter', 'SPBO_NONE',
    'DISPID_SOTDataKey', 'SpeechTokenValueCLSID', 'SRCS_Disabled',
    'SpObjectToken', 'ISpMMSysAudio', 'SVP_15',
    'DISPID_SOTCEnumerateTokens', 'SREStreamEnd',
    'SVSFParseAutodetect', 'IInternetSecurityMgrSite',
    'DISPID_SRSetPropertyString', 'DISPID_SRCBookmark',
    'ISpRecognizer', 'ISpRecoContext', 'DISPID_SVEWord',
    'DISPID_SVAudioOutput', 'eLEXTYPE_RESERVED6', 'DISPID_SRGRules',
    'DISPID_SPRuleConfidence', 'SAFTGSM610_44kHzMono',
    'SPEI_PHRASE_START', 'SGDSInactive', 'DISPID_SRCState',
    'DISPID_SVEEnginePrivate', 'DISPID_SPRText',
    'DISPID_SPANumberOfElementsInResult', 'DISPID_SpeechMemoryStream',
    'SPAS_STOP', 'SPAUDIOSTATE', 'DISPIDSPTSI_ActiveOffset',
    'DISPIDSPTSI', 'DISPID_SpeechBaseStream', 'SAFTADPCM_11kHzStereo',
    'SPEI_START_INPUT_STREAM', 'SPRULE', 'DISPID_SRSAudioStatus',
    'DISPID_SWFESamplesPerSec', 'SAFT12kHz8BitStereo', 'SPSModifier',
    'SRSActiveAlways', 'eLEXTYPE_APP', 'DISPID_SRSetPropertyNumber',
    'SPSHORTCUTTYPE', 'DISPID_SBSFormat', 'DISPID_SpeechFileStream',
    'DISPID_SPRFirstElement', 'SpPhoneticAlphabetConverter',
    'DISPID_SPRuleEngineConfidence', 'SVP_9',
    'SpeechCategoryPhoneConverters', 'SDTProperty', 'SPRS_ACTIVE',
    'SAFTCCITT_ALaw_11kHzMono', 'eLEXTYPE_PRIVATE4',
    'ISpeechPhraseElement', 'SGDSActiveUserDelimited',
    'DISPID_SpeechLexiconProns', 'SP_VISEME_21',
    'DISPID_SGRSAddSpecialTransition', 'DISPID_SLWType',
    'DISPID_SpeechAudioStatus', 'SVP_10', 'STSF_LocalAppData',
    'SAFTCCITT_uLaw_44kHzMono', 'SVP_16', 'SPVOICESTATUS',
    'SPEI_TTS_BOOKMARK', 'ISpeechPhraseRules', 'SpeechVisemeType',
    'DISPID_SPRsItem', 'SREStateChange', 'SPPS_RESERVED4',
    'DISPID_SLWLangId', 'eLEXTYPE_MORPHOLOGY', 'SPRECOSTATE',
    'SPWORD', 'DISPID_SpeechRecognizerStatus', 'SAFT11kHz16BitMono',
    'ISpeechObjectTokens', 'DISPID_SGRClear', 'SPWF_INPUT',
    'DISPID_SPELexicalForm', 'SPPHRASEELEMENT', 'DISPID_SOTCSetId',
    'SP_VISEME_7', 'DISPID_SRAllowVoiceFormatMatchingOnNextSet',
    'DISPID_SVEBookmark', 'DISPID_SADefaultFormat',
    'ISpeechPhraseRule', 'SPEI_TTS_AUDIO_LEVEL', 'DISPID_SDKOpenKey',
    'SPADAPTATIONRELEVANCE', 'SpFileStream', 'SAFTADPCM_8kHzMono',
    'SGLexicalNoSpecialChars', 'SAFTADPCM_11kHzMono',
    'DISPID_SPIRetainedSizeBytes', 'SPCT_COMMAND',
    'DISPID_SRGetPropertyString', 'DISPID_SRSCurrentStreamNumber',
    'SPVPRIORITY', 'DISPID_SPRulesCount',
    'DISPID_SpeechPhraseReplacements', 'SPEI_SENTENCE_BOUNDARY',
    'DISPID_SPRuleNumberOfElements', 'DISPID_SPIEngineId',
    'SpMMAudioOut', 'SpeechVisemeFeature', 'SPCONTEXTSTATE',
    'SPEI_VOICE_CHANGE', 'SPSERIALIZEDPHRASE', 'SpeechInterference',
    'SPPS_LMA', 'SpeechTokenKeyAttributes',
    'DISPID_SpeechLexiconWord', 'DISPID_SVRate',
    'DISPID_SRRSaveToMemory', 'SPLEXICONTYPE',
    'DISPID_SPEActualConfidence', 'DISPID_SPERetainedStreamOffset',
    'eWORDTYPE_DELETED', 'ISpRecoGrammar', 'DISPID_SRCEStartStream',
    'ISpeechFileStream', 'SVEViseme', 'SPCS_ENABLED', 'ISpeechVoice',
    'DISPID_SWFEAvgBytesPerSec', 'DISPID_SpeechPhraseElements',
    'SVEEndInputStream', 'SpeechRegistryLocalMachineRoot',
    'DISPID_SPISaveToMemory', 'DISPID_SVESentenceBoundary',
    'SREPropertyStringChange', 'SPVISEMES',
    'DISPID_SVSCurrentStreamNumber', 'SAFT24kHz8BitStereo',
    'DISPID_SpeechXMLRecoResult', 'DISPID_SpeechGrammarRule',
    'SP_VISEME_0', 'SVP_18', 'SINoise', 'DISPID_SRCEEndStream',
    'DISPID_SOTCDefault', 'DISPID_SBSRead',
    'DISPID_SRCCreateResultFromMemory', 'DISPID_SRRPhraseInfo',
    'DISPID_SWFEBlockAlign', 'DISPID_SPEAudioTimeOffset',
    'SPEI_RECOGNITION', 'SpeechTokenKeyFiles', 'SPLOADOPTIONS',
    'SGSExclusive', 'SPFM_NUM_MODES',
    'DISPID_SRAllowAudioInputFormatChangesOnNextSet', 'SPEI_MAX_TTS',
    'SAFTGSM610_22kHzMono', 'ISpPhrase', 'ISpeechAudioStatus',
    'DISPID_SPPs_NewEnum', 'DISPID_SPERetainedSizeBytes',
    'ISpeechGrammarRules', 'SpeechAudioState',
    'DISPID_SABufferNotifySize'
]

