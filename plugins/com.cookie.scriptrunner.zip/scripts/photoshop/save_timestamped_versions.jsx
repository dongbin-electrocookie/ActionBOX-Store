#target photoshop

function pad(value, length) {
    var text = String(value);
    while (text.length < length) text = "0" + text;
    return text;
}

function getTimestamp() {
    var now = new Date();
    return "_" + now.getFullYear()
        + pad(now.getMonth() + 1, 2)
        + pad(now.getDate(), 2)
        + "_" + pad(now.getHours(), 2)
        + pad(now.getMinutes(), 2)
        + pad(now.getSeconds(), 2)
        + "_" + pad(now.getMilliseconds(), 3);
}

function safeFileName(name) {
    return name.replace(/[\\\/:*?"<>|]/g, "_").replace(/^\s+|\s+$/g, "") || "Untitled";
}

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else {
    var doc = app.activeDocument;
    var baseName = safeFileName(doc.name.replace(/\.[^\.]+$/, "")) + getTimestamp();
    var exportFolder = new Folder(Folder.desktop + "/MultiExport");
    if (!exportFolder.exists && !exportFolder.create()) {
        alert("내보내기 폴더를 만들 수 없습니다.");
    } else {
        var copy = null;
        try {
            copy = doc.duplicate();
            copy.saveAs(new File(exportFolder.fsName + "/" + baseName + ".psd"), new PhotoshopSaveOptions(), true, Extension.LOWERCASE);
            copy.close(SaveOptions.DONOTSAVECHANGES);

            copy = doc.duplicate();
            copy.flatten();
            var jpgOpts = new JPEGSaveOptions();
            jpgOpts.quality = 12;
            jpgOpts.embedColorProfile = true;
            jpgOpts.formatOptions = FormatOptions.STANDARDBASELINE;
            copy.saveAs(new File(exportFolder.fsName + "/" + baseName + ".jpg"), jpgOpts, true, Extension.LOWERCASE);
            copy.close(SaveOptions.DONOTSAVECHANGES);

            copy = doc.duplicate();
            var pngOpts = new PNGSaveOptions();
            pngOpts.compression = 9;
            copy.saveAs(new File(exportFolder.fsName + "/" + baseName + ".png"), pngOpts, true, Extension.LOWERCASE);
            copy.close(SaveOptions.DONOTSAVECHANGES);

            alert("PSD / JPG / PNG 저장 완료:\n" + exportFolder.fsName);
        } catch (e) {
            alert("날짜 자동 저장 오류: " + e.message);
        } finally {
            if (copy) {
                try { copy.close(SaveOptions.DONOTSAVECHANGES); } catch (ignore) {}
            }
            app.activeDocument = doc;
        }
    }
}
