#target premierepro
(function () {
    var sequence = app.project.activeSequence;
    if (!sequence) {
        alert("Open a sequence first.");
        return;
    }
    var markers = sequence.markers;
    var marker = markers.getFirstMarker();
    while (marker) {
        var next = markers.getNextMarker(marker);
        markers.deleteMarker(marker);
        marker = next;
    }
}());
