import asyncio
import os
import sys

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.windows_action_map = {
            "file_save": "ctrl+s",
            "file_export": "ctrl+m",
            "edit_undo": "ctrl+z",
            "edit_redo": "ctrl+shift+z",
            "edit_copy": "ctrl+c",
            "edit_paste": "ctrl+v",
            "edit_ripple_delete": "shift+delete",
            "tool_selection": "v",
            "tool_track_select": "a",
            "tool_ripple_edit": "b",
            "tool_razor": "c",
            "tool_slip": "y",
            "tool_pen": "p",
            "tool_hand": "h",
            "tool_zoom": "z",
            "tool_type": "t",
            "timeline_add_edit": "ctrl+k",
            "timeline_add_edit_all": "ctrl+shift+k",
            "timeline_trim_in": "q",
            "timeline_trim_out": "w",
            "play_toggle": "space",
            "play_reverse": "j",
            "play_stop": "k",
            "play_forward": "l",
            "play_prev_frame": "left",
            "play_next_frame": "right",
            "mark_in": "i",
            "mark_out": "o",
            "mark_clear": "ctrl+shift+x",
            "marker_add": "m",
            "marker_next": "shift+m",
            "marker_prev": "ctrl+shift+m",
            "view_zoom_in": "=",
            "view_zoom_out": "-",
            "view_fit": "\\"
        }

        self.macos_action_map = {
            "file_save": "command+s",
            "file_export": "command+m",
            "edit_undo": "command+z",
            "edit_redo": "command+shift+z",
            "edit_copy": "command+c",
            "edit_paste": "command+v",
            "edit_ripple_delete": "shift+delete",
            "tool_selection": "v",
            "tool_track_select": "a",
            "tool_ripple_edit": "b",
            "tool_razor": "c",
            "tool_slip": "y",
            "tool_pen": "p",
            "tool_hand": "h",
            "tool_zoom": "z",
            "tool_type": "t",
            "timeline_add_edit": "command+k",
            "timeline_add_edit_all": "command+shift+k",
            "timeline_trim_in": "q",
            "timeline_trim_out": "w",
            "play_toggle": "space",
            "play_reverse": "j",
            "play_stop": "k",
            "play_forward": "l",
            "play_prev_frame": "left",
            "play_next_frame": "right",
            "mark_in": "i",
            "mark_out": "o",
            "mark_clear": "option+x",
            "marker_add": "m",
            "marker_next": "shift+m",
            "marker_prev": "command+shift+m",
            "view_zoom_in": "=",
            "view_zoom_out": "-",
            "view_fit": "\\"
        }

        self.action_map = self.macos_action_map if IS_MACOS else self.windows_action_map

        self.icon_map = {
            "file_save": "STATE_FILE_SAVE",
            "file_export": "STATE_FILE_EXPORT",
            "edit_undo": "STATE_EDIT_UNDO",
            "edit_redo": "STATE_EDIT_REDO",
            "edit_copy": "STATE_EDIT_COPY",
            "edit_paste": "STATE_EDIT_PASTE",
            "edit_ripple_delete": "STATE_EDIT_RIPPLE_DELETE",
            "tool_selection": "STATE_TOOL_SELECTION",
            "tool_track_select": "STATE_TOOL_TRACK_SELECT",
            "tool_ripple_edit": "STATE_TOOL_RIPPLE_EDIT",
            "tool_razor": "STATE_TOOL_RAZOR",
            "tool_slip": "STATE_TOOL_SLIP",
            "tool_pen": "STATE_TOOL_PEN",
            "tool_hand": "STATE_TOOL_HAND",
            "tool_zoom": "STATE_TOOL_ZOOM",
            "tool_type": "STATE_TOOL_TYPE",
            "timeline_add_edit": "STATE_TIMELINE_ADD_EDIT",
            "timeline_add_edit_all": "STATE_TIMELINE_ADD_EDIT_ALL",
            "timeline_trim_in": "STATE_TIMELINE_TRIM_IN",
            "timeline_trim_out": "STATE_TIMELINE_TRIM_OUT",
            "play_toggle": "STATE_PLAY_TOGGLE",
            "play_reverse": "STATE_PLAY_REVERSE",
            "play_stop": "STATE_PLAY_STOP",
            "play_forward": "STATE_PLAY_FORWARD",
            "play_prev_frame": "STATE_PLAY_PREV_FRAME",
            "play_next_frame": "STATE_PLAY_NEXT_FRAME",
            "mark_in": "STATE_MARK_IN",
            "mark_out": "STATE_MARK_OUT",
            "mark_clear": "STATE_MARK_CLEAR",
            "marker_add": "STATE_MARKER_ADD",
            "marker_next": "STATE_MARKER_NEXT",
            "marker_prev": "STATE_MARKER_PREV",
            "view_zoom_in": "STATE_VIEW_ZOOM_IN",
            "view_zoom_out": "STATE_VIEW_ZOOM_OUT",
            "view_fit": "STATE_VIEW_FIT"
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "timeline_add_edit", "STATE_TIMELINE_ADD_EDIT")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "command", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "timeline_add_edit"
        new_settings = {
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        await self._send_builtin_icon(context, default_action)

    def _normalize_pyautogui_key(self, key_name):
        aliases = {
            "ctrl": "ctrl",
            "control": "ctrl",
            "alt": "option" if IS_MACOS else "alt",
            "option": "option" if IS_MACOS else "alt",
            "cmd": "command" if IS_MACOS else "win",
            "command": "command" if IS_MACOS else "win",
            "win": "command" if IS_MACOS else "win",
            "windows": "command" if IS_MACOS else "win",
            "return": "enter",
            "esc": "escape",
            "plus": "+",
            "spacebar": "space",
        }
        return aliases.get(key_name, key_name)

    def _send_hotkey_sync(self, hotkey):
        parts = [self._normalize_pyautogui_key(p.strip().lower()) for p in hotkey.split('+') if p.strip()]
        if not parts:
            return

        if IS_WINDOWS and keyboard_available:
            keyboard.send(hotkey)
            return

        if not pyautogui_available:
            return

        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or "timeline_add_edit")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("command", "timeline_add_edit")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(self._send_hotkey_sync, hotkey)
