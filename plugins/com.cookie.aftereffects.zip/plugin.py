import asyncio
import os
import sys

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        # Windows/Linux 기준 단축키. Windows에서는 기존 keyboard.send() 경로를 우선 사용합니다.
        self.windows_action_map = {
            "file_save": "ctrl+s",
            "file_render": "ctrl+m",
            "prop_position": "p",
            "prop_scale": "s",
            "prop_rotation": "r",
            "prop_opacity": "t",
            "prop_anchor": "a",
            "prop_reveal_keys": "u",
            "key_add_position": "alt+p",
            "key_add_scale": "alt+s",
            "key_add_rotation": "alt+r",
            "key_add_opacity": "alt+t",
            "key_easy_ease": "f9",
            "key_ease_in": "shift+f9",
            "key_ease_out": "ctrl+shift+f9",
            "time_prev_key": "j",
            "time_next_key": "k",
            "time_prev_frame": "page up",
            "time_next_frame": "page down",
            "time_go_in": "i",
            "time_go_out": "o",
            "layer_split": "ctrl+shift+d",
            "layer_trim_in": "alt+[",
            "layer_trim_out": "alt+]",
            "layer_precomp": "ctrl+shift+c",
            "preview_ram": "space",
            "tool_selection": "v",
            "tool_hand": "h",
            "tool_pen": "g"
        }

        # macOS 기준 단축키. Ctrl 계열은 Command, Alt 계열은 Option으로 변환합니다.
        self.macos_action_map = {
            "file_save": "command+s",
            "file_render": "command+m",
            "prop_position": "p",
            "prop_scale": "s",
            "prop_rotation": "r",
            "prop_opacity": "t",
            "prop_anchor": "a",
            "prop_reveal_keys": "u",
            "key_add_position": "option+p",
            "key_add_scale": "option+s",
            "key_add_rotation": "option+r",
            "key_add_opacity": "option+t",
            "key_easy_ease": "f9",
            "key_ease_in": "shift+f9",
            "key_ease_out": "command+shift+f9",
            "time_prev_key": "j",
            "time_next_key": "k",
            "time_prev_frame": "page up",
            "time_next_frame": "page down",
            "time_go_in": "i",
            "time_go_out": "o",
            "layer_split": "command+shift+d",
            "layer_trim_in": "option+[",
            "layer_trim_out": "option+]",
            "layer_precomp": "command+shift+c",
            "preview_ram": "space",
            "tool_selection": "v",
            "tool_hand": "h",
            "tool_pen": "g"
        }

        self.action_map = self.macos_action_map if IS_MACOS else self.windows_action_map

        self.icon_map = {
            "file_save": "FILE_SAVE",
            "file_render": "FILE_RENDER",
            "prop_position": "PROP_POSITION",
            "prop_scale": "PROP_SCALE",
            "prop_rotation": "PROP_ROTATION",
            "prop_opacity": "PROP_OPACITY",
            "prop_anchor": "PROP_ANCHOR",
            "prop_reveal_keys": "PROP_REVEAL_KEYS",
            "key_add_position": "KEY_ADD_POSITION",
            "key_add_scale": "KEY_ADD_SCALE",
            "key_add_rotation": "KEY_ADD_ROTATION",
            "key_add_opacity": "KEY_ADD_OPACITY",
            "key_easy_ease": "KEY_EASY_EASE",
            "key_ease_in": "KEY_EASE_IN",
            "key_ease_out": "KEY_EASE_OUT",
            "time_prev_key": "TIME_PREV_KEY",
            "time_next_key": "TIME_NEXT_KEY",
            "time_prev_frame": "TIME_PREV_FRAME",
            "time_next_frame": "TIME_NEXT_FRAME",
            "time_go_in": "TIME_GO_IN",
            "time_go_out": "TIME_GO_OUT",
            "layer_split": "LAYER_SPLIT",
            "layer_trim_in": "LAYER_TRIM_IN",
            "layer_trim_out": "LAYER_TRIM_OUT",
            "layer_precomp": "LAYER_PRECOMP",
            "preview_ram": "PREVIEW_RAM",
            "tool_selection": "TOOL_SELECTION",
            "tool_hand": "TOOL_HAND",
            "tool_pen": "TOOL_PEN"
        }

    def _default_action(self):
        return "prop_position"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or self._default_action()
        if action not in self.icon_map:
            action = self._default_action()
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map[action]
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False),
            s.get("_lang")
        ])

    def _get_builtin_icon_path(self, command):
        icon_name = self.icon_map.get(command or self._default_action(), self.icon_map[self._default_action()])
        icon_path = os.path.join(self.plugin_dir, 'icon', f'{icon_name}.png')
        if os.path.exists(icon_path):
            return icon_path
        fallback = os.path.join(self.plugin_dir, 'icon', 'pluginIcon.png')
        return fallback if os.path.exists(fallback) else None

    async def _send_builtin_icon(self, context, command):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_builtin_icon_path(command)
        if not context or not icon_path:
            return
        await self.runner.send_message({
            'event': 'setIcon',
            'context': context,
            'payload': {'icon_path': icon_path}
        })

    def _normalize_pyautogui_key(self, key):
        key = str(key).strip().lower()
        aliases = {
            "ctrl": "ctrl",
            "control": "ctrl",
            "cmd": "command",
            "command": "command",
            "win": "win",
            "windows": "win",
            "option": "option" if IS_MACOS else "alt",
            "alt": "option" if IS_MACOS else "alt",
            "page up": "pageup",
            "pageup": "pageup",
            "pgup": "pageup",
            "page down": "pagedown",
            "pagedown": "pagedown",
            "pgdn": "pagedown",
            "space": "space",
            "esc": "esc",
            "escape": "esc",
        }
        return aliases.get(key, key)

    def _send_hotkey_sync(self, hotkey):
        hotkey = (hotkey or "").strip()
        if not hotkey:
            return

        # Windows는 기존 keyboard 모듈을 우선 사용합니다.
        if IS_WINDOWS and keyboard_available:
            keyboard.send(hotkey)
            return

        # macOS 또는 keyboard 미설치 환경은 pyautogui로 처리합니다.
        if pyautogui_available:
            parts = [self._normalize_pyautogui_key(part) for part in hotkey.split("+") if part.strip()]
            if not parts:
                return
            if len(parts) == 1:
                pyautogui.press(parts[0])
            else:
                pyautogui.hotkey(*parts)
            return

        # 마지막 fallback: Windows/Linux에서 keyboard가 있으면 사용
        if keyboard_available:
            keyboard.send(hotkey)

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                'event': 'setSettings',
                'context': context,
                'payload': defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get('event')
        payload = data.get('payload', {}) or {}
        context = data.get('context') or payload.get('context')
        payload_settings = payload.get('settings')
        incoming_settings = payload_settings if isinstance(payload_settings, dict) else data.get('settings', {}) or {}

        control_command = data.get('command') or payload.get('command')

        if event in ['willAppear', 'keyDidAppear']:
            if context:
                await self._initialize_default_visuals_if_new(context, incoming_settings)
            return

        if event == 'didReceiveSettings':
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **incoming_settings})
            return

        if event in ['keyDidDisappear', 'willDisappear']:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == 'apply_builtin_icon':
            cached = self.context_settings.get(context, {})
            action = data.get('action_command') or payload.get('action_command') or incoming_settings.get('command') or cached.get('command') or self._default_action()
            await self._send_builtin_icon(context, action)
            return

        if event == 'keyDown':
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get('payload', {}).get('settings', {}) or {}
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = settings

        selected_action = settings.get('command', self._default_action())

        if selected_action in self.action_map:
            await asyncio.to_thread(self._send_hotkey_sync, self.action_map[selected_action])
