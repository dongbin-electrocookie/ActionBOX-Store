import asyncio
import ctypes
import sys
import time

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']

        self.windows_action_map = {
            "file_export": "ctrl+m",
            "edit_paste_attributes": "ctrl+alt+v",
            "edit_ripple_delete": "alt+backspace",
            "tool_selection": "v",
            "tool_razor": "c",
            "tool_pen": "p",
            "tool_hand": "h",
            "tool_type": "t",
            "timeline_add_edit": "ctrl+k",
            "timeline_trim_in": "q",
            "timeline_trim_out": "w",
            "timeline_speed_duration": "ctrl+r",
            "play_toggle": "space",
            "play_reverse": "j",
            "play_stop": "k",
            "play_forward": "l",
            "play_prev_frame": "left",
            "play_next_frame": "right",
            "view_zoom_in": "=",
            "view_zoom_out": "-"
        }

        self.macos_action_map = {
            "file_export": "command+m",
            "edit_paste_attributes": "option+command+v",
            "edit_ripple_delete": "shift+delete",
            "tool_selection": "v",
            "tool_razor": "c",
            "tool_pen": "p",
            "tool_hand": "h",
            "tool_type": "t",
            "timeline_add_edit": "command+k",
            "timeline_trim_in": "q",
            "timeline_trim_out": "w",
            "timeline_speed_duration": "command+r",
            "play_toggle": "space",
            "play_reverse": "j",
            "play_stop": "k",
            "play_forward": "l",
            "play_prev_frame": "left",
            "play_next_frame": "right",
            "view_zoom_in": "=",
            "view_zoom_out": "-"
        }

        self.action_map = self.macos_action_map if IS_MACOS else self.windows_action_map

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "command", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "timeline_add_edit"
        new_settings = {
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

    def _normalize_pyautogui_key(self, key_name):
        aliases = {
            "ctrl": "ctrl",
            "control": "ctrl",
            "alt": "option" if IS_MACOS else "alt",
            "option": "option" if IS_MACOS else "alt",
            "cmd": "command" if IS_MACOS else "win",
            "command": "command" if IS_MACOS else "win",
            "win": "command" if IS_MACOS else "win",
            "windows": "command" if IS_MACOS else "win",
            "return": "enter",
            "esc": "escape",
            "plus": "+",
            "spacebar": "space",
        }
        return aliases.get(key_name, key_name)

    def _send_hotkey_sync(self, hotkey):
        parts = [self._normalize_pyautogui_key(p.strip().lower()) for p in hotkey.split('+') if p.strip()]
        if not parts:
            return

        if IS_WINDOWS:
            # ``keyboard`` resolves these names to the numeric keypad first.
            # Send the dedicated arrow keys and the main-keyboard minus key
            # explicitly so their behavior does not depend on Num Lock.
            windows_virtual_keys = {
                "left": (0x25, True),   # VK_LEFT
                "right": (0x27, True),  # VK_RIGHT
                "-": (0xBD, False),     # VK_OEM_MINUS
            }
            special_key = windows_virtual_keys.get(hotkey.strip().lower())
            if special_key:
                virtual_key, extended = special_key
                self._send_windows_virtual_key(virtual_key, extended)
                return

        if IS_WINDOWS and keyboard_available:
            keyboard.send(hotkey)
            return

        if not pyautogui_available:
            return

        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts)

    def _send_windows_virtual_key(self, virtual_key, extended=False):
        user32 = ctypes.windll.user32
        scan_code = user32.MapVirtualKeyW(virtual_key, 0)
        extended_flag = 0x0001 if extended else 0  # KEYEVENTF_EXTENDEDKEY
        keyup_flag = 0x0002                       # KEYEVENTF_KEYUP

        user32.keybd_event(virtual_key, scan_code, extended_flag, 0)
        time.sleep(0.02)
        user32.keybd_event(virtual_key, scan_code, extended_flag | keyup_flag, 0)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("command", "timeline_add_edit")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(self._send_hotkey_sync, hotkey)
