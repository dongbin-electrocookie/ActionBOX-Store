import asyncio
import json
import os
import urllib.request
import websockets

PLUGIN_UUID = "com.cookie.tiktok"
COOKIEDECK_URI = "ws://localhost:8765"
PORTS = [28189, 39728, 34246, 42205, 38534, 40825, 40622]
SUBPROTOCOLS = ["streamdeck_ttls_v1"]

ACTIONS = {
    "com.cookie.tiktok.scene": "com.tiktok.livestudio.scene",
    "com.cookie.tiktok.source": "com.tiktok.livestudio.source",
    "com.cookie.tiktok.live": "com.tiktok.livestudio.livestartend",
    "com.cookie.tiktok.audio": "com.tiktok.livestudio.audio",
    "com.cookie.tiktok.mic": "com.tiktok.livestudio.mic",
    "com.cookie.tiktok.recording": "com.tiktok.livestudio.recording",
    "com.cookie.tiktok.pause": "com.tiktok.livestudio.livepauseresume",
    "com.cookie.tiktok.highlight": "com.tiktok.livestudio.highlight",
}

ACTION_ICON_MAP = {
    "com.cookie.tiktok.scene": "ACTION_SCENE",
    "com.cookie.tiktok.source": "ACTION_SOURCE",
    "com.cookie.tiktok.live": "ACTION_LIVE",
    "com.cookie.tiktok.audio": "ACTION_AUDIO",
    "com.cookie.tiktok.mic": "ACTION_MIC",
    "com.cookie.tiktok.recording": "ACTION_RECORDING",
    "com.cookie.tiktok.pause": "ACTION_PAUSE",
    "com.cookie.tiktok.highlight": "ACTION_HIGHLIGHT",
}

STREAM_STATUS_DEFAULT = 0
STREAM_STATUS_PAUSE = 1
STREAM_STATUS_LIVING = 2

I18N = {
    "en": {"STATUS_WAITING": "Waiting...", "STATUS_NOT_FOUND": "Could not find the TikTok Live Studio service.", "STATUS_CONNECTED": "Connected (port {port})", "STATUS_CONNECTION_FAILED": "Connection failed: {error}"},
    "ko": {"STATUS_WAITING": "대기 중...", "STATUS_NOT_FOUND": "TikTok Live Studio 서비스를 찾지 못했습니다.", "STATUS_CONNECTED": "연결됨 (포트 {port})", "STATUS_CONNECTION_FAILED": "연결 실패: {error}"},
    "ja": {"STATUS_WAITING": "待機中...", "STATUS_NOT_FOUND": "TikTok Live Studio サービスが見つかりませんでした。", "STATUS_CONNECTED": "接続済み (ポート {port})", "STATUS_CONNECTION_FAILED": "接続失敗: {error}"},
    "de": {"STATUS_WAITING": "Warten...", "STATUS_NOT_FOUND": "Der TikTok Live Studio-Dienst konnte nicht gefunden werden.", "STATUS_CONNECTED": "Verbunden (Port {port})", "STATUS_CONNECTION_FAILED": "Verbindung fehlgeschlagen: {error}"},
    "es": {"STATUS_WAITING": "Esperando...", "STATUS_NOT_FOUND": "No se pudo encontrar el servicio de TikTok Live Studio.", "STATUS_CONNECTED": "Conectado (puerto {port})", "STATUS_CONNECTION_FAILED": "Conexión fallida: {error}"},
    "fr": {"STATUS_WAITING": "En attente...", "STATUS_NOT_FOUND": "Impossible de trouver le service TikTok Live Studio.", "STATUS_CONNECTED": "Connecté (port {port})", "STATUS_CONNECTION_FAILED": "Échec de connexion : {error}"},
    "ru": {"STATUS_WAITING": "Ожидание...", "STATUS_NOT_FOUND": "Не удалось найти сервис TikTok Live Studio.", "STATUS_CONNECTED": "Подключено (порт {port})", "STATUS_CONNECTION_FAILED": "Ошибка подключения: {error}"},
    "it": {"STATUS_WAITING": "In attesa...", "STATUS_NOT_FOUND": "Impossibile trovare il servizio TikTok Live Studio.", "STATUS_CONNECTED": "Connesso (porta {port})", "STATUS_CONNECTION_FAILED": "Connessione fallita: {error}"},
    "pt-PT": {"STATUS_WAITING": "A aguardar...", "STATUS_NOT_FOUND": "Não foi possível encontrar o serviço TikTok Live Studio.", "STATUS_CONNECTED": "Ligado (porta {port})", "STATUS_CONNECTION_FAILED": "Falha na ligação: {error}"},
}

def norm_lang(v):
    code = str(v or "en").lower()
    alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
    code = alias.get(code, code)
    return code if code in I18N else "en"

class TikTokPlugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.tt_ws = None
        self.connected_port = None
        self.tt_connected = False
        self.pending_context = {}
        self.settings_cache = {}
        self.latest_sync = {}
        self.status_state = {"key": "STATUS_WAITING"}
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        asyncio.create_task(self.tt_loop())

    def log(self, msg):
        print(f"[{self.uuid}] {msg}", flush=True)

    def _default_settings_for_action(self, action_uuid):
        base = {
            "action_uuid": action_uuid,
            "_lang": "en",
            "builtin_icon_name": ACTION_ICON_MAP.get(action_uuid, "ACTION_SCENE"),
            "default_visuals_initialized": True,
        }
        if action_uuid == "com.cookie.tiktok.scene":
            base.update({"scene": "", "sync_title_on_target_change": False})
        elif action_uuid == "com.cookie.tiktok.source":
            base.update({"scene": "", "source": "", "sync_title_on_target_change": False})
        else:
            base.update({"sync_title_on_action_change": False})
        return base

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("scene"),
            s.get("source"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_target_change", False),
            s.get("sync_title_on_action_change", False),
            s.get("action_uuid"),
        ])

    def _get_builtin_icon_path(self, action_id):
        icon_name = ACTION_ICON_MAP.get(action_id, "ACTION_SCENE")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id):
        icon_path = self._get_builtin_icon_path(action_id)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, incoming_settings):
        merged = {**self._default_settings_for_action(action_id), **(incoming_settings or {})}
        self.settings_cache[context] = merged

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings_for_action(action_id)
            self.settings_cache[context] = defaults.copy()
            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })
            await self._send_builtin_icon(context, action_id)
            return False

        await self._send_builtin_icon(context, action_id)
        return True

    def _lang(self, context):
        settings = self.settings_cache.get(context, {})
        return norm_lang(settings.get("_lang", "en"))

    def _status_text(self, context):
        lang = self._lang(context)
        data = I18N.get(lang, I18N["en"])
        key = self.status_state.get("key", "STATUS_WAITING")
        template = data.get(key, key)
        return template.format(port=self.status_state.get("port", ""), error=self.status_state.get("error", ""))

    async def send_pi(self, context, payload):
        await self.runner.send_message({"event": "sendToPropertyInspector", "context": context, "payload": payload})

    async def scan_socketio_port(self):
        for port in PORTS:
            url = f"http://127.0.0.1:{port}/socket.io/?EIO=4&transport=polling"
            try:
                with urllib.request.urlopen(url, timeout=1.5) as resp:
                    body = resp.read().decode("utf-8", errors="ignore")
                    if body.startswith("0{") and "sid" in body and "pingInterval" in body:
                        return port
            except Exception:
                continue
        return None

    async def tt_loop(self):
        while True:
            try:
                if self.tt_ws is None:
                    port = await self.scan_socketio_port()
                    if port is None:
                        self.tt_connected = False
                        self.connected_port = None
                        self.status_state = {"key": "STATUS_NOT_FOUND"}
                        await asyncio.sleep(5)
                        continue
                    self.connected_port = port
                    uri = f"ws://127.0.0.1:{port}/socket.io/?EIO=4&transport=websocket"
                    self.log(f"TikTok socket.io connect: {uri}")
                    self.tt_ws = await websockets.connect(uri, subprotocols=SUBPROTOCOLS, ping_interval=None)
                    open_packet = await asyncio.wait_for(self.tt_ws.recv(), timeout=5)
                    if not str(open_packet).startswith("0"):
                        raise RuntimeError("socket.io open packet not received")
                    await self.tt_ws.send("40")
                    self.tt_connected = True
                    self.status_state = {"key": "STATUS_CONNECTED", "port": port}
                    asyncio.create_task(self.tt_listener())
                    await asyncio.sleep(0.2)
                    await self.emit_socketio("stream_deck/join_room")
                    await asyncio.sleep(0.2)
                    await self.emit_socketio("stream_deck/sync_settings")
                await asyncio.sleep(3)
            except Exception as e:
                self.log(f"TikTok connection failed: {e}")
                self.tt_connected = False
                self.status_state = {"key": "STATUS_CONNECTION_FAILED", "error": str(e)}
                try:
                    if self.tt_ws:
                        await self.tt_ws.close()
                except Exception:
                    pass
                self.tt_ws = None
                await asyncio.sleep(5)

    async def tt_listener(self):
        ws = self.tt_ws
        try:
            async for message in ws:
                text = message.decode("utf-8", errors="ignore") if isinstance(message, bytes) else str(message)
                if text == "2":
                    await ws.send("3")
                    continue
                if text.startswith("40"):
                    continue
                if text.startswith("42"):
                    try:
                        payload = json.loads(text[2:])
                    except Exception:
                        continue
                    if not isinstance(payload, list) or not payload:
                        continue
                    event_name = payload[0]
                    event_data = payload[1] if len(payload) > 1 else None
                    await self.handle_tt_event(event_name, event_data)
        except Exception as e:
            self.log(f"TikTok listener ended: {e}")
        finally:
            if self.tt_ws == ws:
                self.tt_ws = None
                self.tt_connected = False

    async def handle_tt_event(self, event_name, event_data):
        if event_name == "stream_deck/join_room":
            await self.emit_socketio("stream_deck/sync_settings")
            return
        if event_name == "stream_deck/sync_settings":
            data = self.parse_jsonish(event_data, {})
            if isinstance(data, dict):
                self.latest_sync = data
                self.status_state = {"key": "STATUS_CONNECTED", "port": self.connected_port}
            return
        if event_name.startswith("stream_deck/"):
            context = event_name.split("/", 1)[1]
            fut = self.pending_context.pop(context, None)
            if fut and not fut.done():
                fut.set_result(self.parse_jsonish(event_data, {}))

    def parse_jsonish(self, value, default=None):
        if isinstance(value, (dict, list)):
            return value
        if isinstance(value, str):
            try:
                return json.loads(value)
            except Exception:
                return default if default is not None else value
        return default if default is not None else value

    async def emit_socketio(self, event_name, data=None):
        if self.tt_ws is None:
            raise RuntimeError("TikTok socket not connected")
        packet = [event_name] if data is None else [event_name, data]
        await self.tt_ws.send("42" + json.dumps(packet, ensure_ascii=False))

    async def emit_action(self, action_name, context, payload):
        if not self.tt_connected or self.tt_ws is None:
            raise RuntimeError("TikTok Live Studio is not connected")
        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        self.pending_context[context] = fut
        await self.emit_socketio("stream_deck/action_emit", json.dumps({"action": action_name, "context": context, "payload": payload}, ensure_ascii=False))
        try:
            result = await asyncio.wait_for(fut, timeout=5)
        except asyncio.TimeoutError:
            self.pending_context.pop(context, None)
            result = {"code": -1, "message": "timeout"}
        await self.emit_socketio("stream_deck/sync_settings")
        return result

    def get_scene_names(self):
        return [s.get("name") for s in self.latest_sync.get("scene_list", []) if s.get("name")]

    async def handle_refresh(self, context):
        if self.tt_connected:
            try:
                await self.emit_socketio("stream_deck/sync_settings")
                await asyncio.sleep(0.2)
            except Exception:
                pass
        scene_names = self.get_scene_names()
        await self.send_pi(context, {"command": "syncData", "status": self._status_text(context), "connected_port": self.connected_port or "", "scene_list": scene_names, "sync": self.latest_sync})

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or data.get("key")
        action_uuid = data.get("action") or payload.get("action")
        if event == "keyDidAppear":
            raw_settings = payload.get("settings", {}) or {}
            action_uuid = action_uuid or raw_settings.get("action_uuid")
            if context and action_uuid:
                await self._initialize_default_visuals_if_new(context, action_uuid, raw_settings)
            return

        if event in ("keyDidDisappear", "willDisappear"):
            if context in self.settings_cache:
                self.settings_cache.pop(context, None)
            return

        if event == "didReceiveSettings":
            settings = payload.get("settings", {}) or payload or {}
            if context:
                cached = self.settings_cache.get(context, {})
                self.settings_cache[context] = {**cached, **settings}
            cmd = settings.get("pi_command")
            if cmd == "refresh":
                await self.handle_refresh(context)
                settings["pi_command"] = ""
            return

        if event == "sendToPlugin":
            cmd = payload.get("command")
            if cmd == "refresh":
                await self.handle_refresh(context)
            elif cmd == "apply_builtin_icon":
                action_uuid = payload.get("action_uuid") or self.settings_cache.get(context, {}).get("action_uuid")
                if action_uuid:
                    await self._send_builtin_icon(context, action_uuid)
            return

        if event == "keyDown":
            incoming = payload.get("settings", {}) or {}
            cached = self.settings_cache.get(context, {})
            final_settings = {**cached, **incoming}
            if incoming:
                self.settings_cache[context] = final_settings
            if not action_uuid:
                action_uuid = final_settings.get("action_uuid")

            if action_uuid == "com.cookie.tiktok.scene":
                scene = final_settings.get("scene", "")
                source = final_settings.get("source", "")
                if not scene:
                    self.log("scene action ignored: no scene selected")
                    return
                await self.emit_action(ACTIONS[action_uuid], context, {"settings": {"scene": scene, "source": source}})

            elif action_uuid == "com.cookie.tiktok.source":
                scene = final_settings.get("scene", "")
                source = final_settings.get("source", "")
                if not scene or not source:
                    self.log("source action ignored: scene/source not selected")
                    return
                await self.emit_action(ACTIONS[action_uuid], context, {"settings": {"scene": scene, "source": source}})

            elif action_uuid in ACTIONS:
                sync = self.latest_sync or {}
                if action_uuid == "com.cookie.tiktok.live":
                    state = 0 if sync.get("stream_status") == STREAM_STATUS_LIVING else 1
                elif action_uuid == "com.cookie.tiktok.audio":
                    state = 0 if sync.get("audio_mute") else 1
                elif action_uuid == "com.cookie.tiktok.mic":
                    state = 0 if sync.get("mic_mute") else 1
                elif action_uuid == "com.cookie.tiktok.recording":
                    state = 1 if sync.get("recording") else 0
                elif action_uuid == "com.cookie.tiktok.pause":
                    state = 1 if sync.get("stream_status") == STREAM_STATUS_PAUSE else 0
                elif action_uuid == "com.cookie.tiktok.highlight":
                    state = 1 if sync.get("highlight_able") else 0
                else:
                    state = 0
                await self.emit_action(ACTIONS[action_uuid], context, {"settings": {}, "state": state})

if __name__ == "__main__":
    class ExternalRunner:
        def __init__(self, ws):
            self.ws = ws
        async def send_message(self, msg):
            await self.ws.send(json.dumps(msg, ensure_ascii=False))

    async def main():
        while True:
            try:
                manifest_path = os.path.join(os.path.dirname(__file__), "manifest.json")
                with open(manifest_path, "r", encoding="utf-8") as f:
                    manifest = json.load(f)
                async with websockets.connect(COOKIEDECK_URI) as websocket:
                    await websocket.send(json.dumps({"event": "register", "uuid": manifest["UUID"]}))
                    runner = ExternalRunner(websocket)
                    plugin = TikTokPlugin(runner, manifest)
                    async for message in websocket:
                        try:
                            data = json.loads(message)
                        except Exception:
                            continue
                        try:
                            await plugin.handle_message(data)
                        except Exception as e:
                            print(f"[{PLUGIN_UUID}] message error: {e}", flush=True)
            except Exception as e:
                print(f"[{PLUGIN_UUID}] bootstrap error: {e}", flush=True)
                await asyncio.sleep(5)

    asyncio.run(main())
