import asyncio
import json
import time
import platform
import threading

# --- 라이브러리 임포트 및 상태 확인 ---
IS_WINDOWS = (platform.system() == "Windows")
libraries_ok = False

if IS_WINDOWS:
    try:
        import win32gui
        import win32con
        import keyboard
        libraries_ok = True
    except ImportError:
        print("[Discord Plugin Error] Missing 'pywin32' or 'keyboard'.")
        # sys.exit(1) <--- 절대 금지 (러너 보호)

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # --- 액션 매핑 (기존과 동일) ---
        self.action_map = {
            "togglemute": self.toggle_mute,
            "toggledeafen": self.toggle_deafen,
            "answercall": self.answer_call,
            "rejectcall": self.reject_call,
            "navserver_up": self.nav_server_up,
            "navserver_down": self.nav_server_down,
            "navchannel_up": self.nav_channel_up,
            "navchannel_down": self.nav_channel_down,
            "navhistory_back": self.nav_history_back,
            "navhistory_forward": self.nav_history_forward,
            "navunread_up": self.nav_unread_up,
            "navunread_down": self.nav_unread_down,
            "openemoji": self.open_emoji,
            "opengif": self.open_gif,
            "uploadfile": self.upload_file,
            "quickswitcher": self.quick_switcher,
        }

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not libraries_ok or not IS_WINDOWS:
            print(f"[{self.uuid}] Plugin disabled: Missing libraries or not Windows.")
            return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("discord_action")

        if selected_action:
            action_func = self.action_map.get(selected_action)
            if action_func:
                # print(f"[{self.uuid}] Executing: {selected_action}")
                # [중요] time.sleep이 포함된 "바보 같은 방식"이므로
                # 반드시 스레드로 분리해야 공유 런타임이 멈추지 않습니다.
                await asyncio.to_thread(action_func)
            else:
                print(f"[{self.uuid}] Unknown action: {selected_action}")

    # --- 디스코드 제어 메소드 (기존 로직 100% 유지) ---
    def _send_hotkey_with_focus(self, hotkey):
        """
        디스코드 창을 찾아서 맨 앞으로 가져온 뒤 단축키를 누르고
        다시 원래 창으로 돌아가는 방식 (Focus Stealing)
        """
        try:
            original_foreground_window = win32gui.GetForegroundWindow()
            discord_hwnd = 0
            
            def callback(hwnd, extra):
                nonlocal discord_hwnd
                if "Discord" in win32gui.GetWindowText(hwnd) and win32gui.GetClassName(hwnd) == "Chrome_WidgetWin_1":
                    discord_hwnd = hwnd
            win32gui.EnumWindows(callback, None)

            if discord_hwnd == 0:
                # 디스코드 창을 못 찾으면 그냥 글로벌 단축키 전송 시도
                # print(f"[{self.uuid}] Discord window not found. Sending global hotkey.")
                keyboard.send(hotkey)
                return

            # 1. 디스코드 창 활성화
            win32gui.ShowWindow(discord_hwnd, win32con.SW_RESTORE)
            win32gui.SetForegroundWindow(discord_hwnd)
            time.sleep(0.15) # 창 전환 대기 (필수)
            
            # 2. 단축키 전송
            keyboard.send(hotkey)
            # print(f"[{self.uuid}] Sent '{hotkey}'")
            
            # 3. 원래 창 복구
            time.sleep(0.05)
            win32gui.SetForegroundWindow(original_foreground_window)
            
        except Exception as e:
            print(f"[{self.uuid} ERROR] Focus switch failed: {e}")

    # --- 랩퍼 함수들 (기존과 동일) ---
    def toggle_mute(self): self._send_hotkey_with_focus("ctrl+shift+m")
    def toggle_deafen(self): self._send_hotkey_with_focus("ctrl+shift+d")
    def answer_call(self): self._send_hotkey_with_focus("ctrl+enter")
    def reject_call(self): self._send_hotkey_with_focus("esc")
    def nav_server_up(self): self._send_hotkey_with_focus("ctrl+alt+up")
    def nav_server_down(self): self._send_hotkey_with_focus("ctrl+alt+down")
    def nav_channel_up(self): self._send_hotkey_with_focus("alt+up")
    def nav_channel_down(self): self._send_hotkey_with_focus("alt+down")
    def nav_history_back(self): self._send_hotkey_with_focus("alt+left")
    def nav_history_forward(self): self._send_hotkey_with_focus("alt+right")
    def nav_unread_up(self): self._send_hotkey_with_focus("alt+shift+up")
    def nav_unread_down(self): self._send_hotkey_with_focus("alt+shift+down")
    def quick_switcher(self): self._send_hotkey_with_focus("ctrl+k")
    def open_emoji(self): self._send_hotkey_with_focus("ctrl+e")
    def open_gif(self): self._send_hotkey_with_focus("ctrl+g")
    def upload_file(self): self._send_hotkey_with_focus("ctrl+shift+u")