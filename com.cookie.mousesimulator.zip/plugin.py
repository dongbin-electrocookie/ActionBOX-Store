import asyncio
import os

try:
    import pyautogui
    PYAUTOGUI_OK = True
    pyautogui.FAILSAFE = True
except ImportError:
    pyautogui = None
    PYAUTOGUI_OK = False


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        self.icon_map = {
            "click": "MOUSE_CLICK",
            "double_click": "MOUSE_DOUBLE_CLICK",
            "right_click": "MOUSE_RIGHT_CLICK",
            "move_only": "MOUSE_MOVE_ONLY",
        }

    def _default_action(self):
        return "click"

    def _default_settings(self):
        action = self._default_action()
        return {
            "mouse_action": action,
            "pos_x": "",
            "pos_y": "",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("mouse_action") or self._default_action()
        if action not in self.icon_map:
            action = self._default_action()
        merged["mouse_action"] = action
        merged["builtin_icon_name"] = self.icon_map[action]
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("mouse_action"),
            s.get("pos_x"),
            s.get("pos_y"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False),
            s.get("_lang")
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        path = os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")
        if os.path.exists(path):
            return path
        fallback = os.path.join(self.plugin_dir, "icon", "pluginIcon.png")
        return fallback if os.path.exists(fallback) else None

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if context and icon_path:
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["mouse_action"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            action_name = data.get("action_command") or payload.get("action_command") or settings.get("mouse_action") or cached.get("mouse_action") or self._default_action()
            await self._send_builtin_icon(context, action_name)
            return

        if event == "sendToPlugin":
            if payload.get("command") == "capturePosition":
                await self.capture_position(context)
            return

        if event == "keyDown":
            await self.on_key_down(context, settings)

    async def capture_position(self, context):
        if not PYAUTOGUI_OK or not context:
            return
        await asyncio.sleep(3)
        x, y = pyautogui.position()
        await self.runner.send_message({
            "event": "sendToPropertyInspector",
            "context": context,
            "payload": {
                "command": "positionCaptured",
                "x": int(x),
                "y": int(y)
            }
        })

    async def on_key_down(self, context, incoming_settings):
        if not PYAUTOGUI_OK:
            return

        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **(incoming_settings or {})})
        if context:
            self.context_settings[context] = settings

        action = settings.get("mouse_action", self._default_action())

        x_raw = settings.get("pos_x")
        y_raw = settings.get("pos_y")
        x = int(x_raw) if str(x_raw).strip() != "" else None
        y = int(y_raw) if str(y_raw).strip() != "" else None

        await asyncio.to_thread(self._execute_mouse_action, action, x, y)

    def _execute_mouse_action(self, action, x, y):
        try:
            if x is not None and y is not None:
                pyautogui.moveTo(x, y, duration=0.2)

            if action == "click":
                pyautogui.click()
            elif action == "double_click":
                pyautogui.doubleClick()
            elif action == "right_click":
                pyautogui.rightClick()
            elif action == "move_only":
                pass

        except Exception as e:
            print(f"[Mouse Simulator Error] {e}")
