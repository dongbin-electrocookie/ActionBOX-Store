# COMBO-X Premiere background bridge — test build

Users do not download, install, open or keep a panel visible. The COMBO-X
Windows installer and macOS postinstall deploy the signed CEP extension to
the current user's Adobe CEP folder. Source execution also installs/repairs
it when a Premiere action appears or is pressed. Restart Premiere after first
installation or an update, then activate its window once. Its `Custom`
extension starts on `com.adobe.csxs.events.ApplicationActivate` and remains
invisible. No Adobe `PlayerDebugMode`, remote debugger, firewall rule or local
network server is used.

The source tree currently includes a **development-only, self-signed** ZXP:

- CN: `COMBO-X Test Bridge` (not an Adobe endorsement or OS-trusted identity).
- Valid 2026-10-21 through 2027-10-21; no RFC3161 timestamp.
- Adobe ZXPSignCmd verified its signature. This does not verify functional
  operation or compatibility with a particular Premiere version.
- The temporary development private key was discarded, not shipped.
- Do not ship this development package as the maintained production release.

## Test on the developer machine

1. Restart COMBO-X from the modified source, select/place a Premiere script
   action, and wait for its initial settings to load (automatic installation).
2. Fully quit and restart Premiere Pro; bring its window to the foreground.
3. Select the matching Premiere application path in COMBO-X. Open a disposable
   sequence, select **Add Marker at Playhead**, and press the COMBO-X button.
4. Verify the marker actually appears. `executed` means the ExtendScript call
   returned; a script that handles its own errors can still return normally.
5. Also check a custom `.jsx`, two installed Premiere versions, failed script,
   Premiere closed, repeated presses, and application/extension updates.

No real Premiere process was launched or scripted during automated tests.
Real Premiere startup, macOS, and installer end-to-end validation remain
necessary before claiming this feature is supported.

## Release signing (developer task, not a customer task)

Use Adobe's official ZXPSignCmd and a maintained CEP signing certificate.
Set the password in `COMBOX_CEP_CERT_PASSWORD`, then run from the source root:

```
py tools/build_premiere_bridge.py --sign-tool <ZXPSignCmd> --certificate <release.p12> --timestamp <RFC3161-URL>
```

On macOS use the corresponding Python and Adobe signing tool. Never put the
certificate/private key/password into the plugin, installer, SDK or logs.
This creates the ZXP and its `package.json` together. Modifying a file under
`extension/` requires re-signing. The installer rejects missing signatures,
package checksum mismatches or source/package mismatches rather than turning
off Adobe signature checks. A certificate valid for Windows EXE signing or
Apple notarization is not automatically interchangeable with CEP signing.

Include the **entire plugin directory**, especially `premiere_bridge.py`,
`premiere_bridge/package.json` and `premiere_bridge/*.zxp`, in the release's
`internal_plugins` resources. Neither EXE rebuilding nor the existing SDK's
hotkey helper is needed for the plugin source itself; the revised installers
must be rebuilt to install the bridge before COMBO-X's first launch.

## Diagnostics / safety

- Extension: `%APPDATA%/Adobe/CEP/extensions/com.electrocookie.combox.premiere.bridge`
  or `~/Library/Application Support/Adobe/CEP/extensions/` with the same ID.
- Local mailbox: `%APPDATA%/COMBO-X/PremiereBridge/<application-hash>` or the
  corresponding macOS Application Support directory.
- The canonical selected executable (macOS `.app` bundle), protocol, process
  instance, random request ID and dispatch deadline must match.
- A request is atomically claimed once. Running requests are never replayed;
  expired requests are cancelled. A timeout is not proof execution stopped.
- Mailbox files are trusted **same-OS-user** IPC, not a sandbox against malicious
  software already running as that user. There is no network ingress.
- Existing extension updates are preserved outside CEP's scan directory under
  `Adobe/CEP/COMBO-X Bridge Backups` for recovery. No Adobe or user script files
  are deleted. Removing COMBO-X currently leaves this extension installed;
  removal of that exact product-specific folder is a separate cleanup step.

References:

- https://github.com/Adobe-CEP/CEP-Resources/blob/master/CEP_12.x/Documentation/CEP%2012%20HTML%20Extension%20Cookbook.md#invisible-html-extensions
- https://github.com/Adobe-CEP/Getting-Started-guides/tree/master/Package%20Distribute%20Install
