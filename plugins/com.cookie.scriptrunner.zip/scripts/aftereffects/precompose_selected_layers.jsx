#target aftereffects
(function () {
    var comp = app.project && app.project.activeItem;
    if (!(comp instanceof CompItem) || comp.selectedLayers.length === 0) {
        alert("Open a composition and select at least one layer.");
        return;
    }
    var indices = [];
    for (var i = 0; i < comp.selectedLayers.length; i++) {
        indices.push(comp.selectedLayers[i].index);
    }
    indices.sort(function (a, b) { return a - b; });
    app.beginUndoGroup("Pre-compose Selected Layers");
    comp.layers.precompose(indices, "Precomp " + comp.name, true);
    app.endUndoGroup();
}());
