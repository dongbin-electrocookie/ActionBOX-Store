import asyncio
import websockets
import json
import subprocess
import os
import shlex
import sys
import time
import copy
import shutil
import re

try:
    from utility.native_hotkeys import send_windows_hotkey
except ModuleNotFoundError:
    try:
        from native_hotkeys import send_windows_hotkey
    except ModuleNotFoundError:
        # Direct standalone invocation, outside the shared runner's import root.
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
        from utility.native_hotkeys import send_windows_hotkey


try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

class VSCodeDevToolsPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.vscodedevtools"
        self.uri = "ws://localhost:8765"
        self.websocket = None
        self.last_valid_settings = {}
        self.last_results = {}
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.action_default_icon = {
            "com.cookie.vscodedevtools.hotkey": "command palette",
            "com.cookie.vscodedevtools.git": "git pull",
        }

        self.hotkey_icon_map = {
            "ctrl+shift+p": "command palette",
            "command+shift+p": "command palette",
            "ctrl+`": "toggle terminal",
            "ctrl+b": "toggle sidebar",
            "command+b": "toggle sidebar",
            "ctrl+,": "settings",
            "command+,": "settings",
            "f5": "start debug",
            "shift+f5": "stop debug",
            "f10": "step over",
            "f11": "step into",
            "alt+shift+f": "format document",
            "option+shift+f": "format document",
            "ctrl+/": "toggle comment",
            "command+/": "toggle comment",
            "ctrl+d": "select next match",
            "command+d": "select next match",
        }

        self.git_icon_map = {
            "pull": "git pull",
            "push": "git push",
            "status": "git status",
            "add .": "git add all",
            "commit -m 'Update'": "git quick commit",
            "fetch": "git fetch",
        }

    def _default_settings_for_action(self, action_id):
        base = {
            "action_uuid": action_id,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "default_visuals_initialized": True,
        }
        if action_id == "com.cookie.vscodedevtools.hotkey":
            base.update({
                "keys": "",
                "command": "",
                "builtin_icon_name": self.action_default_icon[action_id],
            })
        else:
            base.update({
                "git_command": "",
                "project_path": "",
                "command": "",
                "builtin_icon_name": self.action_default_icon["com.cookie.vscodedevtools.git"],
            })
        return base

    def _merge_with_defaults(self, action_id, settings, cached=None):
        incoming = copy.deepcopy(settings) if isinstance(settings, dict) else {}
        cached = cached if isinstance(cached, dict) and cached.get("action_uuid") == action_id else {}
        merged = self._default_settings_for_action(action_id)
        merged.update(copy.deepcopy(cached))
        merged.update(incoming)
        merged["action_uuid"] = action_id
        field = "keys" if action_id == "com.cookie.vscodedevtools.hotkey" else "git_command"
        # Resolve incoming aliases BEFORE merging cached mirrors. Explicit empty
        # values clear a command; title/path-only updates keep the current one.
        source = incoming if field in incoming or "command" in incoming else cached
        cmd = source.get(field) if field in source else source.get("command", "")
        cmd = cmd.strip() if isinstance(cmd, str) else ""
        merged[field] = merged["command"] = cmd
        merged["builtin_icon_name"] = self._get_icon_name(action_id, cmd)
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("keys"),
            s.get("git_command"),
            s.get("project_path"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False),
        ])

    def _get_icon_name(self, action_id, command_value):
        cmd = (command_value or "").strip()
        if action_id == "com.cookie.vscodedevtools.hotkey":
            return self.hotkey_icon_map.get(cmd, self.action_default_icon[action_id])
        return self.git_icon_map.get(cmd, self.action_default_icon["com.cookie.vscodedevtools.git"])

    def _get_icon_path(self, action_id, command_value):
        icon_name = self._get_icon_name(action_id, command_value)
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id, command_value=""):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        if not self.websocket or not context:
            return
        icon_path = self._get_icon_path(action_id, command_value)
        if os.path.exists(icon_path):
            await self.websocket.send(json.dumps({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            }))

    async def _initialize_default_visuals_if_new(self, context, action_id, incoming_settings):
        if not context or not action_id:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings_for_action(action_id)
            self.last_valid_settings[context] = defaults.copy()
            if self.websocket:
                await self.websocket.send(json.dumps({
                    "event": "setSettings",
                    "context": context,
                    "payload": defaults
                }))
            await self._send_builtin_icon(context, action_id, "")
            return False

        merged = self._merge_with_defaults(action_id, incoming_settings)
        self.last_valid_settings[context] = merged
        await self._send_builtin_icon(context, action_id, merged.get("command", ""))
        return True

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.uri) as websocket:
                    self.websocket = websocket
                    await self.register()
                    await self.listen()
            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] Connection failed: {e}. Retrying in 5s...", flush=True)
                await asyncio.sleep(5)
            finally:
                self.websocket = None

    async def register(self):
        await self.websocket.send(json.dumps({
            "event": "register",
            "uuid": self.PLUGIN_UUID
        }))
        print(f"[{self.PLUGIN_UUID}] Registered.", flush=True)

    async def listen(self):
        async for message in self.websocket:
            try:
                await self.handle_message(json.loads(message))
            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] Error: {e}", flush=True)

    async def ensure_settings(self, context, data):
        payload = data.get("payload", {}) or {}
        incoming_settings = payload.get("settings", {}) or {}
        action_id = data.get("action") or incoming_settings.get("action_uuid") or self.last_valid_settings.get(context, {}).get("action_uuid")
        if not action_id:
            return None, {}
        cached = self.last_valid_settings.get(context, {})
        merged = self._merge_with_defaults(action_id, incoming_settings, cached)
        self.last_valid_settings[context] = merged
        return action_id, merged


    def _mac_hotkey_for_vscode(self, keys):
        """Translate Windows-style VS Code defaults to macOS VS Code shortcuts."""
        key = (keys or "").strip().lower()
        mac_map = {
            "ctrl+shift+p": "command+shift+p",
            # VS Code on macOS commonly keeps Ctrl+` for integrated terminal.
            "ctrl+`": "ctrl+`",
            "ctrl+b": "command+b",
            "ctrl+,": "command+,",
            "f5": "f5",
            "shift+f5": "shift+f5",
            "f10": "f10",
            "f11": "f11",
            "alt+shift+f": "option+shift+f",
            "ctrl+/": "command+/",
            "ctrl+d": "command+d",
        }
        return mac_map.get(key, key)

    def _normalize_pyautogui_key(self, key_name):
        key = (key_name or "").strip().lower()
        aliases = {
            "cmd": "command" if IS_MACOS else "win",
            "command": "command" if IS_MACOS else "win",
            "meta": "command" if IS_MACOS else "win",
            "win": "command" if IS_MACOS else "win",
            "windows": "command" if IS_MACOS else "win",
            "option": "option" if IS_MACOS else "alt",
            "alt": "option" if IS_MACOS else "alt",
            "control": "ctrl",
            "return": "enter",
            "escape": "esc",
            "plus": "+",
        }
        return aliases.get(key, key)

    def _send_hotkey_sync(self, keys):
        hotkey = self._mac_hotkey_for_vscode(keys) if IS_MACOS else (keys or "")
        parts = [self._normalize_pyautogui_key(p) for p in hotkey.split('+') if p.strip()]
        if not parts:
            raise ValueError("Empty shortcut")

        if IS_WINDOWS:
            # OEM Slash (VK_OEM_2) is not numpad Divide. The keyboard package
            # chooses Divide first for '/', which VS Code treats differently.
            # The shared sender also preserves physical modifier/F-key events.
            if send_windows_hotkey(parts):
                return True
            raise ValueError("Unsupported Windows shortcut")

        if IS_LINUX and keyboard_available:
            pressed_keys = []
            try:
                for key_name in parts:
                    keyboard.press(key_name)
                    pressed_keys.append(key_name)
                    time.sleep(0.04)
                time.sleep(0.04)
            finally:
                for key_name in reversed(pressed_keys):
                    try:
                        keyboard.release(key_name)
                    except Exception:
                        pass
                    finally:
                        time.sleep(0.04)
            return True

        if not pyautogui_available:
            print(f"[Hotkey Error] pyautogui is not available. Cannot send: {hotkey}", flush=True)
            raise RuntimeError("Keyboard input backend is unavailable")

        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts, interval=0.04)
        return True

    async def _publish_result(self, context, result):
        if self.websocket and context:
            await self.websocket.send(json.dumps({
                "event": "sendToPropertyInspector", "context": context,
                "payload": {"command": "vscodeResult", "result": result},
            }))

    async def on_key_down(self, data):
        context = data.get("context")
        if not context:
            return
        action_id, final_settings = await self.ensure_settings(context, data)
        if not action_id:
            return

        cmd_value = final_settings.get("command", "")
        result = None

        if action_id == "com.cookie.vscodedevtools.hotkey":
            keys = cmd_value or final_settings.get("keys")
            if keys:
                send_keys = self._mac_hotkey_for_vscode(keys) if IS_MACOS else keys
                print(f"[Hotkey] Sending: {send_keys}", flush=True)
                await asyncio.sleep(0.05)
                try:
                    await asyncio.to_thread(self._send_hotkey_sync, keys)
                    result = {"code": "HOTKEY_SENT", "output": ""}
                except Exception:
                    result = {"code": "HOTKEY_FAILED", "output": ""}
            else:
                result = {"code": "HOTKEY_EMPTY", "output": ""}

        elif action_id == "com.cookie.vscodedevtools.git":
            git_cmd = cmd_value or final_settings.get("git_command")
            project_path = final_settings.get("project_path") or ""
            await self._publish_result(context, {"code": "RESULT_RUNNING", "output": ""})
            result = await asyncio.to_thread(self.run_git, git_cmd, project_path)

        # A slow result from a replaced/edited button must not describe its new
        # assignment. No result is persisted to user settings or key titles.
        if isinstance(result, dict) and self.last_valid_settings.get(context) is final_settings:
            self.last_results[context] = result
            print(f"[{self.PLUGIN_UUID}] {result['code']}", flush=True)
            await self._publish_result(context, result)

    def _find_git(self):
        found = shutil.which("git")
        if found:
            return found
        if IS_WINDOWS:
            local = os.environ.get("LOCALAPPDATA")
            candidates = [os.path.join(root, "Git", "cmd", "git.exe")
                          for root in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"),
                                       os.path.join(local, "Programs") if local else None) if root]
        else:
            candidates = ["/opt/homebrew/bin/git", "/usr/local/bin/git", "/usr/bin/git"]
        return next((path for path in candidates if os.path.isfile(path)), None)

    @staticmethod
    def _safe_output(text):
        text = str(text or "")
        # Remote errors can echo credential-bearing URLs. Never show their
        # userinfo/query/fragment in the inspector or write raw output to logs.
        text = re.sub(r"https?://[^\s<>\"']+", lambda m: re.sub(
            r"[?#].*$", "", re.sub(r"(https?://)[^/@]+@", r"\1[redacted]@", m.group(0), flags=re.I)), text, flags=re.I)
        text = re.sub(r"(?i)\b(?:gh[pousr]_[A-Za-z0-9_]+|github_pat_[A-Za-z0-9_]+)\b", "[redacted]", text)
        return text[:4096]

    def run_git(self, command, cwd):
        def result(code, output="", returncode=None):
            return {"code": code, "output": self._safe_output(output), "returncode": returncode}

        if not isinstance(command, str) or not command.strip():
            return result("GIT_NO_COMMAND")
        if not isinstance(cwd, str) or not cwd.strip():
            return result("GIT_NO_PROJECT")
        cwd = os.path.expandvars(os.path.expanduser(cwd.strip().strip('"')))
        if not os.path.isdir(cwd):
            return result("GIT_PATH_INVALID")
        git = self._find_git()
        if not git:
            return result("GIT_NOT_INSTALLED")
        try:
            env = os.environ.copy()
            env.update(GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="Never")
            options = dict(cwd=cwd, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", env=env, stdin=subprocess.DEVNULL)
            if IS_WINDOWS:
                options["creationflags"] = subprocess.CREATE_NO_WINDOW
            check = subprocess.run([git, "rev-parse", "--show-toplevel"], timeout=5, **options)
            if check.returncode:
                return result("GIT_NOT_REPOSITORY", check.stderr)
            # Preserve all stored state IDs. 'Add All' must cover the whole
            # working tree even when the selected folder is a subdirectory.
            args = ["add", "--all"] if command.strip() == "add ." else shlex.split(command)
            if not args or args[0].startswith("-"):
                return result("GIT_NO_COMMAND")
            completed = subprocess.run([git] + args, timeout=30, **options)
            output = (completed.stdout or "").strip()
            error = (completed.stderr or "").strip()
            if completed.returncode == 0:
                return result("RESULT_SUCCESS", output or error, 0)
            diagnostic = error.lower()
            if any(part in diagnostic for part in ("authentication failed", "could not read username",
                       "terminal prompts disabled", "permission denied (publickey)", "invalid username or token")):
                code = "GIT_AUTH_REQUIRED"
            elif any(part in diagnostic for part in ("no configured push destination", "has no upstream",
                         "no tracking information", "does not appear to be a git repository")):
                code = "GIT_REMOTE_REQUIRED"
            else:
                code = "RESULT_FAILED"
            return result(code, error or output, completed.returncode)
        except subprocess.TimeoutExpired:
            # A timeout is not proof that a mutating operation did nothing.
            # Do not retry pull/push/add/commit automatically.
            return result("GIT_TIMEOUT")
        except FileNotFoundError:
            return result("GIT_NOT_INSTALLED")
        except Exception:
            return result("RESULT_FAILED")

    async def on_pi_request(self, data):
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        command = payload.get("command")
        action_id = payload.get("action_uuid") or self.last_valid_settings.get(context, {}).get("action_uuid")

        if command == "getVSCodeResult":
            await self._publish_result(context, self.last_results.get(context))
        elif command == "apply_builtin_icon" and action_id:
            action_command = payload.get("action_command", "")
            await self._send_builtin_icon(context, action_id, action_command)


    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        action_id = data.get("action") or payload.get("action") or payload.get("action_uuid")

        if event in ("keyDidAppear", "willAppear"):
            raw_settings = payload.get("settings", {}) or {}
            action_id = data.get("action") or raw_settings.get("action_uuid")
            if context and action_id:
                self.last_results.pop(context, None)
                await self._initialize_default_visuals_if_new(context, action_id, raw_settings)
        elif event == "didReceiveSettings":
            settings = payload.get("settings", payload) or {}
            action_id = settings.get("action_uuid") or action_id or self.last_valid_settings.get(context, {}).get("action_uuid")
            if context and action_id:
                self.last_valid_settings[context] = self._merge_with_defaults(
                    action_id, settings, self.last_valid_settings.get(context, {}),
                )
                self.last_results.pop(context, None)
        elif event in ("keyDidDisappear", "willDisappear"):
            self.last_valid_settings.pop(context, None)
            self.last_results.pop(context, None)
        elif event == "sendToPlugin":
            await self.on_pi_request(data)
        elif event == "keyDown":
            await self.on_key_down(data)

    async def shutdown(self):
        self.last_valid_settings.clear()
        self.last_results.clear()


class Plugin(VSCodeDevToolsPlugin):
    """COMBO-X shared-runtime entry point (same dispatch as standalone)."""

    def __init__(self, runner, manifest):
        super().__init__()
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.websocket = runner

if __name__ == "__main__":
    plugin = VSCodeDevToolsPlugin()
    asyncio.run(plugin.connect())
