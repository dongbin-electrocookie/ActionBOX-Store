import asyncio
import os
import sys

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"

keyboard = None
keyboard_available = False
if IS_WINDOWS:
    try:
        import keyboard
        keyboard_available = True
    except ImportError:
        pass

pyautogui = None
pyautogui_available = False
try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pass


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        self.windows_action_map = {
            "file_save": "ctrl+s",
            "file_save_as": "ctrl+shift+s",
            "edit_undo": "ctrl+z",
            "edit_redo": "ctrl+y",
            "edit_cut": "ctrl+x",
            "edit_copy": "ctrl+c",
            "edit_paste": "ctrl+v",
            "edit_transform": "ctrl+t",
            "select_all": "ctrl+a",
            "select_deselect": "ctrl+d",
            "layer_new": "ctrl+shift+n",
            "layer_merge_down": "ctrl+e",
            "brush_size_down": "[",
            "brush_size_up": "]",
            "tool_pen": "p",
            "tool_brush": "b",
            "tool_eraser": "e",
            "tool_blend": "j",
            "tool_fill": "g",
            "tool_figure": "u",
            "tool_text": "t",
            "tool_operation": "o",
            "tool_move_layer": "k",
            "tool_auto_select": "w",
            "tool_selection": "m",
            "tool_eyedropper": "i",
            "tool_hand": "h",
            "tool_zoom": "z",
            "tool_rotate": "r",
        }
        self.macos_action_map = {
            key: value.replace("ctrl", "command").replace("alt", "option")
            for key, value in self.windows_action_map.items()
        }
        self.action_map = self.macos_action_map if IS_MACOS else self.windows_action_map

    def _default_settings(self):
        return {
            "command": "tool_pen",
            "custom_hotkey": "",
            "_lang": "en",
            "default_visuals_initialized": True,
        }

    def _merge_settings(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        return merged

    def _get_icon_path(self, action):
        icon_dir = os.path.join(self.plugin_dir, "icon")
        action_icon = os.path.join(icon_dir, f"{str(action).upper()}.png")
        return action_icon if os.path.exists(action_icon) else os.path.join(icon_dir, "DEFAULT.png")

    async def _send_action_icon(self, context, action):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action)
        if context and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path},
            })

    def _normalize_hotkey_parts(self, hotkey):
        aliases = {
            "cmd": "command",
            "command": "command" if IS_MACOS else "win",
            "win": "command" if IS_MACOS else "win",
            "windows": "command" if IS_MACOS else "win",
            "control": "ctrl",
            "alt": "option" if IS_MACOS else "alt",
            "option": "option" if IS_MACOS else "alt",
            "return": "enter",
            "esc": "escape",
            "del": "delete",
        }
        return [
            aliases.get(part.strip().lower(), part.strip().lower())
            for part in str(hotkey).split("+")
            if part.strip()
        ]

    def _send_hotkey_sync(self, hotkey):
        if not hotkey:
            return
        if IS_WINDOWS and keyboard_available:
            keyboard.send(hotkey)
            return
        if not pyautogui_available:
            print(f"[Clip Studio Plugin] No input backend available for hotkey: {hotkey}")
            return

        parts = self._normalize_hotkey_parts(hotkey)
        if len(parts) == 1:
            pyautogui.press(parts[0])
        elif parts:
            pyautogui.hotkey(*parts)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        settings = payload.get("settings") if isinstance(payload.get("settings"), dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            merged = self._merge_settings(settings)
            if context:
                self.context_settings[context] = merged
            if not settings:
                await self.runner.send_message({
                    "event": "setSettings",
                    "context": context,
                    "payload": merged,
                })
                await self._send_action_icon(context, merged["command"])
            return

        if event == "didReceiveSettings":
            if context:
                self.context_settings[context] = self._merge_settings({
                    **self.context_settings.get(context, {}),
                    **settings,
                })
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            self.context_settings.pop(context, None)
            return

        control_command = data.get("command") or payload.get("command")
        if control_command == "apply_builtin_icon":
            action = payload.get("action_command") or settings.get("command") or "tool_pen"
            await self._send_action_icon(context, action)
            return

        if event == "keyDown":
            incoming = payload.get("settings", {}) or {}
            final_settings = self._merge_settings({
                **self.context_settings.get(context, {}),
                **incoming,
            })
            if context:
                self.context_settings[context] = final_settings
            hotkey = final_settings.get("custom_hotkey", "").strip()
            if not hotkey:
                hotkey = self.action_map.get(final_settings.get("command", "tool_pen"), "")
            await asyncio.to_thread(self._send_hotkey_sync, hotkey)
