import asyncio
import websockets
import json
import platform

class XSplitPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.xsplit"
        self.cd_uri = "ws://localhost:8765"
        self.cd_ws = None
        
        self.xs_ws = None
        self.is_connected = False
        self.xs_ports = [55511, 55512, 55513]
        
        self.req_id = 0
        self.pending_requests = {}
        self.xsplit_task = None

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.cd_uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    print(f"[{self.PLUGIN_UUID}] CookieDeck 등록 완료.")
                    
                    if not self.xsplit_task:
                        self.xsplit_task = asyncio.create_task(self.xsplit_reconnect_loop())
                        
                    await self.listen_cookiedeck()
            except Exception as e:
                await asyncio.sleep(3)

    async def listen_cookiedeck(self):
        async for message in self.cd_ws:
            try:
                data = json.loads(message)
                event = data.get("event")
                if event == "keyDown":
                    await self.on_key_down(data)
                elif event == "sendToPlugin":
                    await self.on_pi_request(data.get("payload", {}), data.get("context"))
            except Exception:
                pass

    # =================================================================
    # 🔘 XSplit 기능 실행부 (총 9개 기능 완벽 매핑)
    # =================================================================
    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        action = settings.get("xs_action", "toggle_mic")
        
        if action == "set_scene" and settings.get("target_scene"):
            await self.send_to_xsplit("setActiveScene", {"id": settings.get("target_scene")})
            
        elif action == "toggle_source" and settings.get("target_scene") and settings.get("target_source"):
            await self.send_to_xsplit("toggleSourceState", {"sceneId": settings.get("target_scene"), "sourceId": settings.get("target_source")})
            
        elif action == "set_preset" and settings.get("target_scene") and settings.get("target_preset"):
            await self.send_to_xsplit("setActivePreset", {"sceneId": settings.get("target_scene"), "presetId": settings.get("target_preset")})
            
        elif action in ["toggle_output", "toggle_record"] and settings.get("target_output"):
            # 방송과 녹화는 둘 다 Output 토글 API를 같이 씁니다!
            await self.send_to_xsplit("toggleOutputState", {"id": settings.get("target_output")})
            
        elif action == "toggle_mic":
            await self.send_to_xsplit("toggleMicrophoneState")
            
        elif action == "toggle_speaker":
            await self.send_to_xsplit("toggleSpeakerState")
            
        elif action == "screenshot":
            await self.send_to_xsplit("doScreenshot")
            
        elif action == "push_to_live":
            await self.send_to_xsplit("doPushToLive")

    # =================================================================
    # ⚙️ 설정창(PI) 데이터 요청 처리부 (목록 가져오기)
    # =================================================================
    async def on_pi_request(self, payload, context):
        command = payload.get("command")
        
        if command == "getSceneList":
            res = await self.send_to_xsplit("getAllScenes")
            if res:
                scenes = res.get("payload", {}).get("scenes", [])
                await self.cd_ws.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": {"command": "sceneList", "scenes": scenes}}))
                
        elif command == "getSourceList":
            scene_id = payload.get("sceneId")
            res = await self.send_to_xsplit("getSceneSources", {"sceneId": scene_id})
            if res:
                sources = res.get("payload", {}).get("sources", [])
                await self.cd_ws.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": {"command": "sourceList", "sources": sources}}))
                
        elif command == "getPresetList":
            scene_id = payload.get("sceneId")
            res = await self.send_to_xsplit("getScenePresets", {"sceneId": scene_id})
            if res:
                presets = res.get("payload", {}).get("presets", [])
                await self.cd_ws.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": {"command": "presetList", "presets": presets}}))

        elif command == "getOutputList":
            res = await self.send_to_xsplit("getAllOutputs")
            if res:
                outputs = res.get("payload", {}).get("outputs", [])
                await self.cd_ws.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": {"command": "outputList", "outputs": outputs}}))

    async def xsplit_reconnect_loop(self):
        while True:
            for port in self.xs_ports:
                if self.is_connected: break
                try:
                    url = f"ws://127.0.0.1:{port}"
                    async with websockets.connect(url, open_timeout=1) as ws:
                        print(f"[{self.PLUGIN_UUID}] ✅ XSplit 연결됨 ({url})")
                        self.xs_ws = ws
                        self.is_connected = True
                        await self.listen_xsplit(ws)
                except Exception: pass
            self.is_connected = False
            await asyncio.sleep(2)

    async def listen_xsplit(self, ws):
        try:
            async for message in ws:
                data = json.loads(message)
                async_id = data.get("asyncId")
                if async_id in self.pending_requests:
                    self.pending_requests[async_id].set_result(data)
        except websockets.ConnectionClosed:
            print(f"[{self.PLUGIN_UUID}] ❌ XSplit 연결 끊김.")

    async def send_to_xsplit(self, event, payload=None):
        if not self.is_connected or not self.xs_ws: return None
        
        self.req_id += 1
        req_id = self.req_id
        msg = {"asyncId": req_id, "event": event}
        if payload: msg["payload"] = payload
        
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        self.pending_requests[req_id] = future
        
        try:
            await self.xs_ws.send(json.dumps(msg))
            return await asyncio.wait_for(future, timeout=2.0)
        except Exception:
            return None
        finally:
            if req_id in self.pending_requests:
                del self.pending_requests[req_id]

async def main():
    plugin = XSplitPlugin()
    await plugin.connect()

if __name__ == "__main__":
    asyncio.run(main())