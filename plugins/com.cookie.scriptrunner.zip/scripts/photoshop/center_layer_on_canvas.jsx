#target photoshop

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else {
    var originalRulerUnits = app.preferences.rulerUnits;
    try {
        var doc = app.activeDocument;
        var layer = doc.activeLayer;
        if (layer.isBackgroundLayer || layer.allLocked) {
            throw new Error("배경 또는 잠긴 레이어는 이동할 수 없습니다.");
        }

        app.preferences.rulerUnits = Units.PIXELS;
        var bounds = layer.bounds;
        var layerCenterX = (bounds[0].as("px") + bounds[2].as("px")) / 2;
        var layerCenterY = (bounds[1].as("px") + bounds[3].as("px")) / 2;
        layer.translate(
            doc.width.as("px") / 2 - layerCenterX,
            doc.height.as("px") / 2 - layerCenterY
        );
    } catch (e) {
        alert("중앙 이동 오류: " + e.message);
    } finally {
        app.preferences.rulerUnits = originalRulerUnits;
    }
}
