import asyncio
import websockets
import json
import os
import hashlib
import base64
import platform
import time

IS_WINDOWS = (platform.system() == "Windows")

class OBSPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.prism"
        self.uri = "ws://localhost:8765"
        self.websocket = None
        
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_file = os.path.join(self.plugin_dir, 'obs_config.json')
        
        self.obs_request_queue = asyncio.Queue()
        self.obs_connection_task = None
        self.is_obs_connected = False
        
        self.desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.uri) as websocket:
                    self.websocket = websocket
                    await self.register()
                    await self.listen()
            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] CookieDeck connection failed: {e}. Retrying...")
                await asyncio.sleep(5)

    async def register(self):
        await self.websocket.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
        print(f"[{self.PLUGIN_UUID}] Registered with CookieDeck.")
        self.start_obs_connection()

    async def listen(self):
        async for message in self.websocket:
            try:
                data = json.loads(message)
                event = data.get("event")
                if event == "keyDown":
                    await self.on_key_down(data)
                elif event == "sendToPlugin":
                    payload = data.get("payload") or {}
                    context = data.get("context") or data.get("key")
                    await self.on_pi_request(payload, context)
                    continue

                if isinstance(data, dict) and isinstance(data.get("command"), str):
                    context = data.get("context") or data.get("key")
                    await self.on_pi_request(data, context)                    
            except Exception as e:
                print(f"[{self.PLUGIN_UUID} ERROR] Error processing message: {e}")

    async def on_key_down(self, data):
        context = data.get("context")
        settings = data.get("payload", {}).get("settings", {})
        obs_action = settings.get("obs_action", "stream_toggle")
        
        req_type = None
        req_data = {}

        # 1. 방송/녹화/가상카메라
        if obs_action == "stream_toggle": req_type = "ToggleStream"
        elif obs_action == "record_toggle": req_type = "ToggleRecord"
        elif obs_action == "virtual_cam_toggle": req_type = "ToggleVirtualCam"
        
        # 2. 리플레이 버퍼
        elif obs_action == "replay_buffer_toggle": req_type = "ToggleReplayBuffer"
        elif obs_action == "replay_buffer_save": req_type = "SaveReplayBuffer"
        
        # 3. 마커(챕터) 추가 기능
        elif obs_action == "stream_marker": req_type = "CreateStreamMarker"
        elif obs_action == "record_chapter": 
            req_type = "CreateRecordChapter"
            req_data = {"chapterName": "CookieDeck Marker"}

        # 4. 스튜디오 모드 & 트랜지션
        elif obs_action == "studio_mode_toggle": req_type = "ToggleStudioMode"
        elif obs_action == "trigger_transition": req_type = "TriggerStudioModeTransition"
        elif obs_action == "set_transition":
            if settings.get("target_transition"):
                req_type = "SetCurrentSceneTransition"
                req_data = {"transitionName": settings.get("target_transition")}

        # 5. 장면/소스 제어
        elif obs_action == "change_scene":
            if settings.get("target_scene"): 
                req_type = "SetCurrentProgramScene"
                req_data = {"sceneName": settings.get("target_scene")}

        elif obs_action == "toggle_source":
            parts = settings.get("target_name", "").split(';')
            if len(parts) == 2:
                req_type = "ToggleSceneItemEnabled"
                req_data = {"sceneName": parts[0].strip(), "sceneItemName": parts[1].strip()}

        elif obs_action == "filter_control":
            src = settings.get("target_input")
            flt = settings.get("filter_name")
            state = settings.get("enable_state", "true") == "true"
            if src and flt:
                req_type = "SetSourceFilterEnabled"
                req_data = {"sourceName": src, "filterName": flt, "filterEnabled": state}

        # 6. 미디어/오디오/스크린샷
        elif obs_action == "media_play_pause":
            if settings.get("target_input"): 
                req_type = "TriggerMediaInputAction"
                req_data = {"inputName": settings.get("target_input"), "mediaAction": "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_PLAY_PAUSE"}
        
        elif obs_action == "media_restart":
            if settings.get("target_input"): 
                req_type = "TriggerMediaInputAction"
                req_data = {"inputName": settings.get("target_input"), "mediaAction": "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_RESTART"}

        elif obs_action == "toggle_mute":
            if settings.get("target_input"): 
                req_type = "ToggleInputMute"
                req_data = {"inputName": settings.get("target_input")}

        elif obs_action == "screenshot_source":
            src = settings.get("target_input")
            if src:
                req_type = "SaveSourceScreenshot"
                timestamp = time.strftime("%Y%m%d_%H%M%S")
                filename = f"OBS_{src}_{timestamp}.png".replace(" ", "_")
                save_path = os.path.join(self.desktop_path, filename).replace("\\", "/")
                req_data = {"sourceName": src, "imageFormat": "png", "imageFilePath": save_path}

        if req_type:
            await self.send_to_obs(req_type, req_data, f"{obs_action}-{context}")

    async def on_pi_request(self, payload, context):
        command = payload.get("command")
        
        if command == "getSceneList":
            await self.send_to_obs("GetSceneList", {}, f"get-scenes-{context}")
        elif command == "getInputList":
            await self.send_to_obs("GetInputList", {}, f"get-inputs-{context}")
        elif command == "getTransitionList":
            await self.send_to_obs("GetSceneTransitionList", {}, f"get-transitions-{context}")
            
        elif command == "getObsSettings":
            settings = {}
            if os.path.exists(self.config_file):
                try:
                    with open(self.config_file, 'r') as f: settings = json.load(f)
                except: pass
            
            await self.websocket.send(json.dumps({
                "event": "sendToPropertyInspector", 
                "context": context, 
                "payload": {"command": "obsSettings", "settings": settings}
            }))
            
        elif command == "setObsSettings":
            try:
                with open(self.config_file, 'w', encoding='utf-8') as f: 
                    json.dump(payload.get("settings", {}), f, indent=4)
                print(f"[{self.PLUGIN_UUID}] OBS settings saved. Reconnecting...")
                self.start_obs_connection()
                await self.websocket.send(json.dumps({"event": "closeSettings", "key": context}))
            except: pass

    def start_obs_connection(self):
        if self.obs_connection_task and not self.obs_connection_task.done():
            self.obs_connection_task.cancel()
        self.obs_connection_task = asyncio.create_task(self.obs_reconnect_loop())

    async def obs_reconnect_loop(self):
        while True:
            settings = {}
            if os.path.exists(self.config_file):
                try:
                    with open(self.config_file, 'r') as f: settings = json.load(f)
                except: pass
                
            password = settings.get("password", "")
            host = settings.get("ip", "localhost")
            port = settings.get("port", 4455)
            obs_url = f"ws://{host}:{port}"

            if not self.is_obs_connected:
                await self.obs_task(obs_url, password)
                
            await asyncio.sleep(3)

    async def send_to_obs(self, req_type, req_data, req_id):
        if self.is_obs_connected:
            await self.obs_request_queue.put({
                "op": 6, 
                "d": {"requestType": req_type, "requestId": req_id, "requestData": req_data}
            })
        else:
            print(f"[{self.PLUGIN_UUID}] Cannot send {req_type}: OBS Disconnected")

    async def obs_task(self, obs_url, password):
        self.is_obs_connected = False
        try:
            print(f"[{self.PLUGIN_UUID}] Connecting to OBS ({obs_url})...")
            async with websockets.connect(obs_url, open_timeout=2, ping_interval=10) as ws:
                hello = json.loads(await ws.recv())
                if hello['d'].get('authentication'):
                    secret = base64.b64encode(hashlib.sha256((password + hello['d']['authentication']['salt']).encode()).digest()).decode()
                    auth = base64.b64encode(hashlib.sha256((secret + hello['d']['authentication']['challenge']).encode()).digest()).decode()
                    await ws.send(json.dumps({"op": 1, "d": {"rpcVersion": 1, "authentication": auth}}))
                    response = json.loads(await ws.recv())
                    if response['op'] != 2: 
                        print(f"[{self.PLUGIN_UUID}] Authentication Failed!")
                        return
                
                print(f"[{self.PLUGIN_UUID}] ✅ SUCCESS: Connected to OBS.")
                self.is_obs_connected = True
                await asyncio.gather(self.obs_consumer(ws), self.obs_producer(ws))
        except Exception as e:
            pass 
        finally:
            self.is_obs_connected = False
            print(f"[{self.PLUGIN_UUID}] OBS Connection Closed.")

    async def obs_consumer(self, ws):
        try:
            async for message in ws:
                data = json.loads(message)
                op = data.get('op')
                d = data.get('d', {})

                if op == 7:
                    req_type = d.get('requestType')
                    req_id = d.get('requestId', '')
                    req_status = d.get('requestStatus')

                    if not req_status.get('result'):
                        print(f"[{self.PLUGIN_UUID}] OBS Request Failed: {req_type} / Error: {req_status}")
                        continue

                    if req_type == 'GetSceneList':
                        if "get-scenes-" in req_id:
                            context = req_id.replace("get-scenes-", "")
                            scenes = d['responseData']['scenes']
                            await self.websocket.send(json.dumps({
                                "event": "sendToPropertyInspector",
                                "context": context, "payload": {"command": "sceneList", "scenes": scenes}
                            }))

                    elif req_type == 'GetInputList':
                        if "get-inputs-" in req_id:
                            context = req_id.replace("get-inputs-", "")
                            inputs = d['responseData']['inputs']
                            await self.websocket.send(json.dumps({
                                "event": "sendToPropertyInspector",
                                "context": context, "payload": {"command": "inputList", "inputs": inputs}
                            }))

                    elif req_type == 'GetSceneTransitionList':
                        if "get-transitions-" in req_id:
                            context = req_id.replace("get-transitions-", "")
                            transitions = d['responseData']['transitions']
                            await self.websocket.send(json.dumps({
                                "event": "sendToPropertyInspector",
                                "context": context, "payload": {"command": "transitionList", "transitions": transitions}
                            }))

        except websockets.ConnectionClosed:
            pass

    async def obs_producer(self, ws):
        while True:
            try:
                request = await self.obs_request_queue.get()
                await ws.send(json.dumps(request))
                self.obs_request_queue.task_done()
            except: break

async def main():
    plugin = OBSPlugin()
    await plugin.connect()

if __name__ == "__main__":
    asyncio.run(main())