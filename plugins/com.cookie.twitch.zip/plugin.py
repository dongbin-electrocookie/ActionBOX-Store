import asyncio
import json
import os
import sys
import traceback
import time
import webbrowser
import tempfile
from urllib.parse import urlsplit
import aiohttp
import websockets

CLIENT_ID = "u1k4hdkyci96y1j9dktkl87q69d3k2"
SCOPES = (
    "channel:manage:broadcast", "channel:edit:commercial",
    "user:write:chat", "moderator:manage:chat_messages", "moderator:manage:chat_settings",
)
AUTH_URL = "https://id.twitch.tv/oauth2/"


class AuthError(Exception):
    """Only stable, non-secret error codes may reach the UI/log."""


class TwitchPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.twitch"
        self.uri = "ws://localhost:8765"
        self.cd_ws = None
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_dir = self._get_user_config_dir()
        os.makedirs(self.config_dir, exist_ok=True)
        self.config_file = os.path.join(self.config_dir, "twitch_config.json")
        self.last_valid_settings = {}
        self.config = {"client_id": CLIENT_ID, "access_token": "", "broadcaster_id": ""}
        self.load_config()
        self._auth_lock = asyncio.Lock()
        self._auth_task = None
        self._maintenance_task = None
        self._owner = None
        self._pending = None
        self._flow = {"status": "idle"}
        self._connection_status = "saved" if self.config.get("access_token") else "idle"
        self._validated_at = 0

    async def _oauth_request(self, endpoint, form=None, token=None):
        headers = {"Authorization": "OAuth " + token} if token else None
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as session:
            async with session.request(
                "GET" if token else "POST", AUTH_URL + endpoint,
                data=form, headers=headers, allow_redirects=False,
            ) as response:
                try:
                    body = await response.json()
                except (ValueError, aiohttp.ContentTypeError):
                    body = {}
                return response.status, body if isinstance(body, dict) else {}

    async def _validate_token(self, token):
        status, body = await self._oauth_request("validate", token=token)
        if status == 401:
            raise AuthError("expired")
        if status != 200:
            raise AuthError("network_error")
        scopes = body.get("scopes", [])
        if isinstance(scopes, str):
            scopes = scopes.split()
        if (body.get("client_id") != CLIENT_ID or
                not str(body.get("user_id", "")).isdigit() or
                not set(SCOPES).issubset(scopes) or int(body.get("expires_in", 0)) <= 0):
            raise AuthError("permissions_error")
        return {
            "client_id": CLIENT_ID, "broadcaster_id": str(body["user_id"]),
            "login": str(body.get("login", "")),
            "expires_at": time.time() + int(body["expires_in"]),
        }

    def _public_settings(self):
        candidate = self._pending or self.config
        return {
            "status": self._flow["status"] if self._flow["status"] != "idle" else self._connection_status,
            "has_token": bool(candidate.get("access_token")),
            "broadcaster_id": candidate.get("broadcaster_id", ""),
            "login": candidate.get("login", ""),
            "user_code": self._flow.get("user_code", ""),
        }

    async def _publish_auth(self, owner):
        if owner != self._owner or not self.cd_ws:
            return
        try:
            await self.cd_ws.send(json.dumps({
                "event": "sendToPropertyInspector", "context": owner[0],
                "payload": {"command": "twitchSettings", "sessionId": owner[1],
                            "settings": self._public_settings()},
            }))
        except Exception:
            pass  # The inspector can reconnect and request the latest state.

    async def _cancel_auth(self):
        task, self._auth_task = self._auth_task, None
        if task and not task.done():
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
        self._pending = None
        self._flow = {"status": "idle"}

    async def _device_login(self, owner):
        try:
            status, device = await self._oauth_request("device", {
                "client_id": CLIENT_ID, "scopes": " ".join(SCOPES),
            })
            if status != 200:
                raise AuthError("network_error" if status >= 500 else "auth_error")
            uri = str(device.get("verification_uri", ""))
            parsed = urlsplit(uri)
            if (parsed.scheme != "https" or parsed.netloc != "www.twitch.tv" or
                    parsed.path.rstrip("/") != "/activate" or not device.get("device_code") or
                    not device.get("user_code")):
                raise AuthError("auth_error")
            expires = int(device.get("expires_in", 0))
            interval = max(1, int(device.get("interval", 5)))
            if expires <= 0 or expires > 86400:
                raise AuthError("auth_error")
            deadline = time.monotonic() + expires
            self._flow = {"status": "waiting", "user_code": str(device["user_code"])}
            await self._publish_auth(owner)
            # The only external UI is the OS default browser, on explicit user request.
            if not await asyncio.to_thread(webbrowser.open, uri, new=2):
                raise AuthError("browser_error")
            while time.monotonic() < deadline:
                await asyncio.sleep(min(interval, max(0, deadline - time.monotonic())))
                if time.monotonic() >= deadline:
                    break
                try:
                    status, result = await self._oauth_request("token", {
                        "client_id": CLIENT_ID, "scopes": " ".join(SCOPES),
                        "device_code": device["device_code"],
                        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                    })
                except (aiohttp.ClientError, asyncio.TimeoutError):
                    interval = max(interval, 5)
                    continue
                if status == 200:
                    token = result.get("access_token")
                    refresh = result.get("refresh_token")
                    if not isinstance(token, str) or not token or not isinstance(refresh, str) or not refresh:
                        raise AuthError("auth_error")
                    metadata = await self._validate_token(token)
                    if owner != self._owner:
                        return
                    if time.monotonic() >= deadline:
                        raise AuthError("expired")
                    self._pending = {**metadata, "access_token": token, "refresh_token": refresh}
                    self._flow = {"status": "approved"}
                    await self._publish_auth(owner)
                    return
                known_errors = {"authorization_pending", "slow_down", "access_denied",
                                "expired_token", "invalid device code"}
                errors = [str(result.get(field, "")).lower() for field in ("error", "message")]
                error = next((value for value in errors if value in known_errors), "auth_error")
                if error == "authorization_pending":
                    continue
                if error == "slow_down" or status == 429:
                    interval += 5
                    continue
                if status >= 500:
                    interval = max(interval, 5)
                    continue
                raise AuthError("denied" if error == "access_denied" else
                                "expired" if error in ("expired_token", "invalid device code") else "auth_error")
            raise AuthError("expired")
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if owner == self._owner:
                code = str(error) if isinstance(error, AuthError) else "network_error"
                self._flow = {"status": code}
                await self._publish_auth(owner)

    async def _ensure_credentials(self):
        """Serialize rotating refresh tokens; validate on startup and hourly."""
        async with self._auth_lock:
            token = self.config.get("access_token")
            if not token or self._connection_status in ("expired", "permissions_error", "save_error"):
                return False
            if self.config.get("client_id") != CLIENT_ID:
                self._connection_status = "permissions_error"
                return False
            try:
                expires = float(self.config.get("expires_at", 0))
                if expires and expires <= time.time() + 60 and self.config.get("refresh_token"):
                    status, result = await self._oauth_request("token", {
                        "client_id": CLIENT_ID, "grant_type": "refresh_token",
                        "refresh_token": self.config["refresh_token"],
                    })
                    if status != 200:
                        raise AuthError("expired" if status in (400, 401) else "network_error")
                    if not result.get("access_token") or not result.get("refresh_token"):
                        raise AuthError("expired")
                    # Save rotation before validation: the previous refresh token is single-use.
                    self.config.update(access_token=result["access_token"],
                                       refresh_token=result["refresh_token"],
                                       expires_at=time.time() + int(result.get("expires_in", 0)))
                    self.save_config()
                    token = self.config["access_token"]
                    self._validated_at = 0
                if not self._validated_at or time.monotonic() - self._validated_at >= 3600:
                    self.config.update(await self._validate_token(token))
                    self.save_config()
                    self._validated_at = time.monotonic()
                self._connection_status = "connected"
                return True
            except Exception as error:
                self._connection_status = str(error) if isinstance(error, AuthError) else "network_error"
                return False

    async def startup(self):
        if self._maintenance_task is None or self._maintenance_task.done():
            self._maintenance_task = asyncio.create_task(self._maintain_auth())

    async def _maintain_auth(self):
        while True:
            await self._ensure_credentials()
            if self._owner:
                await self._publish_auth(self._owner)
            await asyncio.sleep(60)

    async def shutdown(self):
        await self._cancel_auth()
        if self._maintenance_task:
            self._maintenance_task.cancel()
            await asyncio.gather(self._maintenance_task, return_exceptions=True)
        self._maintenance_task = None

    async def _handle_auth_command(self, command, context, payload):
        session = payload.get("sessionId")
        if not context or not isinstance(session, str) or not 1 <= len(session) <= 128:
            return
        owner = (context, session)
        if command == "getTwitchSettings":
            if owner != self._owner:
                await self._cancel_auth()
                self._owner = owner
            await self.startup()
        elif owner != self._owner:
            return  # Late commands from a closed/replaced popup cannot change a new login.
        elif command == "startTwitchAuth":
            if self._auth_task and not self._auth_task.done():
                return
            await self._cancel_auth()
            self._flow = {"status": "starting"}
            self._auth_task = asyncio.create_task(self._device_login(owner))
        elif command == "cancelTwitchAuth":
            await self._cancel_auth()
        elif command == "setTwitchSettings":
            if self._flow["status"] in ("starting", "waiting"):
                return
            async with self._auth_lock:
                if self._pending:
                    try:
                        candidate = {**self._pending, **await self._validate_token(self._pending["access_token"])}
                        self.save_config(candidate)
                        self.config = candidate
                        self._validated_at = time.monotonic()
                        self._connection_status = "connected"
                        self._pending = None
                        self._flow = {"status": "idle"}
                    except Exception as error:
                        self._flow = {"status": str(error) if isinstance(error, AuthError) else "network_error"}
                        await self._publish_auth(owner)
                        return
            # Never take credentials or a client ID from inspector messages.
            await self.cd_ws.send(json.dumps({"event": "closeSettings", "key": context}))
            return
        await self._publish_auth(owner)

    def _get_user_config_dir(self):
        """Return a writable per-user config directory for packaged Windows/macOS/Linux builds."""
        if sys.platform == "darwin":
            base = os.path.expanduser("~/Library/Application Support")
        elif sys.platform.startswith("win"):
            base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Roaming")
        else:
            base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
        return os.path.join(base, "CookieDeck", "com_cookie_twitch")

    def log(self, message: str):
        try:
            print(message, flush=True)
        except Exception:
            pass

    def _default_action(self):
        return "send_chat"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "target_text": "",
            "_lang": "en",
            "sync_title_on_action_change": False
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or self._default_action()
        merged["command"] = action
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("target_text"),
            s.get("title"),
            s.get("sync_title_on_action_change", False),
        ])

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.last_valid_settings[context] = defaults.copy()
            if self.cd_ws:
                await self.cd_ws.send(json.dumps({
                    "event": "setSettings",
                    "context": context,
                    "payload": defaults
                }))
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.last_valid_settings[context] = merged
        return True

    def load_config(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    self.config.update(json.load(f))
            except Exception as e:
                self.log(f"[Twitch] Config load error: {e}")

    def save_config(self, settings=None):
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=self.config_dir,
                                             prefix=".twitch-", delete=False) as f:
                temporary = f.name
                os.chmod(temporary, 0o600)
                json.dump(self.config if settings is None else settings, f, indent=4, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temporary, self.config_file)
        except Exception:
            raise AuthError("save_error") from None
        finally:
            if temporary and os.path.exists(temporary):
                os.unlink(temporary)

    async def twitch_api_request(self, method, endpoint, payload=None):
        if not await self._ensure_credentials():
            self.log("[Twitch] Login required or connection unavailable.")
            return None
        url = f"https://api.twitch.tv/helix/{endpoint}"
        headers = {
            "Client-Id": self.config.get("client_id", ""),
            "Authorization": f"Bearer {self.config.get('access_token', '')}",
            "Content-Type": "application/json"
        }

        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as session:
                async with session.request(method, url, headers=headers, json=payload,
                                           allow_redirects=False) as resp:
                    if resp.status == 401:
                        self._connection_status = "expired"
                        # Do not replay a stream/chat/ad mutation automatically.
                        return None
                    if method == "POST":
                        return await resp.json() if resp.status in (200, 202) else None
                    return resp.status == 204
        except Exception:
            self.log("[Twitch] API request failed.")
            return None

    async def connect_to_cookiedeck(self):
        while True:
            try:
                self.log(f"[Twitch Plugin] Connecting to CookieDeck at {self.uri}...")
                async with websockets.connect(self.uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    self.log("[Twitch Plugin] Registered!")

                    async for message in ws:
                        data = json.loads(message)
                        await self.handle_message(data)

            except Exception as e:
                self.log(f"[Twitch Plugin] Disconnected. Retrying... ({e})")
            finally:
                self.cd_ws = None
            await asyncio.sleep(3)

    async def handle_message(self, data):
        try:
            event = data.get("event")
            context = data.get("context")
            payload = data.get("payload", {}) or {}

            if event == "keyDidAppear":
                raw_settings = payload.get("settings", {}) or {}
                if context:
                    await self._initialize_default_visuals_if_new(context, raw_settings)
                return

            if event == "didReceiveSettings":
                settings = payload.get("settings", payload) or {}
                if context:
                    self.last_valid_settings[context] = self._merge_with_defaults({
                        **self.last_valid_settings.get(context, {}),
                        **settings
                    })
                return

            if event in ["keyDidDisappear", "willDisappear"]:
                if context in self.last_valid_settings:
                    self.last_valid_settings.pop(context, None)
                return

            if event == "keyDown":
                await self.on_key_down(data)
                return

            if event == "sendToPlugin":
                command = payload.get("command")
                if command in ("getTwitchSettings", "getTwitchAuthStatus", "startTwitchAuth",
                               "cancelTwitchAuth", "setTwitchSettings"):
                    await self._handle_auth_command(command, context, payload)

        except Exception as e:
            self.log(f"[Twitch Plugin] Error: {e}")
            self.log(traceback.format_exc())

    async def ensure_settings(self, context, payload):
        incoming_settings = payload.get("settings", {}) if isinstance(payload, dict) else {}
        if incoming_settings:
            cached = self.last_valid_settings.get(context, {})
            self.last_valid_settings[context] = self._merge_with_defaults({**cached, **incoming_settings})
        return self._merge_with_defaults(self.last_valid_settings.get(context, {}))

    async def on_key_down(self, data):
        context = data.get("context") or data.get("action")
        payload = data.get("payload", {}) or {}
        final_settings = await self.ensure_settings(context, payload)

        command = final_settings.get("command")
        target_text = final_settings.get("target_text", "")
        if command not in ("run_commercial_30", "run_commercial_60", "send_chat",
                           "clear_chat", "emote_only_on", "emote_only_off", "change_title"):
            return
        if not await self._ensure_credentials():
            self.log("[Twitch] Login required or connection unavailable.")
            return
        broadcaster_id = self.config.get("broadcaster_id")

        if not command or not broadcaster_id:
            self.log("[Twitch] Action aborted. Check settings or Broadcaster ID.")
            return

        self.log(f"[Twitch Action] Executing: {command}")

        if command == "run_commercial_30":
            await self.twitch_api_request("POST", "channels/commercial", {"broadcaster_id": broadcaster_id, "length": 30})

        elif command == "run_commercial_60":
            await self.twitch_api_request("POST", "channels/commercial", {"broadcaster_id": broadcaster_id, "length": 60})

        elif command == "send_chat":
            if target_text:
                await self.twitch_api_request("POST", "chat/messages", {"broadcaster_id": broadcaster_id, "sender_id": broadcaster_id, "message": target_text})

        elif command == "clear_chat":
            await self.twitch_api_request("DELETE", f"moderation/chat?broadcaster_id={broadcaster_id}&moderator_id={broadcaster_id}")

        elif command == "emote_only_on":
            await self.twitch_api_request("PATCH", f"chat/settings?broadcaster_id={broadcaster_id}&moderator_id={broadcaster_id}", {"emote_mode": True})

        elif command == "emote_only_off":
            await self.twitch_api_request("PATCH", f"chat/settings?broadcaster_id={broadcaster_id}&moderator_id={broadcaster_id}", {"emote_mode": False})

        elif command == "change_title":
            if target_text:
                await self.twitch_api_request("PATCH", f"channels?broadcaster_id={broadcaster_id}", {"title": target_text})

    async def start(self):
        await self.startup()
        try:
            await self.connect_to_cookiedeck()
        finally:
            await self.shutdown()


class Plugin(TwitchPlugin):
    """COMBO-X shared-runtime entry point."""

    def __init__(self, runner, manifest):
        super().__init__()
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.cd_ws = runner

if __name__ == "__main__":
    plugin = TwitchPlugin()
    try:
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(plugin.start())
    except KeyboardInterrupt:
        print("[Twitch Plugin] Shutting down...", flush=True)
