import asyncio
import websockets
import json
import os

class XSplitPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.xsplit"
        self.cd_uri = "ws://localhost:8765"
        self.cd_ws = None

        self.xs_ws = None
        self.is_connected = False
        self.xs_ports = [55511, 55512, 55513]

        self.req_id = 0
        self.pending_requests = {}
        self.xsplit_task = None

        self.last_valid_settings = {}
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.icon_map = {
            "set_scene": "STATE_SET_SCENE",
            "toggle_source": "STATE_TOGGLE_SOURCE",
            "set_preset": "STATE_SET_PRESET",
            "toggle_output": "STATE_TOGGLE_OUTPUT",
            "toggle_record": "STATE_TOGGLE_RECORD",
            "toggle_mic": "STATE_TOGGLE_MIC",
            "toggle_speaker": "STATE_TOGGLE_SPEAKER",
            "screenshot": "STATE_SCREENSHOT",
            "push_to_live": "STATE_PUSH_TO_LIVE",
        }

    def _default_action(self):
        return "toggle_mic"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "xs_action": action,
            "target_scene": "",
            "target_source": "",
            "target_preset": "",
            "target_output": "",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or merged.get("xs_action") or self._default_action()
        merged["command"] = action
        merged["xs_action"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("xs_action"),
            s.get("target_scene"),
            s.get("target_source"),
            s.get("target_preset"),
            s.get("target_output"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        if not self.cd_ws or not context:
            return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.cd_ws.send(json.dumps({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            }))

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.last_valid_settings[context] = defaults.copy()
            if self.cd_ws:
                await self.cd_ws.send(json.dumps({
                    "event": "setSettings",
                    "context": context,
                    "payload": defaults
                }))
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.last_valid_settings[context] = merged
        await self._send_builtin_icon(context, merged["command"])
        return True

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.cd_uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    print(f"[{self.PLUGIN_UUID}] CookieDeck registered.", flush=True)

                    if not self.xsplit_task:
                        self.xsplit_task = asyncio.create_task(self.xsplit_reconnect_loop())

                    await self.listen_cookiedeck()
            except Exception:
                await asyncio.sleep(3)
            finally:
                self.cd_ws = None

    async def listen_cookiedeck(self):
        async for message in self.cd_ws:
            try:
                data = json.loads(message)
                event = data.get("event")
                context = data.get("context")
                payload = data.get("payload", {}) or {}

                if event == "keyDidAppear":
                    raw_settings = payload.get("settings", {}) or {}
                    if context:
                        await self._initialize_default_visuals_if_new(context, raw_settings)

                elif event == "didReceiveSettings":
                    settings = payload.get("settings", payload) or {}
                    if context:
                        cached = self.last_valid_settings.get(context, {})
                        self.last_valid_settings[context] = self._merge_with_defaults({**cached, **settings})

                elif event in ["keyDidDisappear", "willDisappear"]:
                    if context in self.last_valid_settings:
                        self.last_valid_settings.pop(context, None)

                elif event == "sendToPlugin":
                    await self.on_pi_request(payload, context)

                elif event == "keyDown":
                    await self.on_key_down(data)
            except Exception:
                pass

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}

        saved = self.last_valid_settings.get(context, {})
        final_settings = self._merge_with_defaults({**saved, **incoming_settings})
        self.last_valid_settings[context] = final_settings

        action = final_settings.get("command") or final_settings.get("xs_action", self._default_action())

        if action == "set_scene" and final_settings.get("target_scene"):
            await self.send_to_xsplit("setActiveScene", {"id": final_settings.get("target_scene")})

        elif action == "toggle_source" and final_settings.get("target_scene") and final_settings.get("target_source"):
            await self.send_to_xsplit("toggleSourceState", {
                "sceneId": final_settings.get("target_scene"),
                "sourceId": final_settings.get("target_source")
            })

        elif action == "set_preset" and final_settings.get("target_scene") and final_settings.get("target_preset"):
            await self.send_to_xsplit("setActivePreset", {
                "sceneId": final_settings.get("target_scene"),
                "presetId": final_settings.get("target_preset")
            })

        elif action in ["toggle_output", "toggle_record"] and final_settings.get("target_output"):
            await self.send_to_xsplit("toggleOutputState", {"id": final_settings.get("target_output")})

        elif action == "toggle_mic":
            await self.send_to_xsplit("toggleMicrophoneState")

        elif action == "toggle_speaker":
            await self.send_to_xsplit("toggleSpeakerState")

        elif action == "screenshot":
            await self.send_to_xsplit("doScreenshot")

        elif action == "push_to_live":
            await self.send_to_xsplit("doPushToLive")

    async def on_pi_request(self, payload, context):
        command = payload.get("command")

        if command == "apply_builtin_icon":
            action_name = payload.get("action_command")
            if not action_name and context:
                action_name = self.last_valid_settings.get(context, {}).get("command")
            await self._send_builtin_icon(context, action_name or self._default_action())
            return

        if command == "getSceneList":
            res = await self.send_to_xsplit("getAllScenes")
            if res:
                scenes = res.get("payload", {}).get("scenes", [])
                await self.cd_ws.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": {"command": "sceneList", "scenes": scenes}}))
        elif command == "getSourceList":
            scene_id = payload.get("sceneId")
            res = await self.send_to_xsplit("getSceneSources", {"sceneId": scene_id})
            if res:
                sources = res.get("payload", {}).get("sources", [])
                await self.cd_ws.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": {"command": "sourceList", "sources": sources}}))
        elif command == "getPresetList":
            scene_id = payload.get("sceneId")
            res = await self.send_to_xsplit("getScenePresets", {"sceneId": scene_id})
            if res:
                presets = res.get("payload", {}).get("presets", [])
                await self.cd_ws.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": {"command": "presetList", "presets": presets}}))
        elif command == "getOutputList":
            res = await self.send_to_xsplit("getAllOutputs")
            if res:
                outputs = res.get("payload", {}).get("outputs", [])
                await self.cd_ws.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": {"command": "outputList", "outputs": outputs}}))

    async def xsplit_reconnect_loop(self):
        while True:
            for port in self.xs_ports:
                if self.is_connected:
                    break
                try:
                    url = f"ws://127.0.0.1:{port}"
                    async with websockets.connect(url, open_timeout=1) as ws:
                        print(f"[{self.PLUGIN_UUID}] Connected to XSplit ({url})", flush=True)
                        self.xs_ws = ws
                        self.is_connected = True
                        await self.listen_xsplit(ws)
                except Exception:
                    pass
            self.is_connected = False
            await asyncio.sleep(2)

    async def listen_xsplit(self, ws):
        try:
            async for message in ws:
                data = json.loads(message)
                async_id = data.get("asyncId")
                if async_id in self.pending_requests:
                    self.pending_requests[async_id].set_result(data)
        except websockets.ConnectionClosed:
            print(f"[{self.PLUGIN_UUID}] XSplit disconnected.", flush=True)

    async def send_to_xsplit(self, event, payload=None):
        if not self.is_connected or not self.xs_ws:
            return None
        self.req_id += 1
        req_id = self.req_id
        msg = {"asyncId": req_id, "event": event}
        if payload:
            msg["payload"] = payload
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        self.pending_requests[req_id] = future
        try:
            await self.xs_ws.send(json.dumps(msg))
            return await asyncio.wait_for(future, timeout=2.0)
        except Exception:
            return None
        finally:
            if req_id in self.pending_requests:
                del self.pending_requests[req_id]

async def main():
    plugin = XSplitPlugin()
    await plugin.connect()

if __name__ == "__main__":
    asyncio.run(main())
