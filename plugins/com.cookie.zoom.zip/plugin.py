import asyncio
import platform

try:
    import keyboard
    keyboard_available = True
except ImportError:
    print("[Zoom Plugin] 'keyboard' 라이브러리가 없습니다.")
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # Zoom 윈도우 단축키 풀세트 매핑
        self.action_map = {
            "toggle_mic": "alt+a",
            "toggle_cam": "alt+v",
            "toggle_share": "alt+s",
            "toggle_hand": "alt+y",
            "leave_meeting": "alt+q",
            "toggle_chat": "alt+h",
            "toggle_participants": "alt+u",
            "toggle_record": "alt+r",
            "mute_all": "alt+m"
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("zoom_action")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)