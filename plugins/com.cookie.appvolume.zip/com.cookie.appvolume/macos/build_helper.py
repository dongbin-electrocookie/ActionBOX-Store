"""Build the universal helper before packaging this plugin (Xcode required only here)."""
from pathlib import Path
import argparse
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
APP = ROOT / "COMBO-X App Volume.app"


def build(identity="-"):
    with tempfile.TemporaryDirectory(prefix="combo-x-appvolume-") as directory:
        temporary = Path(directory)
        executables = []
        for arch in ("arm64", "x86_64"):
            obj, binary = temporary / f"gain-{arch}.o", temporary / arch
            subprocess.run(["xcrun", "clang", "-O2", "-std=c11", "-arch", arch,
                            "-mmacosx-version-min=14.2", "-c", str(ROOT / "Gain.c"), "-o", str(obj)], check=True)
            subprocess.run(["xcrun", "swiftc", "-swift-version", "5", "-O",
                            "-target", f"{arch}-apple-macosx14.2", str(ROOT / "Mixer.swift"),
                            str(obj), "-o", str(binary)], check=True)
            executables.append(str(binary))
        target = APP / "Contents/MacOS/COMBO-X-App-Volume"
        target.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(["xcrun", "lipo", "-create", *executables, "-output", str(target)], check=True)
        target.chmod(0o755)
        shutil.copy2(ROOT / "Info.plist", APP / "Contents/Info.plist")
        subprocess.run(["codesign", "--force", "--sign", identity,
                        *(["--timestamp", "--options", "runtime"] if identity != "-" else []), str(APP)], check=True)
        subprocess.run(["codesign", "--verify", "--strict", str(APP)], check=True)
        return target


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--sign-identity", default="-")
    print(build(parser.parse_args().sign_identity))
