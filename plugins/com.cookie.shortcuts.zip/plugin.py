import asyncio
import keyboard
import os
import subprocess
import sys
import time
import ctypes
import json

VK_MAP = {
    0x11: 'ctrl', 0x10: 'shift', 0x12: 'alt', 0x5B: 'windows', 0x5C: 'windows',
    0x25: 'left', 0x26: 'up', 0x27: 'right', 0x28: 'down',
    0x0D: 'enter', 0x20: 'space', 0x1B: 'esc', 0x08: 'backspace', 0x09: 'tab',
    0x2E: 'delete', 0x2D: 'insert', 0x24: 'home', 0x23: 'end', 0x21: 'page up', 0x22: 'page down',
    0xBA: ';', 0xBB: '=', 0xBC: ',', 0xBD: '-', 0xBE: '.', 0xBF: '/', 0xC0: '`',
    0xDB: '[', 0xDC: '\\', 0xDD: ']', 0xDE: "'"
}
for i in range(65, 91):
    VK_MAP[i] = chr(i).lower()
for i in range(48, 58):
    VK_MAP[i] = chr(i)
for i in range(112, 124):
    VK_MAP[i] = f"f{i-111}"


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.is_recording = False
        self.app_list_cache = None
        self.context_settings = {}
        self.log_file = os.path.join(self.plugin_dir, "shortcuts_debug_log.txt")

        self.texts = {
            "en": {"timeout": "Scan timed out (PowerShell not responding)", "error": "Error while loading app list"},
            "ko": {"timeout": "스캔 시간 초과 (파워쉘 응답 없음)", "error": "목록을 불러오는 중 오류 발생"},
            "ja": {"timeout": "スキャン時間切れ (PowerShell 応答なし)", "error": "一覧読み込み中にエラーが発生しました"},
            "de": {"timeout": "Scan-Zeitüberschreitung (PowerShell antwortet nicht)", "error": "Fehler beim Laden der App-Liste"},
            "es": {"timeout": "Tiempo de escaneo agotado (PowerShell no responde)", "error": "Error al cargar la lista de apps"},
            "fr": {"timeout": "Délai d’analyse dépassé (PowerShell ne répond pas)", "error": "Erreur lors du chargement de la liste des applications"},
            "ru": {"timeout": "Время сканирования истекло (PowerShell не отвечает)", "error": "Ошибка при загрузке списка приложений"},
            "it": {"timeout": "Timeout scansione (PowerShell non risponde)", "error": "Errore durante il caricamento dell'elenco app"},
            "pt-PT": {"timeout": "Tempo de análise esgotado (PowerShell sem resposta)", "error": "Erro ao carregar a lista de apps"}
        }
        self.action_icon_map = {
            "open": "ACTION_OPEN",
            "hotkey": "ACTION_HOTKEY",
            "typetext": "ACTION_TYPETEXT",
            "runapp": "ACTION_RUNAPP"
        }

    def _log(self, msg):
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(msg + "\n")
        except Exception:
            pass

    def _lang(self, code):
        code = (code or "en").lower()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        code = alias.get(code, code)
        return code if code in self.texts else "en"

    def _get_action_key(self, action_id):
        action_id = (action_id or "").lower()
        if action_id.endswith(".open"):
            return "open"
        if action_id.endswith(".hotkey"):
            return "hotkey"
        if action_id.endswith(".typetext"):
            return "typetext"
        if action_id.endswith(".runapp"):
            return "runapp"
        return "open"

    def _get_icon_path(self, action_id):
        action_key = self._get_action_key(action_id)
        icon_name = self.action_icon_map.get(action_key, "ACTION_OPEN")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id):
        icon_path = self._get_icon_path(action_id)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return

        settings = dict(settings or {})
        action_key = self._get_action_key(action_id)

        if action_key == "open":
            meaningful_keys = ["path", "command", "builtin_icon_name", "default_visuals_initialized", "sync_title_on_path_change", "title"]
            default_settings = {
                "path": "",
                "command": "",
                "_lang": "en",
                "sync_title_on_path_change": False,
                "builtin_icon_name": self.action_icon_map["open"],
                "default_visuals_initialized": True
            }
        elif action_key == "hotkey":
            meaningful_keys = ["hotkey", "hotkey_custom", "command", "builtin_icon_name", "default_visuals_initialized", "sync_title_on_hotkey_change", "title"]
            default_settings = {
                "hotkey": "custom",
                "hotkey_custom": "",
                "command": "",
                "_lang": "en",
                "sync_title_on_hotkey_change": False,
                "builtin_icon_name": self.action_icon_map["hotkey"],
                "default_visuals_initialized": True
            }
        elif action_key == "typetext":
            meaningful_keys = ["text_to_type", "command", "builtin_icon_name", "default_visuals_initialized", "sync_title_on_text_change", "title"]
            default_settings = {
                "text_to_type": "",
                "command": "",
                "_lang": "en",
                "sync_title_on_text_change": False,
                "builtin_icon_name": self.action_icon_map["typetext"],
                "default_visuals_initialized": True
            }
        else:
            meaningful_keys = ["appid", "appname", "command", "builtin_icon_name", "default_visuals_initialized", "sync_title_on_app_change", "title"]
            default_settings = {
                "appid": "",
                "appname": "",
                "command": "",
                "_lang": "en",
                "sync_title_on_app_change": False,
                "builtin_icon_name": self.action_icon_map["runapp"],
                "default_visuals_initialized": True
            }

        meaningful = any(settings.get(k) not in ("", None, False) for k in meaningful_keys)
        if meaningful:
            self.context_settings[context] = settings.copy()
            return

        self.context_settings[context] = default_settings.copy()
        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": default_settings
        })
        await self._send_builtin_icon(context, action_id)

    def _get_installed_apps(self, lang_code="en"):
        lang = self._lang(lang_code)
        if self.app_list_cache is not None:
            return self.app_list_cache
        try:
            ps_script = (
                "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
                "$apps = Get-StartApps | Select-Object Name, AppID; "
                "if ($apps) { ConvertTo-Json $apps -Compress } else { '[]' }"
            )
            cmd = ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps_script]
            creation_flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
            result = subprocess.run(cmd, capture_output=True, text=True, creationflags=creation_flags,
                                    encoding='utf-8', errors='ignore', timeout=15)
            output = result.stdout.strip()
            if not output:
                return []
            apps = json.loads(output)
            if isinstance(apps, list):
                apps = sorted(apps, key=lambda x: x.get('Name', '').lower())
                self.app_list_cache = apps
                return apps
            return []
        except subprocess.TimeoutExpired:
            return [{"Name": self.texts[lang]["timeout"], "AppID": ""}]
        except Exception:
            return [{"Name": self.texts[lang]["error"], "AppID": ""}]

    def _normalize_hotkey(self, hotkey):
        s = (hotkey or "").strip().lower()
        if not s:
            return ""
        parts = [p.strip() for p in s.split("+") if p.strip()]
        alias = {
            "win": "windows",
            "cmd": "windows",
            "control": "ctrl",
            "escape": "esc",
            "return": "enter",
            "pgup": "page up",
            "pgdn": "page down",
            "del": "delete",
            "ins": "insert"
        }
        parts = [alias.get(p, p) for p in parts]
        return "+".join(parts)

    def _send_hotkey_blocking(self, hotkey):
        hk = self._normalize_hotkey(hotkey)
        if not hk:
            self._log("[hotkey] empty")
            return
        self._log(f"[hotkey] send -> {hk}")
        try:
            keyboard.press_and_release(hk)
            return
        except Exception as e:
            self._log(f"[hotkey] press_and_release failed: {e}")

        try:
            keyboard.send(hk)
            return
        except Exception as e:
            self._log(f"[hotkey] send failed: {e}")

        try:
            parts = [p.strip() for p in hk.split("+") if p.strip()]
            for key_name in parts:
                keyboard.press(key_name)
            time.sleep(0.03)
            for key_name in reversed(parts):
                keyboard.release(key_name)
        except Exception as e:
            self._log(f"[hotkey] manual failed: {e}")

    async def handle_message(self, data):
        event = data.get("event")
        action_id = data.get("action", "")
        command = data.get("command") or data.get("payload", {}).get("command")
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                merged = dict(cached)
                merged.update(settings or {})
                self.context_settings[context] = merged
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_id)
            return

        if event == "keyDown":
            await self.on_key_down(data)
        elif command == "get_app_list":
            lang_code = data.get("payload", {}).get("lang", "en")
            apps = await asyncio.to_thread(self._get_installed_apps, lang_code)
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {"command": "app_list_result", "apps": apps}
            })
        elif command == "start_recording":
            if not self.is_recording:
                self.is_recording = True
                async def _record_task():
                    try:
                        hotkey = await asyncio.to_thread(self._poll_hardware_keys)
                        await self.runner.send_message({
                            "event": "sendToPropertyInspector",
                            "context": context,
                            "payload": {"command": "recording_finished", "hotkey": hotkey}
                        })
                    finally:
                        self.is_recording = False
                asyncio.create_task(_record_task())

    def _poll_hardware_keys(self):
        start_time = time.time()
        modifiers_set = {'ctrl', 'shift', 'alt', 'windows'}
        while time.time() - start_time < 10.0:
            pressed_keys = []
            for vk, name in VK_MAP.items():
                if ctypes.windll.user32.GetAsyncKeyState(vk) & 0x8000:
                    if name not in pressed_keys:
                        pressed_keys.append(name)
            non_mods = [k for k in pressed_keys if k not in modifiers_set]
            if non_mods:
                mods_pressed = [m for m in ['ctrl', 'shift', 'alt', 'windows'] if m in pressed_keys]
                return "+".join(mods_pressed + non_mods)
            time.sleep(0.01)
        return ""

    async def on_key_down(self, data):
        action_id = data.get("action")
        context = data.get("context")
        payload_settings = data.get("payload", {}).get("settings")
        incoming_settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = dict(cached)
        settings.update(incoming_settings or {})
        if context:
            self.context_settings[context] = settings

        command = settings.get("command")
        self._log(f"[keyDown] action={action_id} context={context} command={command} settings={settings}")

        if action_id == "com.cookie.shortcuts.open":
            path = command or settings.get("path")
            if path:
                await asyncio.to_thread(self.open_path, path)

        elif action_id == "com.cookie.shortcuts.hotkey":
            hotkey_preset = settings.get("hotkey")
            hotkey_to_send = command or (settings.get("hotkey_custom") if hotkey_preset == 'custom' else hotkey_preset)
            if hotkey_to_send:
                await asyncio.to_thread(self._send_hotkey_blocking, hotkey_to_send)
            else:
                self._log("[hotkey] missing hotkey_to_send")

        elif action_id == "com.cookie.shortcuts.typetext":
            text = command or settings.get("text_to_type")
            if text:
                await asyncio.to_thread(keyboard.write, text, 0.01)

        elif action_id == "com.cookie.shortcuts.runapp":
            app_id = command or settings.get("appid")
            if app_id:
                if "\\" in app_id or ":" in app_id:
                    await asyncio.to_thread(self.open_path, app_id)
                else:
                    os.startfile(f"shell:AppsFolder\\{app_id}")

    def open_path(self, path):
        if sys.platform == "win32":
            os.startfile(path)
        elif sys.platform == "darwin":
            subprocess.run(['open', path])
        else:
            subprocess.run(['xdg-open', path])
