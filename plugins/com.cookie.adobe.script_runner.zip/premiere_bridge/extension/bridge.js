/* Invisible CEP extension. All I/O is local, per-user; no HTTP/debug server. */
(function () {
    'use strict';
    var fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto');
    var cep = window.__adobe_cep__;
    if (!cep || JSON.parse(cep.getHostEnvironment()).appId !== 'PPRO') return;
    var platform = process.platform;
    var application = decodeURI(cep.getSystemPath('hostApplication'));
    application = application.replace(platform === 'win32' ? /^file:\/\/\// : /^file:\/\//, '');
    application = fs.realpathSync(application).replace(/\\/g, '/');
    if (platform === 'win32') application = application.toLowerCase();
    if (platform === 'darwin') application = application.replace(/(\.app)\/.*$/i, '$1');
    application = application.replace(/\/$/, '');
    var dataRoot = platform === 'win32' ? (process.env.APPDATA || path.join(os.homedir(), 'AppData/Roaming')) :
        path.join(os.homedir(), 'Library/Application Support');
    var hostId = crypto.createHash('sha256').update(application, 'utf8').digest('hex');
    var root = path.join(dataRoot, 'COMBO-X/PremiereBridge', hostId);
    var jobs = path.join(root, 'jobs'), instance = crypto.randomBytes(16).toString('hex');
    var busy = false, stopped = false;
    function mkdir(folder) {
        if (fs.existsSync(folder)) return;
        mkdir(path.dirname(folder));
        try { fs.mkdirSync(folder, 448); } catch (error) { if (error.code !== 'EEXIST') throw error; }
    }
    function writeJSON(file, value) {
        var tmp = file + '.' + instance + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(value), {encoding: 'utf8', mode: 384});
        fs.renameSync(tmp, file);
    }
    function heartbeat() {
        writeJSON(path.join(root, 'heartbeat.json'), {protocol: 1, instance: instance,
            application: application, time: Date.now() / 1000});
    }
    function literal(value) {
        return JSON.stringify(value).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
    }
    function result(job, id, status, detail) {
        writeJSON(path.join(job, 'response.json'), {id: id, instance: instance,
            status: status, detail: String(detail || '').slice(0, 400)});
    }
    function execute(job, id) {
        var request = path.join(job, 'request.json'), running = path.join(job, 'running.json');
        var value = JSON.parse(fs.readFileSync(request, 'utf8'));
        // Do not consume another Premiere process/version's request.
        if (value.instance !== instance || value.application !== application) return false;
        fs.renameSync(request, running); // Atomic claim: never replay a running job.
        if (value.protocol !== 1 || value.id !== id || typeof value.deadline !== 'number' ||
                value.deadline < Date.now() / 1000 || fs.existsSync(path.join(job, 'cancelled.json'))) {
            result(job, id, 'expired'); return false;
        }
        if (typeof value.script !== 'string' || !path.isAbsolute(value.script) ||
                !/\.(jsx|jsxbin|js)$/i.test(value.script) || !fs.statSync(value.script).isFile()) {
            result(job, id, 'failed', 'Invalid script file'); return false;
        }
        // Recheck immediately before evalScript; no request is ever retried.
        if (value.deadline < Date.now() / 1000 || fs.existsSync(path.join(job, 'cancelled.json'))) {
            result(job, id, 'expired'); return false;
        }
        var source = '(function(){try{$.evalFile(new File(' + literal(value.script) + '));return ' +
            literal('COMBOX_OK:' + id) + ';}catch(e){return "COMBOX_ERROR:"+encodeURIComponent(String(e));}})()';
        busy = true;
        try {
            cep.evalScript(source, function (reply) {
                try {
                    var ok = reply === 'COMBOX_OK:' + id;
                    var detail = String(reply || 'No ExtendScript response');
                    if (detail.indexOf('COMBOX_ERROR:') === 0) detail = decodeURIComponent(detail.slice(13));
                    result(job, id, ok ? 'executed' : 'failed', ok ? '' : detail);
                } finally { busy = false; }
            });
        } catch (error) {
            busy = false; result(job, id, 'failed', error);
        }
        return true;
    }
    function tick() {
        if (stopped) return;
        try {
            heartbeat();
            if (!busy) {
                var entries = fs.readdirSync(jobs).sort();
                for (var index = 0; index < entries.length; index++) {
                    var id = entries[index];
                    if (!/^[a-f0-9]{32}$/.test(id)) continue;
                    var job = path.join(jobs, id), request = path.join(job, 'request.json');
                    if (fs.lstatSync(job).isSymbolicLink() || !fs.existsSync(request)) continue;
                    try { if (execute(job, id)) break; }
                    catch (error) {
                        // A removed or concurrently claimed request is not an execution failure.
                        if (fs.existsSync(path.join(job, 'running.json'))) result(job, id, 'failed', error);
                    }
                }
            }
        } catch (error) { console.error('[COMBO-X Premiere Bridge]', String(error)); }
        if (!stopped) window.setTimeout(tick, busy ? 500 : 250);
    }
    mkdir(jobs);
    window.addEventListener('unload', function () {
        stopped = true;
        try {
            var file = path.join(root, 'heartbeat.json');
            if (JSON.parse(fs.readFileSync(file, 'utf8')).instance === instance) fs.unlinkSync(file);
        } catch (error) { /* host already closed */ }
    });
    tick();
}());
