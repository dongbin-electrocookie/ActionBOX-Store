import asyncio
import os
import platform

IS_WINDOWS = (platform.system() == "Windows")
win32_available = False

if IS_WINDOWS:
    try:
        import win32com.client
        win32_available = True
    except ImportError:
        print("[Word Plugin Error] 'pywin32' library is missing.")

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.word = None
        self.win32 = win32com.client if win32_available else None
        
        self.action_map = {
            "togglebold": self.apply_bold,
            "togglehighlight": self.toggle_highlight,
            "formatheader": self.format_as_header,
            "addtable": self.add_table,
            "pasteunformatted": self.paste_unformatted,
            "insertpagebreak": self.insert_pagebreak,
            "togglebullet": self.toggle_bullet,
            "saveaspdf": self.save_doc_as_pdf
        }

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not win32_available: return
        selected_action = data.get("payload", {}).get("settings", {}).get("word_action")
        if selected_action and selected_action in self.action_map:
            await asyncio.to_thread(self.action_map[selected_action])

    def _connect_to_word(self):
        if not self.win32: return False
        try:
            self.word = self.win32.GetActiveObject("Word.Application")
            return True
        except Exception:
            return False

    def apply_bold(self):
        if self._connect_to_word():
            try: self.word.Selection.Font.Bold = not self.word.Selection.Font.Bold
            except: pass

    def toggle_highlight(self):
        if self._connect_to_word():
            try:
                # 0 = 없음, 7 = 노란색
                current = self.word.Selection.Range.HighlightColorIndex
                self.word.Selection.Range.HighlightColorIndex = 0 if current == 7 else 7
            except: pass

    def format_as_header(self):
        if self._connect_to_word():
            try: self.word.Selection.Style = -2 # wdStyleHeading1 상수값
            except: pass

    def add_table(self):
        if self._connect_to_word():
            try: self.word.ActiveDocument.Tables.Add(Range=self.word.Selection.Range, NumRows=3, NumColumns=3)
            except: pass

    def paste_unformatted(self):
        if self._connect_to_word():
            try: self.word.Selection.PasteSpecial(DataType=22) # wdFormatPlainText
            except: pass

    def insert_pagebreak(self):
        if self._connect_to_word():
            try: self.word.Selection.InsertBreak(Type=7) # wdPageBreak
            except: pass

    def toggle_bullet(self):
        if self._connect_to_word():
            try: self.word.Selection.Range.ListFormat.ApplyBulletDefault()
            except: pass

    def save_doc_as_pdf(self):
        if self._connect_to_word():
            try:
                doc = self.word.ActiveDocument
                if doc:
                    pdf_path = os.path.splitext(doc.FullName)[0] + ".pdf"
                    doc.SaveAs(pdf_path, FileFormat=17) # wdFormatPDF
                    print(f"[{self.uuid}] PDF 저장 완료: {pdf_path}")
            except: pass