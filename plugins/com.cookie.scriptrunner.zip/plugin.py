import asyncio
import json
import os
import subprocess
import sys
import glob
import re

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

if IS_WINDOWS:
    import winreg

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.scripts_dir = os.path.join(self.plugin_dir, "scripts")
        self.builtin_scripts = self._load_builtin_scripts()
        self.app_paths_file = os.path.join(self.plugin_dir, "app_paths.json")
        self.selected_app_paths = self._load_selected_app_paths()
        self.last_valid_settings = {}

        self.action_to_exe = {
            "photoshop": "Photoshop.exe",
            "illustrator": "Illustrator.exe",
            "aftereffects": "AfterFX.exe",
            "premiere": "Adobe Premiere Pro.exe",
            "indesign": "InDesign.exe",
        }

        self.action_to_macos_app_patterns = {
            "photoshop": ["/Applications/Adobe Photoshop*/Adobe Photoshop*.app"],
            "illustrator": ["/Applications/Adobe Illustrator*/Adobe Illustrator*.app"],
            "aftereffects": ["/Applications/Adobe After Effects*/Adobe After Effects*.app"],
            "premiere": ["/Applications/Adobe Premiere Pro*/Adobe Premiere Pro*.app"],
            "indesign": ["/Applications/Adobe InDesign*/Adobe InDesign*.app"],
        }

        self.action_to_windows_patterns = {
            "photoshop": [r"C:\Program Files\Adobe\Adobe Photoshop *\Photoshop.exe"],
            "illustrator": [r"C:\Program Files\Adobe\Adobe Illustrator *\Support Files\Contents\Windows\Illustrator.exe"],
            "aftereffects": [r"C:\Program Files\Adobe\Adobe After Effects *\Support Files\AfterFX.exe"],
            "premiere": [r"C:\Program Files\Adobe\Adobe Premiere Pro *\Adobe Premiere Pro.exe"],
            "indesign": [r"C:\Program Files\Adobe\Adobe InDesign *\InDesign.exe"],
        }

        self.action_to_icon = {
            "photoshop": "APP_PHOTOSHOP",
            "illustrator": "APP_ILLUSTRATOR",
            "aftereffects": "APP_AFTEREFFECTS",
            "premiere": "APP_PREMIERE",
            "indesign": "APP_INDESIGN",
        }

    def _load_builtin_scripts(self):
        catalog_path = os.path.join(self.scripts_dir, "catalog.json")
        try:
            with open(catalog_path, "r", encoding="utf-8") as catalog_file:
                entries = json.load(catalog_file)
            return {
                entry["id"]: entry
                for entry in entries
                if isinstance(entry, dict) and entry.get("id") and entry.get("file")
            }
        except Exception as error:
            print(f"[{self.uuid}] Failed to load built-in script catalog: {error}")
            return {}

    def _load_selected_app_paths(self):
        try:
            with open(self.app_paths_file, "r", encoding="utf-8") as settings_file:
                values = json.load(settings_file)
            return values if isinstance(values, dict) else {}
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return {}

    def _save_selected_app_paths(self):
        temp_path = self.app_paths_file + ".tmp"
        with open(temp_path, "w", encoding="utf-8") as settings_file:
            json.dump(self.selected_app_paths, settings_file, ensure_ascii=False, indent=2)
        os.replace(temp_path, self.app_paths_file)

    def _get_action_key(self, action_id: str) -> str:
        action_id = (action_id or "").lower()
        for key in self.action_to_exe.keys():
            if key in action_id:
                return key
        return "photoshop"

    def _get_icon_path(self, action_id: str) -> str:
        action_key = self._get_action_key(action_id)
        icon_name = self.action_to_icon.get(action_key, "APP_PHOTOSHOP")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id):
        icon_path = self._get_icon_path(action_id)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "exe_path", "script_path", "command", "script_source",
            "builtin_script_id", "builtin_icon_name",
            "default_visuals_initialized", "sync_title_on_script_change", "title"
        ])
        if meaningful:
            return

        action_key = self._get_action_key(action_id)
        new_settings = {
            "exe_path": "",
            "script_path": "",
            "command": "",
            "script_source": "builtin",
            "builtin_script_id": "",
            "action_id": action_id or "",
            "_lang": "en",
            "sync_title_on_script_change": False,
            "builtin_icon_name": self.action_to_icon.get(action_key, "APP_PHOTOSHOP"),
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        # Initial placement: icon only, never overwrite title
        await self._send_builtin_icon(context, action_id)

    async def handle_message(self, data):
        event = data.get("event")
        action_id = data.get("action", "")
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if event == "keyDown":
            await self.on_key_down(data)
        elif event == "sendToPlugin":
            await self.on_pi_request(data)

    async def on_key_down(self, data):
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}

        if incoming_settings:
            filtered = {k: v for k, v in incoming_settings.items() if v not in ("", None)}
            self.last_valid_settings.update(filtered)

        final_settings = {**self.last_valid_settings, **incoming_settings}

        action_key = self._get_action_key(data.get("action", "") or final_settings.get("action_id", ""))
        exe_path = self._resolve_exe_path(action_key, final_settings.get("exe_path"))
        script_path = self._resolve_script_path(final_settings, action_key)

        if not exe_path or not os.path.exists(exe_path):
            print(f"[{self.uuid}] Invalid executable path: '{exe_path}'")
            return

        if not script_path or not os.path.exists(script_path):
            print(f"[{self.uuid}] Invalid script path: '{script_path}'")
            return

        print(f"[{self.uuid}] Running: {os.path.basename(exe_path)} + {os.path.basename(script_path)}")
        await asyncio.to_thread(self._run_script_sync, exe_path, script_path)

    def _resolve_exe_path(self, action_key, legacy_path=None):
        selected_path = self.selected_app_paths.get(action_key)
        if selected_path and os.path.exists(selected_path):
            return selected_path
        if legacy_path and os.path.exists(legacy_path):
            return legacy_path
        candidates = self._find_adobe_candidates(action_key)
        return candidates[0]["path"] if candidates else None

    def _resolve_script_path(self, settings, action_key):
        source = settings.get("script_source")
        command = settings.get("command") or ""
        builtin_id = settings.get("builtin_script_id") or ""

        if command.startswith("builtin:"):
            source = "builtin"
            builtin_id = command[len("builtin:"):]

        if source == "builtin" or builtin_id:
            entry = self.builtin_scripts.get(builtin_id)
            if not entry or entry.get("app") != action_key:
                return None

            scripts_root = os.path.realpath(self.scripts_dir)
            script_path = os.path.realpath(os.path.join(scripts_root, entry["file"]))
            if os.path.commonpath([scripts_root, script_path]) != scripts_root:
                return None
            return script_path

        return command or settings.get("script_path")

    async def on_pi_request(self, data):
        context = data.get("context")
        action_id = data.get("action", "")
        payload = data.get("payload", {}) or {}
        command = payload.get("command")

        if command in ("getDefaultPath", "getAppCandidates"):
            action_id_for_lookup = payload.get("actionId") or action_id or ""
            action_key = self._get_action_key(action_id_for_lookup)
            candidates = self._find_adobe_candidates(action_key)
            selected_path = self.selected_app_paths.get(action_key, "")
            if selected_path and not os.path.exists(selected_path):
                selected_path = ""
                self.selected_app_paths.pop(action_key, None)
            if not selected_path and candidates:
                selected_path = candidates[0]["path"]
                self.selected_app_paths[action_key] = selected_path
                self._save_selected_app_paths()
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {
                    "command": "appCandidatesFound",
                    "app": action_key,
                    "candidates": candidates,
                    "selectedPath": selected_path
                }
            })

        elif command == "setAppPath":
            action_key = self._get_action_key(payload.get("actionId") or action_id or "")
            selected_path = payload.get("path") or ""
            if selected_path and os.path.exists(selected_path):
                self.selected_app_paths[action_key] = os.path.normpath(selected_path)
                self._save_selected_app_paths()
            elif not selected_path:
                self.selected_app_paths.pop(action_key, None)
                self._save_selected_app_paths()

        elif command == "apply_builtin_icon":
            action_id_for_icon = payload.get("actionId") or action_id or ""
            await self._send_builtin_icon(context, action_id_for_icon)

    def _run_script_sync(self, exe_path, script_path):
        if IS_MACOS:
            # Adobe macOS apps are usually .app bundles, not executable files.
            # The most compatible lightweight launch method is to ask LaunchServices
            # to open the script file with the selected Adobe app.
            try:
                if exe_path.lower().endswith(".app") or os.path.isdir(exe_path):
                    return subprocess.run(["open", "-a", exe_path, script_path], check=False)
                return subprocess.run([exe_path, script_path], check=False)
            except Exception as e:
                print(f"[{self.uuid}] macOS open failed: {e}")
                return None

        creationflags = subprocess.CREATE_NO_WINDOW if IS_WINDOWS else 0
        return subprocess.run([exe_path, script_path], creationflags=creationflags, check=False)

    def _find_adobe_path(self, exe_name):
        action_key = next((key for key, value in self.action_to_exe.items() if value == exe_name), None)
        candidates = self._find_adobe_candidates(action_key) if action_key else []
        return candidates[0]["path"] if candidates else None

    def _find_adobe_candidates(self, action_key):
        candidates = []

        if IS_MACOS:
            for pattern in self.action_to_macos_app_patterns.get(action_key, []):
                for path in glob.glob(pattern):
                    if os.path.exists(path):
                        candidates.append(path)

        elif IS_WINDOWS:
            for pattern in self.action_to_windows_patterns.get(action_key, []):
                candidates.extend(path for path in glob.glob(pattern) if os.path.isfile(path))

            exe_name = self.action_to_exe.get(action_key)
            app_paths_key = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"
            if exe_name:
                for hkey in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
                    try:
                        key = winreg.OpenKey(hkey, os.path.join(app_paths_key, exe_name))
                        path, _ = winreg.QueryValueEx(key, None)
                        winreg.CloseKey(key)
                        if os.path.isfile(path):
                            candidates.append(path)
                    except FileNotFoundError:
                        continue

        unique_paths = list(dict.fromkeys(os.path.normpath(path) for path in candidates))
        unique_paths.sort(key=self._candidate_sort_key, reverse=True)
        return [{"label": self._candidate_label(action_key, path), "path": path} for path in unique_paths]

    def _candidate_sort_key(self, path):
        numbers = re.findall(r"\d+", path)
        return tuple(int(number) for number in numbers) if numbers else (0,)

    def _candidate_label(self, action_key, path):
        app_names = {
            "photoshop": "Photoshop",
            "illustrator": "Illustrator",
            "aftereffects": "After Effects",
            "premiere": "Premiere Pro",
            "indesign": "InDesign",
        }
        version_match = re.findall(r"20\d{2}", path)
        version = version_match[-1] if version_match else ""
        return f"{app_names.get(action_key, action_key.title())} {version}".strip()
