import asyncio
import pyautogui

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        cmd_type = settings.get("cmd_type")
        key_val = settings.get("key_val", "")

        if not key_val: return

        try:
            # 🚀 넘패드(Numpad) 특수키 보정 로직
            if "num" in key_val:
                key_val = key_val.replace("num", "numpad") # pyautogui 규격
            if key_val == "decimal":
                key_val = "numpaddecimal" # 넘패드 '.' 키

            if cmd_type == "single":
                pyautogui.press(key_val)
            elif cmd_type == "combo":
                keys = key_val.split('+')
                pyautogui.hotkey(*keys)
        except Exception as e:
            print(f"[Blender Error] {e}")