import asyncio
try:
    import keyboard
except ImportError:
    print("[Error] keyboard 라이브러리가 없습니다. pip install keyboard")
    keyboard = None

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 한컴오피스 전용 단축키 맵
        self.action_map = {
            # 글자/문단
            "font_shape": "alt+l",
            "paragraph_shape": "alt+t",
            "font_size_up": "ctrl+]",
            "font_size_down": "ctrl+[",
            "widen_tracking": "alt+shift+w",
            "narrow_tracking": "alt+shift+n",
            # 표
            "create_table": "ctrl+n,t",
            "cell_properties": "enter",
            "add_row_col": "alt+insert",
            "delete_row_col": "alt+delete",
            "merge_cells": "m",
            "split_cells": "s",
            "set_height_equal": "h",
            "set_width_equal": "w",
            # 편집/도구
            "find_replace_pro": "ctrl+q,a",
            "spell_check": "f8",
            "hanja_convert": "f9",
            "special_chars": "ctrl+f10",
            "copy_format": "alt+c",
            "paste_format": "alt+v",
            # 보기
            "toggle_page_layout": "ctrl+g,g",
            "toggle_control_codes": "ctrl+g,c",
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard: return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("command")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            # 백그라운드 스레드에서 단축키 실행 (UI 멈춤 방지)
            await asyncio.to_thread(keyboard.send, hotkey)