import asyncio
import json
import sys
import os
import platform

# --- 라이브러리 임포트 및 OS 확인 ---
IS_WINDOWS = (platform.system() == "Windows")
win32_available = False

if IS_WINDOWS:
    try:
        import win32com.client
        win32_available = True
    except ImportError:
        print("[Excel Plugin Error] 'pywin32' library is missing.")
        # sys.exit(1) <--- 절대 금지 (러너 전체가 죽음)

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.excel = None
        self.win32 = win32com.client if win32_available else None
        
        # --- 액션 매핑 (기존과 동일) ---
        self.action_map = {
            "togglebold": self.apply_bold,
            "applyborder": self.apply_border,
            "formatheader": self.format_as_header,
            "formatnumber": self.format_as_number,
            "pastevalues": self.paste_as_values,
            "autofitcolumns": self.autofit_columns,
            "togglefilter": self.toggle_filter,
            "freezepanes": self.freeze_panes,
            "unfreezepanes": self.unfreeze_panes,
            "addsheet": self.add_new_sheet,
            "saveaspdf": self.save_sheet_as_pdf,
            "reportformat": self.apply_report_format,
        }

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not win32_available:
            print(f"[{self.uuid}] Plugin disabled: pywin32 not installed or not Windows.")
            return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("excel_action")

        if selected_action:
            action_func = self.action_map.get(selected_action)
            if action_func:
                # print(f"[{self.uuid}] Executing: {selected_action}")
                # COM 객체 조작은 Blocking이므로 반드시 스레드로 분리 (유지)
                await asyncio.to_thread(action_func)
            else:
                print(f"[{self.uuid}] Unknown action: {selected_action}")

    # --- Excel 제어 로직 (기존 코드 100% 동일) ---
    def _connect_to_excel(self):
        if not self.win32: return False
        try:
            # 현재 실행 중인 엑셀 인스턴스를 잡습니다.
            self.excel = self.win32.GetActiveObject("Excel.Application")
            return True
        except Exception:
            print(f"[{self.uuid}] Could not connect to Excel. Is it running?")
            return False

    def apply_bold(self):
        if self._connect_to_excel(): self.excel.Selection.Font.Bold = not self.excel.Selection.Font.Bold
    
    def apply_border(self):
        if self._connect_to_excel():
            # xlEdgeLeft(7) ~ xlInsideHorizontal(12)
            for i in range(7, 13): 
                try: self.excel.Selection.Borders(i).LineStyle = 1
                except: pass

    def format_as_header(self):
        if self._connect_to_excel():
            s = self.excel.Selection
            s.Font.Bold = True
            s.Interior.ColorIndex = 15 # 회색
            s.HorizontalAlignment = -4108 # Center

    def format_as_number(self):
        if self._connect_to_excel(): self.excel.Selection.NumberFormat = "#,##0"

    def paste_as_values(self):
        if self._connect_to_excel(): self.excel.Selection.PasteSpecial(Paste=-4163) # xlPasteValues

    def autofit_columns(self):
        if self._connect_to_excel(): self.excel.Selection.Columns.AutoFit()

    def toggle_filter(self):
        if self._connect_to_excel(): self.excel.Selection.AutoFilter()

    def freeze_panes(self):
        if self._connect_to_excel(): self.excel.ActiveWindow.FreezePanes = True

    def unfreeze_panes(self):
        if self._connect_to_excel(): self.excel.ActiveWindow.FreezePanes = False

    def add_new_sheet(self):
        if self._connect_to_excel(): self.excel.Worksheets.Add()

    def save_sheet_as_pdf(self):
        if self._connect_to_excel():
            try:
                wb = self.excel.ActiveWorkbook
                sheet = self.excel.ActiveSheet
                if wb and sheet:
                    base_name = os.path.splitext(wb.FullName)[0]
                    pdf_path = f"{base_name}-{sheet.Name}.pdf"
                    sheet.ExportAsFixedFormat(0, pdf_path) # 0=xlTypePDF
                    print(f"[{self.uuid}] Saved as PDF: {pdf_path}")
            except Exception as e:
                print(f"[{self.uuid}] Failed to save as PDF. Error: {e}")

    def apply_report_format(self):
        if self._connect_to_excel():
            self.format_as_header()
            self.apply_border()