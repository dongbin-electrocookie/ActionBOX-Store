import asyncio
import base64
import io
import ctypes
from PIL import Image
import pyautogui

# 윈도우 그래픽관련 API 설정
user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    def get_pixel_color(self, x, y):
        """윈도우 API를 사용하여 특정 좌표의 색상을 정확하게 가져옵니다."""
        # 1. 화면 전체의 Device Context(DC)를 가져옴
        hdc = user32.GetDC(0)
        # 2. 특정 좌표의 픽셀값 추출 (COLORREF 형식: 0xBBGGRR)
        pixel = gdi32.GetPixel(hdc, x, y)
        # 3. 사용한 DC 해제 (메모리 누수 방지)
        user32.ReleaseDC(0, hdc)
        
        # COLORREF에서 R, G, B 분리
        r = pixel & 0xFF
        g = (pixel >> 8) & 0xFF
        b = (pixel >> 16) & 0xFF
        return r, g, b

    async def on_key_down(self, data):
        context = data.get("context")
        settings = data.get("payload", {}).get("settings", {})
        
        # 현재 마우스 위치 (DPI 스케일링이 적용된 좌표)
        x, y = pyautogui.position()
        
        try:
            # 윈도우 API 방식으로 색상 추출
            r, g, b = self.get_pixel_color(x, y)
            hex_val = f"#{r:02x}{g:02x}{b:02x}".upper()
            
            # --- 이후 로직은 기존과 동일 ---

            # 1. 버튼 제목 업데이트 (HEX 코드)
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": hex_val}
            })

            # 2. 버튼 아이콘 업데이트 (단색 이미지)
            color_img = Image.new("RGB", (128, 128), (r, g, b))
            buffer = io.BytesIO()
            color_img.save(buffer, format="PNG")
            b64_str = base64.b64encode(buffer.getvalue()).decode()

            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": {"image": f"data:image/png;base64,{b64_str}"}
            })

            # 3. LED 연동 (0xC0)
            if settings.get("sync_led", False):
                await self.runner.send_message({
                    "event": "sendToPlugin",
                    "context": context,
                    "payload": {
                        "command": "direct_serial",
                        "serial_cmd": 0xC0,
                        "serial_data": [255, r, g, b]
                    }
                })
            
            print(f"[ColorPicker] API Picked: {hex_val} at ({x}, {y})")

        except Exception as e:
            print(f"[ColorPicker Error] {e}")