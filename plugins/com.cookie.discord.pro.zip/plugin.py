import asyncio
import json
import struct
import uuid
import platform
import os

IS_WINDOWS = (platform.system() == "Windows")

class DiscordIPC:
    """디스코드 로컬 백도어(IPC)에 직접 연결하는 통신 클래스"""
    def __init__(self, client_id):
        self.client_id = client_id
        self.pipe = None
        self.connected = False

    def connect(self):
        if not IS_WINDOWS: return False
        try:
            # 윈도우 전용 디스코드 파이프라인
            self.pipe = open(r'\\.\pipe\discord-ipc-0', 'w+b')
            self.handshake()
            self.connected = True
            return True
        except Exception as e:
            print(f"[Discord Pro] IPC 연결 실패 (디스코드가 켜져있나요?): {e}")
            self.connected = False
            return False

    def send(self, op, payload):
        if not self.pipe: return
        payload_json = json.dumps(payload).encode('utf-8')
        header = struct.pack('<II', op, len(payload_json))
        try:
            self.pipe.write(header + payload_json)
            self.pipe.flush()
        except:
            self.connected = False

    def recv(self):
        if not self.pipe: return None, None
        try:
            header = self.pipe.read(8)
            if not header: return None, None
            op, length = struct.unpack('<II', header)
            payload = self.pipe.read(length)
            return op, json.loads(payload.decode('utf-8'))
        except:
            self.connected = False
            return None, None

    def handshake(self):
        # 0 = Handshake
        self.send(0, {'v': 1, 'client_id': self.client_id})
        self.recv()


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.ipc = None
        self.current_client_id = ""

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        client_id = settings.get("client_id", "").strip()
        action = settings.get("discord_action", "mute_on")

        if not client_id:
            print(f"[{self.uuid}] Client ID가 입력되지 않았습니다!")
            return

        # IPC가 끊겨있거나 Client ID가 바뀌었으면 재연결
        if not self.ipc or not self.ipc.connected or self.current_client_id != client_id:
            self.ipc = DiscordIPC(client_id)
            success = await asyncio.to_thread(self.ipc.connect)
            if success:
                self.current_client_id = client_id
            else:
                return

        # 동작 명령 구성
        is_mute = (action == "mute_on")
        is_deafen = (action == "deafen_on")
        
        args = {}
        if "mute" in action: args["mute"] = is_mute
        if "deafen" in action: args["deafen"] = is_deafen

        payload = {
            "cmd": "SET_VOICE_SETTINGS",
            "args": args,
            "nonce": str(uuid.uuid4())
        }

        # 1 = Frame (명령 전송)
        await asyncio.to_thread(self.ipc.send, 1, payload)
        print(f"[{self.uuid}] 디스코드 IPC로 명령 전송 완료: {action}")