import asyncio
import os
import sys
import time

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False


IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        self.windows_action_map = {
            "togglebold": ["ctrl+b"],
            "toggleitalic": ["ctrl+i"],
            "toggleunderline": ["ctrl+u"],
            "togglehighlight": ["alt+h", "i"],
            "formatheader": ["ctrl+alt+1"],
            "formatheading2": ["ctrl+alt+2"],
            "formatheading3": ["ctrl+alt+3"],
            "formatnormal": ["ctrl+shift+n"],
            "togglebullet": ["ctrl+shift+l"],
            "alignleft": ["ctrl+l"],
            "aligncenter": ["ctrl+e"],
            "alignright": ["ctrl+r"],
            "justify": ["ctrl+j"],
            "increaseindent": ["ctrl+m"],
            "decreaseindent": ["ctrl+shift+m"],
            "increasefontsize": ["ctrl+shift+>"],
            "decreasefontsize": ["ctrl+shift+<"],
            "clearformatting": ["ctrl+space"],
            "superscript": ["ctrl+shift+="],
            "subscript": ["ctrl+shift+-"],
            "linespacing1": ["ctrl+1"],
            "linespacing15": ["ctrl+5"],
            "linespacing2": ["ctrl+2"],
            "copyformat": ["ctrl+alt+c"],
            "pasteformat": ["ctrl+alt+v"],
            "pasteunformatted": ["ctrl+shift+v"],
            "insertpagebreak": ["ctrl+enter"],
            "addtable": ["alt+n", "t", "i", "3", "tab", "3", "enter"],
            "inserthyperlink": ["ctrl+k"],
            "newcomment": ["ctrl+alt+m"],
            "find": ["ctrl+f"],
            "replace": ["ctrl+h"],
            "selectall": ["ctrl+a"],
            "undo": ["ctrl+z"],
            "redo": ["ctrl+y"],
            "save": ["ctrl+s"],
            "print": ["ctrl+p"],
            "saveaspdf": ["ctrl+p"],
        }

        self.macos_action_map = {
            "togglebold": ["command+b"],
            "toggleitalic": ["command+i"],
            "toggleunderline": ["command+u"],
            "togglehighlight": ["control+option+h"],
            "formatheader": ["command+option+1"],
            "formatheading2": ["command+option+2"],
            "formatheading3": ["command+option+3"],
            "formatnormal": ["command+shift+n"],
            "togglebullet": ["command+shift+l"],
            "alignleft": ["command+l"],
            "aligncenter": ["command+e"],
            "alignright": ["command+r"],
            "justify": ["command+j"],
            "increaseindent": ["control+shift+m"],
            "decreaseindent": ["command+shift+m"],
            "increasefontsize": ["command+shift+>"],
            "decreasefontsize": ["command+shift+<"],
            "clearformatting": ["control+space"],
            "superscript": ["command+shift+="],
            "subscript": ["command+shift+-"],
            "linespacing1": ["command+1"],
            "linespacing15": ["command+5"],
            "linespacing2": ["command+2"],
            "copyformat": ["command+option+c"],
            "pasteformat": ["command+option+v"],
            "pasteunformatted": ["command+shift+v"],
            "insertpagebreak": ["command+enter"],
            "addtable": ["control+option+n", "t", "i"],
            "inserthyperlink": ["command+k"],
            "newcomment": ["command+option+a"],
            "find": ["command+f"],
            "replace": ["control+h"],
            "selectall": ["command+a"],
            "undo": ["command+z"],
            "redo": ["command+y"],
            "save": ["command+s"],
            "print": ["command+p"],
            "saveaspdf": ["command+p"],
        }
        self.action_map = self.macos_action_map if IS_MACOS else self.windows_action_map

        self.icon_map = {
            "togglebold": "STATE_TOGGLE_BOLD",
            "toggleitalic": "STATE_TOGGLE_BOLD",
            "toggleunderline": "STATE_TOGGLE_BOLD",
            "togglehighlight": "STATE_TOGGLE_HIGHLIGHT",
            "formatheader": "STATE_FORMAT_HEADER",
            "formatheading2": "STATE_FORMAT_HEADER",
            "formatheading3": "STATE_FORMAT_HEADER",
            "formatnormal": "STATE_FORMAT_HEADER",
            "togglebullet": "STATE_TOGGLE_BULLET",
            "alignleft": "STATE_FORMAT_HEADER",
            "aligncenter": "STATE_FORMAT_HEADER",
            "alignright": "STATE_FORMAT_HEADER",
            "justify": "STATE_FORMAT_HEADER",
            "increaseindent": "STATE_FORMAT_HEADER",
            "decreaseindent": "STATE_FORMAT_HEADER",
            "increasefontsize": "STATE_TOGGLE_BOLD",
            "decreasefontsize": "STATE_TOGGLE_BOLD",
            "clearformatting": "STATE_PASTE_UNFORMATTED",
            "superscript": "STATE_TOGGLE_BOLD",
            "subscript": "STATE_TOGGLE_BOLD",
            "linespacing1": "STATE_FORMAT_HEADER",
            "linespacing15": "STATE_FORMAT_HEADER",
            "linespacing2": "STATE_FORMAT_HEADER",
            "copyformat": "STATE_PASTE_UNFORMATTED",
            "pasteformat": "STATE_PASTE_UNFORMATTED",
            "pasteunformatted": "STATE_PASTE_UNFORMATTED",
            "insertpagebreak": "STATE_INSERT_PAGEBREAK",
            "addtable": "STATE_ADD_TABLE",
            "inserthyperlink": "STATE_ADD_TABLE",
            "newcomment": "STATE_ADD_TABLE",
            "find": "STATE_SAVE_AS_PDF",
            "replace": "STATE_SAVE_AS_PDF",
            "selectall": "STATE_TOGGLE_BOLD",
            "undo": "STATE_SAVE_AS_PDF",
            "redo": "STATE_SAVE_AS_PDF",
            "save": "STATE_SAVE_AS_PDF",
            "print": "STATE_SAVE_AS_PDF",
            "saveaspdf": "STATE_SAVE_AS_PDF",
        }

    def _default_settings(self):
        return {
            "word_action": "togglebold",
            "command": "togglebold",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map["togglebold"],
            "default_visuals_initialized": True,
        }

    def _merge_settings(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        return merged

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "togglebold", "STATE_TOGGLE_BOLD")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if context and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path},
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return
        meaningful = any((settings or {}).get(k) not in ("", None, False) for k in [
            "command", "word_action", "builtin_icon_name",
            "default_visuals_initialized", "sync_title_on_action_change", "title",
        ])
        if meaningful:
            self.context_settings[context] = self._merge_settings(settings)
            return

        defaults = self._default_settings()
        self.context_settings[context] = defaults.copy()
        await self.runner.send_message({
            "event": "setSettings", "context": context, "payload": defaults,
        })
        await self._send_builtin_icon(context, defaults["command"])

    def _normalize_key(self, key_name):
        key = str(key_name).strip().lower()
        aliases = {
            "control": "ctrl", "option": "option" if IS_MACOS else "alt",
            "command": "command" if IS_MACOS else "win", "return": "enter",
            "escape": "esc",
        }
        return aliases.get(key, key)

    def _send_hotkey_sequence(self, sequence):
        for chord in sequence:
            if IS_WINDOWS and keyboard_available:
                keyboard.send(chord)
            elif pyautogui_available:
                parts = [self._normalize_key(part) for part in chord.split("+") if part.strip()]
                if len(parts) == 1:
                    pyautogui.press(parts[0])
                elif parts:
                    pyautogui.hotkey(*parts)
            else:
                print(f"[{self.uuid}] No keyboard injection library is available.")
                return
            time.sleep(0.06)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}
        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ("willAppear", "keyDidAppear"):
            await self._initialize_default_visuals_if_new(context, settings)
            return
        if event == "didReceiveSettings" and context:
            cached = self.context_settings.get(context, {})
            self.context_settings[context] = self._merge_settings({**cached, **settings})
            return
        if event in ("keyDidDisappear", "willDisappear"):
            self.context_settings.pop(context, None)
            return
        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            action = action_command or settings.get("command") or settings.get("word_action") or cached.get("command") or "togglebold"
            await self._send_builtin_icon(context, action)
            return
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = self._merge_settings({**cached, **incoming})
        if context:
            self.context_settings[context] = settings
        selected_action = settings.get("command") or settings.get("word_action") or "togglebold"
        sequence = self.action_map.get(selected_action)
        if sequence:
            await asyncio.to_thread(self._send_hotkey_sequence, sequence)
        else:
            print(f"[{self.uuid}] Unknown action: {selected_action}")
