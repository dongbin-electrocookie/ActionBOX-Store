#target photoshop

if (app.documents.length === 0) {
  alert("❌ 열린 문서가 없습니다.");
} else {
  try {
    var originalDoc = app.activeDocument;
    var selectedLayer = originalDoc.activeLayer;

    // 새 문서 만들기
    var newDoc = app.documents.add(
      originalDoc.width,
      originalDoc.height,
      originalDoc.resolution,
      "선택 레이어 복사됨",
      NewDocumentMode.RGB,
      DocumentFill.TRANSPARENT
    );

    // 원래 문서로 다시 포커스
    app.activeDocument = originalDoc;

    // 복제 실행
    selectedLayer.duplicate(newDoc, ElementPlacement.PLACEATBEGINNING);

    // 복제된 문서로 포커스 이동
    app.activeDocument = newDoc;

    // ✅ Trim 실행: 투명 픽셀 기준 여백 제거
    newDoc.trim(TrimType.TRANSPARENT, true, true, true, true);

    alert("✅ 선택한 레이어가 새 문서로 복사되고, 여백이 잘렸습니다.");
  } catch (e) {
    alert("⚠ 오류 발생: " + e.message);
  }
}
