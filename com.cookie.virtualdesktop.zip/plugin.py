import asyncio
import ctypes
import sys
import time
import os
import subprocess

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

VK_CONTROL = 0x11
VK_LWIN = 0x5B
VK_LEFT = 0x25
VK_RIGHT = 0x27
VK_D = 0x44
VK_F4 = 0x73
VK_TAB = 0x09

KEYEVENTF_KEYDOWN = 0x0000
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_EXTENDEDKEY = 0x0001


def press_hardware_key(vk, is_arrow=False):
    if not IS_WINDOWS:
        return
    scan = ctypes.windll.user32.MapVirtualKeyA(vk, 0)
    flags = KEYEVENTF_KEYDOWN
    if is_arrow:
        flags |= KEYEVENTF_EXTENDEDKEY
    ctypes.windll.user32.keybd_event(vk, scan, flags, 0)


def release_hardware_key(vk, is_arrow=False):
    if not IS_WINDOWS:
        return
    scan = ctypes.windll.user32.MapVirtualKeyA(vk, 0)
    flags = KEYEVENTF_KEYUP
    if is_arrow:
        flags |= KEYEVENTF_EXTENDEDKEY
    ctypes.windll.user32.keybd_event(vk, scan, flags, 0)


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self._mac_pressed_hotkeys = {}

        self.icon_map = {
            "next": "STATE_NEXT",
            "prev": "STATE_PREV",
            "new": "STATE_NEW",
            "close": "STATE_CLOSE",
            "view": "STATE_VIEW",
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "next", "STATE_NEXT")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _send_status_title(self, context, title):
        if context:
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": title}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "command", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        state_val = None
        if "#" in (action_id or ""):
            state_val = action_id.split("#")[-1]

        default_action = state_val or "next"
        if default_action not in self.icon_map:
            default_action = "next"

        new_settings = {
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        action_id = data.get("action", "")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or "next")
            return

        if event == "keyDown":
            await self.on_key_down(data)
        elif event == "keyUp":
            await self.on_key_up(data)

    async def on_key_down(self, data):
        action_id = data.get("action", "")
        state_val = None
        if "#" in action_id:
            state_val = action_id.split("#")[-1]

        payload = data.get("payload", {}) or {}
        settings = payload.get("settings", {}) or {}
        context = data.get("context") or payload.get("context")
        action = settings.get("command") or state_val or "next"

        if IS_WINDOWS:
            await asyncio.to_thread(self._run_windows_vd_command, action)
        elif IS_MACOS:
            ok = await asyncio.to_thread(
                self._run_macos_space_key_down, context, action, settings
            )
            if not ok and action in ("new", "close"):
                await self._send_status_title(context, "macOS limited")
        else:
            # Linux desktop/workspace shortcuts vary by desktop environment.
            await asyncio.to_thread(self._run_linux_workspace_command, action)

    async def on_key_up(self, data):
        if not IS_MACOS:
            return
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        await asyncio.to_thread(self._run_macos_space_key_up, context)

    def _run_macos_space_key_down(self, context, action, settings=None):
        defaults = {"next": "ctrl+right", "prev": "ctrl+left", "view": "ctrl+up"}
        if action in defaults:
            saved = (settings or {}).get("mac_hotkeys") or {}
            return self._run_macos_applescript_hotkey(saved.get(action) or defaults[action])
        return self._run_macos_space_command(action)

    def _run_macos_applescript_hotkey(self, hotkey):
        parts = [str(part).strip().lower() for part in str(hotkey or "").split("+") if str(part).strip()]
        aliases = {
            "control": "ctrl", "cmd": "command", "meta": "command",
            "alt": "option", "escape": "esc", "return": "enter",
            "arrowleft": "left", "arrowright": "right", "arrowup": "up", "arrowdown": "down",
        }
        parts = [aliases.get(part, part) for part in parts]
        modifiers = {
            "ctrl": "control down", "command": "command down",
            "option": "option down", "shift": "shift down",
        }
        keycodes = {
            "a": 0, "s": 1, "d": 2, "f": 3, "h": 4, "g": 5, "z": 6, "x": 7,
            "c": 8, "v": 9, "b": 11, "q": 12, "w": 13, "e": 14, "r": 15,
            "y": 16, "t": 17, "1": 18, "2": 19, "3": 20, "4": 21, "6": 22,
            "5": 23, "=": 24, "9": 25, "7": 26, "-": 27, "8": 28, "0": 29,
            "]": 30, "o": 31, "u": 32, "[": 33, "i": 34, "p": 35, "enter": 36,
            "l": 37, "j": 38, "'": 39, "k": 40, ";": 41, "\\": 42, ",": 43,
            "/": 44, "n": 45, "m": 46, ".": 47, "tab": 48, "space": 49,
            "`": 50, "backspace": 51, "esc": 53, "left": 123, "right": 124,
            "down": 125, "up": 126, "home": 115, "end": 119, "pageup": 116,
            "pagedown": 121, "delete": 117, "f1": 122, "f2": 120, "f3": 99,
            "f4": 118, "f5": 96, "f6": 97, "f7": 98, "f8": 100, "f9": 101,
            "f10": 109, "f11": 103, "f12": 111,
        }
        keys = [part for part in parts if part not in modifiers]
        if len(keys) != 1 or keys[0] not in keycodes:
            return False
        using_parts = [modifiers[part] for part in parts if part in modifiers]
        using = f" using {{{', '.join(using_parts)}}}" if using_parts else ""
        try:
            return subprocess.run(
                ["osascript", "-e", f'tell application "System Events" to key code {keycodes[keys[0]]}{using}'],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5,
            ).returncode == 0
        except Exception:
            return False

    def _run_macos_applescript_key(self, keycode):
        if int(keycode) not in (123, 124):
            return False
        try:
            return subprocess.run(
                [
                    "osascript",
                    "-e",
                    f'tell application "System Events" to key code '
                    f'{int(keycode)} using control down',
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
            ).returncode == 0
        except Exception:
            return False

    def _mac_hotkey_key_down(self, context, arrow_keycode):
        try:
            import Quartz

            key = str(context or "__virtualdesktop_once__")
            self._run_macos_space_key_up(key)
            source = Quartz.CGEventSourceCreate(Quartz.kCGEventSourceStatePrivate)
            if source is None:
                return False
            base_flags = (
                Quartz.kCGEventFlagMaskControl
                | Quartz.kCGEventFlagMaskNonCoalesced
            )
            arrow_flags = base_flags | Quartz.kCGEventFlagMaskNumericPad
            control = Quartz.CGEventCreateKeyboardEvent(source, 59, True)
            Quartz.CGEventSetFlags(control, base_flags)
            Quartz.CGEventPost(Quartz.kCGSessionEventTap, control)
            time.sleep(0.001)
            arrow = Quartz.CGEventCreateKeyboardEvent(source, arrow_keycode, True)
            Quartz.CGEventSetFlags(arrow, arrow_flags)
            Quartz.CGEventPost(Quartz.kCGSessionEventTap, arrow)
            self._mac_pressed_hotkeys[key] = {
                "source": source,
                "arrow_keycode": arrow_keycode,
                "arrow_flags": arrow_flags,
            }
            return True
        except Exception:
            return False

    def _run_macos_space_key_up(self, context):
        key = str(context or "__virtualdesktop_once__")
        pressed = self._mac_pressed_hotkeys.pop(key, None)
        if not pressed:
            return False
        try:
            import Quartz

            arrow = Quartz.CGEventCreateKeyboardEvent(
                pressed["source"], pressed["arrow_keycode"], False
            )
            Quartz.CGEventSetFlags(arrow, pressed["arrow_flags"])
            Quartz.CGEventPost(Quartz.kCGSessionEventTap, arrow)
            control = Quartz.CGEventCreateKeyboardEvent(
                pressed["source"], 59, False
            )
            Quartz.CGEventSetFlags(
                control, Quartz.kCGEventFlagMaskNonCoalesced
            )
            Quartz.CGEventPost(Quartz.kCGSessionEventTap, control)
            return True
        except Exception:
            return False

    def _run_windows_vd_command(self, action):
        press_hardware_key(VK_CONTROL)
        press_hardware_key(VK_LWIN)
        time.sleep(0.05)

        if action == "next":
            press_hardware_key(VK_RIGHT, is_arrow=True)
            time.sleep(0.05)
            release_hardware_key(VK_RIGHT, is_arrow=True)
        elif action == "prev":
            press_hardware_key(VK_LEFT, is_arrow=True)
            time.sleep(0.05)
            release_hardware_key(VK_LEFT, is_arrow=True)
        elif action == "new":
            press_hardware_key(VK_D)
            time.sleep(0.05)
            release_hardware_key(VK_D)
        elif action == "close":
            press_hardware_key(VK_F4)
            time.sleep(0.05)
            release_hardware_key(VK_F4)
        elif action == "view":
            release_hardware_key(VK_CONTROL)
            press_hardware_key(VK_TAB)
            time.sleep(0.05)
            release_hardware_key(VK_TAB)

        time.sleep(0.05)
        release_hardware_key(VK_LWIN)
        release_hardware_key(VK_CONTROL)

    def _mac_hotkey(self, *keys):
        try:
            import Quartz

            key_code_map = {
                "left": 123, "right": 124, "up": 126, "down": 125,
                "escape": 53, "esc": 53,
            }
            modifier_map = {
                "ctrl": (59, Quartz.kCGEventFlagMaskControl),
                "control": (59, Quartz.kCGEventFlagMaskControl),
                "command": (55, Quartz.kCGEventFlagMaskCommand),
                "cmd": (55, Quartz.kCGEventFlagMaskCommand),
                "option": (58, Quartz.kCGEventFlagMaskAlternate),
                "alt": (58, Quartz.kCGEventFlagMaskAlternate),
                "shift": (56, Quartz.kCGEventFlagMaskShift),
            }
            keycode = key_code_map.get(keys[-1])
            if keycode is not None:
                source = Quartz.CGEventSourceCreate(
                    Quartz.kCGEventSourceStatePrivate
                )
                if source is not None:
                    flags = Quartz.kCGEventFlagMaskNonCoalesced
                    modifiers = []
                    for name in keys[:-1]:
                        if name in modifier_map:
                            modifier_keycode, modifier_flag = modifier_map[name]
                            flags |= modifier_flag
                            modifiers.append(modifier_keycode)

                    for modifier_keycode in modifiers:
                        event = Quartz.CGEventCreateKeyboardEvent(
                            source, modifier_keycode, True
                        )
                        Quartz.CGEventSetFlags(event, flags)
                        Quartz.CGEventPost(Quartz.kCGSessionEventTap, event)
                        time.sleep(0.02)

                    down = Quartz.CGEventCreateKeyboardEvent(source, keycode, True)
                    up = Quartz.CGEventCreateKeyboardEvent(source, keycode, False)
                    Quartz.CGEventSetFlags(down, flags)
                    Quartz.CGEventSetFlags(up, flags)
                    Quartz.CGEventPost(Quartz.kCGSessionEventTap, down)
                    time.sleep(0.08)
                    Quartz.CGEventPost(Quartz.kCGSessionEventTap, up)
                    time.sleep(0.04)

                    for modifier_keycode in reversed(modifiers):
                        event = Quartz.CGEventCreateKeyboardEvent(
                            source, modifier_keycode, False
                        )
                        Quartz.CGEventSetFlags(
                            event, Quartz.kCGEventFlagMaskNonCoalesced
                        )
                        Quartz.CGEventPost(Quartz.kCGSessionEventTap, event)
                        time.sleep(0.01)
                    return True
        except Exception:
            pass

        if pyautogui_available:
            modifiers = list(keys[:-1])
            key = keys[-1]
            try:
                for modifier in modifiers:
                    pyautogui.keyDown(modifier)
                    time.sleep(0.02)
                pyautogui.keyDown(key)
                time.sleep(0.08)
                pyautogui.keyUp(key)
                time.sleep(0.04)
                return True
            finally:
                for modifier in reversed(modifiers):
                    try:
                        pyautogui.keyUp(modifier)
                    except Exception:
                        pass

        # Fallback through AppleScript/System Events when pyautogui is unavailable.
        key_code_map = {
            "left": 123,
            "right": 124,
            "up": 126,
            "down": 125,
            "escape": 53,
        }
        modifier_map = {
            "ctrl": "control down",
            "control": "control down",
            "command": "command down",
            "cmd": "command down",
            "option": "option down",
            "alt": "option down",
            "shift": "shift down",
        }
        mods = [modifier_map[k] for k in keys[:-1] if k in modifier_map]
        last = keys[-1]
        if last not in key_code_map:
            return False
        using = f" using {{{', '.join(mods)}}}" if mods else ""
        subprocess.run([
            "osascript", "-e",
            f'tell application "System Events" to key code {key_code_map[last]}{using}'
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True

    def _switch_macos_space(self, direction):
        """Switch adjacent macOS Spaces without relying on synthetic keys."""
        if direction not in (-1, 1):
            return False
        try:
            import objc

            sky = ctypes.CDLL(
                "/System/Library/PrivateFrameworks/SkyLight.framework/SkyLight"
            )
            sky.CGSMainConnectionID.argtypes = []
            sky.CGSMainConnectionID.restype = ctypes.c_uint32
            sky.CGSCopyManagedDisplaySpaces.argtypes = [ctypes.c_uint32]
            sky.CGSCopyManagedDisplaySpaces.restype = ctypes.c_void_p
            sky.CGSGetActiveSpace.argtypes = [ctypes.c_uint32]
            sky.CGSGetActiveSpace.restype = ctypes.c_uint64
            setter = sky.CGSManagedDisplaySetCurrentSpace
            setter.argtypes = [ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint64]
            setter.restype = ctypes.c_int32

            connection = sky.CGSMainConnectionID()
            rows_pointer = sky.CGSCopyManagedDisplaySpaces(connection)
            if not rows_pointer:
                return False
            displays = objc.objc_object(c_void_p=rows_pointer)
            active = int(sky.CGSGetActiveSpace(connection))
            display = next(
                (
                    row for row in displays
                    if int((row.get("Current Space") or {}).get("ManagedSpaceID", 0))
                    == active
                ),
                displays[0] if displays else None,
            )
            if display is None:
                return False
            spaces = [
                int(space.get("ManagedSpaceID", 0))
                for space in (display.get("Spaces") or [])
                if int(space.get("ManagedSpaceID", 0)) > 0
            ]
            if active not in spaces:
                return False
            target_index = spaces.index(active) + int(direction)
            if not 0 <= target_index < len(spaces):
                return True
            identifier = display.get("Display Identifier")
            objc_identifier = getattr(identifier, "__pyobjc_object__", None)
            if objc_identifier is None:
                import Foundation
                identifier = Foundation.NSString.stringWithString_(str(identifier))
                objc_identifier = getattr(identifier, "__pyobjc_object__", None)
            if objc_identifier is None:
                return False
            return int(setter(
                connection,
                objc.pyobjc_id(objc_identifier),
                spaces[target_index],
            )) == 0
        except Exception:
            return False

    def _run_macos_space_command(self, action):
        """
        macOS Spaces is not a 1:1 match with Windows Virtual Desktop.
        Reliable default shortcuts:
          - Control + Left/Right: move between Spaces, if enabled in Mission Control shortcuts.
          - Control + Up: Mission Control.
        Creating/closing a Space has no stable default keyboard shortcut, so those are best-effort only.
        """
        if action == "next":
            return self._run_macos_applescript_key(124)
        if action == "prev":
            return self._run_macos_applescript_key(123)
        if action == "view":
            try:
                return subprocess.run(
                    ["open", "-a", "Mission Control"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=3,
                ).returncode == 0
            except Exception:
                pass
            return self._mac_hotkey("ctrl", "up")

        if action == "new":
            if not pyautogui_available:
                return False
            # Best-effort: open Mission Control and click the + button near the top-right.
            opened = subprocess.run(
                ["open", "-a", "Mission Control"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=3,
            ).returncode == 0
            if not opened:
                return False
            time.sleep(0.45)
            width, _height = pyautogui.size()
            pyautogui.click(width - 32, 28)
            time.sleep(0.15)
            pyautogui.press("escape")
            return True

        if action == "close":
            # macOS has no reliable keyboard-only shortcut to close the current Space.
            # Users can close Spaces in Mission Control manually. Avoid coordinate hacks that may close the wrong Space.
            self._mac_hotkey("ctrl", "up")
            return False

        return False

    def _run_linux_workspace_command(self, action):
        if not pyautogui_available:
            return
        if action == "next":
            pyautogui.hotkey("ctrl", "alt", "right")
        elif action == "prev":
            pyautogui.hotkey("ctrl", "alt", "left")
        elif action == "view":
            pyautogui.hotkey("super", "s")
