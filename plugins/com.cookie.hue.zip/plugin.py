import asyncio
import urllib.request
import json
import comtypes
import os

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        self.icon_map = {
            "toggle": "CMD_TOGGLE",
            "on": "CMD_ON",
            "off": "CMD_OFF",
            "set_brightness": "CMD_SET_BRIGHTNESS",
            "adj_brightness": "CMD_ADJ_BRIGHTNESS",
            "set_colortemp": "CMD_SET_COLORTEMP",
            "adj_colortemp": "CMD_ADJ_COLORTEMP",
            "set_color": "CMD_SET_COLOR",
            "cycle_color": "CMD_CYCLE_COLOR",
        }

    def _default_command(self):
        return "toggle"

    def _default_settings(self):
        default_command = self._default_command()
        return {
            "hue_ip": "",
            "hue_username": "",
            "hue_light_id": "1",
            "command": default_command,
            "hue_brightness": "128",
            "hue_adj_brightness_val": "20",
            "hue_ct": "366",
            "hue_adj_ct_val": "30",
            "hue_color": "white",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_command],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        command = merged.get("command") or self._default_command()
        merged["command"] = command
        merged["builtin_icon_name"] = self.icon_map.get(command, self.icon_map[self._default_command()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("hue_ip"),
            s.get("hue_username"),
            s.get("hue_light_id"),
            s.get("hue_brightness"),
            s.get("hue_adj_brightness_val"),
            s.get("hue_ct"),
            s.get("hue_adj_ct_val"),
            s.get("hue_color"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, command_name):
        icon_name = self.icon_map.get(command_name or self._default_command(), self.icon_map[self._default_command()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, command_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(command_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        command_name = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            await self._send_builtin_icon(context, command_name or settings.get("command") or cached.get("command") or self._default_command())
            return

        if control_command == "register_bridge":
            ip = payload.get("ip")
            result = await asyncio.to_thread(self._register_bridge, ip)
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": result
            })
            return

        if event == "keyDown":
            await self.on_key_down(data)

    def _register_bridge(self, ip):
        url = f"http://{ip}/api"
        payload = json.dumps({"devicetype": "cookiedeck#pro"}).encode("utf-8")
        try:
            req = urllib.request.Request(url, data=payload, method="POST")
            with urllib.request.urlopen(req, timeout=3) as res:
                response_data = json.loads(res.read().decode())
                if isinstance(response_data, list) and "success" in response_data[0]:
                    return {"command": "bridge_registered", "username": response_data[0]["success"]["username"]}
                return {"command": "bridge_error", "error_key": "ALERT_PRESS_BUTTON"}
        except Exception as e:
            return {"command": "bridge_error", "error_key": "ALERT_CONNECTION_FAILED", "detail": str(e)}

    def control_hue(self, ip, username, light_id, settings):
        comtypes.CoInitialize()
        try:
            if not ip or not username or not light_id:
                print(f"[{self.uuid}] Missing control information. (IP: {ip}, ID: {light_id})")
                return

            base_url = f"http://{ip}/api/{username}/lights/{light_id}"
            put_url = f"{base_url}/state"
            action_type = settings.get("command", self._default_command())
            payload = {}

            current_state = {}
            if action_type in ["toggle", "adj_brightness", "adj_colortemp", "cycle_color"]:
                with urllib.request.urlopen(base_url, timeout=2) as res:
                    current_state = json.loads(res.read().decode()).get("state", {})

            if action_type == "toggle":
                payload = {"on": not current_state.get("on", False)}
            elif action_type == "on":
                payload = {"on": True}
            elif action_type == "off":
                payload = {"on": False}
            elif action_type == "set_brightness":
                payload = {"on": True, "bri": int(settings.get("hue_brightness", 128))}
            elif action_type == "adj_brightness":
                current_bri = current_state.get("bri", 128)
                adj_val = int(254 * (int(settings.get("hue_adj_brightness_val", 20)) / 100))
                new_bri = max(1, min(254, current_bri + adj_val))
                payload = {"on": True, "bri": new_bri}
            elif action_type == "set_colortemp":
                payload = {"on": True, "ct": int(settings.get("hue_ct", 366))}
            elif action_type == "adj_colortemp":
                current_ct = current_state.get("ct", 366)
                adj_val = int(settings.get("hue_adj_ct_val", 30))
                new_ct = max(153, min(500, current_ct + adj_val))
                payload = {"on": True, "ct": new_ct}
            elif action_type == "set_color":
                colors = {
                    "red": [0.675, 0.322],
                    "green": [0.409, 0.518],
                    "blue": [0.167, 0.04],
                    "yellow": [0.432, 0.499],
                    "white": [0.3127, 0.329],
                    "purple": [0.24, 0.1],
                    "pink": [0.4, 0.2]
                }
                payload = {"on": True, "xy": colors.get(settings.get("hue_color", "white"))}
            elif action_type == "cycle_color":
                if current_state.get("effect") == "colorloop":
                    payload = {"effect": "none"}
                else:
                    payload = {"on": True, "effect": "colorloop"}

            if payload:
                req = urllib.request.Request(put_url, data=json.dumps(payload).encode(), method="PUT")
                with urllib.request.urlopen(req, timeout=2):
                    print(f"[{self.uuid}] Hue command '{action_type}' sent successfully.")

        except Exception as e:
            print(f"[{self.uuid}] Control Error: {e}")
        finally:
            comtypes.CoUninitialize()

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        final_settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = final_settings

        ip = final_settings.get("hue_ip")
        username = final_settings.get("hue_username")
        light_id = final_settings.get("hue_light_id")

        await asyncio.to_thread(self.control_hue, ip, username, light_id, final_settings)
