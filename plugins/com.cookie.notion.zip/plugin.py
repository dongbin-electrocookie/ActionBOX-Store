import sys
import os
import asyncio

lib_path = os.path.join(os.path.dirname(__file__), 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

try:
    import requests
    import pyperclip
    import pyautogui
    DEPENDENCIES_OK = True
except ImportError:
    DEPENDENCIES_OK = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        self.shortcuts_db = {
            "new_page": ['ctrl', 'n'],
            "new_window": ['ctrl', 'shift', 'n'],
            "search": ['ctrl', 'p'],
            "sidebar": ['ctrl', '\\'],
            "darkmode": ['ctrl', 'shift', 'l'],
            "go_back": ['ctrl', '['],
            "go_forward": ['ctrl', ']'],
            "go_up": ['ctrl', 'shift', 'u'],
            "bold": ['ctrl', 'b'],
            "italic": ['ctrl', 'i'],
            "strikethrough": ['ctrl', 'shift', 's'],
            "code": ['ctrl', 'e'],
            "link": ['ctrl', 'k'],
            "text": ['ctrl', 'shift', '0'],
            "h1": ['ctrl', 'shift', '1'],
            "h2": ['ctrl', 'shift', '2'],
            "h3": ['ctrl', 'shift', '3'],
            "todo": ['ctrl', 'shift', '4'],
            "bullet": ['ctrl', 'shift', '5'],
            "number": ['ctrl', 'shift', '6'],
            "toggle": ['ctrl', 'shift', '7'],
            "code_block": ['ctrl', 'shift', '8'],
            "page_block": ['ctrl', 'shift', '9']
        }

        self.shortcut_icon_map = {
            "new_page": "SC_NEW_PAGE",
            "new_window": "SC_NEW_WINDOW",
            "search": "SC_SEARCH",
            "sidebar": "SC_SIDEBAR",
            "darkmode": "SC_DARKMODE",
            "go_back": "SC_GO_BACK",
            "go_forward": "SC_GO_FORWARD",
            "go_up": "SC_GO_UP",
            "bold": "SC_BOLD",
            "italic": "SC_ITALIC",
            "strikethrough": "SC_STRIKETHROUGH",
            "code": "SC_CODE",
            "link": "SC_LINK",
            "text": "SC_TEXT",
            "h1": "SC_H1",
            "h2": "SC_H2",
            "h3": "SC_H3",
            "todo": "SC_TODO",
            "bullet": "SC_BULLET",
            "number": "SC_NUMBER",
            "toggle": "SC_TOGGLE",
            "code_block": "SC_CODE_BLOCK",
            "page_block": "SC_PAGE_BLOCK"
        }

        self.msg = {
            "en": {
                "module_error": "Module\nError",
                "api_missing": "API Setup\nMissing!",
                "copying": "Copying...✂️",
                "no_selection": "No\nSelection!",
                "sending": "Sending...⏳",
                "saved": "✅ Saved!",
                "quick": "Quick\nCapture",
                "error": "❌ Error"
            },
            "ko": {
                "module_error": "모듈오류",
                "api_missing": "API 설정\n안됨!",
                "copying": "복사중...✂️",
                "no_selection": "드래그\n없음!",
                "sending": "전송중...⏳",
                "saved": "✅ 저장됨!",
                "quick": "Quick\nCapture",
                "error": "❌ 오류발생"
            },
            "ja": {
                "module_error": "モジュール\nエラー",
                "api_missing": "API 設定\n未完了!",
                "copying": "コピー中...✂️",
                "no_selection": "選択\nなし!",
                "sending": "送信中...⏳",
                "saved": "✅ 保存完了!",
                "quick": "Quick\nCapture",
                "error": "❌ エラー"
            },
            "de": {
                "module_error": "Modul\nFehler",
                "api_missing": "API-Setup\nFehlt!",
                "copying": "Kopiere...✂️",
                "no_selection": "Keine\nAuswahl!",
                "sending": "Sende...⏳",
                "saved": "✅ Gespeichert!",
                "quick": "Quick\nCapture",
                "error": "❌ Fehler"
            },
            "es": {
                "module_error": "Error de\nmódulo",
                "api_missing": "Falta\nAPI!",
                "copying": "Copiando...✂️",
                "no_selection": "Sin\nselección!",
                "sending": "Enviando...⏳",
                "saved": "✅ Guardado!",
                "quick": "Quick\nCapture",
                "error": "❌ Error"
            },
            "fr": {
                "module_error": "Erreur\nmodule",
                "api_missing": "API\nmanquante!",
                "copying": "Copie...✂️",
                "no_selection": "Aucune\nsélection!",
                "sending": "Envoi...⏳",
                "saved": "✅ Enregistré!",
                "quick": "Quick\nCapture",
                "error": "❌ Erreur"
            },
            "ru": {
                "module_error": "Ошибка\nмодуля",
                "api_missing": "Нет\nAPI!",
                "copying": "Копирую...✂️",
                "no_selection": "Нет\nвыделения!",
                "sending": "Отправка...⏳",
                "saved": "✅ Сохранено!",
                "quick": "Quick\nCapture",
                "error": "❌ Ошибка"
            },
            "it": {
                "module_error": "Errore\nmodulo",
                "api_missing": "API\nmancante!",
                "copying": "Copia...✂️",
                "no_selection": "Nessuna\nselezione!",
                "sending": "Invio...⏳",
                "saved": "✅ Salvato!",
                "quick": "Quick\nCapture",
                "error": "❌ Errore"
            },
            "pt-PT": {
                "module_error": "Erro de\nmódulo",
                "api_missing": "Falta\nAPI!",
                "copying": "A copiar...✂️",
                "no_selection": "Sem\nseleção!",
                "sending": "A enviar...⏳",
                "saved": "✅ Guardado!",
                "quick": "Quick\nCapture",
                "error": "❌ Erro"
            }
        }

    def _lang(self, settings):
        lang = str(settings.get("_lang") or "en").lower()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        lang = alias.get(lang, lang)
        return lang if lang in self.msg else "en"

    def _t(self, settings, key):
        return self.msg[self._lang(settings)].get(key, key)

    def _default_settings_for_action(self, action):
        if "quickcapture" in (action or ""):
            return {
                "api_key": "",
                "db_id": "",
                "_lang": "en",
                "default_visuals_initialized": True
            }
        default_command = "new_page"
        return {
            "command": default_command,
            "shortcut": default_command,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.shortcut_icon_map[default_command],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, action, settings):
        merged = self._default_settings_for_action(action)
        merged.update(settings or {})
        if "shortcuts" in (action or ""):
            command = merged.get("command") or merged.get("shortcut") or "new_page"
            merged["command"] = command
            merged["shortcut"] = command
            merged["builtin_icon_name"] = self.shortcut_icon_map.get(command, self.shortcut_icon_map["new_page"])
        return merged

    def _has_meaningful_settings(self, action, settings):
        s = settings or {}
        if "quickcapture" in (action or ""):
            return any([
                s.get("api_key"),
                s.get("db_id"),
                s.get("title"),
                s.get("default_visuals_initialized")
            ])
        return any([
            s.get("command"),
            s.get("shortcut"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    async def show_feedback(self, context, text):
        if hasattr(self.runner, "send_message"):
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": text}
            })

    async def _restore_base_title(self, context, settings):
        base_title = settings.get("title") or self._t(settings, "quick")
        await self.show_feedback(context, base_title)

    def _get_shortcut_icon_path(self, command_name):
        icon_name = self.shortcut_icon_map.get(command_name or "new_page", "SC_NEW_PAGE")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_quickcapture_icon(self, context):
        icon_path = os.path.join(self.plugin_dir, "icon", "QUICK_CAPTURE.png")
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _send_shortcut_icon(self, context, command_name):
        icon_path = self._get_shortcut_icon_path(command_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action, settings):
        if not context:
            return False

        if not self._has_meaningful_settings(action, settings):
            new_settings = self._default_settings_for_action(action)
            self.context_settings[context] = self._merge_with_defaults(action, new_settings)

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": new_settings
            })

            # Initial placement: icon only, never overwrite title
            if "quickcapture" in (action or ""):
                await self._send_quickcapture_icon(context)
            elif "shortcuts" in (action or ""):
                await self._send_shortcut_icon(context, new_settings.get("command", "new_page"))
            return False

        self.context_settings[context] = self._merge_with_defaults(action, settings)
        return True

    async def handle_message(self, data):
        event = data.get("event")
        action = data.get("action")
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        shortcut_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, action, settings)
            return

        if event == "didReceiveSettings":
            if context:
                saved = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults(action or saved.get("action_uuid", ""), {**saved, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon" and "shortcuts" in (action or ""):
            cached = self.context_settings.get(context, {})
            await self._send_shortcut_icon(context, shortcut_command or settings.get("command") or settings.get("shortcut") or cached.get("command") or "new_page")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        action = data.get("action")
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}

        saved = self.context_settings.get(context, {})
        final_settings = self._merge_with_defaults(action, {**saved, **incoming_settings})
        if context:
            self.context_settings[context] = final_settings

        if not DEPENDENCIES_OK:
            await self.show_feedback(context, self._t(final_settings, "module_error"))
            await asyncio.sleep(1.2)
            if "quickcapture" in (action or ""):
                await self._restore_base_title(context, final_settings)
            return

        if "quickcapture" in (action or ""):
            api_key = final_settings.get("api_key", "").strip()
            db_id = final_settings.get("db_id", "").strip()

            if not api_key or not db_id:
                await self.show_feedback(context, self._t(final_settings, "api_missing"))
                await asyncio.sleep(1.2)
                await self._restore_base_title(context, final_settings)
                return

            await self.show_feedback(context, self._t(final_settings, "copying"))
            pyautogui.hotkey('ctrl', 'c')
            await asyncio.sleep(0.3)

            try:
                clipboard_text = pyperclip.paste().strip()
            except Exception:
                clipboard_text = ""

            if not clipboard_text:
                await self.show_feedback(context, self._t(final_settings, "no_selection"))
                await asyncio.sleep(1.2)
                await self._restore_base_title(context, final_settings)
                return

            await self.show_feedback(context, self._t(final_settings, "sending"))
            success, err_msg = await self.send_to_notion(api_key, db_id, clipboard_text)

            if success:
                await self.show_feedback(context, self._t(final_settings, "saved"))
            else:
                await self.show_feedback(context, self._t(final_settings, "error"))

            await asyncio.sleep(1.5)
            await self._restore_base_title(context, final_settings)

        elif "shortcuts" in (action or ""):
            selected_shortcut = final_settings.get("command") or final_settings.get("shortcut", "new_page")
            if selected_shortcut in self.shortcuts_db:
                keys = self.shortcuts_db[selected_shortcut]
                await asyncio.to_thread(pyautogui.hotkey, *keys)
                print(f"[{self.uuid}] Shortcut executed: {selected_shortcut} ({keys})")

    async def send_to_notion(self, api_key, db_id, text):
        url = "https://api.notion.com/v1/pages"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Notion-Version": "2022-06-28"
        }
        payload = {
            "parent": {"database_id": db_id},
            "properties": {
                "이름": { "title": [{"text": {"content": text}}] }
            }
        }
        try:
            res = await asyncio.to_thread(requests.post, url, headers=headers, json=payload)
            if res.status_code == 200:
                return True, ""
            else:
                return False, res.text
        except Exception as e:
            return False, str(e)
