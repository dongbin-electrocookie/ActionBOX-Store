import asyncio
import os

try:
    import keyboard
    keyboard_available = True
except ImportError:
    print("[Teams Plugin] 'keyboard' library is missing.")
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.action_map = {
            "toggle_mic": "ctrl+shift+m",
            "toggle_cam": "ctrl+shift+o",
            "toggle_share": "ctrl+shift+e",
            "toggle_hand": "ctrl+shift+k",
            "toggle_blur": "ctrl+shift+p",
            "leave_meeting": "ctrl+shift+h"
        }

        self.icon_map = {
            "toggle_mic": "STATE_TOGGLE_MIC",
            "toggle_cam": "STATE_TOGGLE_CAM",
            "toggle_share": "STATE_TOGGLE_SHARE",
            "toggle_hand": "STATE_TOGGLE_HAND",
            "toggle_blur": "STATE_TOGGLE_BLUR",
            "leave_meeting": "STATE_LEAVE_MEETING"
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "toggle_mic", "STATE_TOGGLE_MIC")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "command", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "toggle_mic"
        new_settings = {
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        # Initial placement: icon only, never overwrite title
        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or "toggle_mic")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available:
            return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("command", "toggle_mic")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)
