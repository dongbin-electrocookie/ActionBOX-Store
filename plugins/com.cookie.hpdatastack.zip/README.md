# HP Data Science Stack Manager for COMBO-X

Official-store plugin baseline for Windows. It uses only documented Windows facilities and installed command-line tools; it does not call an unpublished HP management API.

- Opens or focuses Stack Manager
- Launches common development tools
- Checks Stack Manager, Python, Git, WSL, Docker, Conda, and Jupyter availability
- Runs explicit WSL status/list/launch/shutdown operations
- Runs common WSL commands from a safe, non-interactive preset list
- Runs a user-entered WSL command with distribution, working-directory, output, and timeout controls
- Displays AMD, Intel, and NVIDIA GPU usage plus dedicated/shared graphics-memory usage through Windows GPU counters
- Creates an HTML environment report in the COMBO-X user data directory

Dynamic status actions retain the configured title as the first line and replace the second line with live status.

Stack Manager requires Windows elevation. When it is not already running, the plugin launches it through the standard UAC `runas` flow and uses the application's installation directory as its working directory. Cancelling the UAC prompt is reported as a launch error.

The WSL command Actions read installed distribution names from `wsl.exe`. Results can be shown in the Property Inspector, copied to the Windows clipboard, or saved as `latest_wsl_result.txt` in the plugin user-data directory. Commands run once per physical key press; concurrent runs for the same key are rejected, and timeouts are limited to 1–600 seconds. Custom commands are intentionally never run while editing or saving their settings.

GPU adapters are matched to Windows performance-counter instances by DXGI LUID, so hybrid and integrated AMD/Intel/NVIDIA systems do not depend on vendor utilities. Dedicated and shared memory totals come from DXGI, including large unified-memory configurations. If `nvidia-smi` is present, its temperature and NVIDIA sensor values are appended.
