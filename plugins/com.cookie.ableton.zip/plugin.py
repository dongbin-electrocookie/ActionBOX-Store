import asyncio
import socket
import struct

try:
    import keyboard
except ImportError:
    keyboard = None

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 에이블톤 핵심 단축키 맵
        self.hotkey_map = {
            "play_stop": "space",
            "record": "f9",
            "metronome": "c",
            "loop": "ctrl+l",
            "view_toggle": "tab",
            "device_clip": "shift+tab",
            "browser": "ctrl+alt+b",
            "detail_view": "ctrl+alt+l",
            "duplicate": "ctrl+d",
            "undo": "ctrl+z",
            "redo": "ctrl+y",
            "quantize": "ctrl+u",
            "split": "ctrl+e",
            "consolidate": "ctrl+j",
            "draw_mode": "b"
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        mode = settings.get("control_mode", "hotkey")

        # 1. 단축키 모드
        if mode == "hotkey":
            if not keyboard: return
            action = settings.get("ableton_hotkey")
            if action in self.hotkey_map:
                hotkey = self.hotkey_map[action]
                await asyncio.to_thread(keyboard.send, hotkey)

        # 2. API (OSC) 모드
        elif mode == "osc":
            address = settings.get("osc_address", "").strip()
            val_str = settings.get("osc_value", "").strip()
            port = int(settings.get("osc_port", 9000))
            
            if not address: return
            if not address.startswith("/"): address = "/" + address

            # 입력값 타입 추론 (int, float, string, None)
            value = None
            if val_str:
                try: value = int(val_str)
                except ValueError:
                    try: value = float(val_str)
                    except ValueError: value = val_str

            # 별도 스레드에서 UDP 소켓 발사
            await asyncio.to_thread(self._send_simple_osc, "127.0.0.1", port, address, value)

    # ---------------------------------------------------------
    # 🚀 외부 라이브러리 없이 구현한 초경량 OSC 패킷 제너레이터!
    # ---------------------------------------------------------
    def _send_simple_osc(self, ip, port, address, value):
        """OSC 규격(4바이트 정렬)에 맞춰 바이트 배열을 조립하고 UDP로 전송합니다."""
        try:
            def osc_pad(b_str):
                """OSC는 문자열 끝을 항상 4의 배수로 Null(\x00) 패딩해야 함"""
                pad_len = 4 - (len(b_str) % 4)
                return b_str + (b'\x00' * pad_len)

            # 1. Address
            msg = osc_pad(address.encode('utf-8'))

            # 2. Type Tags & 3. Arguments
            if value is None:
                msg += osc_pad(b',') # 인자 없음
            elif isinstance(value, int):
                msg += osc_pad(b',i')
                msg += struct.pack('>i', value) # 빅엔디안 32비트 정수
            elif isinstance(value, float):
                msg += osc_pad(b',f')
                msg += struct.pack('>f', value) # 빅엔디안 32비트 실수
            elif isinstance(value, str):
                msg += osc_pad(b',s')
                msg += osc_pad(value.encode('utf-8'))

            # UDP 전송
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(msg, (ip, port))
            sock.close()
            print(f"[{self.uuid}] OSC Sent: {address} -> {value} (Port: {port})")

        except Exception as e:
            print(f"[{self.uuid}] OSC 전송 에러: {e}")