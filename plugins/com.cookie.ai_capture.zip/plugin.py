# AI Link is a COMBO-X built-in action.
# The real PySide6 implementation lives in cookiedeck_ai.py and is launched by cookiedeck.py.

class Plugin:
    def __init__(self, *args, **kwargs):
        pass
