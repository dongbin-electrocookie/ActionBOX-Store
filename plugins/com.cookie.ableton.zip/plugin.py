import asyncio
import os
import socket
import struct
import sys

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

try:
    import keyboard
except ImportError:
    keyboard = None

try:
    import pyautogui
except ImportError:
    pyautogui = None


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}
        self.default_hotkey_action = "play_stop"

        # Windows/Linux 기준 단축키
        self.windows_hotkey_map = {
            "play_stop": "space",
            "record": "f9",
            "metronome": "c",
            "loop": "ctrl+l",
            "view_toggle": "tab",
            "device_clip": "shift+tab",
            "browser": "ctrl+alt+b",
            "detail_view": "ctrl+alt+l",
            "duplicate": "ctrl+d",
            "undo": "ctrl+z",
            "redo": "ctrl+y",
            "quantize": "ctrl+u",
            "split": "ctrl+e",
            "consolidate": "ctrl+j",
            "draw_mode": "b",
        }

        # macOS 기준 단축키
        # Ableton Live는 편집/보기 계열에서 Ctrl 대신 Command/Option 조합을 쓰는 경우가 많습니다.
        self.macos_hotkey_map = {
            "play_stop": "space",
            "record": "f9",
            "metronome": "c",
            "loop": "command+l",
            "view_toggle": "tab",
            "device_clip": "shift+tab",
            "browser": "command+option+b",
            "detail_view": "command+option+l",
            "duplicate": "command+d",
            "undo": "command+z",
            "redo": "command+shift+z",
            "quantize": "command+u",
            "split": "command+e",
            "consolidate": "command+j",
            "draw_mode": "b",
        }

        # 기존 코드 호환용: 다른 함수에서 self.hotkey_map을 참조하므로 현재 OS 기준으로 연결
        self.hotkey_map = self.macos_hotkey_map if IS_MACOS else self.windows_hotkey_map

        self.icon_map = {
            "play_stop": "PLAY_STOP",
            "record": "RECORD",
            "metronome": "METRONOME",
            "loop": "LOOP",
            "view_toggle": "VIEW_TOGGLE",
            "device_clip": "DEVICE_CLIP",
            "browser": "BROWSER",
            "detail_view": "DETAIL_VIEW",
            "duplicate": "DUPLICATE",
            "undo": "UNDO",
            "redo": "REDO",
            "quantize": "QUANTIZE",
            "split": "SPLIT",
            "consolidate": "CONSOLIDATE",
            "draw_mode": "DRAW_MODE",
            "osc": "OSC_API",
        }

    def _default_settings(self):
        return {
            "control_mode": "hotkey",
            "ableton_hotkey": self.default_hotkey_action,
            "command": self.default_hotkey_action,
            "osc_address": "",
            "osc_value": "",
            "osc_port": "9000",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[self.default_hotkey_action],
            "default_visuals_initialized": True
        }

    def _selection_key_from_settings(self, settings):
        mode = settings.get("control_mode", "hotkey")
        if mode == "osc":
            return "osc"
        return settings.get("ableton_hotkey") or settings.get("command") or self.default_hotkey_action

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})

        mode = merged.get("control_mode", "hotkey")
        if mode == "osc":
            merged["control_mode"] = "osc"
            merged["command"] = "osc"
            merged["builtin_icon_name"] = self.icon_map["osc"]
        else:
            action = merged.get("ableton_hotkey") or merged.get("command") or self.default_hotkey_action
            if action not in self.hotkey_map:
                action = self.default_hotkey_action
            merged["control_mode"] = "hotkey"
            merged["ableton_hotkey"] = action
            merged["command"] = action
            merged["builtin_icon_name"] = self.icon_map[action]

        lang = (merged.get("_lang") or "en").strip()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        merged["_lang"] = alias.get(lang, lang)
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("control_mode"),
            s.get("command"),
            s.get("ableton_hotkey"),
            s.get("osc_address"),
            s.get("osc_value"),
            s.get("osc_port"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False),
            s.get("_lang")
        ])

    def _get_builtin_icon_path(self, selection_key):
        icon_name = self.icon_map.get(selection_key or self.default_hotkey_action, self.icon_map[self.default_hotkey_action])
        path = os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")
        if os.path.exists(path):
            return path
        fallback = os.path.join(self.plugin_dir, "icon", "DEFAULT.png")
        return fallback if os.path.exists(fallback) else None

    async def _send_builtin_icon(self, context, selection_key):
        icon_path = self._get_builtin_icon_path(selection_key)
        if context and icon_path:
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, self.default_hotkey_action)
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            if context:
                await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        control_command = data.get("command") or payload.get("command")
        if control_command == "apply_builtin_icon":
            selection_key = (
                data.get("selection_key")
                or payload.get("selection_key")
                or self._selection_key_from_settings(self._merge_with_defaults(settings))
            )
            await self._send_builtin_icon(context, selection_key)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        context = data.get("context")
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = settings

        mode = settings.get("control_mode", "hotkey")

        if mode == "hotkey":
            action = settings.get("ableton_hotkey") or settings.get("command") or self.default_hotkey_action
            if action in self.hotkey_map:
                hotkey = self.hotkey_map[action]
                await asyncio.to_thread(self._send_hotkey, hotkey)

        elif mode == "osc":
            address = settings.get("osc_address", "").strip()
            val_str = settings.get("osc_value", "").strip()
            try:
                port = int(settings.get("osc_port", 9000))
            except Exception:
                port = 9000

            if not address:
                return
            if not address.startswith("/"):
                address = "/" + address

            value = None
            if val_str:
                try:
                    value = int(val_str)
                except ValueError:
                    try:
                        value = float(val_str)
                    except ValueError:
                        value = val_str

            await asyncio.to_thread(self._send_simple_osc, "127.0.0.1", port, address, value)

    def _normalize_hotkey_parts(self, hotkey):
        parts = []
        for part in str(hotkey).replace("-", "+").split("+"):
            p = part.strip().lower()
            if not p:
                continue

            aliases = {
                "cmd": "command",
                "command": "command",
                "win": "win",
                "windows": "win",
                "ctrl": "ctrl",
                "control": "ctrl",
                "alt": "option" if IS_MACOS else "alt",
                "option": "option" if IS_MACOS else "alt",
                "return": "enter",
                "esc": "escape",
            }
            parts.append(aliases.get(p, p))
        return parts

    def _send_hotkey(self, hotkey):
        """
        Windows에서는 keyboard 모듈을 우선 사용하고,
        macOS/Linux 또는 keyboard 미설치 환경에서는 pyautogui로 fallback합니다.

        macOS에서 pyautogui 단축키가 동작하려면:
        System Settings > Privacy & Security > Accessibility/Input Monitoring에서
        CookieDeck 또는 Python 실행 파일 권한이 필요할 수 있습니다.
        """
        try:
            if IS_WINDOWS and keyboard:
                keyboard.send(hotkey)
                return

            if not pyautogui:
                print(f"[{self.uuid}] pyautogui is not installed. Hotkey skipped: {hotkey}")
                return

            parts = self._normalize_hotkey_parts(hotkey)
            if not parts:
                return

            if len(parts) == 1:
                pyautogui.press(parts[0])
            else:
                pyautogui.hotkey(*parts)
            print(f"[{self.uuid}] Hotkey sent ({sys.platform}): {hotkey}")

        except Exception as e:
            print(f"[{self.uuid}] Hotkey send error ({sys.platform}): {hotkey} / {e}")

    def _send_simple_osc(self, ip, port, address, value):
        try:
            def osc_pad(b_str):
                pad_len = (4 - (len(b_str) % 4)) % 4
                return b_str + (b"\x00" * pad_len)

            msg = osc_pad(address.encode("utf-8"))

            if value is None:
                msg += osc_pad(b",")
            elif isinstance(value, int):
                msg += osc_pad(b",i")
                msg += struct.pack(">i", value)
            elif isinstance(value, float):
                msg += osc_pad(b",f")
                msg += struct.pack(">f", value)
            elif isinstance(value, str):
                msg += osc_pad(b",s")
                msg += osc_pad(value.encode("utf-8"))

            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(msg, (ip, port))
            sock.close()
            print(f"[{self.uuid}] OSC Sent: {address} -> {value} (Port: {port})")

        except Exception as e:
            print(f"[{self.uuid}] OSC send error: {e}")
