import asyncio
import os
import sys
import subprocess

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.windows_hotkey_map = {
            "left": "win+left",
            "right": "win+right",
            "maximize": "win+up",
            "minimize": "win+down",
            "monitor_prev": "win+shift+left",
            "monitor_next": "win+shift+right",
            "focus_mode": "win+home",
            "snap_layout": "win+z",
            "show_desktop": "win+d"
        }

        # macOS has native window tiling in recent versions, but the old Windows
        # Snap Layout popup does not exist as a 1:1 feature.  For stable behavior
        # we use Accessibility/AppleScript bounds control for the active window.
        self.macos_action_names = set(self.windows_hotkey_map.keys())

        self.icon_map = {
            "left": "STATE_LEFT",
            "right": "STATE_RIGHT",
            "maximize": "STATE_MAXIMIZE",
            "minimize": "STATE_MINIMIZE",
            "monitor_prev": "STATE_MONITOR_PREV",
            "monitor_next": "STATE_MONITOR_NEXT",
            "focus_mode": "STATE_FOCUS_MODE",
            "snap_layout": "STATE_SNAP_LAYOUT",
            "show_desktop": "STATE_SHOW_DESKTOP"
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "left", "STATE_LEFT")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if context and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "command", "win_action", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "left"
        new_settings = {
            "command": default_action,
            "win_action": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })
        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or settings.get("win_action") or "left")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {}) or {}
        selected_action = settings.get("command") or settings.get("win_action", "left")

        if IS_WINDOWS:
            hotkey_to_send = self.windows_hotkey_map.get(selected_action)
            if hotkey_to_send:
                await asyncio.to_thread(self._send_windows_hotkey, hotkey_to_send)
            return

        if IS_MACOS:
            await asyncio.to_thread(self._run_macos_window_action, selected_action)
            return

        # Linux fallback: common desktop shortcuts. Exact support depends on WM/DE.
        linux_map = {
            "left": "super+left",
            "right": "super+right",
            "maximize": "super+up",
            "minimize": "super+down",
            "show_desktop": "super+d",
        }
        hotkey = linux_map.get(selected_action)
        if hotkey:
            await asyncio.to_thread(self._send_pyautogui_hotkey, hotkey)

    def _send_windows_hotkey(self, hotkey):
        if keyboard_available:
            keyboard.send(hotkey)
        else:
            self._send_pyautogui_hotkey(hotkey)

    def _normalize_key(self, key):
        aliases = {
            "win": "win" if not IS_MACOS else "command",
            "windows": "win" if not IS_MACOS else "command",
            "cmd": "command",
            "control": "ctrl",
            "option": "option" if IS_MACOS else "alt",
            "alt": "option" if IS_MACOS else "alt",
        }
        return aliases.get(key.strip().lower(), key.strip().lower())

    def _send_pyautogui_hotkey(self, hotkey):
        if not pyautogui_available:
            return
        parts = [self._normalize_key(p) for p in hotkey.split('+') if p.strip()]
        if not parts:
            return
        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts)

    def _screen_size(self):
        if pyautogui_available:
            try:
                size = pyautogui.size()
                return int(size.width), int(size.height)
            except Exception:
                pass
        return 1440, 900

    def _run_osascript(self, script, timeout=2.0):
        try:
            subprocess.run(
                ["osascript", "-e", script],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=timeout,
                check=False,
            )
        except Exception:
            pass

    def _set_front_window_bounds(self, left, top, right, bottom):
        # System Events requires Accessibility permission for the app/python runtime.
        script = f'''
        tell application "System Events"
            set frontProc to first application process whose frontmost is true
            if exists window 1 of frontProc then
                set bounds of window 1 of frontProc to {{{int(left)}, {int(top)}, {int(right)}, {int(bottom)}}}
            end if
        end tell
        '''
        self._run_osascript(script)

    def _run_macos_window_action(self, action):
        w, h = self._screen_size()
        # Leave a small top margin for menu bar. Most apps still accept these bounds.
        top = 25
        bottom = max(top + 100, h)

        if action == "left":
            self._set_front_window_bounds(0, top, w // 2, bottom)
        elif action == "right":
            self._set_front_window_bounds(w // 2, top, w, bottom)
        elif action == "maximize":
            # Fill active desktop without forcing macOS Full Screen Space.
            self._set_front_window_bounds(0, top, w, bottom)
        elif action == "minimize":
            script = '''
            tell application "System Events"
                set frontProc to first application process whose frontmost is true
                if exists window 1 of frontProc then
                    try
                        set value of attribute "AXMinimized" of window 1 of frontProc to true
                    end try
                end if
            end tell
            '''
            self._run_osascript(script)
        elif action == "focus_mode":
            # Similar to Win+Home: hide other visible apps and keep the front app.
            script = '''
            tell application "System Events"
                set frontProc to first application process whose frontmost is true
                repeat with p in application processes
                    try
                        if visible of p is true and p is not frontProc then set visible of p to false
                    end try
                end repeat
            end tell
            '''
            self._run_osascript(script)
        elif action == "show_desktop":
            # macOS Show Desktop default shortcut. Requires Accessibility permission.
            self._send_pyautogui_hotkey("command+f3")
        elif action == "snap_layout":
            # No Windows 11 style Snap Layout popup on macOS; use Fill as closest safe action.
            self._set_front_window_bounds(0, top, w, bottom)
        elif action in ("monitor_prev", "monitor_next"):
            # No reliable universal macOS shortcut. Try native menu item first; otherwise no-op.
            direction = "Previous" if action == "monitor_prev" else "Next"
            script = f'''
            tell application "System Events"
                set frontProc to first application process whose frontmost is true
                try
                    click menu item "Move to {direction} Display" of menu 1 of menu bar item "Window" of menu bar 1 of frontProc
                end try
            end tell
            '''
            self._run_osascript(script)
