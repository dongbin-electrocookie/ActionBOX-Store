# Claude Code for COMBO-X (v1.0.0)

The Claude Code plugin contains only controls supported by Claude Code.

## Actions

- **Claude Code Status** — Idle, Thinking, Complete, Permission and Error artwork with matching status LED
- **Claude Code Voice** — sends the built-in Desktop dictation shortcut (`Ctrl+D` on Windows or `Command+D` on macOS)
- **Confirm / Cancel** — sends `Enter` (`Command+Enter` on macOS, which Claude Code Desktop uses to approve) or `Esc` to the focused application

Claude Code hooks are automatically installed or repaired. Local Claude transcript JSONL is also monitored as a read-only fallback when Desktop hooks do not execute.

Questions, choices, plan confirmation and permission requests all use the
existing Permission animation and LED. PreToolUse observes AskUserQuestion and
ExitPlanMode; hook/transcript tool-call IDs and elicitation IDs keep requests
pending until their own result, rejection or cancellation. Unrelated tool
activity and ordinary Stop events do not clear pending questions. Display
tracking never submits an answer or grants permission. After updating, show
the status action to repair hooks and fully quit/reopen Claude Code to load them.

The inspector uses equally sized **Claude Code Hook** status and removal
buttons. Installation status is red when missing and green when installed.
Clicking the status button keeps the existing install/repair action and opens
a full-quit/restart notice for the Claude desktop app. The lower diagnostic
details and manual status refresh button are removed. Labels and notices
support English, Korean, Japanese, German, Spanish, French, Italian,
Portuguese and Russian. The underlying hook/voice/approval behavior is unchanged.

The former `com.cookie.ai_monitor` Claude action IDs are retained so existing COMBO-X button assignments continue working after the plugin split. Existing AI Monitor user data is copied into the new `com.cookie.claude_code` data directory on first run.
