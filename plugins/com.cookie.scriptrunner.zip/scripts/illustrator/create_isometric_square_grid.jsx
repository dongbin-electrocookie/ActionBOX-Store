#target illustrator

// Illustrator 아이소메트릭 격자 (마름모꼴) 생성 스크립트
var cols = parseInt(prompt("가로 셀 수?", "10"));
var rows = parseInt(prompt("세로 셀 수?", "10"));
var size = parseFloat(prompt("한 셀의 한 변 길이(px)?", "30"));

if (isNaN(rows) || isNaN(cols) || isNaN(size)) {
  alert("숫자 입력이 잘못되었습니다.");
} else {
  var doc = app.activeDocument;
  var layer = doc.activeLayer;

  var dx = size * Math.cos(Math.PI / 6); // 30도 cos
  var dy = size * Math.sin(Math.PI / 6); // 30도 sin

  for (var row = 0; row < rows; row++) {
    for (var col = 0; col < cols; col++) {
      var x = (col - row) * dx;
      var y = (col + row) * dy;

      var diamond = layer.pathItems.add();
      var points = [
        [x, y],
        [x + dx, y + dy],
        [x, y + 2 * dy],
        [x - dx, y + dy]
      ];

      diamond.setEntirePath(points);
      diamond.closed = true;
      diamond.stroked = true;
      diamond.filled = false;
      diamond.strokeColor = makeGray(60);
    }
  }

  function makeGray(v) {
    var color = new GrayColor();
    color.gray = v;
    return color;
  }

  alert("아이소메트릭 마름모 격자 생성 완료!");
}
