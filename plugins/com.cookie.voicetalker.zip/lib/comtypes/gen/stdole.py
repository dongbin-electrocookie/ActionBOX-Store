from enum import IntFlag

import comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0 as __wrapper_module__
from comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0 import (
    Default, StdPicture, Gray, OLE_HANDLE, DISPPROPERTY, Unchecked,
    Font, OLE_XPOS_CONTAINER, OLE_OPTEXCLUSIVE, StdFont, FONTITALIC,
    OLE_YSIZE_CONTAINER, OLE_CANCELBOOL, EXCEPINFO, FONTBOLD,
    VARIANT_BOOL, DISPPARAMS, _check_version, OLE_YPOS_CONTAINER,
    dispid, COMMETHOD, OLE_XPOS_HIMETRIC, FONTNAME, OLE_XSIZE_PIXELS,
    OLE_YSIZE_HIMETRIC, Color, Checked, HRESULT,
    OLE_ENABLEDEFAULTBOOL, IPictureDisp, Library, Monochrome,
    IPicture, typelib_path, OLE_YPOS_HIMETRIC, IFontDisp, FontEvents,
    OLE_XSIZE_CONTAINER, OLE_XSIZE_HIMETRIC, OLE_COLOR, DISPMETHOD,
    Picture, VgaColor, OLE_YSIZE_PIXELS, GUID, FONTUNDERSCORE,
    IFontEventsDisp, IEnumVARIANT, IUnknown, CoClass, OLE_YPOS_PIXELS,
    OLE_XPOS_PIXELS, FONTSTRIKETHROUGH, IFont, BSTR, _lcid, FONTSIZE,
    IDispatch
)


class LoadPictureConstants(IntFlag):
    Default = 0
    Monochrome = 1
    VgaColor = 2
    Color = 4


class OLE_TRISTATE(IntFlag):
    Unchecked = 0
    Checked = 1
    Gray = 2


__all__ = [
    'LoadPictureConstants', 'OLE_ENABLEDEFAULTBOOL', 'IPictureDisp',
    'Library', 'Default', 'StdPicture', 'Monochrome', 'IPicture',
    'Gray', 'OLE_HANDLE', 'typelib_path', 'OLE_YPOS_HIMETRIC', 'Font',
    'Unchecked', 'OLE_XPOS_CONTAINER', 'OLE_OPTEXCLUSIVE', 'StdFont',
    'IFontDisp', 'FONTITALIC', 'FontEvents', 'OLE_XSIZE_CONTAINER',
    'OLE_XSIZE_HIMETRIC', 'OLE_TRISTATE', 'OLE_YSIZE_CONTAINER',
    'OLE_COLOR', 'Picture', 'VgaColor', 'OLE_CANCELBOOL',
    'OLE_YSIZE_PIXELS', 'FONTUNDERSCORE', 'IFontEventsDisp',
    'FONTBOLD', 'OLE_YPOS_PIXELS', 'OLE_XPOS_PIXELS',
    'FONTSTRIKETHROUGH', 'OLE_YPOS_CONTAINER', 'IFont',
    'OLE_XPOS_HIMETRIC', 'FONTNAME', 'FONTSIZE', 'OLE_XSIZE_PIXELS',
    'OLE_YSIZE_HIMETRIC', 'Color', 'Checked'
]

