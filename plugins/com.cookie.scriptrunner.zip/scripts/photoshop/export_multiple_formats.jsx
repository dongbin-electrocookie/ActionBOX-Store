#target photoshop

function safeFileName(name) {
    return name.replace(/[\\\/:*?"<>|]/g, "_").replace(/^\s+|\s+$/g, "") || "Untitled";
}

function uniqueFile(folder, baseName, extension) {
    var file = new File(folder.fsName + "/" + baseName + extension);
    var index = 2;
    while (file.exists) {
        file = new File(folder.fsName + "/" + baseName + "_" + index + extension);
        index++;
    }
    return file;
}

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else {
    var doc = app.activeDocument;
    var docName = safeFileName(doc.name.replace(/\.[^\.]+$/, ""));
    var exportFolder = new Folder(Folder.desktop + "/MultiExport");
    if (!exportFolder.exists && !exportFolder.create()) {
        alert("내보내기 폴더를 만들 수 없습니다.");
    } else {
        var copy = null;
        try {
            copy = doc.duplicate();
            copy.saveAs(uniqueFile(exportFolder, docName, ".psd"), new PhotoshopSaveOptions(), true, Extension.LOWERCASE);
            copy.close(SaveOptions.DONOTSAVECHANGES);

            copy = doc.duplicate();
            copy.flatten();
            var jpgOpts = new JPEGSaveOptions();
            jpgOpts.quality = 12;
            jpgOpts.embedColorProfile = true;
            jpgOpts.formatOptions = FormatOptions.STANDARDBASELINE;
            copy.saveAs(uniqueFile(exportFolder, docName, ".jpg"), jpgOpts, true, Extension.LOWERCASE);
            copy.close(SaveOptions.DONOTSAVECHANGES);

            copy = doc.duplicate();
            var pngOpts = new PNGSaveOptions();
            pngOpts.compression = 9;
            copy.saveAs(uniqueFile(exportFolder, docName, ".png"), pngOpts, true, Extension.LOWERCASE);
            copy.close(SaveOptions.DONOTSAVECHANGES);

            copy = doc.duplicate();
            var pdfOpts = new PDFSaveOptions();
            pdfOpts.layers = false;
            pdfOpts.preserveEditing = false;
            pdfOpts.jpegQuality = 12;
            copy.saveAs(uniqueFile(exportFolder, docName, ".pdf"), pdfOpts, true, Extension.LOWERCASE);
            copy.close(SaveOptions.DONOTSAVECHANGES);

            alert("PSD / JPG / PNG / PDF 저장 완료:\n" + exportFolder.fsName);
        } catch (e) {
            alert("다중 형식 저장 오류: " + e.message);
        } finally {
            if (copy) {
                try { copy.close(SaveOptions.DONOTSAVECHANGES); } catch (ignore) {}
            }
            app.activeDocument = doc;
        }
    }
}
