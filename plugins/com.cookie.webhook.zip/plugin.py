"""HTTP webhooks: isolated button settings, explicit auth and bounded results."""
import asyncio
import base64
import copy
import json
import os
import re
import socket
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

MAX_BODY = 1024 * 1024
MAX_HEADERS = 16 * 1024
MAX_RESPONSE = 8192
TIMEOUT = 3
HEADER_NAME = re.compile(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+$")
FORBIDDEN_HEADERS = {"host", "content-length", "transfer-encoding", "connection",
                     "proxy-authorization", "proxy-connection", "upgrade", "te", "trailer"}


class InvalidRequest(ValueError):
    """Only public result codes, never user input, belong in exceptions."""


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Do not forward secrets or implicitly change/retry a mutating request.
        return None


def strict_json(value, code):
    def constant(_value):
        raise InvalidRequest(code)
    try:
        return json.loads(value, parse_constant=constant)
    except (ValueError, TypeError, RecursionError):
        raise InvalidRequest(code) from None


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.last_valid_settings = {}  # keyed by full page/button context
        self.last_results = {}
        self.attempts = {}
        self.http = urllib.request.build_opener(NoRedirect())
        self.icon_map = {
            "GET": "webhook_icon",
            "POST": "webhook_icon",
            "PUT": "webhook_icon",
            "DELETE": "webhook_icon"
        }

    def _get_icon_path(self, method):
        icon_name = self.icon_map.get((method or "GET").upper(), "webhook_icon")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, method):
        # The host owns artwork. Never overwrite a user's custom icon.
        return

    def _remember(self, context, incoming, replace=False):
        previous = {} if replace else self.last_valid_settings.get(context, {})
        merged = copy.deepcopy(previous)
        merged.update(copy.deepcopy(incoming))  # empty values explicitly clear
        if "webhook_url" in incoming and "command" not in incoming:
            merged["command"] = incoming["webhook_url"]
        elif "command" in incoming:
            # Legacy profiles and the existing inspector prefer command when
            # both URL aliases are present. Explicit single-field clears still
            # clear both aliases rather than resurrecting a cached URL.
            merged["webhook_url"] = merged["command"] = incoming["command"] or incoming.get("webhook_url") or ""
        if merged != self.last_valid_settings.get(context):
            self.last_valid_settings[context] = merged
            self.last_results.pop(context, None)
        return self.last_valid_settings[context]

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return
        if settings:
            self._remember(context, settings, replace=True)
            return
        defaults = {"webhook_url": "", "command": "", "webhook_method": "GET",
                    "webhook_payload": "", "webhook_auth_type": "none", "webhook_headers": "",
                    "_lang": "en", "sync_title_on_request_change": False,
                    "builtin_icon_name": self.icon_map["GET"], "default_visuals_initialized": True}
        self._remember(context, defaults, replace=True)
        await self.runner.send_message({"event": "setSettings", "context": context, "payload": defaults})

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        if not context:
            return
        settings = payload.get("settings") if isinstance(payload.get("settings"), dict) else data.get("settings", {})
        if event in ("willAppear", "keyDidAppear"):
            await self._initialize_default_visuals_if_new(context, settings or {})
        elif event == "didReceiveSettings":
            self._remember(context, settings if isinstance(settings, dict) and settings else payload)
        elif event in ("willDisappear", "keyDidDisappear"):
            self.last_valid_settings.pop(context, None)
            self.last_results.pop(context, None)
            self.attempts.pop(context, None)
        elif event == "keyDown":
            await self.on_key_down(data)
        elif event == "sendToPlugin" and payload.get("command") == "getWebhookResult":
            await self._publish_result(context, self.last_results.get(context))

    @staticmethod
    def _header(name, value):
        if not isinstance(name, str) or not HEADER_NAME.fullmatch(name) or name.lower() in FORBIDDEN_HEADERS:
            raise InvalidRequest("RESULT_INVALID_HEADERS")
        if not isinstance(value, str) or any(ord(c) < 32 or ord(c) == 127 for c in value):
            raise InvalidRequest("RESULT_INVALID_HEADERS")
        try:
            value.encode("latin-1")
        except UnicodeError:
            raise InvalidRequest("RESULT_INVALID_HEADERS") from None
        return name.lower(), value

    def _headers(self, settings):
        raw = settings.get("webhook_headers") or ""
        if not isinstance(raw, (str, dict)) or len(str(raw)) > MAX_HEADERS:
            raise InvalidRequest("RESULT_INVALID_HEADERS")
        if isinstance(raw, dict):
            pairs = list(raw.items())
        elif raw.strip():
            try:
                pairs = json.loads(raw, object_pairs_hook=lambda items: items)
            except (ValueError, RecursionError):
                raise InvalidRequest("RESULT_INVALID_HEADERS") from None
            if not isinstance(pairs, list) or not raw.lstrip().startswith("{"):
                raise InvalidRequest("RESULT_INVALID_HEADERS")
        else:
            pairs = []
        if len(pairs) > 64:
            raise InvalidRequest("RESULT_INVALID_HEADERS")
        headers = {}
        for name, value in pairs:
            name, value = self._header(name, value)
            if name in headers:
                raise InvalidRequest("RESULT_HEADER_CONFLICT")
            headers[name] = value
        auth = settings.get("webhook_auth_type") or "none"
        if auth == "none":
            return headers
        if auth == "bearer":
            token = settings.get("webhook_bearer_token")
            if not isinstance(token, str) or not token.strip():
                raise InvalidRequest("RESULT_AUTH_REQUIRED")
            name, value = "Authorization", "Bearer " + token.strip()
        elif auth == "basic":
            user, password = settings.get("webhook_username"), settings.get("webhook_password")
            if not isinstance(user, str) or not user or ":" in user or not isinstance(password, str):
                raise InvalidRequest("RESULT_AUTH_REQUIRED")
            name = "Authorization"
            value = "Basic " + base64.b64encode((user + ":" + password).encode("utf-8")).decode("ascii")
        elif auth == "api_key":
            name, value = settings.get("webhook_api_key_name") or "X-API-Key", settings.get("webhook_api_key")
            if not isinstance(value, str) or not value.strip():
                raise InvalidRequest("RESULT_AUTH_REQUIRED")
        else:
            raise InvalidRequest("RESULT_AUTH_REQUIRED")
        name, value = self._header(name, value)
        if name in headers:
            raise InvalidRequest("RESULT_HEADER_CONFLICT")
        headers[name] = value
        return headers

    def _build_request(self, settings):
        url = settings.get("command") or settings.get("webhook_url") or ""
        if not isinstance(url, str):
            raise InvalidRequest("RESULT_INVALID_URL")
        url = url.strip()
        try:
            parsed = urllib.parse.urlsplit(url)
            valid = (parsed.scheme.lower() in ("http", "https") and parsed.hostname
                     and parsed.username is None and parsed.password is None
                     and not any(c.isspace() or ord(c) < 32 or ord(c) == 127 for c in url))
            _ = parsed.port
            if not valid:
                raise ValueError()
        except ValueError:
            raise InvalidRequest("RESULT_INVALID_URL") from None
        method = settings.get("webhook_method") or "GET"
        if not isinstance(method, str) or method.upper() not in self.icon_map:
            raise InvalidRequest("RESULT_INVALID_METHOD")
        headers = self._headers(settings)
        body = settings.get("webhook_payload") or ""
        if not isinstance(body, str) or len(body.encode("utf-8")) > MAX_BODY:
            raise InvalidRequest("RESULT_INVALID_JSON")
        data = None
        if method.upper() in ("POST", "PUT") and body.strip():
            mime = headers.setdefault("content-type", "application/json").split(";", 1)[0].strip().lower()
            if mime == "application/json" or mime.endswith("+json"):
                strict_json(body, "RESULT_INVALID_JSON")
            data = body.encode("utf-8")
        url = urllib.parse.urlunsplit(parsed._replace(fragment=""))
        return urllib.request.Request(url, data=data, headers=headers, method=method.upper()), headers

    @staticmethod
    def _redact(text, settings, headers):
        secrets = [str(settings.get(key) or "") for key in
                   ("webhook_bearer_token", "webhook_password", "webhook_api_key")]
        for name, value in headers.items():
            if name not in ("content-type", "accept", "user-agent"):
                secrets.append(value)
                if name == "authorization" and " " in value:
                    secrets.append(value.split(" ", 1)[1])
        url = str(settings.get("command") or settings.get("webhook_url") or "")
        secrets.append(url)
        parsed = urllib.parse.urlsplit(url)
        secrets.extend(value for _, value in urllib.parse.parse_qsl(parsed.query, keep_blank_values=False))
        secrets.extend(part for part in parsed.path.split("/") if len(part) >= 8)
        try:
            value = json.loads(text)
            def clean(node):
                if isinstance(node, dict):
                    return {key: "[REDACTED]" if re.search(r"token|password|secret|authorization|api.?key|cookie", key, re.I)
                            else clean(child) for key, child in node.items()}
                if isinstance(node, list):
                    return [clean(child) for child in node]
                return node
            text = json.dumps(clean(value), ensure_ascii=False, indent=2)
        except (ValueError, RecursionError):
            pass
        variants = set()
        for secret in secrets:
            if secret:
                variants.update((secret, urllib.parse.quote(secret, safe=""),
                                 urllib.parse.quote_plus(secret), json.dumps(secret, ensure_ascii=True)[1:-1]))
        for secret in sorted(variants, key=len, reverse=True):
            text = text.replace(secret, "[REDACTED]")
        return text[:MAX_RESPONSE]

    def _read_response(self, response, settings, headers):
        raw = response.read(MAX_RESPONSE + 1)
        content_type = (response.headers.get("Content-Type") or "").lower()
        binary = bool(content_type and not (content_type.startswith("text/") or "json" in content_type or "xml" in content_type))
        # A cut-off token cannot be reliably redacted. Omit oversized previews
        # instead of exposing a fragment of a credential at the read boundary.
        preview = "" if binary or len(raw) > MAX_RESPONSE else self._redact(raw.decode("utf-8", "replace"), settings, headers)
        return {"preview": preview, "truncated": len(raw) > MAX_RESPONSE, "binary": binary}

    def send_webhook(self, url=None, method=None, payload=None, *, settings=None):
        # Preserve the old helper signature, but never use shared settings.
        settings = settings if settings is not None else {"webhook_url": url, "webhook_method": method, "webhook_payload": payload}
        started = time.monotonic()
        result = {"code": "RESULT_FAILED", "status": None, "preview": "", "truncated": False, "binary": False}
        try:
            request, headers = self._build_request(settings)
            try:
                response = self.http.open(request, timeout=TIMEOUT)
            except urllib.error.HTTPError as exc:
                response = exc
            with response:
                status = int(response.getcode())
                result["status"] = status
                if 300 <= status < 400:
                    result["code"] = "RESULT_REDIRECT_BLOCKED"
                else:
                    result["code"] = "RESULT_SUCCESS" if 200 <= status < 300 else (
                        "RESULT_AUTH_DENIED" if status in (401, 403) else "RESULT_HTTP_ERROR")
                    try:
                        result.update(self._read_response(response, settings, headers))
                    except Exception:
                        # Do not retry: the server may have completed a mutation.
                        result["preview_unavailable"] = True
        except InvalidRequest as exc:
            result["code"] = str(exc)
        except (TimeoutError, socket.timeout):
            result["code"] = "RESULT_TIMEOUT"
        except ssl.SSLError:
            result["code"] = "RESULT_TLS_ERROR"
        except urllib.error.URLError as exc:
            result["code"] = ("RESULT_TIMEOUT" if isinstance(exc.reason, (TimeoutError, socket.timeout))
                              else "RESULT_TLS_ERROR" if isinstance(exc.reason, ssl.SSLError) else "RESULT_NETWORK_ERROR")
        except Exception:
            # Exceptions may contain URLs or credentials. Never print their text.
            result["code"] = "RESULT_FAILED"
        result["elapsed_ms"] = int((time.monotonic() - started) * 1000)
        print(f"[{self.uuid}] {result['code']} HTTP={result['status']} ({result['elapsed_ms']} ms)", flush=True)
        return result

    async def _publish_result(self, context, result):
        await self.runner.send_message({"event": "sendToPropertyInspector", "context": context,
                                        "payload": {"command": "webhookResult", "result": result}})

    async def on_key_down(self, data):
        context = data.get("context")
        if not context:
            return
        incoming = (data.get("payload") or {}).get("settings") or {}
        snapshot = self._remember(context, incoming)
        attempt = object()
        self.attempts[context] = attempt
        result = await asyncio.to_thread(self.send_webhook, settings=copy.deepcopy(snapshot))
        if self.last_valid_settings.get(context) is snapshot and self.attempts.get(context) is attempt:
            self.last_results[context] = result
            await self._publish_result(context, result)

    async def shutdown(self):
        self.last_valid_settings.clear()
        self.last_results.clear()
        self.attempts.clear()
