// No HTTP actions are sent here. Execution remains a physical/virtual keyDown.
window.WebhookFields = (() => {
    let result = null;
    const fields = () => document.querySelectorAll('[data-webhook-setting]');
    const text = name => langData[name] || name;
    return {
        restore(values) {
            for (const field of fields()) {
                const value = values[field.id] ?? field.dataset.webhookDefault ?? '';
                field.value = field.id === 'webhook_headers' && typeof value === 'object' ? JSON.stringify(value, null, 2) : value;
            }
            document.getElementById('webhook_auth_type').value = values.webhook_auth_type || 'none';
            this.update();
        },
        save(values) {
            for (const field of fields()) values[field.id] = field.value;
            result = null;
            this.render();
        },
        update() {
            const mode = document.getElementById('webhook_auth_type').value;
            for (const row of document.querySelectorAll('[data-webhook-auth]')) {
                row.classList.toggle('hidden', row.dataset.webhookAuth !== mode);
            }
        },
        setResult(value) { result = value; this.render(); },
        render() {
            const status = document.getElementById('webhook-result');
            const preview = document.getElementById('webhook-response');
            if (!status || !preview) return;
            status.textContent = result ? text(result.code) + (result.status != null ? ` (HTTP ${result.status})` : '') : text('RESULT_IDLE');
            if (result && Number.isFinite(result.elapsed_ms)) status.textContent += ` · ${result.elapsed_ms} ms`;
            const lines = [];
            if (result?.preview) lines.push(result.preview);
            if (result?.binary) lines.push(text('RESULT_BINARY'));
            if (result?.preview_unavailable) lines.push(text('RESULT_RESPONSE_UNREADABLE'));
            if (result?.truncated) lines.push(text('RESULT_TRUNCATED'));
            preview.textContent = lines.join('\n');
        }
    };
})();
