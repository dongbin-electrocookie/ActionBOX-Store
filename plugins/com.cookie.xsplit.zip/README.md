# COMBO-X XSplit integration

## First test

1. Restart COMBO-X so the updated shared-runtime plugin starts.
2. Place an XSplit action and click its red/green **XSplit connection** button.
   The button copies the extension's file URL and opens the localized instructions.
3. In XSplit: Extensions > Add extension > Add custom extension
   (the exact labels depend on the UI language/version).
4. Press Ctrl+V in the **URL** field and confirm. The copied file:/// URL points
   to **Combo-X Extend.html**, with spaces and non-ASCII path characters encoded.
   Do not add action_pi.html as the extension.
5. Keep the extension running. Both windows should show a connected status.
6. Lists refresh on connection or function selection. Choose the actual
   scene/item/output, then test the action. Clicking the connection button again
   also refreshes connected lists after copying the URL.

This source checkout's extension path is:
`C:\boxdev4\macos3\internal_plugins\com.cookie.xsplit\Combo-X Extend.html`
The connection button resolves the actual installed URL, including downloaded plugins.
No path field, refresh button, persistent instructions, or success messages are
shown in the inspector. Copy failures and user-triggered action errors use its
skin-aware HTML dialog, following the existing Codex connection-button pattern.

No XSplit extension is registered automatically. No XSplit process is restarted,
no broadcast is started on connection, and no keyboard/focus injection is used.
Closing the extension disconnects it; reopening it reconnects. Automatic startup
after XSplit restart has not been verified. COMBO-X keeps its bridge alive across
page changes through RunInBackground; unloading the plugin closes the listener.

## Operations

- Scene: official XJS Scene lookup and selection. In XSplit Split Mode this
  selects the preview scene, matching XJS's documented selection behavior.
- Source: scene item IDs and item visibility (linked source instances remain independent).
- Preset: the selected scene's preset UID.
- Stream / recording: canonical output/channel name, not display label. Query
  actual active stream channels on every press before starting/stopping.
- Microphone / speaker: XSplit application audio enable state, not Windows mute.
- Push to Live: in Split Mode, copy the current preview scene to the live scene
  using the host scene properties used by XJS. This path needs a real XSplit test
  for transition behavior; it does not call a guessed doPushToLive host function.
- Screenshot: retained in the catalog but explicitly reports unsupported.
  XJS 2.14.1 has no verified screenshot API. No foreground hotkey, desktop capture,
  or thumbnail is substituted.

Loopback WebSocket port **47653**, path **/combox-xsplit**. This is COMBO-X's own
listener, not an assumed built-in XSplit service. One XSplit extension may connect
at a time; other browser origins and invalid protocol handshakes are rejected.
Timeouts and disconnects are shown in the inspector and plugin console. Mutating
operations are never automatically retried because a timed-out toggle may already
have executed.

## Bundled library

The unmodified official `@splitmedialabs/xjs@2.14.1` browser bundle is shipped
locally in vendor/, with the original XSplit-specific license. No runtime CDN.
Package source: https://registry.npmjs.org/@splitmedialabs/xjs/-/xjs-2.14.1.tgz
Package SHA-512 integrity:
`79T1s3dwxg9pLOzLsejr4gR7Rz5UW87VpLvh/rPO5Y3oweNdYEjlKsEHxKl7g/vEEaHAEffjXd3bbq2C0yF57w==`

Official references:
- https://xjs.xsplit.com/tutorials/extension-plugins/
- https://xjs.xsplit.com/api/classes/scene/
- https://xjs.xsplit.com/api/classes/output/
- https://xjs.xsplit.com/api/classes/app/
