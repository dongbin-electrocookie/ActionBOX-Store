import asyncio
import urllib.request
import urllib.parse
import os

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}
        self.default_icon_path = os.path.join(self.plugin_dir, "icon", "DEFAULT.png")

    def _default_settings(self):
        return {
            "command": "",
            "ifttt_event": "",
            "ifttt_key": "",
            "_lang": "en",
            "sync_title_on_event_change": False,
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        merged["command"] = merged.get("command") or merged.get("ifttt_event") or ""
        merged["ifttt_event"] = merged.get("ifttt_event") or merged.get("command") or ""
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("ifttt_event"),
            s.get("ifttt_key"),
            s.get("title"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_event_change", False)
        ])

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            if os.path.exists(self.default_icon_path):
                await self.runner.send_message({
                    "event": "setIcon",
                    "context": context,
                    "payload": {"icon_path": self.default_icon_path}
                })
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    def send_ifttt(self, event_name, webhook_key):
        if not event_name or not webhook_key:
            print(f"[{self.uuid}] Missing Event Name or Webhook Key.")
            return

        safe_event = urllib.parse.quote(event_name)
        url = f"https://maker.ifttt.com/trigger/{safe_event}/with/key/{webhook_key}"

        try:
            req = urllib.request.Request(url, method='POST')
            with urllib.request.urlopen(req, timeout=3):
                print(f"[{self.uuid}] IFTTT sent successfully: {event_name}")
        except Exception as e:
            print(f"[{self.uuid}] IFTTT send failed: {e}")

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        final_settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = final_settings

        event_name = (final_settings.get("command") or final_settings.get("ifttt_event") or "").strip()
        webhook_key = (final_settings.get("ifttt_key") or "").strip()

        if event_name and webhook_key:
            await asyncio.to_thread(self.send_ifttt, event_name, webhook_key)
        else:
            print(f"[{self.uuid}] Missing required data for execution.")
