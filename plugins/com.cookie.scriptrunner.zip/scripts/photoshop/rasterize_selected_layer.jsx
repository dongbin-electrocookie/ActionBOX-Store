#target photoshop

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else {
    try {
        var layer = app.activeDocument.activeLayer;
        if (layer.isBackgroundLayer || layer.allLocked) {
            alert("배경 또는 잠긴 레이어는 래스터화할 수 없습니다.");
        } else if (layer.kind === LayerKind.SMARTOBJECT) {
            layer.rasterize(RasterizeType.ENTIRELAYER);
        } else {
            alert("선택한 레이어는 스마트 오브젝트가 아닙니다.");
        }
    } catch (e) {
        alert("래스터화 오류: " + e.message);
    }
}
