import json
import urllib.request
import asyncio

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        
        # 🚀 멀티액션 호환 패치 (혹시 문자열로 넘어올 경우를 대비한 보험)
        if isinstance(settings, str) and settings.startswith("{"):
            try:
                settings = json.loads(settings)
            except Exception:
                pass
        
        if not isinstance(settings, dict):
            settings = {}

        # 설정값 가져오기 (기본값 세팅)
        ip = settings.get("ip", "127.0.0.1")
        port = settings.get("port", "8000")
        page = settings.get("page", "1")
        row = settings.get("row", "0")
        col = settings.get("col", "0")

        # Companion v3 API URL (Press Action)
        url = f"http://{ip}:{port}/api/location/{page}/{row}/{col}/press"

        # 메인 스레드(UI)가 멈추지 않도록 비동기 스레드에서 HTTP 요청 전송
        def make_request():
            try:
                # Companion API는 POST 요청을 권장합니다.
                req = urllib.request.Request(url, method="POST")
                with urllib.request.urlopen(req, timeout=1.0) as response:
                    print(f"[Companion] Triggered {page}/{row}/{col} -> Status: {response.status}")
            except Exception as e:
                print(f"[Companion Error] Failed to trigger URL ({url}): {e}")

        asyncio.create_task(asyncio.to_thread(make_request))