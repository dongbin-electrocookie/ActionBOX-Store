import asyncio
import urllib.request
import urllib.parse
import json
import os
import ssl
import traceback
from PIL import Image, ImageDraw, ImageFont

# 🚀 [추가됨] SSL 보안 인증서 검사를 강제로 무시하여 통신 차단을 뚫어줍니다.
ssl_ctx = ssl.create_default_context()
ssl_ctx.check_hostname = False
ssl_ctx.verify_mode = ssl.CERT_NONE

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        
        self.active_buttons = {} 
        self.loop_started = False

    async def auto_update_loop(self):
        while True:
            await asyncio.sleep(900) 
            for context, settings in list(self.active_buttons.items()):
                await self.update_weather_action(context, settings)

    async def handle_message(self, data):
        # print(f"👀 [데이터 수신 확인]: {data}") # 이제 원인을 알았으니 이 줄은 지우시거나 주석 처리하셔도 됩니다!
        try:
            # 포장지(event, payload)가 있을 수도 있고, 이미 벗겨진 상태(data 직통)일 수도 있으니 양쪽 모두에서 찾습니다!
            event = data.get("event")
            payload = data.get("payload", {})
            
            command = payload.get("command") or data.get("command")
            context = payload.get("context") or data.get("context")
            settings = payload.get("settings") or data.get("settings", {})

            if not self.loop_started:
                self.loop_started = True
                asyncio.create_task(self.auto_update_loop())

            if event == "willAppear":
                self.active_buttons[context] = settings
                await self.update_weather_action(context, settings)

            elif event == "willDisappear":
                if context in self.active_buttons:
                    del self.active_buttons[context]

            elif event == "keyDown":
                self.active_buttons[context] = settings
                await self.update_weather_action(context, settings)

            # 🚀 [핵심 수정] event가 없더라도, command가 존재하면 바로 실행하도록 조건문 변경!
            elif event == "sendToPlugin" or command:
                if command == "search_city":
                    # 검색어도 payload와 data 양쪽에서 찾아봅니다.
                    query = payload.get("query") or data.get("query", "")
                    if query:
                        print(f"🔍 [검색 요청 수신] 사용자가 검색한 단어: '{query}'")
                        results = await asyncio.to_thread(self.search_location, query)
                        
                        await self.runner.send_message({
                            "event": "sendToPropertyInspector",
                            "context": context,
                            "payload": {"command": "search_results", "results": results}
                        })
                        print(f"✅ [검색 완료] UI로 결과 전송 완료! ({len(results)}개 찾음)")
                        
                elif command == "force_update":
                    new_settings = settings
                    self.active_buttons[context] = new_settings
                    await self.update_weather_action(context, new_settings)
                    
        except Exception as e:
            print(f"❌ [에러 발생] 플러그인 내부 동작 중 오류: {e}")
            import traceback
            traceback.print_exc()

    def search_location(self, query):
        try:
            safe_query = urllib.parse.quote(query)
            url = f"https://geocoding-api.open-meteo.com/v1/search?name={safe_query}&count=5&language=ko&format=json"
            
            # 브라우저인 척 위장 (User-Agent 강화)
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
            
            # context=ssl_ctx 로 강제 우회 적용
            with urllib.request.urlopen(req, timeout=5, context=ssl_ctx) as res:
                data = json.loads(res.read().decode('utf-8'))
                
                results = []
                if "results" in data:
                    for item in data["results"]:
                        results.append({
                            "name": item.get("name", "알 수 없음"),
                            "country": item.get("country", "국가 없음"),
                            "lat": round(item.get("latitude", 0), 4),
                            "lon": round(item.get("longitude", 0), 4)
                        })
                return results
        except Exception as e:
            print(f"❌ [{self.uuid}] 장소 검색 API 호출 오류: {e}")
            return []

    def fetch_weather_image(self, lat, lon, city_name, units, context):
        if not lat or not lon:
            return None

        try:
            print(f"🌤️ [날씨 요청] 위도:{lat}, 경도:{lon} 날씨를 가져옵니다...")
            url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true"
            if units == 'fahrenheit':
                url += "&temperature_unit=fahrenheit"
                
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
            
            # context=ssl_ctx 로 강제 우회 적용
            with urllib.request.urlopen(req, timeout=10, context=ssl_ctx) as res:
                weather_data = json.loads(res.read().decode('utf-8'))

            current = weather_data.get('current_weather', {})
            temp = current.get('temperature', 0)
            code = current.get('weathercode', 0) 
            
            symbol = "°C" if units == 'celsius' else "°F"
            temp_str = f"{temp}{symbol}"

            if code == 0:
                bg_color = (41, 128, 185)
                kor_cond = "맑음"
            elif code in [1, 2, 3, 45, 48]:
                bg_color = (127, 140, 141)
                kor_cond = "흐림"
            elif code in [51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82]:
                bg_color = (52, 73, 94)
                kor_cond = "비 옴"
            elif code in [71, 73, 75, 77, 85, 86]:
                bg_color = (149, 165, 166)
                kor_cond = "눈 옴"
            elif code in [95, 96, 99]:
                bg_color = (44, 62, 80)
                kor_cond = "천둥/번개"
            else:
                bg_color = (127, 140, 141)
                kor_cond = "알 수 없음"

            img = Image.new('RGB', (128, 128), color=bg_color)
            draw = ImageDraw.Draw(img)

            try:
                # 1. 도시 폰트를 굵은 글씨체(malgunbd)로 바꾸고, 크기를 16 -> 24로 대폭 키웁니다!
                font_city = ImageFont.truetype("malgunbd.ttf", 24) 
                font_temp = ImageFont.truetype("malgunbd.ttf", 36)
                font_cond = ImageFont.truetype("malgun.ttf", 20)
            except:
                font_city = font_temp = font_cond = ImageFont.load_default()

            def draw_centered_text(y_pos, text, font, fill_color):
                try:
                    bbox = font.getbbox(text)
                    w = bbox[2] - bbox[0]
                except AttributeError:
                    w = len(text) * 10
                x_pos = (128 - w) / 2
                draw.text((x_pos, y_pos), text, font=font, fill=fill_color)

            display_city = city_name[:8] + ".." if len(city_name) > 8 else city_name
            if not display_city:
                display_city = "위치 지정됨"

            draw_centered_text(8, display_city, font_city, (255, 255, 255))
            draw_centered_text(45, temp_str, font_temp, (255, 255, 255))
            draw_centered_text(95, kor_cond, font_cond, (241, 196, 15))

            save_path = os.path.join(self.plugin_dir, f"weather_{context}.png")
            img.save(save_path)
            
            print(f"✅ [날씨 그리기 완료] 이미지 저장 성공!")
            return save_path

        except Exception as e:
            print(f"❌ [{self.uuid}] 날씨 가져오기 오류: {e}")
            return None

    async def update_weather_action(self, context, settings):
        lat = settings.get("lat", "")
        lon = settings.get("lon", "")
        units = settings.get("units", "celsius")
        city_name = settings.get("last_query", "위치 지정됨")

        if not lat or not lon:
            return

        await self.runner.send_message({
            "event": "setTitle",
            "context": context,
            "payload": {"title": "로딩중..."}
        })

        icon_path = await asyncio.to_thread(self.fetch_weather_image, lat, lon, city_name, units, context)

        if icon_path:
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": ""}
            })
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })
        else:
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": "날씨\n오류"}
            })