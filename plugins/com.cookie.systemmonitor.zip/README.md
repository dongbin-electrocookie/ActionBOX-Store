# COMBO-X System Monitor 1.0.0

Windows system-monitor plugin for COMBO-X using LibreHardwareMonitor.

## 1.0.0

- Displays CPU, memory, GPU, network, and power information on COMBO-X.
- Keeps live monitor state page-scoped so values do not leak to other pages or slots.
- Clears stale live text when an action disappears and resets runtime state after reconnects.
- Deduplicates dynamic updates and delays startup updates during the initial device synchronization.
- Keeps the COMBO-X desktop preview icon-only while live values are sent to the physical device.
- Property Inspector follows the current COMBO-X context/settings conventions.
- Metric icon changes are page-scoped and preserve user-provided custom icons.
- Built-in icon artwork is normalized to remain inside the key canvas.
- LibreHardwareMonitor connection honors configured listener IP/port, with IPv4 and loopback fallbacks.
- Network throughput selects an active/high-throughput interface and uses compact values.
- Missing sensor data is shown as N/A instead of a misleading zero.
