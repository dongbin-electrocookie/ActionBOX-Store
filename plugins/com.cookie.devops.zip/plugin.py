import asyncio
import urllib.request
import json

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.polling_tasks = {}
        self.active_contexts = {} # 🚀 꼬리표(target_page)를 기억할 보관함

    async def handle_message(self, data):
        event = data.get("event", "")
        context = data.get("context")
        payload = data.get("payload") or {}
        action_id = data.get("action") or self.active_contexts.get(context, {}).get("action")

        if not context: return

        # 🧟 좀비 킬러
        if "disappear" in event.lower() or "delete" in event.lower() or "remove" in event.lower() or "clear" in event.lower():
            if context in self.polling_tasks:
                self.polling_tasks[context].cancel()
                del self.polling_tasks[context]
            self.active_contexts.pop(context, None)
            return

        # 🚀 [버그 해결 1] payload 자체가 설정값일 경우를 대비한 철벽 방어!
        settings = payload.get("settings") if "settings" in payload else payload

        if event in ["willAppear", "keyDidAppear", "didReceiveSettings"]:
            target_page = payload.get("page") or self.active_contexts.get(context, {}).get("page")
            
            # 꼬리표와 액션 ID 기억하기
            self.active_contexts[context] = {"action": action_id, "page": target_page}

            # 기존에 돌고 있던 갱신 루프가 있다면 끄고 새로 시작
            if context in self.polling_tasks:
                self.polling_tasks[context].cancel()
                
            self.polling_tasks[context] = asyncio.create_task(
                self.start_polling(context, action_id, settings, target_page)
            )

        elif event == "keyDown":
            target_page = payload.get("page", self.active_contexts.get(context, {}).get("page"))
            await self.on_key_down(context, action_id, settings, target_page)


    async def start_polling(self, context, action_id, settings, target_page):
        """1분마다 주기적으로 서버 상태를 모니터링하는 백그라운드 스레드"""
        while True:
            try:
                action_type = settings.get("action_type", "monitor")
                
                if action_type == "monitor" and action_id:
                    if "vercel" in action_id:
                        await self.check_vercel_status(context, settings, target_page)
                    elif "netlify" in action_id:
                        await self.check_netlify_status(context, settings, target_page)
                    elif "cloudflare" in action_id:
                        await self.check_cloudflare_status(context, settings, target_page)
                    elif "railway" in action_id:
                        await self.check_railway_status(context, settings, target_page)
                    elif "github" in action_id:
                        await self.check_github_status(context, settings, target_page)
            except Exception as e:
                print(f"Polling error: {e}")

            await asyncio.sleep(60) # 1분마다 갱신

    # ==========================================
    # 🌐 플랫폼별 API 모니터링 로직
    # ==========================================
    async def _fetch_api(self, req):
        def fetch():
            try:
                with urllib.request.urlopen(req) as response:
                    return json.loads(response.read().decode())
            except Exception as e:
                print(f"API 호출 실패: {e}")
                return None
        return await asyncio.to_thread(fetch)

    async def check_vercel_status(self, context, settings, target_page):
        api_key, project_id = settings.get("api_key"), settings.get("project_id")
        if not api_key or not project_id:
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "설정\n필요", "page": target_page}})
            return
        req = urllib.request.Request(f"https://api.vercel.com/v6/deployments?projectId={project_id}&limit=1", headers={"Authorization": f"Bearer {api_key}"})
        res = await self._fetch_api(req)
        if res and "deployments" in res and res["deployments"]:
            state = res["deployments"][0].get("state", "UNKNOWN")
            title = {"READY": "✅\nReady", "ERROR": "❌\nError", "BUILDING": "🔄\nBuilding"}.get(state, f"⚠️\n{state}")
        else:
            title = "❌\nAPI Err"
        await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": title, "page": target_page}})

    async def check_netlify_status(self, context, settings, target_page):
        api_key, site_id = settings.get("api_key"), settings.get("project_id")
        if not api_key or not site_id: 
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "설정\n필요", "page": target_page}})
            return
        req = urllib.request.Request(f"https://api.netlify.com/api/v1/sites/{site_id}/deploys?per_page=1", headers={"Authorization": f"Bearer {api_key}"})
        res = await self._fetch_api(req)
        if res and len(res) > 0:
            state = res[0].get("state", "unknown")
            title = {"ready": "✅\nReady", "error": "❌\nError", "building": "🔄\nBuilding"}.get(state, f"⚠️\n{state}")
        else:
            title = "❌\nAPI Err"
        await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": title, "page": target_page}})

    async def check_github_status(self, context, settings, target_page):
        api_key, repo = settings.get("api_key"), settings.get("project_id")
        if not api_key or not repo:
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "설정\n필요", "page": target_page}})
            return
            
        # 🚀 [버그 해결 2] GitHub API는 User-Agent 헤더가 없으면 403 에러를 뱉습니다!
        req = urllib.request.Request(
            f"https://api.github.com/repos/{repo}/actions/runs?per_page=1", 
            headers={
                "Authorization": f"token {api_key}", 
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "CookieDeck-App" # 필수 항목!
            }
        )
        res = await self._fetch_api(req)
        
        if res and "workflow_runs" in res:
            if res["workflow_runs"]:
                status = res["workflow_runs"][0].get("status")
                conclusion = res["workflow_runs"][0].get("conclusion")
                title = "🔄\nRunning" if status in ["in_progress", "queued"] else ("✅\nSuccess" if conclusion == "success" else "❌\nFailed")
            else:
                title = "⚠️\nNo Run" # 실행 내역이 없을 때
        else:
            title = "❌\nAPI Err" # 토큰이 틀렸거나 권한이 없을 때
            
        await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": title, "page": target_page}})

    async def check_cloudflare_status(self, context, settings, target_page):
        await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "☁️\nCF Ready", "page": target_page}})

    async def check_railway_status(self, context, settings, target_page):
        await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "🚂\nRW Ready", "page": target_page}})

    # ==========================================
    # ⚡ 액션 실행 로직 (강제 재배포 / Webhook)
    # ==========================================
    async def on_key_down(self, context, action_id, settings, target_page):
        action_type = settings.get("action_type", "monitor")

        if action_type == "redeploy":
            webhook_url = settings.get("webhook_url")
            if not webhook_url: return

            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "🚀\nSending", "page": target_page}})
            try:
                req = urllib.request.Request(webhook_url, method="POST")
                
                # 🚀 Webhook 전송 시에도 깃허브는 User-Agent를 요구합니다!
                if action_id and "github" in action_id:
                    req.add_header("Authorization", f"token {settings.get('api_key')}")
                    req.add_header("Accept", "application/vnd.github.v3+json")
                    req.add_header("User-Agent", "CookieDeck-App")
                    
                await asyncio.to_thread(lambda: urllib.request.urlopen(req))
                await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "✅\nSent", "page": target_page}})
            except Exception as e:
                print(f"Webhook 전송 실패: {e}")
                await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "❌\nFail", "page": target_page}})