# TikTok LIVE Studio

The inspectors request refreshes through `sendToPlugin`, without saving or
clearing the selected scene/source/title. LIVE Studio sync pushes are forwarded
to open inspectors. Source choices use the full `sources` list and its
`label`/`value` fields, including hidden sources.

Change Scene is temporarily absent from the manifest action list. On the local
LIVE Studio 1.38.0 installation, list retrieval worked but the official scene
command returned failure and no scene change was observed. The implementation,
translations and existing bindings are retained for later compatibility work.
Show / Hide Source was verified against the running application, including
restoring the original visibility after the test.

Regression checks:

- `tests/test_tiktok_sync.py`: real host routing and a local Socket.IO test server.
- `tests/test_tiktok_plugin_icons.py`: catalog, artwork and action dispatch.
- `tools/test_tiktok_controls.py`: actual Chromium inspectors, all 10 locale
  files, normal/popup settings, hidden sources, timeout and recovery.
