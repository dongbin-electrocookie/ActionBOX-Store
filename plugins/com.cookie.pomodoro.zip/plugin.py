import asyncio
import os
import sys

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

try:
    import winsound
except ImportError:
    winsound = None

class Plugin:
    SETTINGS_SCHEMA_VERSION = 2

    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get('UUID', 'com.cookie.pomodoro')
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.timers = {}
        self.default_icon_name = "TIMER"

        self.i18n = {
            "en": {"MODE_WORK": "WORK", "MODE_REST": "REST", "STATUS_RUNNING": "Running", "STATUS_PAUSED": "Paused"},
            "ko": {"MODE_WORK": "작업", "MODE_REST": "휴식", "STATUS_RUNNING": "실행중", "STATUS_PAUSED": "일시정지"},
            "ja": {"MODE_WORK": "作業", "MODE_REST": "休憩", "STATUS_RUNNING": "実行中", "STATUS_PAUSED": "一時停止"},
            "de": {"MODE_WORK": "ARBEIT", "MODE_REST": "PAUSE", "STATUS_RUNNING": "Läuft", "STATUS_PAUSED": "Pausiert"},
            "es": {"MODE_WORK": "TRABAJO", "MODE_REST": "DESCANSO", "STATUS_RUNNING": "En marcha", "STATUS_PAUSED": "Pausado"},
            "fr": {"MODE_WORK": "TRAVAIL", "MODE_REST": "PAUSE", "STATUS_RUNNING": "En cours", "STATUS_PAUSED": "En pause"},
            "ru": {"MODE_WORK": "РАБОТА", "MODE_REST": "ОТДЫХ", "STATUS_RUNNING": "Работает", "STATUS_PAUSED": "Пауза"},
            "it": {"MODE_WORK": "LAVORO", "MODE_REST": "PAUSA", "STATUS_RUNNING": "In esecuzione", "STATUS_PAUSED": "In pausa"},
            "pt-PT": {"MODE_WORK": "TRABALHO", "MODE_REST": "PAUSA", "STATUS_RUNNING": "Em execução", "STATUS_PAUSED": "Em pausa"}
        }

    def _lang(self, settings):
        lang = (settings.get("_lang") or "en").lower()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        lang = alias.get(lang, lang)
        return lang if lang in self.i18n else "en"

    def _t(self, settings, key):
        lang = self._lang(settings)
        return self.i18n.get(lang, self.i18n["en"]).get(key, key)

    def _get_icon_path(self):
        return os.path.join(self.plugin_dir, "icon", f"{self.default_icon_name}.png")

    async def _send_builtin_icon(self, context):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path()
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    def _build_default_settings(self):
        return {
            "work_time": 25,
            "rest_time": 5,
            "_lang": "en",
            "show_timer_on_title": True,
            "builtin_icon_name": self.default_icon_name,
            "default_visuals_initialized": True,
            "_timer_settings_version": self.SETTINGS_SCHEMA_VERSION
        }

    @staticmethod
    def _page_from_context(context):
        if isinstance(context, str) and context.startswith("p") and ":" in context:
            page_part = context.split(":", 1)[0][1:]
            if page_part.isdigit():
                return int(page_part)
        return None

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return {}

        settings = dict(settings or {})
        try:
            settings_version = int(settings.get("_timer_settings_version", 0) or 0)
        except (TypeError, ValueError):
            settings_version = 0

        # Version 1 used a hidden timer as the default. It still counted
        # down, but emitted no visible feedback. Migrate once so future
        # user changes to the checkbox remain respected.
        if settings_version < self.SETTINGS_SCHEMA_VERSION:
            migrated = self._build_default_settings()
            migrated.update(settings)
            migrated["show_timer_on_title"] = True
            migrated["_timer_settings_version"] = self.SETTINGS_SCHEMA_VERSION
            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": migrated
            })
            settings = migrated

        return settings

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        settings = payload.get("settings", {}) or {}
        command = payload.get("command")

        if not context:
            return

        if event in ["willAppear", "keyDidAppear"]:
            settings = await self._initialize_default_visuals_if_new(context, settings)
            if context not in self.timers:
                self._init_timer_state(context, settings, payload.get("page"))
            else:
                self.timers[context]["settings"].update(settings)
                if payload.get("page") is not None:
                    self.timers[context]["page"] = int(payload.get("page"))
            if self.timers[context]["settings"].get("show_timer_on_title"):
                await self._update_display(context)
            return

        if event == "didReceiveSettings":
            # COMBO-X can deliver settings either under payload.settings or
            # directly as the payload, depending on which editor path saved them.
            incoming_settings = settings
            if not incoming_settings and isinstance(payload, dict):
                if any(k in payload for k in ("work_time", "rest_time", "show_timer_on_title", "_lang")):
                    incoming_settings = payload

            state = self.timers.get(context)
            if state is None:
                self._init_timer_state(context, incoming_settings, payload.get("page"))
                state = self.timers.get(context)
            elif incoming_settings:
                old_work = self._minutes(state["settings"].get("work_time"), 25)
                old_rest = self._minutes(state["settings"].get("rest_time"), 5)
                new_work = self._minutes(incoming_settings.get("work_time", old_work), old_work)
                new_rest = self._minutes(incoming_settings.get("rest_time", old_rest), old_rest)

                state["settings"].update(incoming_settings)
                if payload.get("page") is not None:
                    state["page"] = int(payload.get("page"))

                # Changing either duration is defined as a timer reset.  This is
                # important for the popup Key Editor path: that path persists
                # settings through the parent and does not send reset_timer
                # directly to the plugin.  Reset here so both the real timer and
                # the Key Editor/device title immediately show the new work time.
                if old_work != new_work or old_rest != new_rest:
                    if state.get("task") and not state["task"].done():
                        state["task"].cancel()
                    state["task"] = None
                    state["mode"] = "work"
                    state["time_left"] = new_work * 60
                    state["is_running"] = False

            if state and state["settings"].get("show_timer_on_title"):
                await self._update_display(context)
            return

        if event == "keyDown":
            state = self.timers.get(context)
            if not state:
                self._init_timer_state(context, settings)
                state = self.timers.get(context)

            incoming_settings = payload.get("settings", {}) or {}
            if incoming_settings:
                state["settings"].update(incoming_settings)

            state["is_running"] = not state["is_running"]
            if state["is_running"]:
                if state["task"] is None or state["task"].done():
                    state["task"] = asyncio.create_task(self._timer_loop(context))

            if state["settings"].get("show_timer_on_title"):
                await self._update_display(context)

        elif event == "sendToPlugin" and command == "reset_timer":
            self._init_timer_state(context, settings, payload.get("page"))
            state = self.timers.get(context)
            if state and state["settings"].get("show_timer_on_title"):
                await self._update_display(context)

    @staticmethod
    def _minutes(value, default):
        try:
            value = int(value)
        except (TypeError, ValueError):
            value = int(default)
        return max(1, value)

    def _init_timer_state(self, context, settings, page=None):
        work_time = self._minutes(settings.get("work_time", 25), 25) * 60
        if context in self.timers and self.timers[context].get("task"):
            self.timers[context]["task"].cancel()
        self.timers[context] = {
            "task": None,
            "time_left": work_time,
            "is_running": False,
            "mode": "work",
            "settings": settings.copy() if isinstance(settings, dict) else {},
            "page": (
                int(page)
                if page is not None
                else self._page_from_context(context)
            )
        }

    async def _timer_loop(self, context):
        try:
            while self.timers[context]["is_running"]:
                await asyncio.sleep(1)
                state = self.timers[context]
                state["time_left"] -= 1
                if state["time_left"] <= 0:
                    await self._handle_time_up(context, state)
                if state["settings"].get("show_timer_on_title"):
                    await self._update_display(context)
        except asyncio.CancelledError:
            pass

    def _play_notification_sound_sync(self):
        if IS_WINDOWS and winsound:
            try:
                winsound.MessageBeep(winsound.MB_ICONASTERISK)
                return
            except Exception:
                pass

        # Cross-platform fallback: terminal/system bell.
        # On macOS packaged apps this may be silent, but it does not break the timer.
        try:
            print("\a", end="", flush=True)
        except Exception:
            pass

    async def _handle_time_up(self, context, state):
        await asyncio.to_thread(self._play_notification_sound_sync)
        settings = state["settings"]
        if state["mode"] == "work":
            state["mode"] = "rest"
            state["time_left"] = self._minutes(settings.get("rest_time", 5), 5) * 60
        else:
            state["mode"] = "work"
            state["time_left"] = self._minutes(settings.get("work_time", 25), 25) * 60
        state["is_running"] = False

    def _build_display_text(self, state):
        mins, secs = divmod(state["time_left"], 60)
        time_str = f"{mins:02d}:{secs:02d}"
        settings = state.get("settings", {})
        mode_text = self._t(settings, "MODE_WORK") if state["mode"] == "work" else self._t(settings, "MODE_REST")
        status_text = self._t(settings, "STATUS_RUNNING") if state["is_running"] else self._t(settings, "STATUS_PAUSED")
        return f"[{mode_text}]\n{time_str}\n{status_text}"

    async def _update_display(self, context):
        state = self.timers.get(context)
        if not state:
            return
        display_text = self._build_display_text(state)
        await self.runner.send_message({
            "event": "setTitle",
            "context": context,
            "payload": {
                "title": display_text,
                "page": state.get("page")
            }
        })
