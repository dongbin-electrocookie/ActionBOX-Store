import asyncio
import base64
import hashlib
import json
import os
import sys
import time
import traceback

import websockets


class OBSPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.obs"
        self.uri = "ws://localhost:8765"
        self.cd_ws = None
        self.obs_ws = None
        self.obs_connected = False

        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_file = os.path.join(self.plugin_dir, "obs_config.json")
        self.desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")

        self.last_valid_settings = {}
        self.pending_requests = {}
        self.config = {"ip": "localhost", "port": 4455, "password": ""}
        self.load_config()

        self.scene_list_contexts = set()
        self.input_list_contexts = set()
        self.transition_list_contexts = set()

        self.cached_scenes = []
        self.cached_inputs = []
        self.cached_transitions = []
        self.available_requests = set()

        self.post_connect_refresh_task = None

        self.icon_map = {
            "stream_toggle": "STATE_STREAM_TOGGLE",
            "record_toggle": "STATE_RECORD_TOGGLE",
            "replay_buffer_toggle": "STATE_REPLAY_BUFFER_TOGGLE",
            "replay_buffer_save": "STATE_REPLAY_BUFFER_SAVE",
            "stream_marker": "STATE_STREAM_MARKER",
            "record_chapter": "STATE_RECORD_CHAPTER",
            "virtual_cam_toggle": "STATE_VIRTUAL_CAM_TOGGLE",
            "studio_mode_toggle": "STATE_STUDIO_MODE_TOGGLE",
            "trigger_transition": "STATE_TRIGGER_TRANSITION",
            "set_transition": "STATE_SET_TRANSITION",
            "change_scene": "STATE_CHANGE_SCENE",
            "toggle_source": "STATE_TOGGLE_SOURCE",
            "filter_control": "STATE_FILTER_CONTROL",
            "media_play_pause": "STATE_MEDIA_PLAY_PAUSE",
            "media_restart": "STATE_MEDIA_RESTART",
            "toggle_mute": "STATE_TOGGLE_MUTE",
            "screenshot_source": "STATE_SCREENSHOT_SOURCE",
        }

    def log(self, message: str):
        try:
            print(message, flush=True)
        except Exception:
            pass

    def _default_obs_action(self):
        return "stream_toggle"

    def _default_settings(self):
        action = self._default_obs_action()
        return {
            "obs_action": action,
            "command": action,
            "target_scene": "",
            "target_transition": "",
            "target_input": "",
            "target_name": "",
            "filter_name": "",
            "enable_state": "true",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_obs_action(), self.icon_map[self._default_obs_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        if not self.cd_ws or not context:
            return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.cd_ws.send(json.dumps({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            }))

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or merged.get("obs_action") or self._default_obs_action()
        merged["obs_action"] = action
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_obs_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("obs_action"),
            s.get("target_scene"),
            s.get("target_transition"),
            s.get("target_input"),
            s.get("target_name"),
            s.get("filter_name"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.last_valid_settings[context] = defaults.copy()
            if self.cd_ws:
                await self.cd_ws.send(json.dumps({
                    "event": "setSettings",
                    "context": context,
                    "payload": defaults
                }))
            await self._send_builtin_icon(context, defaults["obs_action"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.last_valid_settings[context] = merged
        await self._send_builtin_icon(context, merged["obs_action"])
        return True

    def load_config(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    self.config.update(json.load(f))
            except Exception as e:
                self.log(f"[OBS] Config load error: {e}")

    def save_config(self):
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            self.log(f"[OBS] Save config error: {e}")

    def is_obs_connected(self) -> bool:
        return self.obs_ws is not None and self.obs_connected

    def supports_request(self, request_name: str) -> bool:
        return (not self.available_requests) or (request_name in self.available_requests)

    async def send_to_pi(self, context, payload):
        if not self.cd_ws or not context:
            return
        try:
            await self.cd_ws.send(json.dumps({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": payload,
            }))
        except Exception as e:
            self.log(f"[OBS] sendToPI error: {e}")

    async def fetch_scene_list(self):
        if not self.is_obs_connected():
            return self.cached_scenes
        res = await self.send_to_obs("GetSceneList")
        if self._response_ok(res):
            self.cached_scenes = self._response_data(res).get("scenes", [])
        return self.cached_scenes

    async def fetch_input_list(self):
        if not self.is_obs_connected():
            return self.cached_inputs
        res = await self.send_to_obs("GetInputList")
        if self._response_ok(res):
            self.cached_inputs = self._response_data(res).get("inputs", [])
        return self.cached_inputs

    async def fetch_transition_list(self):
        if not self.is_obs_connected():
            return self.cached_transitions
        res = await self.send_to_obs("GetSceneTransitionList")
        if self._response_ok(res):
            self.cached_transitions = self._response_data(res).get("transitions", [])
        return self.cached_transitions

    async def fetch_available_requests(self):
        if not self.is_obs_connected():
            return
        res = await self.send_to_obs("GetVersion")
        if self._response_ok(res):
            self.available_requests = set(self._response_data(res).get("availableRequests", []))
            self.log(f"[OBS] Available requests loaded: {len(self.available_requests)}")

    async def broadcast_scene_list(self):
        for context in list(self.scene_list_contexts):
            await self.send_to_pi(context, {"command": "sceneList", "scenes": self.cached_scenes})

    async def broadcast_input_list(self):
        for context in list(self.input_list_contexts):
            await self.send_to_pi(context, {"command": "inputList", "inputs": self.cached_inputs})

    async def broadcast_transition_list(self):
        for context in list(self.transition_list_contexts):
            await self.send_to_pi(context, {"command": "transitionList", "transitions": self.cached_transitions})

    async def refresh_all_lists_and_broadcast(self):
        if not self.is_obs_connected():
            return
        await self.fetch_scene_list()
        await self.fetch_input_list()
        await self.fetch_transition_list()
        await self.broadcast_scene_list()
        await self.broadcast_input_list()
        await self.broadcast_transition_list()
        self.log("[OBS] Property Inspector lists refreshed after connect/reconnect")

    async def delayed_refresh_after_connect(self):
        try:
            await asyncio.sleep(0.4)
            if not self.is_obs_connected():
                return
            await self.fetch_available_requests()
        except Exception as e:
            self.log(f"[OBS] GetVersion failed: {e}")

        delays = (0.8, 1.5, 3.0)
        for idx, delay in enumerate(delays, start=1):
            await asyncio.sleep(delay)
            if not self.is_obs_connected():
                return
            try:
                await self.refresh_all_lists_and_broadcast()
                self.log(f"[OBS] Delayed auto-refresh pass {idx} completed")
            except Exception as e:
                self.log(f"[OBS] Delayed auto-refresh pass {idx} failed: {e}")

    async def connect_to_obs(self):
        while True:
            try:
                if self.obs_ws is not None:
                    try:
                        await self.obs_ws.close()
                    except Exception:
                        pass

                self.obs_ws = None
                self.obs_connected = False
                self.available_requests = set()

                obs_uri = f"ws://{self.config['ip']}:{self.config['port']}"
                self.log(f"[OBS] Connecting to OBS Studio at {obs_uri}...")

                async with websockets.connect(obs_uri) as ws:
                    self.obs_ws = ws

                    hello_msg = json.loads(await ws.recv())
                    if hello_msg.get("op") != 0:
                        raise RuntimeError(f"Unexpected hello packet: {hello_msg}")

                    auth_data = hello_msg.get("d", {}).get("authentication")
                    identify_payload = {
                        "op": 1,
                        "d": {
                            "rpcVersion": 1,
                            "eventSubscriptions": 0,
                        },
                    }

                    if auth_data:
                        password = self.config.get("password", "")
                        if not password:
                            raise RuntimeError("OBS password is empty in obs_config.json")

                        secret = base64.b64encode(
                            hashlib.sha256((password + auth_data["salt"]).encode("utf-8")).digest()
                        ).decode("utf-8")
                        auth_response = base64.b64encode(
                            hashlib.sha256((secret + auth_data["challenge"]).encode("utf-8")).digest()
                        ).decode("utf-8")
                        identify_payload["d"]["authentication"] = auth_response

                    await ws.send(json.dumps(identify_payload))
                    identified_msg = json.loads(await ws.recv())
                    if identified_msg.get("op") != 2:
                        raise RuntimeError(f"OBS identify/auth failed: {identified_msg}")

                    self.obs_connected = True
                    self.log("[OBS] Successfully Connected & Authenticated!")

                    if self.post_connect_refresh_task and not self.post_connect_refresh_task.done():
                        self.post_connect_refresh_task.cancel()

                    self.post_connect_refresh_task = asyncio.create_task(self.delayed_refresh_after_connect())

                    async for message in ws:
                        try:
                            msg_data = json.loads(message)
                        except Exception:
                            continue

                        if msg_data.get("op") == 7:
                            req_id = msg_data.get("d", {}).get("requestId")
                            future = self.pending_requests.get(req_id)
                            if future and not future.done():
                                future.set_result(msg_data)

            except Exception as e:
                self.log(f"[OBS] Connection Error: {e}")

            finally:
                self.obs_connected = False
                self.obs_ws = None
                self.available_requests = set()
                if self.post_connect_refresh_task and not self.post_connect_refresh_task.done():
                    self.post_connect_refresh_task.cancel()
                self.post_connect_refresh_task = None
                for _, fut in list(self.pending_requests.items()):
                    if not fut.done():
                        fut.cancel()
                self.pending_requests.clear()

            await asyncio.sleep(5)

    async def send_to_obs(self, request_type, request_data=None, request_id=None):
        if not self.is_obs_connected():
            self.log(f"[OBS] Not connected. Cannot send {request_type}")
            return None

        if request_data is None:
            request_data = {}
        if request_id is None:
            request_id = f"{request_type}-{time.time()}"

        payload = {
            "op": 6,
            "d": {
                "requestType": request_type,
                "requestId": request_id,
                "requestData": request_data,
            },
        }

        loop = asyncio.get_running_loop()
        future = loop.create_future()
        self.pending_requests[request_id] = future

        try:
            await self.obs_ws.send(json.dumps(payload))
            response = await asyncio.wait_for(future, timeout=4.0)
            status = response.get("d", {}).get("requestStatus", {})
            if not status.get("result", False):
                self.log(f"[OBS] Request failed: {request_type} code={status.get('code')} comment={status.get('comment')}")
            return response
        except asyncio.TimeoutError:
            self.log(f"[OBS] Request Timeout: {request_type}")
            return None
        except asyncio.CancelledError:
            self.log(f"[OBS] Request Cancelled: {request_type}")
            return None
        except Exception as e:
            self.log(f"[OBS] Send Error: {request_type} -> {e}")
            self.obs_connected = False
            return None
        finally:
            self.pending_requests.pop(request_id, None)

    def _response_ok(self, response):
        return bool(response and response.get("d", {}).get("requestStatus", {}).get("result", False))

    def _response_data(self, response):
        if not response:
            return {}
        return response.get("d", {}).get("responseData", {}) or {}

    async def connect_to_cookiedeck(self):
        while True:
            try:
                self.log(f"[OBS Plugin] Connecting to CookieDeck at {self.uri}...")
                async with websockets.connect(self.uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    self.log("[OBS Plugin] Registered to CookieDeck!")

                    async for message in ws:
                        data = json.loads(message)
                        await self.handle_message(data)
            except Exception as e:
                self.log(f"[OBS Plugin] Disconnected. Retrying... ({e})")
            finally:
                self.cd_ws = None

            await asyncio.sleep(3)

    async def handle_message(self, data):
        try:
            event = data.get("event")
            context = data.get("context")
            payload = data.get("payload", {}) or {}

            if event == "keyDidAppear":
                settings = self._merge_with_defaults(payload.get("settings", {}) or {})
                if context:
                    data["_target_page"] = payload.get("page")
                    self.last_valid_settings[context] = settings
                    self.log(f"[OBS] keyDidAppear primed for {context}")
                    await self._initialize_default_visuals_if_new(context, payload.get("settings", {}) or {})
                return

            if event == "didReceiveSettings":
                settings = self._merge_with_defaults(payload.get("settings", payload) or {})
                if context:
                    self.last_valid_settings[context] = settings
                    self.log(f"[OBS] Settings Cached for {context}")
                return

            if event == "keyDown":
                await self.on_key_down(data)
                return

            if event == "sendToPlugin":
                command = payload.get("command")
                if not command:
                    payload = payload.get("payload", {}) or {}
                    command = payload.get("command")

                if command == "apply_builtin_icon":
                    action_name = payload.get("action_command")
                    if not action_name and context:
                        action_name = self.last_valid_settings.get(context, {}).get("command") or self.last_valid_settings.get(context, {}).get("obs_action")
                    await self._send_builtin_icon(context, action_name or self._default_obs_action())

                elif command == "getObsSettings":
                    await self.send_to_pi(context, {"command": "obsSettings", "settings": self.config})

                elif command == "setObsSettings":
                    new_settings = payload.get("settings", {}) or {}
                    self.config.update(new_settings)
                    self.save_config()
                    self.log("[OBS] Config updated. Reconnecting to OBS...")
                    try:
                        if self.obs_ws is not None:
                            await self.obs_ws.close()
                    except Exception:
                        pass
                    if self.cd_ws and context:
                        await self.cd_ws.send(json.dumps({"event": "closeSettings", "key": context}))

                elif command == "getSceneList":
                    if context:
                        self.scene_list_contexts.add(context)
                    if self.cached_scenes:
                        await self.send_to_pi(context, {"command": "sceneList", "scenes": self.cached_scenes})
                    if self.is_obs_connected():
                        await self.fetch_scene_list()
                        await self.send_to_pi(context, {"command": "sceneList", "scenes": self.cached_scenes})

                elif command == "getInputList":
                    if context:
                        self.input_list_contexts.add(context)
                    if self.cached_inputs:
                        await self.send_to_pi(context, {"command": "inputList", "inputs": self.cached_inputs})
                    if self.is_obs_connected():
                        await self.fetch_input_list()
                        await self.send_to_pi(context, {"command": "inputList", "inputs": self.cached_inputs})

                elif command == "getTransitionList":
                    if context:
                        self.transition_list_contexts.add(context)
                    if self.cached_transitions:
                        await self.send_to_pi(context, {"command": "transitionList", "transitions": self.cached_transitions})
                    if self.is_obs_connected():
                        await self.fetch_transition_list()
                        await self.send_to_pi(context, {"command": "transitionList", "transitions": self.cached_transitions})
                return

        except Exception as e:
            self.log(f"[OBS Plugin] Message Handling Error: {e}")
            self.log(traceback.format_exc())

    async def ensure_settings(self, context, payload):
        incoming_settings = self._merge_with_defaults(payload.get("settings", {}) if isinstance(payload, dict) else {})
        if incoming_settings:
            self.last_valid_settings[context] = incoming_settings

        final_settings = self.last_valid_settings.get(context, {})
        if final_settings:
            return self._merge_with_defaults(final_settings)

        if self.cd_ws and context:
            self.log(f"[OBS] Missing settings for {context}. Requesting from engine...")
            await self.cd_ws.send(json.dumps({"event": "getSettings", "context": context}))
            for _ in range(15):
                await asyncio.sleep(0.1)
                if self.last_valid_settings.get(context):
                    final_settings = self.last_valid_settings[context]
                    break
        return self._merge_with_defaults(final_settings)

    async def toggle_studio_mode(self):
        state_res = await self.send_to_obs("GetStudioModeEnabled")
        if not self._response_ok(state_res):
            return False
        enabled = bool(self._response_data(state_res).get("studioModeEnabled", False))
        set_res = await self.send_to_obs("SetStudioModeEnabled", {"studioModeEnabled": not enabled})
        return self._response_ok(set_res)

    async def toggle_scene_item(self, scene_name, source_name):
        item_res = await self.send_to_obs("GetSceneItemId", {"sceneName": scene_name, "sourceName": source_name})
        if not self._response_ok(item_res):
            return False

        scene_item_id = self._response_data(item_res).get("sceneItemId")
        if scene_item_id is None:
            self.log(f"[OBS] Scene item not found: scene={scene_name!r}, source={source_name!r}")
            return False

        enabled_res = await self.send_to_obs("GetSceneItemEnabled", {"sceneName": scene_name, "sceneItemId": scene_item_id})
        if not self._response_ok(enabled_res):
            return False

        current = bool(self._response_data(enabled_res).get("sceneItemEnabled", False))
        set_res = await self.send_to_obs("SetSceneItemEnabled", {
            "sceneName": scene_name,
            "sceneItemId": scene_item_id,
            "sceneItemEnabled": not current,
        })
        return self._response_ok(set_res)

    async def media_play_pause(self, input_name):
        status_res = await self.send_to_obs("GetMediaInputStatus", {"inputName": input_name})
        if not self._response_ok(status_res):
            return False

        media_state = self._response_data(status_res).get("mediaState")
        if media_state in ("OBS_MEDIA_STATE_PLAYING", "OBS_MEDIA_STATE_OPENING", "OBS_MEDIA_STATE_BUFFERING"):
            action = "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_PAUSE"
        else:
            action = "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_PLAY"

        act_res = await self.send_to_obs("TriggerMediaInputAction", {
            "inputName": input_name,
            "mediaAction": action,
        })
        return self._response_ok(act_res)

    async def screenshot_source(self, source_name):
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"OBS_{source_name}_{timestamp}.png".replace(" ", "_")
        save_path = os.path.join(self.desktop_path, filename).replace("\\\\", "/")
        res = await self.send_to_obs("SaveSourceScreenshot", {
            "sourceName": source_name,
            "imageFormat": "png",
            "imageFilePath": save_path,
        })
        if self._response_ok(res):
            self.log(f"[OBS] Screenshot saved: {save_path}")
            return True
        return False

    async def on_key_down(self, data):
        context = data.get("context") or data.get("action")
        if not context:
            self.log("[OBS] keyDown without context/action")
            return

        payload = data.get("payload", {}) or {}
        final_settings = await self.ensure_settings(context, payload)

        obs_action = final_settings.get("command") or final_settings.get("obs_action")
        if not obs_action:
            self.log(f"[OBS] No action found for {context}. Ignored.")
            return

        req_type = None
        req_data = {}

        if obs_action == "stream_toggle":
            req_type = "ToggleStream"
        elif obs_action == "record_toggle":
            req_type = "ToggleRecord"
        elif obs_action == "virtual_cam_toggle":
            req_type = "ToggleVirtualCam"
        elif obs_action == "replay_buffer_toggle":
            req_type = "ToggleReplayBuffer"
        elif obs_action == "replay_buffer_save":
            req_type = "SaveReplayBuffer"
        elif obs_action == "record_chapter":
            if self.supports_request("CreateRecordChapter"):
                req_type = "CreateRecordChapter"
                req_data = {"chapterName": "CookieDeck Marker"}
            else:
                self.log("[OBS] CreateRecordChapter is unavailable on this OBS / obs-websocket version")
                return
        elif obs_action == "stream_marker":
            self.log("[OBS] Stream markers are not available in this build because the current OBS WebSocket request set has no stream marker request.")
            return
        elif obs_action == "studio_mode_toggle":
            ok = await self.toggle_studio_mode()
            self.log(f"[OBS] studio_mode_toggle => {ok}")
            return
        elif obs_action == "trigger_transition":
            req_type = "TriggerStudioModeTransition"
        elif obs_action == "set_transition":
            target_trans = final_settings.get("target_transition")
            if target_trans:
                req_type = "SetCurrentSceneTransition"
                req_data = {"transitionName": target_trans}
        elif obs_action == "change_scene":
            target_sc = final_settings.get("target_scene") or final_settings.get("scene_name")
            if target_sc:
                req_type = "SetCurrentProgramScene"
                req_data = {"sceneName": target_sc}
        elif obs_action == "toggle_source":
            target_nm = final_settings.get("target_name", "")
            parts = [p.strip() for p in target_nm.split(";", 1)]
            if len(parts) == 2 and parts[0] and parts[1]:
                ok = await self.toggle_scene_item(parts[0], parts[1])
                self.log(f"[OBS] toggle_source => {ok}")
                return
        elif obs_action == "filter_control":
            src = final_settings.get("target_input")
            flt = final_settings.get("filter_name")
            state = final_settings.get("enable_state", "true") == "true"
            if src and flt:
                req_type = "SetSourceFilterEnabled"
                req_data = {"sourceName": src, "filterName": flt, "filterEnabled": state}
        elif obs_action == "media_play_pause":
            inp = final_settings.get("target_input")
            if inp:
                ok = await self.media_play_pause(inp)
                self.log(f"[OBS] media_play_pause => {ok}")
                return
        elif obs_action == "media_restart":
            inp = final_settings.get("target_input")
            if inp:
                req_type = "TriggerMediaInputAction"
                req_data = {"inputName": inp, "mediaAction": "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_RESTART"}
        elif obs_action == "toggle_mute":
            inp = final_settings.get("target_input")
            if inp:
                req_type = "ToggleInputMute"
                req_data = {"inputName": inp}
        elif obs_action == "screenshot_source":
            src = final_settings.get("target_input")
            if src:
                ok = await self.screenshot_source(src)
                self.log(f"[OBS] screenshot_source => {ok}")
                return

        if req_type:
            self.log(f"[OBS Action] Executing: {req_type} with data {req_data}")
            await self.send_to_obs(req_type, req_data, f"{obs_action}-{context}")

    async def start(self):
        asyncio.create_task(self.connect_to_obs())
        await self.connect_to_cookiedeck()


if __name__ == "__main__":
    plugin = OBSPlugin()
    try:
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(plugin.start())
    except KeyboardInterrupt:
        print("[OBS Plugin] Shutting down...", flush=True)
