import asyncio
import importlib.util
import threading
import ctypes
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from ctypes import wintypes

if sys.platform.startswith("win"):
    import winreg


IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
BUILTIN_DISPLAY_INDEX = -1

VCP_CODES = {
    "brightness": 0x10,
    "contrast": 0x12,
    "color_preset": 0x14,
    "input_select": 0x60,
    "sharpness": 0x87,
}

INPUT_VALUES = {
    "vga_1": 0x01,
    "dvi_1": 0x03,
    "dvi_2": 0x04,
    "displayport_1": 0x0F,
    "displayport_2": 0x10,
    "hdmi_1": 0x11,
    "hdmi_2": 0x12,
    "usb_c_1": 0x1B,
    "usb_c_2": 0x1C,
}

INPUT_NAMES = {
    0x01: "VGA 1",
    0x02: "VGA 2",
    0x03: "DVI 1",
    0x04: "DVI 2",
    0x05: "Composite 1",
    0x06: "Composite 2",
    0x07: "S-Video 1",
    0x08: "S-Video 2",
    0x09: "Tuner 1",
    0x0A: "Tuner 2",
    0x0B: "Tuner 3",
    0x0C: "Component 1",
    0x0D: "Component 2",
    0x0E: "Component 3",
    0x0F: "DisplayPort 1",
    0x10: "DisplayPort 2",
    0x11: "HDMI 1",
    0x12: "HDMI 2",
    0x1B: "USB-C 1",
    0x1C: "USB-C 2",
}

VENDOR_INPUT_NAMES = {
    "SAM": {
        0x05: "HDMI 1",
        0x06: "HDMI 2",
    },
}

COLOR_PRESET_NAMES = {
    0x01: "sRGB",
    0x02: "Display Native",
    0x03: "4000 K",
    0x04: "5000 K",
    0x05: "6500 K",
    0x06: "7500 K",
    0x07: "8200 K",
    0x08: "9300 K",
    0x09: "10000 K",
    0x0A: "11500 K",
    0x0B: "User 1",
    0x0C: "User 2",
    0x0D: "User 3",
}

LEGACY_INPUT_VALUES = {name: value for name, value in INPUT_VALUES.items()}
LEGACY_COLOR_PRESET_VALUES = {
    "srgb": 0x01,
    "display_native": 0x02,
    "warm": 0x04,
    "cool": 0x08,
    "user_1": 0x0B,
}


if IS_WINDOWS:
    class PHYSICAL_MONITOR(ctypes.Structure):
        _fields_ = [
            ("hPhysicalMonitor", wintypes.HANDLE),
            ("szPhysicalMonitorDescription", wintypes.WCHAR * 128),
        ]

    class MONITORINFOEXW(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD),
            ("rcMonitor", wintypes.RECT),
            ("rcWork", wintypes.RECT),
            ("dwFlags", wintypes.DWORD),
            ("szDevice", wintypes.WCHAR * 32),
        ]

    class DISPLAY_DEVICEW(ctypes.Structure):
        _fields_ = [
            ("cb", wintypes.DWORD),
            ("DeviceName", wintypes.WCHAR * 32),
            ("DeviceString", wintypes.WCHAR * 128),
            ("StateFlags", wintypes.DWORD),
            ("DeviceID", wintypes.WCHAR * 128),
            ("DeviceKey", wintypes.WCHAR * 128),
        ]

    class POINTL(ctypes.Structure):
        _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]

    class DEVMODE_DISPLAY(ctypes.Structure):
        _fields_ = [
            ("dmPosition", POINTL),
            ("dmDisplayOrientation", wintypes.DWORD),
            ("dmDisplayFixedOutput", wintypes.DWORD),
        ]

    class DEVMODE_PRINTER(ctypes.Structure):
        _fields_ = [
            ("dmOrientation", wintypes.SHORT),
            ("dmPaperSize", wintypes.SHORT),
            ("dmPaperLength", wintypes.SHORT),
            ("dmPaperWidth", wintypes.SHORT),
            ("dmScale", wintypes.SHORT),
            ("dmCopies", wintypes.SHORT),
            ("dmDefaultSource", wintypes.SHORT),
            ("dmPrintQuality", wintypes.SHORT),
        ]

    class DEVMODE_UNION(ctypes.Union):
        _fields_ = [
            ("display", DEVMODE_DISPLAY),
            ("printer", DEVMODE_PRINTER),
        ]

    class DEVMODEW(ctypes.Structure):
        _anonymous_ = ("union",)
        _fields_ = [
            ("dmDeviceName", wintypes.WCHAR * 32),
            ("dmSpecVersion", wintypes.WORD),
            ("dmDriverVersion", wintypes.WORD),
            ("dmSize", wintypes.WORD),
            ("dmDriverExtra", wintypes.WORD),
            ("dmFields", wintypes.DWORD),
            ("union", DEVMODE_UNION),
            ("dmColor", wintypes.SHORT),
            ("dmDuplex", wintypes.SHORT),
            ("dmYResolution", wintypes.SHORT),
            ("dmTTOption", wintypes.SHORT),
            ("dmCollate", wintypes.SHORT),
            ("dmFormName", wintypes.WCHAR * 32),
            ("dmLogPixels", wintypes.WORD),
            ("dmBitsPerPel", wintypes.DWORD),
            ("dmPelsWidth", wintypes.DWORD),
            ("dmPelsHeight", wintypes.DWORD),
            ("dmDisplayFlags", wintypes.DWORD),
            ("dmDisplayFrequency", wintypes.DWORD),
            ("dmICMMethod", wintypes.DWORD),
            ("dmICMIntent", wintypes.DWORD),
            ("dmMediaType", wintypes.DWORD),
            ("dmDitherType", wintypes.DWORD),
            ("dmReserved1", wintypes.DWORD),
            ("dmReserved2", wintypes.DWORD),
            ("dmPanningWidth", wintypes.DWORD),
            ("dmPanningHeight", wintypes.DWORD),
        ]

    MONITORENUMPROC = ctypes.WINFUNCTYPE(
        wintypes.BOOL,
        wintypes.HMONITOR,
        wintypes.HDC,
        ctypes.POINTER(wintypes.RECT),
        wintypes.LPARAM,
    )


class DDCMonitor:
    def __init__(self, handle, description, index, vendor_id="", display_name=""):
        self.handle = handle
        self.description = description or f"Display {index + 1}"
        self.index = index
        self.vendor_id = vendor_id
        self.display_name = display_name


class WindowsInternalBrightness:
    """Control the active laptop panel through Windows' WMI brightness provider."""

    @staticmethod
    def _powershell_env():
        environment = os.environ.copy()
        system_root = environment.get("SystemRoot", r"C:\Windows")
        environment["PSModulePath"] = os.path.join(
            system_root,
            "System32",
            "WindowsPowerShell",
            "v1.0",
            "Modules",
        )
        return environment

    @classmethod
    def _run(cls, script):
        if not IS_WINDOWS:
            return None
        try:
            return subprocess.run(
                [
                    os.path.join(
                        os.environ.get("SystemRoot", r"C:\Windows"),
                        "System32",
                        "WindowsPowerShell",
                        "v1.0",
                        "powershell.exe",
                    ),
                    "-NoLogo",
                    "-NoProfile",
                    "-NonInteractive",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-Command",
                    script,
                ],
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
                env=cls._powershell_env(),
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except (OSError, subprocess.SubprocessError):
            return None

    def get_current(self):
        result = self._run(
            "$item = Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightness "
            "| Where-Object Active | Select-Object -First 1; "
            "if ($null -ne $item) { [Console]::Write([int]$item.CurrentBrightness) }"
        )
        if not result or result.returncode != 0:
            return None
        try:
            return max(0, min(100, int(result.stdout.strip())))
        except (TypeError, ValueError):
            return None

    def set_value(self, value):
        target = max(0, min(100, int(value)))
        result = self._run(
            "$level = " + str(target) + "; "
            "$active = Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightness "
            "| Where-Object Active | Select-Object -First 1; "
            "if ($null -eq $active) { exit 2 }; "
            "$method = Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightnessMethods "
            "| Where-Object InstanceName -eq $active.InstanceName | Select-Object -First 1; "
            "if ($null -eq $method) { exit 3 }; "
            "$response = Invoke-CimMethod -InputObject $method -MethodName WmiSetBrightness "
            "-Arguments @{ Timeout = [uint32]0; Brightness = [byte]$level }; "
            "if ($null -ne $response.ReturnValue -and [int]$response.ReturnValue -ne 0) { exit 4 }"
        )
        return bool(result and result.returncode == 0)


class DDCController:
    def __init__(self):
        self.user32 = ctypes.windll.user32 if IS_WINDOWS else None
        self.dxva2 = ctypes.windll.dxva2 if IS_WINDOWS else None
        self.mac_ddc_tool = self._find_mac_ddc_tool() if IS_MACOS else None

    @staticmethod
    def _find_mac_ddc_tool():
        candidates = [
            shutil.which("m1ddc"),
            "/opt/homebrew/bin/m1ddc",
            "/usr/local/bin/m1ddc",
        ]
        return next((path for path in candidates if path and os.path.isfile(path) and os.access(path, os.X_OK)), None)

    def _run_mac_ddc(self, *args):
        if not self.mac_ddc_tool:
            return None
        try:
            return subprocess.run(
                [self.mac_ddc_tool, *map(str, args)],
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
            )
        except (OSError, subprocess.SubprocessError):
            return None

    @staticmethod
    def _model_name_from_edid(edid):
        if not isinstance(edid, bytes) or len(edid) < 128:
            return None
        for offset in (54, 72, 90, 108):
            descriptor = edid[offset:offset + 18]
            if descriptor[:5] != b"\x00\x00\x00\xfc\x00":
                continue
            name = descriptor[5:18].split(b"\n", 1)[0].decode("ascii", "ignore").strip()
            if name:
                return name
        return None

    def _identity_for_hmonitor(self, hmonitor):
        monitor_info = MONITORINFOEXW()
        monitor_info.cbSize = ctypes.sizeof(monitor_info)
        if not self.user32.GetMonitorInfoW(hmonitor, ctypes.byref(monitor_info)):
            return None, "", ""

        display_device = DISPLAY_DEVICEW()
        display_device.cb = ctypes.sizeof(display_device)
        if not self.user32.EnumDisplayDevicesW(
            monitor_info.szDevice,
            0,
            ctypes.byref(display_device),
            1,
        ):
            return None, "", monitor_info.szDevice

        parts = display_device.DeviceID.split("#")
        if len(parts) < 3:
            return None, "", monitor_info.szDevice
        vendor_product_id, instance_id = parts[1], parts[2]
        vendor_id = vendor_product_id[:3].upper()
        registry_path = (
            rf"SYSTEM\CurrentControlSet\Enum\DISPLAY\{vendor_product_id}"
            rf"\{instance_id}\Device Parameters"
        )
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, registry_path) as key:
                edid = winreg.QueryValueEx(key, "EDID")[0]
            return self._model_name_from_edid(edid), vendor_id, monitor_info.szDevice
        except OSError:
            return None, vendor_id, monitor_info.szDevice

    def enumerate_monitors(self):
        if IS_MACOS:
            result = self._run_mac_ddc("display", "list")
            if not result or result.returncode != 0:
                return []
            lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
            return [
                DDCMonitor(index + 1, line, index, display_name=str(index + 1))
                for index, line in enumerate(lines)
            ]
        if not IS_WINDOWS:
            return []

        monitors = []

        @MONITORENUMPROC
        def callback(hmonitor, _hdc, _rect, _data):
            friendly_name, vendor_id, display_name = self._identity_for_hmonitor(hmonitor)
            count = wintypes.DWORD()
            if not self.dxva2.GetNumberOfPhysicalMonitorsFromHMONITOR(hmonitor, ctypes.byref(count)):
                return True
            physical = (PHYSICAL_MONITOR * count.value)()
            if not self.dxva2.GetPhysicalMonitorsFromHMONITOR(hmonitor, count.value, physical):
                return True
            for item in physical:
                description = friendly_name or item.szPhysicalMonitorDescription
                monitors.append(DDCMonitor(
                    item.hPhysicalMonitor,
                    description,
                    len(monitors),
                    vendor_id,
                    display_name,
                ))
            return True

        self.user32.EnumDisplayMonitors(None, None, callback, 0)
        return monitors

    def close_monitors(self, monitors):
        if not IS_WINDOWS:
            return
        if not monitors:
            return
        handles = (PHYSICAL_MONITOR * len(monitors))()
        for index, monitor in enumerate(monitors):
            handles[index].hPhysicalMonitor = monitor.handle
            handles[index].szPhysicalMonitorDescription = monitor.description
        self.dxva2.DestroyPhysicalMonitors(len(monitors), handles)

    def get_value(self, monitor, vcp_code):
        if IS_MACOS:
            feature = {0x10: "luminance", 0x12: "contrast"}.get(vcp_code)
            if not feature:
                return None
            current_result = self._run_mac_ddc("display", monitor.handle, "get", feature)
            maximum_result = self._run_mac_ddc("display", monitor.handle, "max", feature)
            if not current_result or current_result.returncode != 0:
                return None
            current_values = re.findall(r"-?\d+", current_result.stdout)
            maximum_values = re.findall(r"-?\d+", maximum_result.stdout if maximum_result else "")
            if not current_values:
                return None
            return int(current_values[-1]), int(maximum_values[-1]) if maximum_values else 100
        current = wintypes.DWORD()
        maximum = wintypes.DWORD()
        value_type = wintypes.DWORD()
        success = self.dxva2.GetVCPFeatureAndVCPFeatureReply(
            monitor.handle,
            wintypes.BYTE(vcp_code),
            ctypes.byref(value_type),
            ctypes.byref(current),
            ctypes.byref(maximum),
        )
        if not success:
            return None
        return current.value, maximum.value

    def set_value(self, monitor, vcp_code, value):
        if IS_MACOS:
            feature = {0x10: "luminance", 0x12: "contrast", 0x60: "input"}.get(vcp_code)
            if not feature:
                return False
            result = self._run_mac_ddc("display", monitor.handle, "set", feature, int(value))
            return bool(result and result.returncode == 0)
        return bool(self.dxva2.SetVCPFeature(monitor.handle, wintypes.BYTE(vcp_code), wintypes.DWORD(value)))

    def get_capabilities(self, monitor):
        if IS_MACOS:
            return "vcp(10 12 60(0F 10 11 12 1B 1C))"
        length = wintypes.DWORD()
        if not self.dxva2.GetCapabilitiesStringLength(monitor.handle, ctypes.byref(length)):
            return None
        if not length.value:
            return None
        buffer = ctypes.create_string_buffer(length.value)
        if not self.dxva2.CapabilitiesRequestAndCapabilitiesReply(monitor.handle, buffer, length.value):
            return None
        return buffer.value.decode("ascii", "replace")

    def with_monitor(self, monitor_index, operation):
        monitors = self.enumerate_monitors()
        try:
            if not monitors:
                return None
            index = int(monitor_index or 0)
            if index < 0 or index >= len(monitors):
                return None
            return operation(monitors[index])
        finally:
            self.close_monitors(monitors)

    def set_orientation(self, monitor_index, orientation):
        target_orientation = int(orientation)

        def operation(monitor):
            if not monitor.display_name:
                return False
            mode = DEVMODEW()
            mode.dmSize = ctypes.sizeof(DEVMODEW)
            if not self.user32.EnumDisplaySettingsW(monitor.display_name, -1, ctypes.byref(mode)):
                return False

            current_landscape = mode.dmPelsWidth >= mode.dmPelsHeight
            target_landscape = target_orientation in (0, 2)
            if current_landscape != target_landscape:
                mode.dmPelsWidth, mode.dmPelsHeight = mode.dmPelsHeight, mode.dmPelsWidth
            mode.display.dmDisplayOrientation = target_orientation
            mode.dmFields |= 0x00000080 | 0x00080000 | 0x00100000
            return self.user32.ChangeDisplaySettingsExW(
                monitor.display_name,
                ctypes.byref(mode),
                None,
                0x00000001,
                None,
            ) == 0

        return bool(self.with_monitor(monitor_index, operation))


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.display_action = next(action for action in manifest["Actions"]
                                   if action["UUID"] == self.uuid + ".action")
        self.layout_action = next(action for action in manifest["Actions"]
                                  if action["UUID"] == self.uuid + ".windowlayout")
        self.action_definitions = [
            (state["Value"], state["NameKey"], state["VCPCode"])
            for state in self.display_action["States"]
        ]
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.ddc = DDCController()
        self.internal_brightness = WindowsInternalBrightness()
        self.context_settings = {}
        self.layout_hold_file = os.path.join(tempfile.gettempdir(), "com.cookie.hpdisplayquicksettings.layout_hold")
        self.layout_hold_contexts = set()
        self.windows_layout_helper_warmed = False
        self._layout_service = None
        self._layout_closing = False
        self._layout_lock = threading.RLock()
        if IS_WINDOWS:
            self._warm_windows_layout_helper(self._default_settings("com.cookie.hpdisplayquicksettings.windowlayout"))

    @staticmethod
    def _is_layout_action(action_id):
        return "windowlayout" in (action_id or "")

    def _builtin_icon_name(self, settings=None, action_id=""):
        settings = settings or {}
        action_id = action_id or settings.get("action_id", "")
        action = self.layout_action if self._is_layout_action(action_id) else self.display_action
        command = settings.get("command", "brightness_up")
        state = next((item for item in action.get("States", [])
                      if item["Value"] == command), action)
        return os.path.splitext(os.path.basename(state["Icon"]))[0]

    def _default_settings(self, action_id=""):
        if self._is_layout_action(action_id):
            return {
                "layout_preset": "halves",
                "layout_modifier": "alt_f17",
                "action_id": "com.cookie.hpdisplayquicksettings.windowlayout",
                "_lang": "en",
                "builtin_icon_name": self._builtin_icon_name(action_id=action_id),
                "default_visuals_initialized": True,
            }
        return {
            "monitor_index": 0,
            "command": "brightness_up",
            "value": 50,
            "step": 10,
            "input_value": "hdmi_1",
            "color_preset": "display_native",
            "show_result_on_title": True,
            "action_id": "com.cookie.hpdisplayquicksettings.action",
            "_lang": "en",
            "builtin_icon_name": self._builtin_icon_name(action_id=action_id),
            "default_visuals_initialized": True,
        }

    def _merge_settings(self, settings, action_id=""):
        action_id = action_id or (settings or {}).get("action_id", "")
        merged = self._default_settings(action_id)
        merged.update(settings or {})
        merged["builtin_icon_name"] = self._builtin_icon_name(merged, action_id)
        return merged

    def _has_meaningful_settings(self, settings):
        values = settings or {}
        return any([
            values.get("command"),
            values.get("builtin_icon_name"),
            values.get("default_visuals_initialized"),
            values.get("title"),
            values.get("_lang"),
        ])

    async def _send_default_icon(self, context):
        # COMBO-X assigns the manifest artwork once; preserve custom button images.
        return

    async def _initialize_if_new(self, context, settings, action_id=""):
        if not context:
            return
        if self._has_meaningful_settings(settings):
            merged = self._merge_settings(settings, action_id)
            self.context_settings[context] = merged
            if self._is_layout_action(action_id or merged.get("action_id")):
                await asyncio.to_thread(self._warm_windows_layout_helper, merged)
            return

        defaults = self._default_settings(action_id)
        self.context_settings[context] = defaults.copy()
        if self._is_layout_action(action_id or defaults.get("action_id")):
            await asyncio.to_thread(self._warm_windows_layout_helper, defaults)
        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": defaults,
        })
        await self._send_default_icon(context)

    def _monitor_list(self):
        monitors = self.ddc.enumerate_monitors()
        try:
            description_counts = {}
            compatible_monitors = [
                monitor for monitor in monitors
                if self.ddc.get_value(monitor, VCP_CODES["brightness"]) is not None
            ]
            for monitor in compatible_monitors:
                description_counts[monitor.description] = description_counts.get(monitor.description, 0) + 1

            result = []
            for monitor in compatible_monitors:
                name = monitor.description
                if description_counts.get(name, 0) > 1:
                    name = f"{name} {monitor.index + 1}"
                result.append({"index": monitor.index, "name": name})
            if IS_WINDOWS and self.internal_brightness.get_current() is not None:
                result.append({
                    "index": BUILTIN_DISPLAY_INDEX,
                    "name": "Built-in display",
                    "name_key": "BUILTIN_DISPLAY",
                    "backend": "windows-wmi",
                })
            return result
        finally:
            self.ddc.close_monitors(monitors)

    def _ddc_status(self):
        if IS_WINDOWS:
            return {"available": True, "backend": "windows-ddc"}
        if IS_MACOS:
            return {
                "available": bool(self.ddc.mac_ddc_tool),
                "backend": "m1ddc" if self.ddc.mac_ddc_tool else "missing",
            }
        return {"available": False, "backend": "unsupported"}

    @staticmethod
    def _extract_group(text, marker):
        start = text.lower().find(marker.lower())
        if start < 0:
            return None
        open_index = text.find("(", start + len(marker))
        if open_index < 0:
            return None
        depth = 0
        for index in range(open_index, len(text)):
            if text[index] == "(":
                depth += 1
            elif text[index] == ")":
                depth -= 1
                if depth == 0:
                    return text[open_index + 1:index]
        return None

    @classmethod
    def _parse_vcp_capabilities(cls, capabilities):
        body = cls._extract_group(capabilities or "", "vcp")
        if not body:
            return {}

        features = {}
        index = 0
        while index < len(body):
            while index < len(body) and body[index].isspace():
                index += 1
            start = index
            while index < len(body) and body[index] in "0123456789abcdefABCDEF":
                index += 1
            code_text = body[start:index]
            if len(code_text) != 2:
                index += 1
                continue

            values = []
            if index < len(body) and body[index] == "(":
                depth = 1
                group_start = index + 1
                index += 1
                while index < len(body) and depth:
                    if body[index] == "(":
                        depth += 1
                    elif body[index] == ")":
                        depth -= 1
                    index += 1
                group = body[group_start:index - 1]
                if "(" not in group:
                    for value in group.split():
                        try:
                            values.append(int(value, 16))
                        except ValueError:
                            pass
            features[int(code_text, 16)] = values
        return features

    @staticmethod
    def _option(value, names):
        return {"value": f"0x{value:02X}", "name": names.get(value, f"Value 0x{value:02X}")}

    def _monitor_capabilities(self, monitor_index):
        if IS_WINDOWS and int(monitor_index or 0) == BUILTIN_DISPLAY_INDEX:
            if self.internal_brightness.get_current() is None:
                return None
            return {
                "monitor_index": BUILTIN_DISPLAY_INDEX,
                "monitor_name": "Built-in display",
                "monitor_vendor": "",
                "actions": [
                    {"value": value, "label_key": label_key}
                    for value, label_key, _code in self.action_definitions
                    if value.startswith("brightness_")
                ],
                "inputs": [],
                "color_presets": [],
                "fallback": False,
                "backend": "windows-wmi",
            }

        def operation(monitor):
            raw = self.ddc.get_capabilities(monitor)
            features = self._parse_vcp_capabilities(raw)
            fallback = not bool(features)
            if fallback:
                features = {code: [] for code in VCP_CODES.values()}

            actions = [
                {"value": value, "label_key": label_key}
                for value, label_key, code in self.action_definitions
                if code in features
            ]
            input_values = features.get(VCP_CODES["input_select"], [])
            color_values = features.get(VCP_CODES["color_preset"], [])
            if fallback:
                input_values = sorted(set(INPUT_VALUES.values()))
                color_values = sorted(COLOR_PRESET_NAMES)
            elif VCP_CODES["input_select"] in features and not input_values:
                input_values = sorted(set(INPUT_VALUES.values()))
            if VCP_CODES["color_preset"] in features and not color_values:
                color_values = sorted(COLOR_PRESET_NAMES)

            input_names = dict(INPUT_NAMES)
            input_names.update(VENDOR_INPUT_NAMES.get(monitor.vendor_id, {}))
            return {
                "monitor_index": monitor.index,
                "monitor_name": monitor.description,
                "monitor_vendor": monitor.vendor_id,
                "actions": actions,
                "inputs": [self._option(value, input_names) for value in input_values],
                "color_presets": [self._option(value, COLOR_PRESET_NAMES) for value in color_values],
                "fallback": fallback,
            }

        return self.ddc.with_monitor(monitor_index, operation)

    @staticmethod
    def _setting_value(value, legacy_values, default):
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            if value in legacy_values:
                return legacy_values[value]
            try:
                return int(value, 16) if value.lower().startswith("0x") else int(value)
            except ValueError:
                pass
        return default

    def _execute(self, settings):
        command = settings.get("command", "brightness_up")
        monitor_index = settings.get("monitor_index", 0)

        feature = None
        mode = None
        if command.startswith("brightness_"):
            feature, mode = "brightness", command[len("brightness_"):]
        elif command.startswith("contrast_"):
            feature, mode = "contrast", command[len("contrast_"):]
        elif command.startswith("sharpness_"):
            feature, mode = "sharpness", command[len("sharpness_"):]

        use_internal_brightness = (
            IS_WINDOWS
            and feature == "brightness"
            and int(monitor_index or 0) == BUILTIN_DISPLAY_INDEX
        )
        if IS_WINDOWS and feature == "brightness" and not use_internal_brightness:
            selected_ddc_value = self.ddc.with_monitor(
                monitor_index,
                lambda monitor: self.ddc.get_value(monitor, VCP_CODES["brightness"]),
            )
            # Migrate legacy/default monitor_index=0 automatically on laptops
            # whose internal panel was previously exposed as an unusable DDC handle.
            use_internal_brightness = (
                selected_ddc_value is None
                and self.internal_brightness.get_current() is not None
            )

        if use_internal_brightness:
            if feature != "brightness":
                return None
            settings["monitor_index"] = BUILTIN_DISPLAY_INDEX
            current = self.internal_brightness.get_current()
            if current is None:
                return None
            if mode == "up":
                target = min(100, current + int(settings.get("step", 10)))
            elif mode == "down":
                target = max(0, current - int(settings.get("step", 10)))
            else:
                target = max(0, min(100, int(settings.get("value", 50))))
            if not self.internal_brightness.set_value(target):
                return None
            return f"Built-in display\nBrightness {target}"

        def operation(monitor):
            if feature:
                current_data = self.ddc.get_value(monitor, VCP_CODES[feature])
                if not current_data:
                    return None
                current, maximum = current_data
                if mode == "up":
                    target = min(maximum, current + int(settings.get("step", 10)))
                elif mode == "down":
                    target = max(0, current - int(settings.get("step", 10)))
                else:
                    target = max(0, min(maximum, int(settings.get("value", 50))))
                if not self.ddc.set_value(monitor, VCP_CODES[feature], target):
                    return None
                return f"{monitor.description}\n{feature.title()} {target}"

            if command == "input_select":
                target = self._setting_value(settings.get("input_value"), LEGACY_INPUT_VALUES, 0x11)
                if self.ddc.set_value(monitor, VCP_CODES["input_select"], target):
                    return f"{monitor.description}\n{INPUT_NAMES.get(target, f'Input 0x{target:02X}')}"
                return None

            if command == "color_preset":
                target = self._setting_value(settings.get("color_preset"), LEGACY_COLOR_PRESET_VALUES, 0x02)
                if self.ddc.set_value(monitor, VCP_CODES["color_preset"], target):
                    return f"{monitor.description}\n{COLOR_PRESET_NAMES.get(target, f'Preset 0x{target:02X}')}"
                return None

            return None

        return self.ddc.with_monitor(monitor_index, operation)

    def _layout_command(self, settings, active=False, preview=False):
        with self._layout_lock:
            if self._layout_closing or not (IS_WINDOWS or IS_MACOS):
                return False
            if self._layout_service is None:
                if not active and not preview and not IS_WINDOWS:
                    return False
                path = os.path.join(self.plugin_dir, "window_layout", "layout_runtime.py")
                spec = importlib.util.spec_from_file_location("hp_layout_runtime", path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                self._layout_service = module.LayoutService(self.plugin_dir)
            return self._layout_service.command(settings.get("layout_preset", "halves"), active, preview)

    def _execute_window_layout(self, settings):
        layout = settings.get("layout_preset", "halves")
        try:
            if self._layout_command(settings, active=True, preview=IS_MACOS):
                return f"Layout\n{layout.replace('-', ' ').title()}"
        except (OSError, RuntimeError, subprocess.SubprocessError) as error:
            print(f"[{self.uuid}] Window layout helper failed: {error}")
            if IS_MACOS and not self._layout_closing:
                return self._execute_macos_layout_fallback(layout)
        return None

    def _warm_windows_layout_helper(self, settings):
        if IS_WINDOWS and not self.windows_layout_helper_warmed:
            try:
                self.windows_layout_helper_warmed = self._layout_command(settings)
            except (OSError, RuntimeError, subprocess.SubprocessError) as error:
                print(f"[{self.uuid}] Window layout warm-up failed: {error}")

    def _set_layout_hold(self, settings, active):
        try:
            # Releasing an unused action must not launch a new resident worker.
            if active or self._layout_service is not None:
                self._layout_command(settings, active=active)
        except (OSError, RuntimeError, subprocess.SubprocessError) as error:
            print(f"[{self.uuid}] Layout hold state failed: {error}")

    def _shutdown_layout(self):
        with self._layout_lock:
            self._layout_closing = True
            if self._layout_service is None:
                path = os.path.join(self.plugin_dir, "window_layout", "layout_runtime.py")
                spec = importlib.util.spec_from_file_location("hp_layout_runtime", path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                self._layout_service = module.LayoutService(self.plugin_dir)
            self._layout_service.stop()
            self.layout_hold_contexts.clear()

    async def shutdown(self):
        # The shared runner acknowledges unload only after this has finished.
        await asyncio.to_thread(self._shutdown_layout)

    def _execute_macos_layout_fallback(self, layout):
        script_path = os.path.join(self.plugin_dir, "window_layout", "window_layout_macos.applescript")
        if not os.path.isfile(script_path):
            return None
        try:
            result = subprocess.run(
                ["osascript", script_path, layout],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            if result.returncode == 0:
                return f"Layout\n{layout.replace('-', ' ').title()}"
            print(f"[{self.uuid}] macOS layout fallback failed: {result.stderr.strip()}")
        except (OSError, subprocess.SubprocessError):
            return None

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        settings = payload.get("settings") if isinstance(payload.get("settings"), dict) else data.get("settings", {}) or {}
        action_id = data.get("action", "") or settings.get("action_id", "")
        control_command = data.get("command") or payload.get("command")

        if event in ("willAppear", "keyDidAppear"):
            await self._initialize_if_new(context, settings, action_id)
            return

        if event == "didReceiveSettings":
            self.context_settings[context] = self._merge_settings(settings, action_id)
            return

        if event in ("keyDidDisappear", "willDisappear"):
            cached = self.context_settings.get(context, {})
            if self._is_layout_action(action_id or cached.get("action_id")):
                self._set_layout_hold(cached, False)
                self.layout_hold_contexts.discard(context)
            self.context_settings.pop(context, None)
            return

        if control_command == "get_monitors":
            monitors = await asyncio.to_thread(self._monitor_list)
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {
                    "command": "monitor_list",
                    "monitors": monitors,
                    "ddc_status": self._ddc_status(),
                },
            })
            return

        if control_command == "get_monitor_capabilities":
            monitor_index = payload.get("monitor_index", 0)
            capabilities = await asyncio.to_thread(self._monitor_capabilities, monitor_index)
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {
                    "command": "monitor_capabilities",
                    "capabilities": capabilities,
                },
            })
            return

        if event == "keyDown":
            merged = self._merge_settings({**self.context_settings.get(context, {}), **settings}, action_id)
            self.context_settings[context] = merged
            original_monitor_index = merged.get("monitor_index", 0)
            is_layout = self._is_layout_action(action_id or merged.get("action_id"))
            if is_layout:
                repeated_hold = context in self.layout_hold_contexts
                if repeated_hold and not IS_WINDOWS:
                    try:
                        repeated_hold = (time.time() - os.path.getmtime(self.layout_hold_file)) < 15
                    except OSError:
                        repeated_hold = False
                self.layout_hold_contexts.add(context)
                self._set_layout_hold(merged, True)
                if repeated_hold:
                    return
            execute = self._execute_window_layout if is_layout else self._execute
            result = await asyncio.to_thread(execute, merged)
            if merged.get("monitor_index", 0) != original_monitor_index:
                await self.runner.send_message({
                    "event": "setSettings",
                    "context": context,
                    "payload": merged,
                })
            if result and merged.get("show_result_on_title", True):
                await self.runner.send_message({
                    "event": "setTitle",
                    "context": context,
                    "payload": {"title": result},
                })
            return

        if event == "keyUp":
            merged = self._merge_settings({**self.context_settings.get(context, {}), **settings}, action_id)
            if self._is_layout_action(action_id or merged.get("action_id")):
                self._set_layout_hold(merged, False)
                self.layout_hold_contexts.discard(context)
