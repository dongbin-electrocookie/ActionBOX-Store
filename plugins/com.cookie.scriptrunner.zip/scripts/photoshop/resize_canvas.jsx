#target photoshop

// 해상도 목록 정의
var resolutions = {
  "Full HD (1920x1080)": [1920, 1080],
  "Vertical HD (1080x1920)": [1080, 1920],
  "4K UHD (3840x2160)": [3840, 2160],
  "Instagram Post (1080x1080)": [1080, 1080],
  "Instagram Story (1080x1920)": [1080, 1920],
  "Square (1000x1000)": [1000, 1000]
};

// UI 창 생성
var win = new Window("dialog", "📐 캔버스 해상도 선택");
win.orientation = "column";
win.alignChildren = ["fill", "top"];

win.add("statictext", undefined, "변경할 캔버스 해상도를 선택하세요:");

var dropdown = win.add("dropdownlist", undefined, []);
for (var key in resolutions) {
  dropdown.add("item", key);
}
dropdown.selection = 0;

var btnGroup = win.add("group");
btnGroup.alignment = "center";
var okBtn = btnGroup.add("button", undefined, "확인");
var cancelBtn = btnGroup.add("button", undefined, "취소");

// 확인 버튼 클릭
okBtn.onClick = function() {
  win.close(1);
};

// 취소 버튼 클릭
cancelBtn.onClick = function() {
  win.close(0);
};

var result = win.show();

if (result === 1) {
  var selectedLabel = dropdown.selection.text;
  var selectedRes = resolutions[selectedLabel];
  var w = selectedRes[0];
  var h = selectedRes[1];

  if (app.documents.length > 0) {
    var doc = app.activeDocument;
    var originalRulerUnits = app.preferences.rulerUnits;
    try {
      app.preferences.rulerUnits = Units.PIXELS;
      doc.resizeCanvas(UnitValue(w, "px"), UnitValue(h, "px"), AnchorPosition.MIDDLECENTER);
      alert("✅ 캔버스가 " + w + " x " + h + " 으로 변경되었습니다.");
    } catch (e) {
      alert("캔버스 크기 변경 오류: " + e.message);
    } finally {
      app.preferences.rulerUnits = originalRulerUnits;
    }
  } else {
    alert("❌ 열려 있는 문서가 없습니다.");
  }
} else {
  alert("⛔ 취소되었습니다.");
}
