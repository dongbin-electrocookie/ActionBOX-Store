import asyncio
import keyboard
import os
import subprocess
import sys
import time
import ctypes
import json 

# 윈도우 하드웨어 센서(가상 키코드) 매핑 딕셔너리
VK_MAP = {
    0x11: 'ctrl', 0x10: 'shift', 0x12: 'alt', 0x5B: 'windows', 0x5C: 'windows',
    0x25: 'left', 0x26: 'up', 0x27: 'right', 0x28: 'down',
    0x0D: 'enter', 0x20: 'space', 0x1B: 'esc', 0x08: 'backspace', 0x09: 'tab',
    0x2E: 'delete', 0x2D: 'insert', 0x24: 'home', 0x23: 'end', 0x21: 'page up', 0x22: 'page down',
    0xBA: ';', 0xBB: '=', 0xBC: ',', 0xBD: '-', 0xBE: '.', 0xBF: '/', 0xC0: '`', 
    0xDB: '[', 0xDC: '\\', 0xDD: ']', 0xDE: "'"
}
for i in range(65, 91): VK_MAP[i] = chr(i).lower() # a~z
for i in range(48, 58): VK_MAP[i] = chr(i) # 0~9
for i in range(112, 124): VK_MAP[i] = f"f{i-111}" # f1~f12

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.is_recording = False
        self.app_list_cache = None  # ★ [추가] 앱 목록을 기억해두는 캐시 변수

    def _get_installed_apps(self):
        """PowerShell을 이용해 시작 메뉴의 프로그램과 스토어 앱(UWP) 목록을 가져옵니다."""
        
        # 1. 이미 스캔한 적이 있다면 0.1초 만에 바로 반환! (최적화)
        if self.app_list_cache is not None:
            return self.app_list_cache

        try:
            # 2. 안전한 파워쉘 명령어 구성 (오류 시 빈 배열 반환하도록 방어 코드 추가)
            ps_script = (
                "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
                "$apps = Get-StartApps | Select-Object Name, AppID; "
                "if ($apps) { ConvertTo-Json $apps -Compress } else { '[]' }"
            )
            
            # 3. 명령어를 리스트 형태로 쪼개어 전달 (문자열 꼬임 방지)
            cmd = [
                "powershell", 
                "-NoProfile", 
                "-NonInteractive",    # ★ 무한 대기(입력 요구) 완벽 차단
                "-ExecutionPolicy", "Bypass", 
                "-Command", ps_script
            ]
            
            creation_flags = 0
            if sys.platform == "win32":
                creation_flags = subprocess.CREATE_NO_WINDOW
                
            # 4. timeout=15 추가: 무슨 일이 있어도 15초 뒤엔 무조건 끝냄
            result = subprocess.run(
                cmd, 
                capture_output=True, 
                text=True, 
                creationflags=creation_flags, 
                encoding='utf-8', 
                errors='ignore',
                timeout=15 
            )
            
            output = result.stdout.strip()
            if not output:
                return []

            apps = json.loads(output)
            
            # 5. 가나다 순 정렬 및 캐시에 저장
            if isinstance(apps, list):
                apps = sorted(apps, key=lambda x: x.get('Name', '').lower())
                self.app_list_cache = apps  # ★ 스캔 완료된 목록 저장
                return apps
            return []
            
        except subprocess.TimeoutExpired:
            print(f"[{self.uuid}] App scan timed out!")
            # 타임아웃 발생 시 콤보박스에 에러 메시지 표시
            return [{"Name": "스캔 시간 초과 (파워쉘 응답 없음)", "AppID": ""}]
        except Exception as e:
            print(f"[{self.uuid}] Failed to get app list: {e}")
            return [{"Name": "목록을 불러오는 중 오류 발생", "AppID": ""}]

    async def handle_message(self, data):
        event = data.get("event")
        
        # 메인 프로그램이 알맹이(payload)만 보내므로, command를 바로 꺼냅니다.
        command = data.get("command") or data.get("payload", {}).get("command")
        
        if event == "keyDown":
            await self.on_key_down(data)
            
        # ▼▼▼ [수정됨: event 대신 command를 직접 확인합니다] ▼▼▼
        elif command == "get_app_list":
            context = data.get("context") or data.get("payload", {}).get("context")
            
            # 무거운 스캔 작업이므로 스레드에서 비동기로 실행
            apps = await asyncio.to_thread(self._get_installed_apps)
            
            response = {
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {
                    "command": "app_list_result",
                    "apps": apps
                }
            }
            await self.runner.send_message(response)
        # ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
            
        elif command == "start_recording":
            if not self.is_recording:
                self.is_recording = True
                context = data.get("context") or data.get("payload", {}).get("context")
                
                async def _record_task():
                    try:
                        # 하드웨어 센서 폴링 시작
                        hotkey = await asyncio.to_thread(self._poll_hardware_keys)
                        
                        response = {
                            "event": "sendToPropertyInspector",
                            "context": context,
                            "payload": {
                                "command": "recording_finished",
                                "hotkey": hotkey
                            }
                        }
                        await self.runner.send_message(response)
                    except Exception as e:
                        print(f"[{self.uuid}] 캡처 에러: {e}")
                    finally:
                        self.is_recording = False

                asyncio.create_task(_record_task())

    def _poll_hardware_keys(self):
        """이벤트 가로채기(Hook)를 쓰지 않고, 0.01초마다 하드웨어 센서를 직접 읽습니다!"""
        start_time = time.time()
        modifiers_set = {'ctrl', 'shift', 'alt', 'windows'}
        
        while time.time() - start_time < 10.0:
            pressed_keys = []
            
            # 모든 키의 현재 물리적 상태 검사
            for vk, name in VK_MAP.items():
                if ctypes.windll.user32.GetAsyncKeyState(vk) & 0x8000:
                    if name not in pressed_keys:
                        pressed_keys.append(name)
            
            # 조합키(Ctrl, Win)가 아닌 일반 키(Left, a 등)가 눌렸는지 확인
            non_mods = [k for k in pressed_keys if k not in modifiers_set]
            
            if non_mods:
                # 일반 키가 눌리는 그 즉시 단축키 완성으로 간주하고 루프 탈출!
                mods_pressed = [m for m in ['ctrl', 'shift', 'alt', 'windows'] if m in pressed_keys]
                final_hotkey = "+".join(mods_pressed + non_mods)
                return final_hotkey
                
            time.sleep(0.01) # 10ms 대기 (CPU 과부하 방지)
            
        return "" # 10초 초과 시 빈 문자열

    async def on_key_down(self, data):
        action_id = data.get("action")
        settings = data.get("payload", {}).get("settings", {})

        # 1. 파일/URL 열기
        if action_id == "com.cookie.shortcuts.open":
            path = settings.get("path")
            if path:
                await asyncio.to_thread(self.open_path, path)

        # 2. 단축키 전송
        elif action_id == "com.cookie.shortcuts.hotkey":
            hotkey_preset = settings.get("hotkey")
            hotkey_to_send = settings.get("hotkey_custom") if hotkey_preset == 'custom' else hotkey_preset
            
            if hotkey_to_send:
                try:
                    keyboard.send(hotkey_to_send)
                except Exception as e:
                    print(f"[{self.uuid}] Hotkey Error: {e}")

        # 3. 텍스트 입력
        elif action_id == "com.cookie.shortcuts.typetext":
            text = settings.get("text_to_type")
            if text:
                try:
                    keyboard.write(text)
                except Exception as e:
                    print(f"[{self.uuid}] Typing Error: {e}")
                    
        # ▼▼▼ [4. 앱 실행 로직 추가] ▼▼▼
        elif action_id == "com.cookie.shortcuts.runapp":
            app_id = settings.get("appid")
            if app_id:
                try:
                    # Windows의 특별한 프로토콜(shell:AppsFolder)을 사용하여 
                    # UWP 앱과 일반 앱을 가리지 않고 실행합니다!
                    os.startfile(f"shell:AppsFolder\\{app_id}")
                except Exception as e:
                    print(f"[{self.uuid}] RunApp Error: {e}")                    

    def open_path(self, path):
        try:
            if sys.platform == "win32":
                os.startfile(path)
            elif sys.platform == "darwin": 
                subprocess.run(['open', path])
            else: 
                subprocess.run(['xdg-open', path])
        except Exception as e:
            print(f"[{self.uuid} ERROR] Failed to open path: {e}")