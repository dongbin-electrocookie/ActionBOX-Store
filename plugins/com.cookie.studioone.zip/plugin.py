import asyncio
import os
import sys

try:
    import keyboard
except ImportError:
    keyboard = None

try:
    import pyautogui
except ImportError:
    pyautogui = None

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.windows_hotkey_map = {
            "play_stop": "space",
            "record": "*",
            "return_zero": ".",
            "loop_toggle": "/",
            "metronome": "c",
            "tool_arrow": "1",
            "tool_range": "2",
            "tool_split": "3",
            "tool_eraser": "4",
            "tool_paint": "5",
            "tool_mute": "6",
            "tool_listen": "7",
            "view_editor": "f2",
            "view_console": "f3",
            "view_inspector": "f4",
            "view_browser": "f5",
            "view_video": "f6",
            "undo": "ctrl+z",
            "redo": "ctrl+y",
            "duplicate": "d",
            "duplicate_shared": "shift+d",
            "split_cursor": "alt+x",
            "merge_events": "g",
            "quantize": "q",
            "quantize_50": "alt+q",
            "mute_events": "m",
            "zoom_in": "e",
            "zoom_out": "w",
            "zoom_in_v": "shift+e",
            "zoom_out_v": "shift+w",
            "zoom_full": "shift+e",
            "add_track": "t",
            "add_marker": "y",
            "next_marker": "shift+n",
            "prev_marker": "shift+b"
        }



        self.macos_hotkey_map = {
            "play_stop": "space",
            "record": "*",
            "return_zero": ".",
            "loop_toggle": "/",
            "metronome": "c",
            "tool_arrow": "1",
            "tool_range": "2",
            "tool_split": "3",
            "tool_eraser": "4",
            "tool_paint": "5",
            "tool_mute": "6",
            "tool_listen": "7",
            "view_editor": "f2",
            "view_console": "f3",
            "view_inspector": "f4",
            "view_browser": "f5",
            "view_video": "f6",
            "undo": "command+z",
            "redo": "command+y",
            "duplicate": "d",
            "duplicate_shared": "shift+d",
            "split_cursor": "option+x",
            "merge_events": "g",
            "quantize": "q",
            "quantize_50": "option+q",
            "mute_events": "m",
            "zoom_in": "e",
            "zoom_out": "w",
            "zoom_in_v": "shift+e",
            "zoom_out_v": "shift+w",
            "zoom_full": "shift+e",
            "add_track": "t",
            "add_marker": "y",
            "next_marker": "shift+n",
            "prev_marker": "shift+b"
        }

        self.hotkey_map = self.macos_hotkey_map if IS_MACOS else self.windows_hotkey_map

        self.icon_map = {
            "play_stop": "play stop",
            "record": "toggle record",
            "return_zero": "return to zero",
            "loop_toggle": "toggle loop",
            "metronome": "toggle metronome",
            "tool_arrow": "arrow tool",
            "tool_range": "range tool",
            "tool_split": "knife",
            "tool_eraser": "eraser tool",
            "tool_paint": "paint tool",
            "tool_mute": "mute",
            "tool_listen": "listen",
            "view_editor": "edit",
            "view_console": "console",
            "view_inspector": "inspector",
            "view_browser": "browser",
            "view_video": "video player",
            "undo": "undo",
            "redo": "redo",
            "duplicate": "duplicate",
            "duplicate_shared": "shared duplicate",
            "split_cursor": "split at cursor",
            "merge_events": "merge",
            "quantize": "quantize",
            "quantize_50": "quantize 50%",
            "mute_events": "mute selected events",
            "zoom_in": "horizontal zoom in",
            "zoom_out": "horizontal zoom out",
            "zoom_in_v": "vertical zoom in",
            "zoom_out_v": "vertical zoom out",
            "zoom_full": "fit full view",
            "add_track": "add new track",
            "add_marker": "add marker",
            "next_marker": "go to next marker",
            "prev_marker": "go to prev marker"
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "play_stop", "play stop")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "s1_hotkey", "command", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "play_stop"
        new_settings = {
            "s1_hotkey": default_action,
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })
        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or settings.get("s1_hotkey") or "play_stop")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    def _normalize_pyautogui_key(self, key_name):
        key = str(key_name).strip().lower()
        aliases = {
            "ctrl": "ctrl",
            "control": "ctrl",
            "cmd": "command" if IS_MACOS else "win",
            "command": "command" if IS_MACOS else "win",
            "win": "command" if IS_MACOS else "win",
            "windows": "command" if IS_MACOS else "win",
            "alt": "option" if IS_MACOS else "alt",
            "option": "option" if IS_MACOS else "alt",
            "return": "enter",
            "escape": "esc",
            "del": "delete",
            "page up": "pageup",
            "page down": "pagedown",
            "pgup": "pageup",
            "pgdn": "pagedown",
        }
        return aliases.get(key, key)

    def _send_hotkey_sync(self, hotkey):
        if not hotkey:
            return

        if IS_WINDOWS and keyboard:
            keyboard.send(hotkey)
            return

        if not pyautogui:
            print(f"[{self.uuid}] pyautogui is not available; hotkey skipped: {hotkey}")
            return

        parts = [self._normalize_pyautogui_key(p) for p in hotkey.split('+') if p.strip()]
        if not parts:
            return

        if len(parts) == 1:
            key = parts[0]
            if len(key) == 1 and key in "*/+-=,.;[]\\'`":
                pyautogui.write(key)
            else:
                pyautogui.press(key)
        else:
            pyautogui.hotkey(*parts)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        action = settings.get("command") or settings.get("s1_hotkey")

        if action and action in self.hotkey_map:
            hotkey = self.hotkey_map[action]
            await asyncio.to_thread(self._send_hotkey_sync, hotkey)
            print(f"[{self.uuid}] Fender Studio Pro hotkey sent: {hotkey}")
