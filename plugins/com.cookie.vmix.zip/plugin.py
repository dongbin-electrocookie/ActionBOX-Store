import asyncio
import websockets
import json
import urllib.request
import urllib.parse
import os

class VMixPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.vmix"
        self.cd_uri = "ws://localhost:8765"
        self.cd_ws = None
        self.vmix_url = "http://127.0.0.1:8088/api/"
        self.last_valid_settings = {}
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.icon_map = {
            "Cut": "STATE_CUT",
            "Fade": "STATE_FADE",
            "Merge": "STATE_MERGE",
            "Wipe": "STATE_WIPE",
            "StartStreaming": "STATE_START_STREAMING",
            "StopStreaming": "STATE_STOP_STREAMING",
            "StartRecording": "STATE_START_RECORDING",
            "StopRecording": "STATE_STOP_RECORDING",
            "AudioMute": "STATE_AUDIO_MUTE",
            "AudioMuteOn": "STATE_AUDIO_MUTE_ON",
            "AudioMuteOff": "STATE_AUDIO_MUTE_OFF",
            "Play": "STATE_PLAY",
            "Pause": "STATE_PAUSE",
            "Restart": "STATE_RESTART",
        }

    def _default_action(self):
        return "Cut"

    def _default_settings(self):
        action = self._default_action()
        return {
            "vmix_action": action,
            "command": action,
            "target_input": "",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or merged.get("vmix_action") or self._default_action()
        merged["vmix_action"] = action
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("vmix_action"),
            s.get("target_input"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        if not self.cd_ws or not context:
            return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.cd_ws.send(json.dumps({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            }))

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.last_valid_settings[context] = defaults.copy()
            if self.cd_ws:
                await self.cd_ws.send(json.dumps({
                    "event": "setSettings",
                    "context": context,
                    "payload": defaults
                }))
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.last_valid_settings[context] = merged
        await self._send_builtin_icon(context, merged["command"])
        return True

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.cd_uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    print(f"[{self.PLUGIN_UUID}] CookieDeck registered.", flush=True)
                    await self.listen_cookiedeck()
            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] CookieDeck reconnect... {e}", flush=True)
                await asyncio.sleep(3)
            finally:
                self.cd_ws = None

    async def listen_cookiedeck(self):
        async for message in self.cd_ws:
            try:
                data = json.loads(message)
                event = data.get("event")
                context = data.get("context")
                payload = data.get("payload", {}) or {}

                if event == "keyDidAppear":
                    raw_settings = payload.get("settings", {}) or {}
                    if context:
                        await self._initialize_default_visuals_if_new(context, raw_settings)

                elif event == "didReceiveSettings":
                    settings = payload.get("settings", payload) or {}
                    if context:
                        self.last_valid_settings[context] = self._merge_with_defaults({
                            **self.last_valid_settings.get(context, {}),
                            **settings
                        })

                elif event in ["keyDidDisappear", "willDisappear"]:
                    if context in self.last_valid_settings:
                        self.last_valid_settings.pop(context, None)

                elif event == "sendToPlugin":
                    command = payload.get("command")
                    if command == "apply_builtin_icon":
                        action_name = payload.get("action_command")
                        if not action_name and context:
                            action_name = self.last_valid_settings.get(context, {}).get("command")
                        await self._send_builtin_icon(context, action_name or self._default_action())

                elif event == "keyDown":
                    await self.on_key_down(data)

            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] Listen Error: {e}", flush=True)

    def send_vmix_request(self, params):
        try:
            query_string = urllib.parse.urlencode(params)
            req_url = f"{self.vmix_url}?{query_string}"
            with urllib.request.urlopen(req_url, timeout=1) as response:
                if response.status == 200:
                    print(f"[{self.PLUGIN_UUID}] vMix OK: {req_url}", flush=True)
        except Exception as e:
            print(f"[{self.PLUGIN_UUID}] vMix request failed: {e}", flush=True)

    async def ensure_settings(self, context, payload):
        incoming_settings = payload.get("settings", {}) if isinstance(payload, dict) else {}
        if incoming_settings:
            cached = self.last_valid_settings.get(context, {})
            self.last_valid_settings[context] = self._merge_with_defaults({**cached, **incoming_settings})
        return self._merge_with_defaults(self.last_valid_settings.get(context, {}))

    async def on_key_down(self, data):
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        final_settings = await self.ensure_settings(context, payload)

        action = final_settings.get("command") or final_settings.get("vmix_action", "Cut")
        target_input = (final_settings.get("target_input") or "").strip()

        params = {"Function": action}
        if target_input:
            params["Input"] = target_input

        await asyncio.to_thread(self.send_vmix_request, params)


class Plugin(VMixPlugin):
    """COMBO-X shared-runtime entry point."""

    def __init__(self, runner, manifest):
        super().__init__()
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.cd_ws = runner

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")
        payload = data.get("payload", {}) or {}

        if event == "keyDidAppear":
            raw_settings = payload.get("settings", {}) or {}
            if context:
                await self._initialize_default_visuals_if_new(context, raw_settings)
        elif event == "didReceiveSettings":
            settings = payload.get("settings", payload) or {}
            if context:
                self.last_valid_settings[context] = self._merge_with_defaults({
                    **self.last_valid_settings.get(context, {}),
                    **settings,
                })
        elif event in ("keyDidDisappear", "willDisappear"):
            self.last_valid_settings.pop(context, None)
        elif event == "sendToPlugin":
            command = payload.get("command")
            if command == "apply_builtin_icon":
                action_name = payload.get("action_command")
                if not action_name and context:
                    action_name = self.last_valid_settings.get(context, {}).get("command")
                await self._send_builtin_icon(context, action_name or self._default_action())
        elif event == "keyDown":
            await self.on_key_down(data)

async def main():
    plugin = VMixPlugin()
    await plugin.connect()

if __name__ == "__main__":
    asyncio.run(main())
