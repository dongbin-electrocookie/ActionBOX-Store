import asyncio
import sys

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 🚀 [업그레이드] 실무에서 가장 많이 쓰는 윈도우 창 관리 단축키 총망라
        self.hotkey_map = {
            # 1. 기본 분할 및 크기
            "left": "win+left",
            "right": "win+right",
            "maximize": "win+up",
            "minimize": "win+down",
            
            # 2. 다중 모니터 이동 (듀얼 모니터 필수품!)
            "monitor_prev": "win+shift+left",
            "monitor_next": "win+shift+right",
            
            # 3. 특수 제어
            "focus_mode": "win+home",  # 현재 창 빼고 다 숨기기 (집중 모드)
            "snap_layout": "win+z",    # 윈도우 11 화면 분할 레이아웃 호출
            "show_desktop": "win+d"    # 바탕화면 보기 (토글)
        }

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return
        
        if sys.platform != "win32":
            return

        settings = data.get("payload", {}).get("settings", {})
        
        # 🚀 [표준화] 'command'를 먼저 확인하고, 없으면 기존 'win_action'을 씁니다.
        selected_action = settings.get("command") or settings.get("win_action", "left")
        
        hotkey_to_send = self.hotkey_map.get(selected_action)
        
        if hotkey_to_send:
            await asyncio.to_thread(keyboard.send, hotkey_to_send)