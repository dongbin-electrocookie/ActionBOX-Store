import asyncio
import urllib.request
import json
import base64
import io
import os

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    pass

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get('UUID', 'com.cookie.crypto')
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.active_buttons = {}
        
        # 🚀 루프는 켜자마자 바로 백그라운드에서 가동!
        asyncio.create_task(self.update_loop())
        print(f"[{self.uuid}] 🟢 코인 플러그인 로드 완료! (철벽 방어 모드)")

    async def handle_message(self, data):
        event = data.get("event", "")
        context = data.get("context")
        payload = data.get("payload") or {}
        
        # 💡 [핵심 CCTV] 엔진이 보내는 모든 신호를 터미널에 무조건 출력합니다!
        print(f"👉 [수신됨] 이벤트: {event} | 버튼: {context} | 데이터: {payload}")

        if not context: 
            return

        # 🧟 좀비 킬러 (어떤 단어로 지우든 다 때려잡습니다)
        if "disappear" in event.lower() or "delete" in event.lower() or "remove" in event.lower() or "clear" in event.lower():
            if context in self.active_buttons:
                del self.active_buttons[context]
                print(f"❌ [{context}] 버튼 삭제됨 - 갱신을 완전히 중지합니다.")
            return

        # 설정값 안전하게 추출
        settings = payload.get("settings") if isinstance(payload, dict) and "settings" in payload else payload

        # 🚀 철벽 방어 로직: "제대로 된 코인 심볼이 들어왔을 때만" 덮어씁니다!
        if isinstance(settings, dict) and settings.get("symbol"):
            self.active_buttons[context] = settings
            print(f"✅ [{context}] 종목 갱신 확정: {settings.get('symbol')}")
            await self.update_coin(context, settings)
        
        # 엔진이 빈깡통을 보냈지만, 우리 파이썬이 이미 코인을 기억하고 있다면 그걸로 그리기 (엔진 뒷북 무시)
        elif context in self.active_buttons:
            await self.update_coin(context, self.active_buttons[context])

    async def update_loop(self):
        """1초 자동 갱신 루프"""
        while True:
            # 딕셔너리 크기가 바뀌어도 에러 안 나게 list()로 감싸기
            for context, settings in list(self.active_buttons.items()):
                await self.update_coin(context, settings)
                await asyncio.sleep(0.05)
            await asyncio.sleep(1.0)

    async def update_coin(self, context, settings):
        symbol = settings.get("symbol")
        if not symbol: return

        # 여기서 API로 그림을 그리는 데 시간이 걸림
        b64_image = await asyncio.to_thread(self.get_crypto_image_base64, symbol, settings)
        
        # 🛡️ [방어] 그리는 동안 사용자가 버튼을 지웠거나 페이지를 넘겼으면 즉시 전송 취소!
        current_active = self.active_buttons.get(context)
        if not current_active or current_active.get("symbol") != symbol:
            return

        if b64_image and self.runner:
            await self.runner.send_message({"event": "setImage", "context": context, "payload": {"image": b64_image}})
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": ""}})

    def get_fit_font(self, draw, text, font_name, max_width, start_size, min_size=12):
        size = start_size
        while size > min_size:
            try: font = ImageFont.truetype(os.path.join(self.plugin_dir, font_name), size)
            except: return ImageFont.load_default()
            try: w = draw.textlength(text, font=font)
            except: w = draw.textbbox((0,0), text, font=font)[2]
            if w <= max_width: return font
            size -= 2
        return font

    def get_crypto_image_base64(self, symbol, settings):
        try:
            url = f"https://api.binance.com/api/v3/ticker/24hr?symbol={symbol}"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as res:
                data = json.loads(res.read().decode('utf-8'))
            
            current_price = float(data['lastPrice'])
            price_change_percent = float(data['priceChangePercent'])

            bg_color = (194, 53, 49) if price_change_percent >= 0 else (44, 98, 181)
            img = Image.new('RGB', (128, 128), color=bg_color)
            draw = ImageDraw.Draw(img)
            
            display_name = settings.get("display_name", "").strip()
            if not display_name: display_name = symbol.replace("USDT", "")
            
            if current_price >= 1000: price_str = f"{current_price:,.2f}"
            elif current_price >= 1: price_str = f"{current_price:,.4f}"
            else: price_str = f"{current_price:.6f}"
            
            percent_str = f"{'+' if price_change_percent > 0 else ''}{price_change_percent:.2f}%"

            font_name = self.get_fit_font(draw, display_name, "malgunbd.ttf", 120, 24)
            font_price = self.get_fit_font(draw, price_str, "malgunbd.ttf", 124, 30)
            font_change = self.get_fit_font(draw, percent_str, "malgunbd.ttf", 120, 22)

            def draw_centered(y, text, font, fill):
                try: w = draw.textlength(text, font=font)
                except: w = draw.textbbox((0,0), text, font=font)[2]
                draw.text(((128-w)/2, y), text, font=font, fill=fill)

            draw_centered(10, display_name, font_name, (255,255,255))
            draw_centered(48, price_str, font_price, (255,255,255))
            draw_centered(90, percent_str, font_change, (255,255,0))

            buffered = io.BytesIO()
            img.save(buffered, format="PNG")
            return f"data:image/png;base64,{base64.b64encode(buffered.getvalue()).decode('utf-8')}"
            
        except Exception:
            return None