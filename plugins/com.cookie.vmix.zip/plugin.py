import asyncio
import websockets
import json
import urllib.request
import urllib.parse
import os

class VMixPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.vmix"
        self.cd_uri = "ws://localhost:8765"
        self.cd_ws = None
        
        # vMix의 기본 로컬 API 주소
        self.vmix_url = "http://127.0.0.1:8088/api/"
        
        # 🚀 [대통합 표준] 버튼별(context) 설정을 기억하기 위한 저장소
        # 멀티액션 신호(#데이터)가 올 때 누락된 타겟 입력(Input) 정보를 여기서 복구합니다.
        self.last_valid_settings = {}

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.cd_uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    print(f"[{self.PLUGIN_UUID}] CookieDeck 등록 완료.")
                    await self.listen_cookiedeck()
            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] CookieDeck 연결 실패. 재시도 중... {e}")
                await asyncio.sleep(3)

    async def listen_cookiedeck(self):
        async for message in self.cd_ws:
            try:
                data = json.loads(message)
                event = data.get("event")
                context = data.get("context")
                payload = data.get("payload", {})

                if event == "keyDidAppear":
                    # 버튼이 나타날 때 기존 설정을 메모리에 로드
                    settings = payload.get("settings", {})
                    if settings:
                        self.last_valid_settings[context] = settings

                elif event == "didReceiveSettings":
                    # 설정창(PI)에서 값이 바뀌면 메모리 업데이트
                    if context not in self.last_valid_settings:
                        self.last_valid_settings[context] = {}
                    self.last_valid_settings[context].update(payload)

                elif event == "keyDown":
                    await self.on_key_down(data)

            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] Listen Error: {e}")

    def send_vmix_request(self, params):
        try:
            query_string = urllib.parse.urlencode(params)
            req_url = f"{self.vmix_url}?{query_string}"
            
            with urllib.request.urlopen(req_url, timeout=1) as response:
                if response.status == 200:
                    print(f"[{self.PLUGIN_UUID}] ✅ vMix 전송 성공: {req_url}")
        except Exception as e:
            print(f"[{self.PLUGIN_UUID}] ❌ vMix 연결 실패: {e}")

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {})
        
        # 🚀 1. 유효한 설정이 들어오면 버튼별 메모리에 저장 (캐시)
        if incoming_settings:
            if context not in self.last_valid_settings:
                self.last_valid_settings[context] = {}
            # 값이 있는 설정만 업데이트
            filtered = {k: v for k, v in incoming_settings.items() if v}
            self.last_valid_settings[context].update(filtered)

        # 🚀 2. 메모리와 현재 데이터를 합칩니다 (멀티액션 대응 핵심)
        saved = self.last_valid_settings.get(context, {})
        final_settings = {**saved, **incoming_settings}

        # 🚀 3. [표준화] 'command'를 우선 확인하여 vMix의 Function을 결정합니다.
        action = final_settings.get("command") or final_settings.get("vmix_action", "Cut")
        target_input = final_settings.get("target_input", "").strip()

        # vMix API 파라미터 조립
        params = {"Function": action}
        if target_input:
            params["Input"] = target_input

        # 메인 루프가 멈추지 않도록 스레드에서 전송
        await asyncio.to_thread(self.send_vmix_request, params)

async def main():
    plugin = VMixPlugin()
    await plugin.connect()

if __name__ == "__main__":
    asyncio.run(main())