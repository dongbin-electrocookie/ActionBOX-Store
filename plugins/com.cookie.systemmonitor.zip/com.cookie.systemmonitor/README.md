# COMBO-X System Monitor 1.0.0

Cross-platform live system metrics for COMBO-X.

## Supported platforms

- Windows: LibreHardwareMonitor HTTP JSON provider.
- macOS: Apple Silicon (M1-M5) through macmon HTTP JSON provider.
- Intel Macs are not supported by the macmon provider.

## Metrics

- CPU usage
- Memory usage
- GPU temperature
- GPU usage
- Network upload
- Network download
- CPU power
- GPU power

## Windows provider

The plugin keeps the existing LibreHardwareMonitor integration. The bundled executable is started silently and the plugin reads `data.json` from the listener configured in `LibreHardwareMonitor.config`, with local-address fallbacks.

## macOS provider

The plugin uses the **bundled** `macmon` executable on Apple Silicon. It does not search COMBO-X `utility/`, Homebrew, `/usr/local/bin`, or the user's PATH.

Expected plugin layout:

```text
com.cookie.systemmonitor/
  macmon/
    macmon
    LICENSE
```

The plugin restores executable permission on `macmon/macmon` before launch and starts a localhost-only server on port `19779`:

```text
macmon serve --host 127.0.0.1 -p 19779 -i 1000
```

The `macmon/LICENSE` file contains the upstream MIT license and must remain in distributed copies. The `macmon` executable should also be included in the final macOS code-signing/notarization pass.

## Display behavior

Live values are sent only to the physical COMBO-X device. The desktop key editor keeps the static metric artwork instead of drawing the changing CPU/RAM/GPU value over the preview.

Contexts are page-scoped (`pN:key`), and hidden-page contexts are removed on disappearance so live values do not leak into other pages.

## Third-party components

See `NOTICE.txt` for LibreHardwareMonitor and macmon licensing information.
