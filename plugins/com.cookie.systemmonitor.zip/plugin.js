// plugin.js - 시스템 모니터 대통합(command) 버전
const WebSocket = require('ws');
const { Worker, isMainThread, parentPort } = require('worker_threads');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

// 1. CookieDeck 실행 인자 파싱
const args = {};
for (let i = 2; i < process.argv.length; i += 2) {
    args[process.argv[i]] = process.argv[i + 1];
}
const port = args['-port'] || '8765';
const pluginUUID = args['-pluginUUID'] || 'com.cookie.systemmonitor';
const registerEvent = args['-registerEvent'] || 'register';
const uri = `ws://localhost:${port}`;

// 실시간 감시 중인 버튼들 (메모리 캐시)
let activeKeys = {};
let cookieDeckSocket = null;
let reconnectAttempts = 0;     
const MAX_RETRIES = 5;         

// LibreHardwareMonitor 경로 설정
const lhmPath = path.resolve(__dirname, 'LibreHardwareMonitor', 'LibreHardwareMonitor.exe');
const exeName = "LibreHardwareMonitor.exe";

if (isMainThread) {
    /**
     * [기능] LibreHardwareMonitor 중복 실행 방지 및 자동 실행
     */
    function launchLHM() {
        if (fs.existsSync(lhmPath)) {
            exec(`tasklist /FI "IMAGENAME eq ${exeName}" /NH`, (err, stdout) => {
                if (stdout && stdout.includes(exeName)) {
                    console.log("[SysMon] LibreHardwareMonitor is already running.");
                } else {
                    console.log("[SysMon] Launching LibreHardwareMonitor...");
                    exec(`start "" "${lhmPath}"`, (error) => {
                        if (error) console.log("LHM Start Error:", error.message);
                    });
                }
            });
        }
    }
    
    launchLHM();

    /**
     * [루프] 1초마다 하드웨어 데이터를 파싱할 워커 스레드 생성
     */
    setInterval(() => {
        if (Object.keys(activeKeys).length > 0) {
            const worker = new Worker(__filename);
            worker.on('message', (data) => {
                if (data.error) return;
                if (cookieDeckSocket && cookieDeckSocket.readyState === WebSocket.OPEN && data.result) {
                    updateDynamicContent(data.result);
                }
            });
        }
    }, 1000);

    /**
     * [통신] CookieDeck 서버 연결 및 메시지 처리
     */
    function connectToCookieDeck() {
        cookieDeckSocket = new WebSocket(uri);
        
        cookieDeckSocket.on('open', () => {
            console.log("[SysMon] Connected to CookieDeck!");
            reconnectAttempts = 0; 
            cookieDeckSocket.send(JSON.stringify({ event: registerEvent, uuid: pluginUUID }));
        });
        
        cookieDeckSocket.on('message', (message) => {
            const data = JSON.parse(message);
            const context = data.context;
            const payload = data.payload || {};

            // 🚀 [표준화] 버튼이 나타날 때 초기 측정 항목 설정
            if (data.event === 'keyDidAppear') {
                const settings = payload.settings || {};
                // command(표준) -> selected_metric(기존) 순으로 확인
                const metric = settings.command || settings.selected_metric || 'cpu_usage';
                activeKeys[context] = { 
                    page: payload.page, 
                    metric: metric 
                };
            } 
            // 버튼이 사라지면 감시 목록에서 제거
            else if (data.event === 'keyDidDisappear') {
                delete activeKeys[context];
            } 
            // 🚀 [표준화] 설정창(PI)에서 항목 변경 시 즉시 반영
            else if (data.event === 'didReceiveSettings') {
                if (activeKeys[context]) {
                    const settings = data.payload || {};
                    activeKeys[context].metric = settings.command || settings.selected_metric || 'cpu_usage';
                }
            }
            // 🚀 [멀티액션 대응] keyDown 시 command가 들어오면 모니터링 항목 실시간 스위칭
            else if (data.event === 'keyDown') {
                const settings = payload.settings || {};
                if (settings.command && activeKeys[context]) {
                    console.log(`[SysMon] Multi-action Switch: ${settings.command}`);
                    activeKeys[context].metric = settings.command;
                }
            }
        });

        cookieDeckSocket.on('close', () => {
            reconnectAttempts++;
            if (reconnectAttempts <= MAX_RETRIES) {
                setTimeout(connectToCookieDeck, 2000);
            } else {
                process.exit(0);
            }
        });

        cookieDeckSocket.on('error', () => {});
    }

    /**
     * [화면 갱신] 워커에서 받은 데이터를 기반으로 버튼 텍스트 업데이트
     */
    function updateDynamicContent(parsedData) {
        for (const context in activeKeys) {
            const keyInfo = activeKeys[context];
            const metric = keyInfo.metric;
            let textContent = "N/A";

            // 🚀 대통합 매핑 로직
            switch(metric) {
                case "cpu_usage": textContent = `CPU\n${parsedData.cpu_load}%`; break;
                case "memory_usage": textContent = `RAM\n${parsedData.mem_percent}%`; break;
                case "gpu_temp": textContent = `GPU\n${parsedData.gpu_temp}°C`; break;
                case "gpu_usage": textContent = `GPU\n${parsedData.gpu_load}%`; break;
                case "cpu_temp": textContent = `CPU\n${parsedData.cpu_temp}°C`; break;
                case "cpu_power": textContent = `CPU\n${parsedData.cpu_power}W`; break;
                case "gpu_power": textContent = `GPU\n${parsedData.gpu_power}W`; break;
                case "network_upload": textContent = `UP\n${parsedData.net_upload}`; break;
                case "network_download": textContent = `DN\n${parsedData.net_download}`; break;
            }

            cookieDeckSocket.send(JSON.stringify({
                event: "setDynamicText",
                context: context,
                payload: {
                    "text": textContent,
                    "font_size": "24px",
                    "color": "#FFFFFF",
                    "page": keyInfo.page
                }
            }));
        }
    }
    
    connectToCookieDeck();

} else {
    /**
     * --- [워커 스레드: 하드웨어 데이터 파싱] ---
     */
    const axios = require('axios');

    function getLocalIpAddress() {
        const interfaces = os.networkInterfaces();
        for (const name in interfaces) {
            for (const iface of interfaces[name]) {
                if (iface.family === 'IPv4' && !iface.internal) return iface.address;
            }
        }
        return 'localhost'; 
    }

    const cleanValue = (valStr) => {
        if (!valStr || valStr === "-" || valStr === "N/A") return "0";
        const num = parseFloat(valStr);
        return isNaN(num) ? "0" : num.toFixed(0);
    };

    const findValue = (hardwareNodes, imgKeywords, categoryText, sensorKeywords) => {
        for (const hw of hardwareNodes) {
            const img = (hw.ImageURL || "").toLowerCase();
            if (imgKeywords.some(k => img.includes(k))) {
                const cat = hw.Children?.find(c => c.Text === categoryText);
                if (cat?.Children) {
                    for (const kw of sensorKeywords) {
                        const sensor = cat.Children.find(s => s.Text.includes(kw));
                        if (sensor) return sensor.Value;
                    }
                }
            }
        }
        return "0";
    };

    const findNetwork = (hardwareNodes, type) => {
        const nic = hardwareNodes.find(hw => (hw.ImageURL || "").includes("nic"));
        const throughput = nic?.Children?.find(c => c.Text === "Throughput");
        const sensor = throughput?.Children?.find(s => s.Text.includes(type));
        return sensor ? sensor.Value.split('/')[0].replace(" ", "") : "0";
    };

    const fetchData = async () => {
        try {
            const url = `http://${getLocalIpAddress()}:8085/data.json`;
            const response = await axios.get(url, { timeout: 900 });
            const hardwareNodes = response.data?.Children?.[0]?.Children || [];

            parentPort.postMessage({ result: {
                cpu_load: cleanValue(findValue(hardwareNodes, ['cpu'], 'Load', ['CPU Total'])),
                mem_percent: cleanValue(findValue(hardwareNodes, ['ram'], 'Load', ['Memory'])),
                gpu_temp: cleanValue(findValue(hardwareNodes, ['gpu'], 'Temperatures', ['GPU Core'])),
                gpu_load: cleanValue(findValue(hardwareNodes, ['gpu'], 'Load', ['GPU Core'])),
                cpu_temp: cleanValue(findValue(hardwareNodes, ['cpu'], 'Temperatures', ['Package', 'Core Max'])),
                cpu_power: cleanValue(findValue(hardwareNodes, ['cpu'], 'Powers', ['Package'])),
                gpu_power: cleanValue(findValue(hardwareNodes, ['gpu'], 'Powers', ['GPU Power'])),
                net_upload: findNetwork(hardwareNodes, 'Upload'),
                net_download: findNetwork(hardwareNodes, 'Download')
            }});
        } catch (e) {
            parentPort.postMessage({ error: e.message });
        }
    };
    fetchData();
}