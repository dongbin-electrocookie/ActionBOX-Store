#target illustrator

if (app.documents.length === 0) {
  alert("❌ 열린 문서가 없습니다.");
} else {
  var doc = app.activeDocument;
  var imageFile = File.openDialog("📂 삽입할 이미지 파일을 선택하세요", "*.jpg;*.png;*.psd", false);

  if (!imageFile) {
    alert("⚠ 이미지가 선택되지 않았습니다.");
  } else {
    var margin = 10;

    for (var i = 0; i < doc.artboards.length; i++) {
      var ab = doc.artboards[i];
      var rect = ab.artboardRect; // [left, top, right, bottom]

      // 이미지 삽입
      var placed = doc.placedItems.add();
      placed.file = imageFile;
      // placed.embed(); // 필요 시

      var imgWidth = placed.width;
      var imgHeight = placed.height;

      // 정확히 오른쪽 아래 모서리에서 margin만큼 위, 왼쪽으로 띄운 좌표 계산
      var posX = rect[2] - imgWidth - margin;
      var posY = rect[3] + imgHeight + margin;

      placed.position = [posX, posY];
    }

    alert("✅ 모든 아트보드 오른쪽 아래 10px에 이미지가 정확히 삽입되었습니다.");
  }
}
