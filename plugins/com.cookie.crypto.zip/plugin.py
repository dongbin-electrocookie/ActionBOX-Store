import asyncio
import urllib.request
import json
import base64
import io
import os
import ssl

try:
    import certifi
except ImportError:
    certifi = None

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    Image = None
    ImageDraw = None
    ImageFont = None


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get('UUID', 'com.cookie.crypto')
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.active_buttons = {}
        self.context_settings = {}
        self.default_icon_path = os.path.join(self.plugin_dir, "icon", "DEFAULT.png")
        self.ssl_context = self._create_ssl_context()

        asyncio.create_task(self.update_loop())
        print(f"[{self.uuid}] Crypto plugin loaded.")

    def _create_ssl_context(self):
        if certifi:
            try:
                return ssl.create_default_context(cafile=certifi.where())
            except Exception as e:
                print(f"[{self.uuid}] certifi SSL context failed: {e}")
        return ssl.create_default_context()

    def _default_settings(self):
        return {
            "symbol": "",
            "display_name": "",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("symbol"),
            s.get("display_name"),
            s.get("title"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    async def handle_message(self, data):
        event = data.get("event", "")
        context = data.get("context")
        payload = data.get("payload") or {}

        if not context:
            return

        if "disappear" in event.lower() or "delete" in event.lower() or "remove" in event.lower() or "clear" in event.lower():
            self.active_buttons.pop(context, None)
            self.context_settings.pop(context, None)
            print(f"[{context}] Crypto button removed.")
            return

        settings = payload.get("settings") if isinstance(payload, dict) and "settings" in payload else payload
        if not isinstance(settings, dict):
            settings = {}

        if event in ["willAppear", "keyDidAppear"]:
            await self.on_key_did_appear(context, payload, settings)
            return

        if event == "didReceiveSettings":
            merged = self._merge_with_defaults(settings)
            merged["_target_page"] = payload.get("page", self.active_buttons.get(context, {}).get("_target_page"))
            self.context_settings[context] = merged

            if merged.get("symbol"):
                self.active_buttons[context] = merged
                await self.update_coin(context, merged)
            else:
                self.active_buttons.pop(context, None)
                await self.show_default_icon(context)
            return

        if event in ["button_press", "keyDown"]:
            await self.on_key_down(context, payload, settings)
            return

        if event == "sendToPlugin" and payload.get("command") == "force_update":
            new_settings = payload.get("settings", {}) or {}
            if not isinstance(new_settings, dict):
                new_settings = {}

            merged = self._merge_with_defaults(new_settings)
            merged["_target_page"] = payload.get("page", self.active_buttons.get(context, {}).get("_target_page"))
            self.context_settings[context] = merged

            if merged.get("symbol"):
                self.active_buttons[context] = merged
                await self.update_coin(context, merged)
            else:
                self.active_buttons.pop(context, None)
                await self.show_default_icon(context)

    async def on_key_did_appear(self, context, payload, incoming_settings):
        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = {**defaults, "_target_page": payload.get("page")}

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self.show_default_icon(context)
            return

        merged = self._merge_with_defaults(incoming_settings)
        merged["_target_page"] = payload.get("page")
        self.context_settings[context] = merged

        if merged.get("symbol"):
            self.active_buttons[context] = merged
            await self.update_coin(context, merged)
        else:
            self.active_buttons.pop(context, None)
            await self.show_default_icon(context)

    async def on_key_down(self, context, payload, incoming_settings):
        cached = self.context_settings.get(context, {})
        merged = self._merge_with_defaults({**cached, **incoming_settings})
        merged["_target_page"] = payload.get("page", self.active_buttons.get(context, {}).get("_target_page"))
        self.context_settings[context] = merged

        if merged.get("symbol"):
            self.active_buttons[context] = merged
            await self.update_coin(context, merged)
        else:
            self.active_buttons.pop(context, None)
            await self.show_default_icon(context)

    async def show_default_icon(self, context):
        if self.runner and os.path.exists(self.default_icon_path):
            target_page = None
            current_settings = self.active_buttons.get(context) or self.context_settings.get(context) or {}
            if isinstance(current_settings, dict):
                target_page = current_settings.get("_target_page")
            payload = {"icon_path": self.default_icon_path}
            if target_page is not None:
                payload["page"] = target_page
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": payload
            })

    async def update_loop(self):
        while True:
            for context, settings in list(self.active_buttons.items()):
                await self.update_coin(context, settings)
                await asyncio.sleep(0.05)
            await asyncio.sleep(1.0)

    async def update_coin(self, context, settings):
        symbol = (settings.get("symbol") or "").strip().upper()
        if not symbol:
            await self.show_default_icon(context)
            return

        b64_image = await asyncio.to_thread(self.get_crypto_image_base64, symbol, settings)

        current_active = self.active_buttons.get(context)
        if not current_active or (current_active.get("symbol", "").strip().upper() != symbol):
            return

        if b64_image and self.runner:
            target_page = settings.get("_target_page")
            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": {
                    "image": b64_image,
                    "page": target_page
                }
            })
        else:
            await self.show_default_icon(context)

    def _font_candidates(self):
        """Return font candidates in a Windows/macOS/Linux friendly order."""
        candidates = [
            os.path.join(self.plugin_dir, "malgunbd.ttf"),
            os.path.join(self.plugin_dir, "MalgunGothicBold.ttf"),
            os.path.join(os.path.dirname(os.path.dirname(self.plugin_dir)), "locales", "SourceHanSansK-Regular.otf"),
        ]

        if os.sys.platform == "darwin":
            candidates.extend([
                "/System/Library/Fonts/AppleSDGothicNeo.ttc",
                "/System/Library/Fonts/Supplemental/AppleGothic.ttf",
                "/System/Library/Fonts/PingFang.ttc",
                "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
                "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
                "/System/Library/Fonts/Helvetica.ttc",
            ])
        elif os.sys.platform.startswith("win"):
            windir = os.environ.get("WINDIR", r"C:\Windows")
            candidates.extend([
                os.path.join(windir, "Fonts", "malgunbd.ttf"),
                os.path.join(windir, "Fonts", "arialbd.ttf"),
                os.path.join(windir, "Fonts", "seguisb.ttf"),
            ])
        else:
            candidates.extend([
                "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf",
                "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
            ])

        return [p for p in candidates if p and os.path.exists(p)]

    def _load_font(self, size):
        for path in self._font_candidates():
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
        try:
            return ImageFont.truetype("Arial.ttf", size)
        except Exception:
            return ImageFont.load_default()

    def get_fit_font(self, draw, text, max_width, start_size, min_size=12):
        size = start_size
        last_font = self._load_font(size)
        while size > min_size:
            font = self._load_font(size)
            try:
                width = draw.textlength(text, font=font)
            except Exception:
                width = draw.textbbox((0, 0), text, font=font)[2]
            if width <= max_width:
                return font
            last_font = font
            size -= 2
        return last_font

    def get_crypto_image_base64(self, symbol, settings):
        if Image is None or ImageDraw is None or ImageFont is None:
            return None

        try:
            url = f"https://api.binance.com/api/v3/ticker/24hr?symbol={symbol}"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=5, context=self.ssl_context) as res:
                data = json.loads(res.read().decode("utf-8"))

            current_price = float(data["lastPrice"])
            price_change_percent = float(data["priceChangePercent"])

            bg_color = (194, 53, 49) if price_change_percent >= 0 else (44, 98, 181)
            img = Image.new("RGB", (112, 112), color=bg_color)
            draw = ImageDraw.Draw(img)

            display_name = (settings.get("display_name") or "").strip()
            if not display_name:
                display_name = symbol.replace("USDT", "")

            if current_price >= 1000:
                price_str = f"{current_price:,.2f}"
            elif current_price >= 1:
                price_str = f"{current_price:,.4f}"
            else:
                price_str = f"{current_price:.6f}"

            percent_str = f"{'+' if price_change_percent > 0 else ''}{price_change_percent:.2f}%"

            font_name = self.get_fit_font(draw, display_name, 104, 21)
            font_price = self.get_fit_font(draw, price_str, 108, 26)
            font_change = self.get_fit_font(draw, percent_str, 104, 19)

            def draw_centered(y, text, font, fill):
                try:
                    width = draw.textlength(text, font=font)
                except Exception:
                    width = draw.textbbox((0, 0), text, font=font)[2]
                draw.text(((112 - width) / 2, y), text, font=font, fill=fill)

            draw_centered(9, display_name, font_name, (255, 255, 255))
            draw_centered(42, price_str, font_price, (255, 255, 255))
            draw_centered(79, percent_str, font_change, (255, 255, 0))

            buffered = io.BytesIO()
            img.save(buffered, format="PNG")
            return f"data:image/png;base64,{base64.b64encode(buffered.getvalue()).decode('utf-8')}"

        except Exception as e:
            print(f"[{self.uuid}] Crypto image update failed for {symbol}: {type(e).__name__}: {e}")
            return None
