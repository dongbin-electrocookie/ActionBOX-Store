import asyncio
import urllib.request
import json
import base64
import io
import os

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    Image = None
    ImageDraw = None
    ImageFont = None


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get('UUID', 'com.cookie.crypto')
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.active_buttons = {}
        self.context_settings = {}
        self.default_icon_path = os.path.join(self.plugin_dir, "icon", "DEFAULT.png")

        asyncio.create_task(self.update_loop())
        print(f"[{self.uuid}] Crypto plugin loaded.")

    def _default_settings(self):
        return {
            "symbol": "",
            "display_name": "",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("symbol"),
            s.get("display_name"),
            s.get("title"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    async def handle_message(self, data):
        event = data.get("event", "")
        context = data.get("context")
        payload = data.get("payload") or {}

        if not context:
            return

        if "disappear" in event.lower() or "delete" in event.lower() or "remove" in event.lower() or "clear" in event.lower():
            self.active_buttons.pop(context, None)
            self.context_settings.pop(context, None)
            print(f"[{context}] Crypto button removed.")
            return

        settings = payload.get("settings") if isinstance(payload, dict) and "settings" in payload else payload
        if not isinstance(settings, dict):
            settings = {}

        if event in ["willAppear", "keyDidAppear"]:
            await self.on_key_did_appear(context, payload, settings)
            return

        if event == "didReceiveSettings":
            merged = self._merge_with_defaults(settings)
            self.context_settings[context] = merged

            if merged.get("symbol"):
                merged["_target_page"] = payload.get("page", self.active_buttons.get(context, {}).get("_target_page"))
                self.active_buttons[context] = merged
                await self.update_coin(context, merged)
            else:
                self.active_buttons.pop(context, None)
                await self.show_default_icon(context)
            return

        if event in ["button_press", "keyDown"]:
            await self.on_key_down(context, payload, settings)
            return

        if event == "sendToPlugin" and payload.get("command") == "force_update":
            new_settings = payload.get("settings", {}) or {}
            if not isinstance(new_settings, dict):
                new_settings = {}

            merged = self._merge_with_defaults(new_settings)
            merged["_target_page"] = payload.get("page", self.active_buttons.get(context, {}).get("_target_page"))
            self.context_settings[context] = merged

            if merged.get("symbol"):
                self.active_buttons[context] = merged
                await self.update_coin(context, merged)
            else:
                self.active_buttons.pop(context, None)
                await self.show_default_icon(context)

    async def on_key_did_appear(self, context, payload, incoming_settings):
        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self.show_default_icon(context)
            return

        merged = self._merge_with_defaults(incoming_settings)
        merged["_target_page"] = payload.get("page")
        self.context_settings[context] = merged

        if merged.get("symbol"):
            self.active_buttons[context] = merged
            await self.update_coin(context, merged)
        else:
            self.active_buttons.pop(context, None)
            await self.show_default_icon(context)

    async def on_key_down(self, context, payload, incoming_settings):
        cached = self.context_settings.get(context, {})
        merged = self._merge_with_defaults({**cached, **incoming_settings})
        merged["_target_page"] = payload.get("page", self.active_buttons.get(context, {}).get("_target_page"))
        self.context_settings[context] = merged

        if merged.get("symbol"):
            self.active_buttons[context] = merged
            await self.update_coin(context, merged)
        else:
            self.active_buttons.pop(context, None)
            await self.show_default_icon(context)

    async def show_default_icon(self, context):
        if self.runner and os.path.exists(self.default_icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": self.default_icon_path}
            })

    async def update_loop(self):
        while True:
            for context, settings in list(self.active_buttons.items()):
                await self.update_coin(context, settings)
                await asyncio.sleep(0.05)
            await asyncio.sleep(1.0)

    async def update_coin(self, context, settings):
        symbol = (settings.get("symbol") or "").strip().upper()
        if not symbol:
            await self.show_default_icon(context)
            return

        b64_image = await asyncio.to_thread(self.get_crypto_image_base64, symbol, settings)

        current_active = self.active_buttons.get(context)
        if not current_active or (current_active.get("symbol", "").strip().upper() != symbol):
            return

        if b64_image and self.runner:
            target_page = settings.get("_target_page")
            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": {
                    "image": b64_image,
                    "page": target_page
                }
            })
        else:
            await self.show_default_icon(context)

    def get_fit_font(self, draw, text, font_name, max_width, start_size, min_size=12):
        size = start_size
        while size > min_size:
            try:
                font = ImageFont.truetype(os.path.join(self.plugin_dir, font_name), size)
            except Exception:
                return ImageFont.load_default()
            try:
                width = draw.textlength(text, font=font)
            except Exception:
                width = draw.textbbox((0, 0), text, font=font)[2]
            if width <= max_width:
                return font
            size -= 2
        return font

    def get_crypto_image_base64(self, symbol, settings):
        if Image is None or ImageDraw is None or ImageFont is None:
            return None

        try:
            url = f"https://api.binance.com/api/v3/ticker/24hr?symbol={symbol}"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=5) as res:
                data = json.loads(res.read().decode("utf-8"))

            current_price = float(data["lastPrice"])
            price_change_percent = float(data["priceChangePercent"])

            bg_color = (194, 53, 49) if price_change_percent >= 0 else (44, 98, 181)
            img = Image.new("RGB", (128, 128), color=bg_color)
            draw = ImageDraw.Draw(img)

            display_name = (settings.get("display_name") or "").strip()
            if not display_name:
                display_name = symbol.replace("USDT", "")

            if current_price >= 1000:
                price_str = f"{current_price:,.2f}"
            elif current_price >= 1:
                price_str = f"{current_price:,.4f}"
            else:
                price_str = f"{current_price:.6f}"

            percent_str = f"{'+' if price_change_percent > 0 else ''}{price_change_percent:.2f}%"

            font_name = self.get_fit_font(draw, display_name, "malgunbd.ttf", 120, 24)
            font_price = self.get_fit_font(draw, price_str, "malgunbd.ttf", 124, 30)
            font_change = self.get_fit_font(draw, percent_str, "malgunbd.ttf", 120, 22)

            def draw_centered(y, text, font, fill):
                try:
                    width = draw.textlength(text, font=font)
                except Exception:
                    width = draw.textbbox((0, 0), text, font=font)[2]
                draw.text(((128 - width) / 2, y), text, font=font, fill=fill)

            draw_centered(10, display_name, font_name, (255, 255, 255))
            draw_centered(48, price_str, font_price, (255, 255, 255))
            draw_centered(90, percent_str, font_change, (255, 255, 0))

            buffered = io.BytesIO()
            img.save(buffered, format="PNG")
            return f"data:image/png;base64,{base64.b64encode(buffered.getvalue()).decode('utf-8')}"

        except Exception:
            return None
