import AppKit
import ApplicationServices
import Foundation

private let pidFile = "/tmp/com.cookie.hpdisplayquicksettings.layout.pid"
private let holdFile = NSTemporaryDirectory() + "com.cookie.hpdisplayquicksettings.layout_hold"

private func zones(for name: String) -> [CGRect] {
    func r(_ x: CGFloat, _ y: CGFloat, _ w: CGFloat, _ h: CGFloat) -> CGRect {
        CGRect(x: x, y: y, width: w, height: h)
    }
    switch name {
    case "thirds": return [r(0,0,1/3,1), r(1/3,0,1/3,1), r(2/3,0,1/3,1)]
    case "wide-center": return [r(0,0,0.25,1), r(0.25,0,0.5,1), r(0.75,0,0.25,1)]
    case "rows": return [r(0,0,1,0.5), r(0,0.5,1,0.5)]
    case "quarters": return [r(0,0,0.5,0.5), r(0.5,0,0.5,0.5), r(0,0.5,0.5,0.5), r(0.5,0.5,0.5,0.5)]
    case "left-main": return [r(0,0,0.65,1), r(0.65,0,0.35,0.5), r(0.65,0.5,0.35,0.5)]
    case "right-main": return [r(0,0,0.35,0.5), r(0,0.5,0.35,0.5), r(0.35,0,0.65,1)]
    case "six": return (0..<6).map { r(CGFloat($0 % 3) / 3, CGFloat($0 / 3) / 2, 1/3, 1/2) }
    case "nine": return (0..<9).map { r(CGFloat($0 % 3) / 3, CGFloat($0 / 3) / 3, 1/3, 1/3) }
    case "focus": return [r(0,0,0.2,1), r(0.2,0,0.6,1), r(0.8,0,0.2,1)]
    default: return [r(0,0,0.5,1), r(0.5,0,0.5,1)]
    }
}

private final class ZoneView: NSView {
    var frames: [CGRect] = []
    var hovered = -1

    override func draw(_ dirtyRect: NSRect) {
        NSColor(calibratedRed: 0.08, green: 0.10, blue: 0.15, alpha: 0.34).setFill()
        dirtyRect.fill()
        for (index, frame) in frames.enumerated() {
            let path = NSBezierPath(roundedRect: frame.insetBy(dx: 5, dy: 5), xRadius: 8, yRadius: 8)
            let color = index == hovered
                ? NSColor(calibratedRed: 0.25, green: 0.50, blue: 1.0, alpha: 0.82)
                : NSColor(calibratedRed: 0.25, green: 0.42, blue: 0.95, alpha: 0.42)
            color.setFill()
            path.fill()
            NSColor(calibratedRed: 0.62, green: 0.73, blue: 1.0, alpha: 0.95).setStroke()
            path.lineWidth = 2
            path.stroke()
        }
    }
}

private final class LayoutController: NSObject {
    var layout: String
    var modifier: String
    var layoutZones: [CGRect]
    var overlay: NSWindow?
    var zoneView: ZoneView?
    var targetWindow: AXUIElement?
    var dragActive = false
    var previousMouseDown = false
    var previewUntil = Date().addingTimeInterval(1.6)

    init(layout: String, modifier: String) {
        self.layout = layout
        self.modifier = modifier
        self.layoutZones = zones(for: layout)
        super.init()
    }

    func start() {
        let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
        _ = AXIsProcessTrustedWithOptions(options)
        Timer.scheduledTimer(timeInterval: 0.025, target: self, selector: #selector(tick), userInfo: nil, repeats: true)
        showOverlay(selecting: false)
    }

    private func modifierDown(_ flags: CGEventFlags) -> Bool {
        modifier == "ctrl" ? flags.contains(.maskControl) : flags.contains(.maskShift)
    }

    private func virtualModifierDown() -> Bool {
        guard let text = try? String(contentsOfFile: holdFile, encoding: .utf8) else { return false }
        let parts = text.trimmingCharacters(in: .whitespacesAndNewlines).split(separator: "|")
        guard parts.count >= 3, let expiresAt = Double(parts[2]), expiresAt > Date().timeIntervalSince1970 else {
            try? FileManager.default.removeItem(atPath: holdFile)
            return false
        }
        let nextLayout = String(parts[0])
        let nextModifier = String(parts[1])
        if nextLayout != layout {
            layout = nextLayout
            layoutZones = zones(for: nextLayout)
        }
        modifier = nextModifier
        return true
    }

    private func screenAtMouse() -> NSScreen? {
        let point = NSEvent.mouseLocation
        return NSScreen.screens.first { NSMouseInRect(point, $0.frame, false) } ?? NSScreen.main
    }

    private func pixelFrames(for screen: NSScreen) -> [CGRect] {
        let visible = screen.visibleFrame
        return layoutZones.map { zone in
            CGRect(
                x: visible.minX + visible.width * zone.minX,
                y: visible.maxY - visible.height * (zone.minY + zone.height),
                width: visible.width * zone.width,
                height: visible.height * zone.height
            )
        }
    }

    private func focusedWindow() -> AXUIElement? {
        guard AXIsProcessTrusted(),
              let app = NSWorkspace.shared.frontmostApplication else { return nil }
        let appElement = AXUIElementCreateApplication(app.processIdentifier)
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(appElement, kAXFocusedWindowAttribute as CFString, &value) == .success,
              let value else { return nil }
        return (value as! AXUIElement)
    }

    private func move(_ window: AXUIElement, to frame: CGRect, on screen: NSScreen) {
        let desktopTop = NSScreen.screens.map(\.frame.maxY).max() ?? screen.frame.maxY
        var position = CGPoint(x: frame.minX, y: desktopTop - frame.maxY)
        var size = CGSize(width: frame.width, height: frame.height)
        if let posValue = AXValueCreate(.cgPoint, &position) {
            AXUIElementSetAttributeValue(window, kAXPositionAttribute as CFString, posValue)
        }
        if let sizeValue = AXValueCreate(.cgSize, &size) {
            AXUIElementSetAttributeValue(window, kAXSizeAttribute as CFString, sizeValue)
        }
    }

    private func showOverlay(selecting: Bool) {
        guard let screen = screenAtMouse() else { return }
        let frames = pixelFrames(for: screen)
        let mouse = NSEvent.mouseLocation
        let hovered = selecting ? (frames.firstIndex { $0.contains(mouse) } ?? -1) : -1

        if overlay?.screen != screen {
            overlay?.close()
            let window = NSWindow(
                contentRect: screen.frame,
                styleMask: .borderless,
                backing: .buffered,
                defer: false,
                screen: screen
            )
            window.level = .screenSaver
            window.backgroundColor = .clear
            window.isOpaque = false
            window.ignoresMouseEvents = true
            window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
            let view = ZoneView(frame: screen.frame)
            window.contentView = view
            overlay = window
            zoneView = view
        }

        zoneView?.frames = frames.map { $0.offsetBy(dx: -screen.frame.minX, dy: -screen.frame.minY) }
        zoneView?.hovered = hovered
        zoneView?.needsDisplay = true
        overlay?.orderFrontRegardless()
    }

    @objc private func tick() {
        guard let event = CGEvent(source: nil) else { return }
        let mouseDown = CGEventSource.buttonState(.combinedSessionState, button: .left)
        let modDown = modifierDown(event.flags) || virtualModifierDown()
        let preview = Date() < previewUntil

        if mouseDown && modDown && !previousMouseDown {
            targetWindow = focusedWindow()
            dragActive = targetWindow != nil
        }

        if dragActive && mouseDown {
            showOverlay(selecting: true)
        } else if dragActive && !mouseDown {
            if let screen = screenAtMouse(), let window = targetWindow {
                let frames = pixelFrames(for: screen)
                if let frame = frames.first(where: { $0.contains(NSEvent.mouseLocation) }) {
                    move(window, to: frame.insetBy(dx: 5, dy: 5), on: screen)
                }
            }
            dragActive = false
            targetWindow = nil
            overlay?.orderOut(nil)
        } else if preview {
            showOverlay(selecting: false)
        } else {
            overlay?.orderOut(nil)
        }
        previousMouseDown = mouseDown
    }
}

private func replacePreviousInstance() {
    if let text = try? String(contentsOfFile: pidFile, encoding: .utf8),
       let previousPID = Int32(text.trimmingCharacters(in: .whitespacesAndNewlines)),
       previousPID != getpid() {
        kill(previousPID, SIGTERM)
        usleep(80_000)
    }
    try? String(getpid()).write(toFile: pidFile, atomically: true, encoding: .utf8)
}

replacePreviousInstance()
let layout = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "halves"
let modifier = CommandLine.arguments.count > 2 ? CommandLine.arguments[2] : "shift"
let app = NSApplication.shared
app.setActivationPolicy(.accessory)
private let controller = LayoutController(layout: layout, modifier: modifier)
controller.start()
app.run()
