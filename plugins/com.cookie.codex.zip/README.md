# Codex for COMBO-X (v1.0.0)

The Codex plugin monitors Codex Desktop/CLI session state and provides Codex-specific voice and reasoning controls.

## Actions

- **Codex Status** — Idle, Thinking, Complete, Permission and Error artwork with matching status LED
- **Codex Push to Talk** — holds the configured `composer.startDictation` shortcut while pressed
- **Codex Voice Toggle** — toggles the same dictation shortcut between held and released
- **Codex Reasoning Down / Up** — adjusts the focused Codex composer's reasoning effort
- **Confirm / Cancel** — sends `Enter` or `Esc` to the focused application

Existing Codex shortcuts are preserved. Missing voice/reasoning bindings are assigned an unused reserved chord and written atomically with a backup. Codex hooks are automatically installed or repaired; local rollout JSONL is also monitored as a read-only Desktop fallback.

The inspector shows hook installation as a red/green **Codex Hook** button,
with an equally sized **Remove Codex Hook** button alongside it.
Clicking it keeps the existing install/repair action and opens a localized
full-quit/restart notice. **Remove hooks** remains available; the manual status
refresh button and lower diagnostic/session details are no longer displayed.
Inspector labels and restart notices support English, Korean, Japanese, German,
Spanish, French, Italian, Portuguese and Russian. Installation status indicates
configuration presence, not whether Codex has trusted or executed the hooks.

Async question requests stay in Permission until an actual answer, cancellation,
or a new turn. Their immediate `accepted` result is not a user answer, and results
from other tools do not resolve the pending question. Normal command/file approvals
still use the `PermissionRequest` hook. Explicit app-server approval/resolution
records are also understood when exposed by the monitored log source; not every
Codex build writes those records to rollout JSONL.

For approval compatibility tests, state-only diagnostics appear as
`[Codex Approval]` in the COMBO-X console and in `approval_trace.jsonl` inside this
plugin's user-data directory. The file is capped at 2 MiB and never includes
questions, answers or command arguments. Set `COMBOX_CODEX_APPROVAL_TRACE=0` to
disable these diagnostics. This monitoring never approves requests, changes
Codex security/trust settings or sends automatic replies.

The former `com.cookie.ai_monitor` action IDs are retained so existing COMBO-X button assignments continue working after the plugin split. Existing AI Monitor user data is copied into the new `com.cookie.codex` data directory on first run.
