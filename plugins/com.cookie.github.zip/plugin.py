import asyncio
import websockets
import json
import requests
import os
import time
import webbrowser
import sys
import shutil  # 파일 삭제용
from datetime import datetime, timedelta
from PIL import Image, ImageDraw, ImageFont

class GitHubPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.github"
        self.uri = "ws://localhost:8765"
        self.websocket = None
        self.active_buttons = {}
        self.last_states = {} 
        # 🚀 [대통합] 멀티액션 시 누락되는 설정(repo 등)을 기억합니다.
        self.last_valid_settings = {}
        
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_file = os.path.join(self.plugin_dir, 'github_config.json')
        self.cache_dir = os.path.join(self.plugin_dir, "github_cache")
        
        # 시작 시 캐시 폴더 초기화 (기존 잔여 파일 삭제 후 재생성)
        if os.path.exists(self.cache_dir):
            shutil.rmtree(self.cache_dir)
        os.makedirs(self.cache_dir, exist_ok=True)

        self.token = self.load_token()
        self.username = None

    def load_token(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    return json.load(f).get("token", "")
            except: pass
        return ""

    def save_token(self, token):
        self.token = token
        self.username = None
        try:
            with open(self.config_file, 'w') as f:
                json.dump({"token": token}, f, indent=4)
            asyncio.create_task(self.force_update_all())
        except Exception as e:
            print(f"[GitHub] Save Error: {e}")

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.uri) as websocket:
                    self.websocket = websocket
                    await self.register()
                    # 사용자 이름 미리 가져오기
                    await asyncio.to_thread(self.fetch_username)
                    
                    update_task = asyncio.create_task(self.update_loop())
                    await self.listen()
                    update_task.cancel()
            except Exception as e:
                print(f"[GitHub] Connection Retry: {e}")
                await asyncio.sleep(5)

    async def register(self):
        await self.websocket.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))

    async def listen(self):
        async for message in self.websocket:
            try:
                data = json.loads(message)
                event = data.get("event")
                context = data.get("context")
                payload = data.get("payload", {})

                # CookieDeck 메시지 규격 처리 (기존 유지)
                if event is None and "command" in data:
                    event = "sendToPlugin"
                    payload = data 

                if event == "keyDidAppear":
                    self.active_buttons[context] = data
                    await self.update_button(context)
                elif event == "didReceiveSettings":
                    # 🚀 [핵심] 설정이 들어오면 기억해둡니다.
                    if payload:
                        if context not in self.last_valid_settings:
                            self.last_valid_settings[context] = {}
                        self.last_valid_settings[context].update(payload)
                        
                    if context in self.active_buttons:
                        self.active_buttons[context]["payload"]["settings"] = payload
                        await self.update_button(context)
                elif event == "keyDown":
                    await self.handle_click(context, payload.get("settings", {}))
                
                # 이제 event가 "sendToPlugin"으로 강제 설정되었으므로 이 블록이 실행됩니다.
                elif event == "sendToPlugin":
                    command = payload.get("command")
                    if command == "checkTokenStatus":
                        await self.send_pi_message(context, {"command": "tokenStatus", "hasToken": bool(self.token)})
                    elif command == "getGlobalToken":
                        await self.send_pi_message(context, {"command": "globalToken", "token": self.token})
                    elif command == "saveGlobalToken":
                        self.save_token(payload.get("token", ""))
                        await self.send_pi_message(context, {"command": "tokenStatus", "hasToken": True})
                    elif command == "forceUpdate":
                        await self.update_button(context)
            except Exception as e:
                print(f"[GitHub] Listen Error: {e}")

    async def send_pi_message(self, context, payload):
        if self.websocket:
            await self.websocket.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": payload}))

    def fetch_username(self):
        if not self.token: return
        try:
            headers = {"Authorization": f"token {self.token}"}
            resp = requests.get("https://api.github.com/user", headers=headers, timeout=5)
            if resp.status_code == 200:
                self.username = resp.json().get("login")
                print(f"[GitHub] Logged in as: {self.username}")
        except Exception as e:
            print(f"[GitHub] User Fetch Error: {e}")

    async def update_loop(self):
        while True:
            await asyncio.sleep(60)
            await self.force_update_all()

    async def force_update_all(self):
        if not self.username and self.token:
            await asyncio.to_thread(self.fetch_username)
        for ctx in list(self.active_buttons.keys()):
            await self.update_button(ctx)
            await asyncio.sleep(0.5)

    async def update_button(self, context):
        if context not in self.active_buttons: return
        
        # 🚀 메모리와 현재 설정을 병합합니다.
        incoming = self.active_buttons[context].get("payload", {}).get("settings", {})
        saved = self.last_valid_settings.get(context, {})
        final_settings = {**saved, **incoming}

        if not self.token:
            await self.set_icon(context, "No\nToken", (50, 50, 50))
            return

        action = self.active_buttons[context].get("action")
        # 🚀 [표준화] command에 값이 있으면 레포지토리 주소로 인식합니다.
        repo = final_settings.get("command") or final_settings.get("repo")

        headers = {"Authorization": f"token {self.token}", "Accept": "application/vnd.github.v3+json"}
        
        text_display = "?"
        bg_color = (30, 30, 30)
        
        # 잔디심기용 데이터
        is_grass_mode = False
        grass_data = []

        try:
            # (API 호출 로직은 기존과 동일)
            if action == "com.cookie.github.notifications":
                url = "https://api.github.com/notifications"
                resp = await asyncio.to_thread(requests.get, url, headers=headers, timeout=5)
                if resp.status_code == 200:
                    count = len(resp.json())
                    text_display = str(count)
                    bg_color = (200, 50, 50) if count > 0 else (50, 50, 50)

            elif action == "com.cookie.github.reviews":
                url = "https://api.github.com/search/issues?q=is:pr+is:open+review-requested:@me"
                resp = await asyncio.to_thread(requests.get, url, headers=headers, timeout=5)
                if resp.status_code == 200:
                    count = resp.json().get("total_count", 0)
                    text_display = f"Reviews\n{count}"
                    if count >= 3: bg_color = (200, 50, 50)
                    elif count > 0: bg_color = (200, 100, 0)
                    else: bg_color = (50, 100, 50)

            elif action == "com.cookie.github.contributions":
                is_grass_mode = True
                if not self.username:
                    text_display = "No\nUser"
                else:
                    url = f"https://api.github.com/users/{self.username}/events"
                    resp = await asyncio.to_thread(requests.get, url, headers=headers, timeout=5)
                    if resp.status_code == 200:
                        events = resp.json()
                        today = datetime.utcnow().date()
                        last_5_days = [(today - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(4, -1, -1)]
                        commit_status = {day: False for day in last_5_days}
                        for evt in events:
                            evt_date = evt.get("created_at", "")[:10]
                            if evt_date in commit_status and evt.get("type") == "PushEvent":
                                commit_status[evt_date] = True
                        
                        grass_data = [commit_status[day] for day in last_5_days]
                        is_today_committed = grass_data[-1]
                        text_display = "Committed" if is_today_committed else "Do It!"
                        bg_color = (40, 100, 40) if is_today_committed else (80, 80, 80)
                    else:
                        text_display = "Err"

            elif action == "com.cookie.github.repo" and repo:
                url = f"https://api.github.com/repos/{repo}"
                resp = await asyncio.to_thread(requests.get, url, headers=headers, timeout=5)
                if resp.status_code == 200:
                    stars = resp.json().get("stargazers_count", 0)
                    stars_str = f"{stars/1000:.1f}k" if stars >= 1000 else str(stars)
                    text_display = f"★\n{stars_str}"
                    bg_color = (40, 40, 180)

            elif action == "com.cookie.github.workflow" and repo:
                url = f"https://api.github.com/repos/{repo}/actions/runs?per_page=1"
                resp = await asyncio.to_thread(requests.get, url, headers=headers, timeout=5)
                if resp.status_code == 200:
                    runs = resp.json().get("workflow_runs", [])
                    if runs:
                        status = runs[0].get("conclusion")
                        run_status = runs[0].get("status")
                        text_display = "Build"
                        if run_status in ["in_progress", "queued"]: bg_color = (200, 200, 50)
                        elif status == "success": bg_color = (40, 150, 40)
                        elif status == "failure": bg_color = (180, 40, 40)
                    else: text_display = "No Run"

            # ★★★ [최적화 핵심] 변경 감지 로직 ★★★
            # 현재 상태: (텍스트, 배경색, 잔디데이터(있으면))
            # 리스트는 직접 비교가 안 되므로 튜플로 변환
            grass_tuple = tuple(grass_data) if is_grass_mode else None
            current_state = (text_display, bg_color, grass_tuple)
            
            last_state = self.last_states.get(context)

            # 이전 상태와 똑같으면 아무것도 안 함 (파일 생성 X, 전송 X)
            if last_state == current_state:
                # print(f"[GitHub] Skip update for {context} (No Change)")
                return

            # 상태가 다르면 저장하고 이미지 생성 진행
            self.last_states[context] = current_state
            
            if is_grass_mode:
                icon_path = await asyncio.to_thread(self.create_grass_image, context, text_display, bg_color, grass_data)
            else:
                icon_path = await asyncio.to_thread(self.create_image_file, context, text_display, bg_color)
            
            # 메인 앱으로 전송
            if self.websocket:
                await self.websocket.send(json.dumps({
                    "event": "setIcon", "context": context, "payload": {"icon_path": icon_path}
                }))

        except Exception as e:
            print(f"[GitHub API Error] {e}")
            await self.set_icon(context, "Err", (0, 0, 0))

    async def set_icon(self, context, text, color):
        try:
            icon_path = await asyncio.to_thread(self.create_image_file, context, text, color)
            if self.websocket:
                await self.websocket.send(json.dumps({
                    "event": "setIcon", "context": context, "payload": {"icon_path": icon_path}
                }))
        except: pass

    # ----------------------------------------------------------------
    # 이미지 생성 함수들
    # ----------------------------------------------------------------
    def create_image_file(self, context, text, color_rgb):
        img = Image.new('RGB', (128, 128), color_rgb)
        draw = ImageDraw.Draw(img)
        try: font = ImageFont.truetype("arial.ttf", 30)
        except: font = ImageFont.load_default()

        left, top, right, bottom = draw.textbbox((0, 0), text, font=font)
        w, h = right - left, bottom - top
        draw.text(((128 - w) / 2, (128 - h) / 2 - 5), text, font=font, fill="white", align="center")

        # ★ [파일명 변경] timestamp 대신 context ID 사용 (덮어쓰기)
        # context에는 특수문자가 있을 수 있으므로 안전하게 변환
        safe_name = "".join(c for c in context if c.isalnum() or c in ('-', '_'))
        filename = f"gh_{safe_name}.png"
        filepath = os.path.join(self.cache_dir, filename)
        
        img.save(filepath, "PNG")
        return filepath

    def create_grass_image(self, context, text, bg_color, grass_data):
        img = Image.new('RGB', (128, 128), bg_color)
        draw = ImageDraw.Draw(img)
        
        try: font = ImageFont.truetype("arial.ttf", 28)
        except: font = ImageFont.load_default()

        left, top, right, bottom = draw.textbbox((0, 0), text, font=font)
        w = right - left
        h = bottom - top
        draw.text(((128 - w) / 2, 40), text, font=font, fill="white", align="center")

        box_size = 16; gap = 6
        start_x = (128 - (5 * box_size + 4 * gap)) / 2; start_y = 90

        for i, committed in enumerate(grass_data):
            x = start_x + i * (box_size + gap); y = start_y
            fill_color = (57, 211, 83) if committed else (22, 27, 34)
            if i == 4 and committed: fill_color = (57, 211, 83) # 오늘
            elif i == 4: fill_color = (14, 68, 41) 
            
            outline_color = (200, 200, 200) if i == 4 else (100, 100, 100)
            draw.rectangle([x, y, x + box_size, y + box_size], fill=fill_color, outline=outline_color, width=1)

        # ★ [파일명 변경] context ID 사용
        safe_name = "".join(c for c in context if c.isalnum() or c in ('-', '_'))
        filename = f"gh_grass_{safe_name}.png"
        filepath = os.path.join(self.cache_dir, filename)
        
        img.save(filepath, "PNG")
        return filepath

    async def handle_click(self, context, incoming_settings):
        data = self.active_buttons.get(context)
        if not data: return
        
        # 🚀 클릭 시에도 메모리 데이터를 참조하여 정확한 URL을 생성합니다.
        saved = self.last_valid_settings.get(context, {})
        final_settings = {**saved, **incoming_settings}
        
        action = data.get("action")
        repo = final_settings.get("command") or final_settings.get("repo")

        url = "https://github.com/"
        
        if action == "com.cookie.github.notifications":
            url += "notifications"
        elif action == "com.cookie.github.reviews":
            url += "pulls/review-requested"
        elif action == "com.cookie.github.contributions":
            if self.username: url += self.username
        elif repo:
            url += repo
            if action == "com.cookie.github.workflow":
                url += "/actions"
        
        await asyncio.to_thread(webbrowser.open, url)

if __name__ == "__main__":
    plugin = GitHubPlugin()
    try:
        asyncio.run(plugin.connect())
    except KeyboardInterrupt: pass