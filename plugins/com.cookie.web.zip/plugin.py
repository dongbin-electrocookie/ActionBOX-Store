import asyncio
import webbrowser
import os
import subprocess
import sys
import io
import plistlib
import glob
from urllib.parse import unquote

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

libraries_ok = False
requests = None
BeautifulSoup = None
urljoin = None
urlparse = None
winreg = None
Image = None

try:
    import requests
    from bs4 import BeautifulSoup
    from urllib.parse import urljoin, urlparse
    if IS_WINDOWS:
        import winreg
    from PIL import Image
    libraries_ok = True
except ImportError as e:
    print(f"[Web Plugin Warning] Optional libraries missing: {e}")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.last_valid_settings = {}
        self.available_browsers = self.find_installed_browsers() if libraries_ok else {}
        self.default_icon_name = "ACTION_WEB"

    def _get_icon_path(self):
        icon_path = os.path.join(self.plugin_dir, "icon", f"{self.default_icon_name}.png")
        if os.path.exists(icon_path):
            return icon_path
        fallback = os.path.join(self.plugin_dir, "default.png")
        return fallback if os.path.exists(fallback) else None

    def _app_data_dir(self):
        if IS_WINDOWS:
            root = os.environ.get("APPDATA") or os.path.expanduser("~\\AppData\\Roaming")
        elif IS_MACOS:
            root = os.path.expanduser("~/Library/Application Support")
        else:
            root = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
        path = os.path.join(root, "CookieDeck", "com_cookie_web")
        os.makedirs(path, exist_ok=True)
        return path

    async def _send_builtin_icon(self, context):
        icon_path = self._get_icon_path()
        if context and icon_path and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "url", "browser", "command", "builtin_icon_name",
            "default_visuals_initialized", "sync_title_on_url_change", "title"
        ])

        if not meaningful:
            new_settings = {
                "url": "",
                "browser": "default",
                "command": "",
                "_lang": "en",
                "sync_title_on_url_change": False,
                "builtin_icon_name": self.default_icon_name,
                "default_visuals_initialized": True
            }
            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": new_settings
            })
            await self._send_builtin_icon(context)
            return

        current_url = settings.get("command") or settings.get("url")
        if not current_url:
            await self._send_builtin_icon(context)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        command = data.get("command") or payload.get("command")
        context = data.get("context") or payload.get("context")
        settings = payload.get("settings") if isinstance(payload.get("settings"), dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if command == "apply_builtin_icon":
            await self._send_builtin_icon(context)
            return

        if event == "keyDown":
            await self.on_key_down(data)
        elif event == "fetchIcon" or payload.get("event") == "fetchIcon" or command == "fetchIcon":
            await self.on_fetch_icon(data)
        elif event == "getAvailableBrowsers" or payload.get("event") == "getAvailableBrowsers" or command == "getAvailableBrowsers":
            await self.on_get_browsers(data)

    async def on_key_down(self, data):
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}

        if incoming_settings:
            self.last_valid_settings.update(incoming_settings)

        final_settings = {**self.last_valid_settings, **incoming_settings}

        url = final_settings.get("command") or final_settings.get("url")
        browser_path = final_settings.get("browser", "default")

        url = self.normalize_url_or_shortcut(url)
        if url:
            await asyncio.to_thread(self._open_url, url, browser_path)

    def normalize_url_or_shortcut(self, value):
        """Accepts normal URLs, domains, Windows .url, macOS .webloc/.inetloc, or file:// paths."""
        if not value:
            return ""

        raw = str(value).strip().strip('"').strip("'")
        if not raw:
            return ""

        if raw.startswith("file://"):
            raw = unquote(raw[7:])

        if os.path.exists(raw):
            ext = os.path.splitext(raw)[1].lower()
            if ext == ".url":
                parsed = self._read_windows_url_file(raw)
                if parsed:
                    return parsed
            if ext in (".webloc", ".inetloc"):
                parsed = self._read_macos_url_file(raw)
                if parsed:
                    return parsed
            # If it is a local html/pdf/etc file, let the OS/browser open it.
            return raw

        if raw.startswith(("http://", "https://", "ftp://", "mailto:")):
            return raw

        return "https://" + raw

    def _read_windows_url_file(self, path):
        for enc in ("utf-8-sig", "utf-16", "cp949", "latin-1"):
            try:
                with open(path, "r", encoding=enc, errors="ignore") as f:
                    for line in f:
                        line = line.strip()
                        if line.lower().startswith("url="):
                            return line.split("=", 1)[1].strip()
            except Exception:
                continue
        return ""

    def _read_macos_url_file(self, path):
        try:
            with open(path, "rb") as f:
                data = plistlib.load(f)
            for key in ("URL", "url", "URLString"):
                if data.get(key):
                    return str(data[key]).strip()
        except Exception:
            pass

        # Some .inetloc files may appear as XML-ish or plain text in edge cases.
        try:
            text = open(path, "r", encoding="utf-8", errors="ignore").read()
            for marker in ("<string>", "URL="):
                if marker in text:
                    if marker == "<string>":
                        return text.split("<string>", 1)[1].split("</string>", 1)[0].strip()
                    return text.split("URL=", 1)[1].splitlines()[0].strip()
        except Exception:
            pass
        return ""

    def _open_url(self, url, browser_path):
        if browser_path == "default" or not browser_path:
            if IS_MACOS:
                subprocess.Popen(["open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                webbrowser.open(url)
            return

        try:
            if IS_MACOS:
                # Browser value is normally a .app bundle path.
                if browser_path.endswith(".app"):
                    subprocess.Popen(["open", "-a", browser_path, url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    subprocess.Popen(["open", "-a", browser_path, url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elif IS_WINDOWS:
                subprocess.Popen([browser_path, url])
            else:
                subprocess.Popen([browser_path, url])
        except Exception as e:
            print(f"[{self.uuid}] Browser launch failed: {e}. Falling back to default browser.")
            try:
                if IS_MACOS:
                    subprocess.Popen(["open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    webbrowser.open(url)
            except Exception:
                webbrowser.open(url)

    async def on_fetch_icon(self, data):
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        url = payload.get("url") or payload.get("payload", {}).get("url")

        if not context:
            return

        if not url:
            await self._send_builtin_icon(context)
            return

        if not libraries_ok:
            await self._send_builtin_icon(context)
            return

        normalized = self.normalize_url_or_shortcut(url)
        if not normalized or os.path.exists(normalized):
            await self._send_builtin_icon(context)
            return

        icon_path = await asyncio.to_thread(self.fetch_and_save_favicon, normalized)
        if icon_path and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })
        else:
            await self._send_builtin_icon(context)

    async def on_get_browsers(self, data):
        context = data.get("context")
        if context:
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {
                    "event": "didReceiveAvailableBrowsers",
                    "browsers": self.available_browsers
                }
            })

    def find_installed_browsers(self):
        if IS_WINDOWS:
            return self._find_windows_browsers()
        if IS_MACOS:
            return self._find_macos_browsers()
        if IS_LINUX:
            return self._find_linux_browsers()
        return {}

    def _find_windows_browsers(self):
        if not winreg:
            return {}

        browser_exes = {
            "chrome.exe": "Google Chrome",
            "msedge.exe": "Microsoft Edge",
            "firefox.exe": "Mozilla Firefox",
            "opera.exe": "Opera",
            "vivaldi.exe": "Vivaldi",
            "brave.exe": "Brave",
            "whale.exe": "Naver Whale",
            "Arc.exe": "Arc Browser",
            "DuckDuckGo.exe": "DuckDuckGo Browser",
            "comet.exe": "Comet Browser"
        }

        installed_browsers = {}
        app_paths_key = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"

        for exe, name in browser_exes.items():
            for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
                try:
                    key = winreg.OpenKey(hive, os.path.join(app_paths_key, exe))
                    path, _ = winreg.QueryValueEx(key, None)
                    installed_browsers[name] = path
                    winreg.CloseKey(key)
                    break
                except FileNotFoundError:
                    pass
                except Exception:
                    pass
        return installed_browsers

    def _find_macos_browsers(self):
        candidates = {
            "Safari": ["/Applications/Safari.app"],
            "Google Chrome": ["/Applications/Google Chrome.app", os.path.expanduser("~/Applications/Google Chrome.app")],
            "Microsoft Edge": ["/Applications/Microsoft Edge.app", os.path.expanduser("~/Applications/Microsoft Edge.app")],
            "Mozilla Firefox": ["/Applications/Firefox.app", os.path.expanduser("~/Applications/Firefox.app")],
            "Brave": ["/Applications/Brave Browser.app", os.path.expanduser("~/Applications/Brave Browser.app")],
            "Opera": ["/Applications/Opera.app", os.path.expanduser("~/Applications/Opera.app")],
            "Vivaldi": ["/Applications/Vivaldi.app", os.path.expanduser("~/Applications/Vivaldi.app")],
            "Arc Browser": ["/Applications/Arc.app", os.path.expanduser("~/Applications/Arc.app")],
            "Naver Whale": ["/Applications/Whale.app", "/Applications/Naver Whale.app", os.path.expanduser("~/Applications/Whale.app")],
            "DuckDuckGo Browser": ["/Applications/DuckDuckGo.app", os.path.expanduser("~/Applications/DuckDuckGo.app")],
        }

        installed = {}
        for name, paths in candidates.items():
            for path in paths:
                if os.path.exists(path):
                    installed[name] = path
                    break
        return installed

    def _find_linux_browsers(self):
        import shutil
        candidates = {
            "Google Chrome": "google-chrome",
            "Chromium": "chromium",
            "Microsoft Edge": "microsoft-edge",
            "Mozilla Firefox": "firefox",
            "Brave": "brave-browser",
            "Opera": "opera",
            "Vivaldi": "vivaldi",
        }
        return {name: path for name, cmd in candidates.items() if (path := shutil.which(cmd))}

    def fetch_and_save_favicon(self, url):
        def get_default_icon_path():
            icon_path = self._get_icon_path()
            return icon_path if icon_path and os.path.exists(icon_path) else None

        try:
            url = self.normalize_url_or_shortcut(url)
            if not url or os.path.exists(url):
                return get_default_icon_path()

            headers = {"User-Agent": "Mozilla/5.0"}

            try:
                response = requests.get(url, headers=headers, timeout=3)
                response.raise_for_status()
            except Exception:
                return get_default_icon_path()

            soup = BeautifulSoup(response.text, "html.parser")
            icon_link = soup.find("link", rel=lambda r: r and "icon" in r.lower())
            icon_url = None

            if icon_link and icon_link.get("href"):
                icon_url = urljoin(url, icon_link["href"])
            else:
                fallback_url = urljoin(url, "/favicon.ico")
                try:
                    if requests.head(fallback_url, headers=headers, timeout=2).ok:
                        icon_url = fallback_url
                except Exception:
                    pass

            if not icon_url:
                return get_default_icon_path()

            try:
                icon_response = requests.get(icon_url, headers=headers, timeout=5)
                icon_response.raise_for_status()

                icon_data = io.BytesIO(icon_response.content)
                img = Image.open(icon_data)
                img = img.convert("RGBA")

                cache_dir = os.path.join(self._app_data_dir(), "favicon_cache")
                os.makedirs(cache_dir, exist_ok=True)

                domain = urlparse(url).netloc
                safe_filename = "".join(c for c in domain if c.isalnum() or c in ("-", "_")).rstrip() or "site"
                save_path = os.path.join(cache_dir, f"{safe_filename}.png")

                img.save(save_path, "PNG")
                return os.path.abspath(save_path)

            except Exception:
                return get_default_icon_path()

        except Exception as e:
            print(f"[{self.uuid}] Global error in fetch: {e}. Using default.")
            return get_default_icon_path()
