#target premierepro
(function () {
    var sequence = app.project.activeSequence;
    if (!sequence) {
        alert("Open a sequence first.");
        return;
    }
    var marker = sequence.markers.createMarker(sequence.getPlayerPosition().seconds);
    marker.name = "Combo X Marker";
}());
