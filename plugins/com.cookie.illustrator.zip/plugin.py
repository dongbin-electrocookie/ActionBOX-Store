import asyncio
import platform

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 일러스트레이터 실무용 단축키 매핑!
        self.action_map = {
            # 1. 파일 및 편집 (File & Edit)
            "file_save": "ctrl+s",
            "file_save_as": "ctrl+shift+s",
            "edit_undo": "ctrl+z",
            "edit_redo": "ctrl+shift+z",
            "edit_paste_place": "ctrl+shift+v",
            "edit_paste_front": "ctrl+f",
            "edit_paste_back": "ctrl+b",

            # 2. 도구 선택 (Tools) - 요청하신 돋보기(Z) 포함!
            "tool_select": "v",
            "tool_direct_select": "a",
            "tool_magic": "y",
            "tool_lasso": "q",
            "tool_pen": "p",
            "tool_type": "t",
            "tool_rect": "m",
            "tool_ellipse": "l",
            "tool_brush": "b",
            "tool_eraser": "shift+e",
            "tool_rotate": "r",
            "tool_scale": "s",
            "tool_transform": "e",
            "tool_gradient": "g",
            "tool_eyedropper": "i",
            "tool_zoom": "z",

            # 3. 객체 및 배열 (Object & Arrange)
            "obj_group": "ctrl+g",
            "obj_ungroup": "ctrl+shift+g",
            "obj_front": "ctrl+shift+]",
            "obj_back": "ctrl+shift+[",
            "obj_lock": "ctrl+2",
            "obj_unlock": "ctrl+alt+2",
            "obj_hide": "ctrl+3",
            "obj_show": "ctrl+alt+3",

            # 4. 마스크 및 패스 (Mask & Path)
            "mask_make": "ctrl+7",
            "mask_release": "ctrl+alt+7",
            "path_make": "ctrl+8",
            "path_release": "ctrl+alt+8",

            # 5. 화면 뷰 (View)
            "view_zoom_in": "ctrl+=",
            "view_zoom_out": "ctrl+-",
            "view_fit": "ctrl+0",
            "view_outline": "ctrl+y",
            "view_guides": "ctrl+;"
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("ai_action", "tool_select")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)