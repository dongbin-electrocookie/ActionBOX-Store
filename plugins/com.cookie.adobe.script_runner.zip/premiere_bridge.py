"""Signed, per-user CEP deployment and local, at-most-once JSX requests.

No network listener, shell execution, Adobe debug preference changes or UI.
CEP validates its own signature when loading the installed extension. The
package digest additionally detects incomplete or mismatched COMBO-X builds.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import threading
import time
import uuid
import xml.etree.ElementTree as ET
import zipfile

BUNDLE_ID = 'com.electrocookie.combox.premiere.bridge'
PROTOCOL = 1
PACKAGE_NAME = 'COMBO-X-Premiere-Bridge.zxp'


class BridgeError(Exception):
    def __init__(self, status, detail=''):
        self.status = status
        self.detail = str(detail)[:400]
        super().__init__(status)


def user_data(platform=None, home=None):
    platform = platform or sys.platform
    home = Path(home) if home else Path.home()
    if platform.startswith('win'):
        return Path(os.environ.get('APPDATA', str(home / 'AppData/Roaming')))
    if platform == 'darwin':
        return home / 'Library/Application Support'
    raise BridgeError('platform_unsupported')


def application_identity(path, platform=None):
    platform = platform or sys.platform
    value = os.path.realpath(path).replace('\\', '/')
    if platform == 'darwin':
        # getSystemPath(hostApplication) can name the bundle executable.
        index = value.lower().find('.app/')
        if index >= 0:
            value = value[:index + 4]
    if platform.startswith('win'):
        value = value.lower()
    return value.rstrip('/')


def _linked(path):
    return path.is_symlink() or (hasattr(path, 'is_junction') and path.is_junction())


def _atomic_json(path, value):
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temporary.open('x', encoding='utf-8') as handle:
            json.dump(value, handle, ensure_ascii=True)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def package_payload(plugin_dir):
    root = Path(plugin_dir) / 'premiere_bridge'
    try:
        metadata = json.loads((root / 'package.json').read_text(encoding='utf-8'))
        package = root / PACKAGE_NAME
        if hashlib.sha256(package.read_bytes()).hexdigest() != metadata['sha256']:
            raise ValueError('Package digest mismatch')
        with zipfile.ZipFile(package) as archive:
            files = {}
            for entry in archive.infolist():
                path = PurePosixPath(entry.filename)
                if (path.is_absolute() or '..' in path.parts or '\\' in entry.filename
                        or ':' in entry.filename or stat.S_ISLNK(entry.external_attr >> 16)):
                    raise ValueError('Unsafe package entry')
                if entry.is_dir():
                    continue
                if entry.filename in files or entry.file_size > 2_000_000:
                    raise ValueError('Invalid package entry')
                files[entry.filename] = archive.read(entry)
        if not files.get('META-INF/signatures.xml'):
            raise ValueError('Signed CEP package is required')
        manifest = ET.fromstring(files['CSXS/manifest.xml'])
        if manifest.get('ExtensionBundleId') != BUNDLE_ID:
            raise ValueError('Unexpected extension identity')
        expected = metadata['sourceFiles']
        if files.get('mimetype') != b'application/vnd.adobe.air-ucf-package+zip':
            raise ValueError('Invalid CEP package type')
        if set(files) != set(expected) | {'META-INF/signatures.xml', 'mimetype'}:
            raise ValueError('Unexpected package files')
        for name, digest in expected.items():
            if hashlib.sha256(files[name]).hexdigest() != digest:
                raise ValueError('Package contents mismatch')
            source = root / 'extension' / name
            if source.is_file() and hashlib.sha256(source.read_bytes()).hexdigest() != digest:
                raise ValueError('Bridge source changed; re-sign before distributing')
        return files
    except (OSError, ValueError, KeyError, zipfile.BadZipFile, ET.ParseError) as error:
        raise BridgeError('bridge_package_invalid', error) from None


def install_bridge(plugin_dir, data_root=None):
    """Install only this signed extension; preserve the prior version on update."""
    files = package_payload(plugin_dir)
    parent = (Path(data_root) if data_root else user_data()) / 'Adobe/CEP/extensions'
    parent.mkdir(parents=True, exist_ok=True)
    target = parent / BUNDLE_ID
    if _linked(target):
        raise BridgeError('bridge_install_failed', 'Extension target is a link')
    if target.is_dir():
        if all((target / name).is_file() and not _linked(target / name)
               and (target / name).read_bytes() == value for name, value in files.items()):
            # Extra code files would invalidate the signature: do not overlook them.
            actual = {p.relative_to(target).as_posix() for p in target.rglob('*') if p.is_file()}
            if actual == set(files):
                return False
        try:
            if ET.parse(target / 'CSXS/manifest.xml').getroot().get('ExtensionBundleId') != BUNDLE_ID:
                raise ValueError('Extension identity mismatch')
        except (OSError, ValueError, ET.ParseError) as error:
            raise BridgeError('bridge_install_failed', error) from None
    elif target.exists():
        raise BridgeError('bridge_install_failed', 'Extension target is not a directory')
    staging = parent / (BUNDLE_ID + '.staging-' + uuid.uuid4().hex)
    previous = parent / (BUNDLE_ID + '.previous-' + uuid.uuid4().hex)
    try:
        staging.mkdir(mode=0o700)
        for name, value in files.items():
            destination = staging / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(value)
        if target.exists():
            # Move backups OUTSIDE the CEP scan directory (duplicate IDs matter).
            backup_root = parent.parent / 'COMBO-X Bridge Backups'
            backup_root.mkdir(exist_ok=True)
            previous = backup_root / previous.name
            target.rename(previous)
        staging.rename(target)
    except OSError as error:
        if previous.exists() and not target.exists():
            previous.rename(target)
        raise BridgeError('bridge_install_failed', error) from None
    finally:
        # Only our newly-created staging files, never an existing extension.
        if staging.exists():
            for path in sorted(staging.rglob('*'), key=lambda p: len(p.parts), reverse=True):
                if path.is_file():
                    path.unlink()
                elif path.is_dir():
                    path.rmdir()
            staging.rmdir()
    return True


class PremiereBridge:
    def __init__(self, plugin_dir, *, platform=None, data_root=None):
        self.plugin_dir = Path(plugin_dir)
        self.platform = platform or sys.platform
        self.data_root = Path(data_root) if data_root else user_data(self.platform)
        self._lock = threading.Lock()
        self._prepare_lock = threading.Lock()

    def prepare(self):
        try:
            with self._prepare_lock:
                return install_bridge(self.plugin_dir, self.data_root)
        except OSError as error:
            raise BridgeError('bridge_install_failed', error) from None

    def execute(self, app_path, script_path, *, timeout=300, dispatch_timeout=5):
        if not self._lock.acquire(blocking=False):
            raise BridgeError('bridge_busy')
        try:
            if self.prepare():
                raise BridgeError('bridge_restart_required')
            return self._execute(app_path, script_path, timeout, dispatch_timeout)
        finally:
            self._lock.release()

    def _execute(self, app_path, script_path, timeout, dispatch_timeout):
        app = application_identity(app_path, self.platform)
        host_id = hashlib.sha256(app.encode('utf-8')).hexdigest()
        root = self.data_root / 'COMBO-X/PremiereBridge' / host_id
        try:
            heartbeat = json.loads((root / 'heartbeat.json').read_text(encoding='utf-8'))
            age = time.time() - heartbeat['time']
            if (heartbeat['protocol'] != PROTOCOL or heartbeat['application'] != app
                    or not -2 <= age <= 4 or not re_full_uuid(heartbeat['instance'])):
                raise ValueError('Missing active bridge for selected Premiere version')
        except (OSError, ValueError, KeyError, TypeError):
            raise BridgeError('bridge_restart_required') from None
        identifier = uuid.uuid4().hex
        jobs = root / 'jobs'
        jobs.mkdir(mode=0o700, exist_ok=True)
        job = jobs / identifier
        job.mkdir(mode=0o700)
        request = job / 'request.json'
        response = job / 'response.json'
        started = time.monotonic()
        _atomic_json(request, {'protocol': PROTOCOL, 'id': identifier,
                     'application': app, 'instance': heartbeat['instance'],
                     'script': os.path.realpath(script_path),
                     'deadline': time.time() + dispatch_timeout})
        try:
            while True:
                if response.is_file():
                    result = json.loads(response.read_text(encoding='utf-8'))
                    if result.get('id') != identifier or result.get('instance') != heartbeat['instance']:
                        raise BridgeError('execution_failed', 'Unexpected bridge response')
                    if result.get('status') != 'executed':
                        status = 'bridge_expired' if result.get('status') == 'expired' else 'execution_failed'
                        raise BridgeError(status, result.get('detail', ''))
                    return 'executed'
                elapsed = time.monotonic() - started
                if elapsed >= timeout:
                    raise BridgeError('timed_out')
                if elapsed >= dispatch_timeout and not (job / 'running.json').exists():
                    raise BridgeError('bridge_expired')
                time.sleep(0.05)
        finally:
            # A job already claimed by CEP is never requeued or retried. A timed
            # out unclaimed job is cancelled so opening Premiere later cannot run it.
            if not response.exists():
                _atomic_json(job / 'cancelled.json', {'id': identifier})
            else:
                for name in ('request.json', 'running.json', 'response.json', 'cancelled.json'):
                    (job / name).unlink(missing_ok=True)
                try:
                    job.rmdir()
                except OSError:
                    pass


def re_full_uuid(value):
    return isinstance(value, str) and len(value) == 32 and all(c in '0123456789abcdef' for c in value)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Install the signed COMBO-X Premiere background bridge.')
    parser.add_argument('--install', action='store_true', required=True)
    arguments = parser.parse_args()
    try:
        changed = install_bridge(Path(__file__).resolve().parent)
        print('COMBO-X Premiere bridge: ' + ('installed; restart Premiere.' if changed else 'up to date.'))
    except (BridgeError, OSError) as error:
        print('COMBO-X Premiere bridge installation failed: ' + str(error))
        sys.exit(1)
