import asyncio
import json
import os

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.toggle_states = {}
        self.icon_map = {
            "sequence": "MODE_SEQUENCE",
            "toggle": "MODE_TOGGLE"
        }

    def _mode_from_settings(self, settings):
        return "toggle" if (settings or {}).get("use_toggle_mode", False) else "sequence"

    def _get_icon_path(self, mode):
        icon_name = self.icon_map.get(mode or "sequence", "MODE_SEQUENCE")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, mode):
        icon_path = self._get_icon_path(mode)
        if context and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any([
            settings.get("use_toggle_mode", False),
            settings.get("sync_title_on_action_change", False),
            bool(settings.get("title")),
            bool(settings.get("builtin_icon_name")),
            bool(settings.get("default_visuals_initialized")),
            bool(settings.get("actions_1")),
            bool(settings.get("actions_2"))
        ])

        current_mode = self._mode_from_settings(settings)

        if not meaningful:
            new_settings = {
                "use_toggle_mode": False,
                "actions_1": [],
                "actions_2": [],
                "_lang": "en",
                "sync_title_on_action_change": False,
                "builtin_icon_name": self.icon_map["sequence"],
                "default_visuals_initialized": True
            }
            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": new_settings
            })
            await self._send_builtin_icon(context, "sequence")
            return

        await self._send_builtin_icon(context, current_mode)

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        command = data.get("command") or payload.get("command")
        settings = payload.get("settings") if isinstance(payload.get("settings"), dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            if context:
                self.toggle_states[context] = 1
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event in ["willDisappear", "keyDidDisappear"]:
            if context in self.toggle_states:
                del self.toggle_states[context]
            return

        if command == "apply_builtin_icon":
            mode = payload.get("mode") or self._mode_from_settings(settings)
            await self._send_builtin_icon(context, mode)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        settings = data.get("payload", {}).get("settings", {}) or {}

        use_toggle_mode = settings.get("use_toggle_mode", False)

        if not use_toggle_mode:
            current_state = 1
            self.toggle_states[context] = 1
        else:
            current_state = self.toggle_states.get(context, 1)

        action_list_key = f"actions_{current_state}"
        action_list = settings.get(action_list_key, [])

        for action_to_run in action_list:
            action_id = action_to_run.get("action_id")
            delay_ms = int(action_to_run.get("delay_ms", 0))
            custom_data = action_to_run.get("custom_data", "")

            if delay_ms > 0:
                await asyncio.sleep(delay_ms / 1000.0)

            if not action_id:
                continue

            if isinstance(custom_data, dict):
                payload_str = json.dumps(custom_data) if custom_data else ""
            else:
                payload_str = str(custom_data)

            final_target_id = action_id
            if payload_str and "#" not in action_id:
                final_target_id = f"{action_id}#{payload_str}"

            await self.runner.send_message({
                "event": "requestFakeClick",
                "payload": {
                    "origin_key": context,
                    "target_action_id": final_target_id
                }
            })

        if use_toggle_mode:
            self.toggle_states[context] = 2 if current_state == 1 else 1
