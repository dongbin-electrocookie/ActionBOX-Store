#target illustrator

var fontName = "NotoSansKR-Regular";
var fontSize = 48;
var tracking = -20;

function collectTextFrames(item, result) {
    if (item.typename === "TextFrame") {
        result.push(item);
    } else if (item.typename === "GroupItem") {
        for (var i = 0; i < item.pageItems.length; i++) {
            collectTextFrames(item.pageItems[i], result);
        }
    }
}

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else if (app.activeDocument.selection.length === 0) {
    alert("선택된 객체가 없습니다.");
} else {
    var font = null;
    try {
        font = app.textFonts.getByName(fontName);
    } catch (e) {
        alert(fontName + " 폰트가 설치되어 있지 않습니다.");
    }

    if (font) {
        var textFrames = [];
        var selection = app.activeDocument.selection;
        for (var i = 0; i < selection.length; i++) collectTextFrames(selection[i], textFrames);

        var applied = 0;
        var skipped = 0;
        for (var j = 0; j < textFrames.length; j++) {
            try {
                if (textFrames[j].locked || textFrames[j].hidden) throw new Error();
                var attributes = textFrames[j].textRange.characterAttributes;
                attributes.textFont = font;
                attributes.size = fontSize;
                attributes.tracking = tracking;
                applied++;
            } catch (ignore) {
                skipped++;
            }
        }
        alert("텍스트 " + applied + "개 적용 완료" + (skipped ? ", " + skipped + "개 건너뜀." : "."));
    }
}
