import asyncio
import websockets
import json
import subprocess
import os
import keyboard
import time

class DevToolsPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.devtools"
        self.uri = "ws://localhost:8765"
        self.websocket = None
        # 🚀 [대통합 표준] 버튼별(context) 설정을 기억합니다. (프로젝트 경로 등 유실 방지)
        self.last_valid_settings = {}

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.uri) as websocket:
                    self.websocket = websocket
                    await self.register()
                    await self.listen()
            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] Connection failed: {e}. Retrying in 5s...")
                await asyncio.sleep(5)

    async def register(self):
        await self.websocket.send(json.dumps({
            "event": "register", 
            "uuid": self.PLUGIN_UUID
        }))
        print(f"[{self.PLUGIN_UUID}] Registered.")

    async def listen(self):
        async for message in self.websocket:
            try:
                data = json.loads(message)
                event = data.get("event")
                context = data.get("context")
                payload = data.get("payload", {})

                if event == "didReceiveSettings":
                    # 설정창에서 값이 바뀌면 메모리 업데이트
                    if context not in self.last_valid_settings:
                        self.last_valid_settings[context] = {}
                    self.last_valid_settings[context].update(payload)

                elif event == "keyDown":
                    await self.on_key_down(data)
                
                elif event == "sendToPlugin":
                    await self.on_pi_request(data)

            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] Error: {e}")

    async def on_key_down(self, data):
        context = data.get("context")
        action_id = data.get("action")
        incoming_settings = data.get("payload", {}).get("settings", {})

        # 🚀 1. 유효한 설정 저장 및 병합 (멀티액션 대응)
        if context not in self.last_valid_settings:
            self.last_valid_settings[context] = {}
        
        if incoming_settings:
            filtered = {k: v for k, v in incoming_settings.items() if v}
            self.last_valid_settings[context].update(filtered)
            
        final_settings = {**self.last_valid_settings.get(context, {}), **incoming_settings}

        # 🚀 2. [표준화] 'command'를 우선 확인합니다.
        # 단축키든 Git 명령어든 모두 'command' 주머니에서 꺼냅니다.
        cmd_value = final_settings.get("command")

        # --- [액션 A] 단축키 (Hotkey) ---
        if action_id == "com.cookie.devtools.hotkey":
            keys = cmd_value or final_settings.get("keys")
            if keys:
                print(f"[Hotkey] Sending: {keys}")
                await asyncio.sleep(0.05)
                await asyncio.to_thread(keyboard.send, keys)

        # --- [액션 B] Git 명령어 ---
        elif action_id == "com.cookie.devtools.git":
            git_cmd = cmd_value or final_settings.get("git_command")
            project_path = final_settings.get("project_path")
            
            if git_cmd and project_path:
                if os.path.exists(project_path):
                    await asyncio.to_thread(self.run_git, git_cmd, project_path)
                else:
                    print(f"[Git Error] Path not found: {project_path}")

    def run_git(self, command, cwd):
        try:
            print(f"[Git] Running 'git {command}' in '{cwd}'")
            startupinfo = None
            if os.name == 'nt':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

            full_cmd = ["git"] + command.split()
            result = subprocess.run(
                full_cmd, cwd=cwd, capture_output=True, text=True,
                startupinfo=startupinfo
            )
            
            if result.returncode == 0:
                print(f"[Git Success] {result.stdout.strip()}")
            else:
                print(f"[Git Error] {result.stderr.strip()}")
        except Exception as e:
            print(f"[Git Exception] {e}")

    async def on_pi_request(self, data):
        pass

if __name__ == "__main__":
    plugin = DevToolsPlugin()
    asyncio.run(plugin.connect())