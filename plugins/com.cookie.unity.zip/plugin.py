import asyncio
import os
import sys

try:
    import pyautogui
    PYAUTOGUI_AVAILABLE = True
except ImportError:
    pyautogui = None
    PYAUTOGUI_AVAILABLE = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.windows_action_map = {
            "play_stop": "ctrl+p",
            "pause": "ctrl+shift+p",
            "step": "ctrl+alt+p",
            "console": "ctrl+shift+c",
            "move": "w",
            "rotate": "e",
            "scale": "r",
            "rect": "t",
            "center": "z",
            "local": "x",
            "pivot": "v",
            "new_empty": "ctrl+shift+n",
            "new_child": "alt+shift+n",
            "duplicate": "ctrl+d",
            "rename": "f2",
            "add_comp": "ctrl+shift+a",
            "focus": "f",
            "lock_view": "shift+f",
            "align": "ctrl+shift+f",
            "move_view": "ctrl+alt+f",
            "inspector": "ctrl+1",
            "game": "ctrl+2",
            "scene": "ctrl+3",
            "hierarchy": "ctrl+4",
            "project": "ctrl+5",
            "assetstore": "ctrl+9",
            "maximize": "shift+space",
            "save": "ctrl+s",
            "save_all": "ctrl+shift+s",
            "refresh": "ctrl+r",
        }

        self.macos_action_map = {
            "play_stop": "command+p",
            "pause": "command+shift+p",
            "step": "command+option+p",
            "console": "command+shift+c",
            "move": "w",
            "rotate": "e",
            "scale": "r",
            "rect": "t",
            "center": "z",
            "local": "x",
            "pivot": "v",
            "new_empty": "command+shift+n",
            "new_child": "option+shift+n",
            "duplicate": "command+d",
            "rename": "f2",
            "add_comp": "command+shift+a",
            "focus": "f",
            "lock_view": "shift+f",
            "align": "command+shift+f",
            "move_view": "command+option+f",
            "inspector": "command+1",
            "game": "command+2",
            "scene": "command+3",
            "hierarchy": "command+4",
            "project": "command+5",
            "assetstore": "command+9",
            "maximize": "shift+space",
            "save": "command+s",
            "save_all": "command+shift+s",
            "refresh": "command+r",
        }

        self.icon_map = {
            "play_stop": "STATE_PLAY_STOP",
            "pause": "STATE_PAUSE",
            "step": "STATE_STEP",
            "console": "STATE_CONSOLE",
            "move": "STATE_MOVE",
            "rotate": "STATE_ROTATE",
            "scale": "STATE_SCALE",
            "rect": "STATE_RECT",
            "center": "STATE_CENTER",
            "local": "STATE_LOCAL",
            "pivot": "STATE_PIVOT",
            "new_empty": "STATE_NEW_EMPTY",
            "new_child": "STATE_NEW_CHILD",
            "duplicate": "STATE_DUPLICATE",
            "rename": "STATE_RENAME",
            "add_comp": "STATE_ADD_COMP",
            "focus": "STATE_FOCUS",
            "lock_view": "STATE_LOCK_VIEW",
            "align": "STATE_ALIGN",
            "move_view": "STATE_MOVE_VIEW",
            "inspector": "STATE_INSPECTOR",
            "game": "STATE_GAME",
            "scene": "STATE_SCENE",
            "hierarchy": "STATE_HIERARCHY",
            "project": "STATE_PROJECT",
            "assetstore": "STATE_ASSETSTORE",
            "maximize": "STATE_MAXIMIZE",
            "save": "STATE_SAVE",
            "save_all": "STATE_SAVE_ALL",
            "refresh": "STATE_REFRESH",
        }

    def _get_icon_path(self, action_key):
        icon_name = self.icon_map.get(action_key or "play_stop", "STATE_PLAY_STOP")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_key):
        icon_path = self._get_icon_path(action_key)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "full_cmd", "cmd_type", "key_val", "action_key",
            "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "play_stop"
        default_key = self.macos_action_map[default_action] if IS_MACOS else self.windows_action_map[default_action]
        default_full_cmd = f"combo|{default_key}|Play"
        new_settings = {
            "full_cmd": default_full_cmd,
            "cmd_type": "combo",
            "key_val": default_key,
            "action_key": default_action,
            "command": default_full_cmd,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })
        await self._send_builtin_icon(context, default_action)

    def _normalize_key(self, key):
        k = str(key).strip().lower()
        aliases = {
            "cmd": "command" if IS_MACOS else "win",
            "command": "command" if IS_MACOS else "win",
            "win": "command" if IS_MACOS else "win",
            "windows": "command" if IS_MACOS else "win",
            "alt": "option" if IS_MACOS else "alt",
            "option": "option" if IS_MACOS else "alt",
            "control": "ctrl",
            "ctrl": "ctrl",
            "return": "enter",
            "esc": "escape",
        }
        return aliases.get(k, k)

    def _translate_custom_hotkey_for_macos(self, key_val):
        """Fallback for old saved settings that only contain Windows-style key_val."""
        if not IS_MACOS:
            return key_val
        parts = []
        for raw in str(key_val).split('+'):
            p = raw.strip().lower()
            if p == "ctrl":
                parts.append("command")
            elif p == "alt":
                parts.append("option")
            else:
                parts.append(p)
        return '+'.join(parts)

    def _send_hotkey_sync(self, key_val, cmd_type="combo"):
        if not PYAUTOGUI_AVAILABLE or not key_val:
            return

        key_val = self._translate_custom_hotkey_for_macos(key_val)
        keys = [self._normalize_key(k) for k in str(key_val).split('+') if str(k).strip()]
        if not keys:
            return

        if cmd_type == "single" or len(keys) == 1:
            pyautogui.press(keys[0])
        else:
            pyautogui.hotkey(*keys)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("action_key") or "play_stop")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {}) or {}
        cmd_type = settings.get("cmd_type") or "combo"
        action_key = settings.get("action_key")

        if action_key:
            action_map = self.macos_action_map if IS_MACOS else self.windows_action_map
            key_val = action_map.get(action_key)
        else:
            key_val = settings.get("key_val", "")

        if not key_val:
            return

        try:
            await asyncio.to_thread(self._send_hotkey_sync, key_val, cmd_type)
        except Exception as e:
            print(f"[Unity Plugin] Input Error: {e}")
