macOS Apple Silicon provider
============================

Place the official vladkens/macmon Apple Silicon executable at:

  macmon/macmon

The System Monitor plugin intentionally uses only this plugin-local binary.
It does not search COMBO-X utility folders, Homebrew, /usr/local/bin, or PATH.

Upstream project:
https://github.com/vladkens/macmon

Pinned/tested release for this plugin: v0.8.2
Release asset:
https://github.com/vladkens/macmon/releases/download/v0.8.2/macmon-v0.8.2.tar.gz

Keep LICENSE in this directory when redistributing macmon.
