import asyncio
import base64
import io
import os
import sys

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

try:
    from PIL import Image
    import pyautogui
    PIL_OK = True
except ImportError:
    Image = None
    pyautogui = None
    PIL_OK = False

# Windows 전용: 화면 DC에서 픽셀을 직접 읽기
user32 = None
gdi32 = None
if IS_WINDOWS:
    try:
        import ctypes
        user32 = ctypes.windll.user32
        gdi32 = ctypes.windll.gdi32
    except Exception as e:
        print(f"[ColorPicker Warning] Windows ctypes init failed: {e}")
        user32 = None
        gdi32 = None


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.default_icon_path = os.path.join(self.plugin_dir, "icon", "PICK_COLOR.png")
        self.context_settings = {}

    def _default_settings(self):
        return {
            "sync_led": False,
            "_lang": "en",
            "sync_title_on_pick": False,
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("sync_led", False),
            s.get("_lang"),
            s.get("title"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_pick", False)
        ])

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self.on_key_did_appear(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if event == "keyDown":
            await self.on_key_down(context, settings)

    async def on_key_did_appear(self, context, incoming_settings):
        if not context:
            return

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            if os.path.exists(self.default_icon_path):
                await self.runner.send_message({
                    "event": "setIcon",
                    "context": context,
                    "payload": {"icon_path": self.default_icon_path}
                })
            return

        self.context_settings[context] = self._merge_with_defaults(incoming_settings)

    def _get_pixel_color_windows(self, x, y):
        if not user32 or not gdi32:
            raise RuntimeError("Windows GDI is not available")

        hdc = user32.GetDC(0)
        try:
            pixel = gdi32.GetPixel(hdc, int(x), int(y))
        finally:
            user32.ReleaseDC(0, hdc)

        if pixel == -1:
            raise RuntimeError("GetPixel failed")

        r = pixel & 0xFF
        g = (pixel >> 8) & 0xFF
        b = (pixel >> 16) & 0xFF
        return r, g, b

    def _get_pixel_color_screenshot(self, x, y):
        """
        macOS/Linux 공통 fallback.
        macOS에서는 시스템 설정 > 개인정보 보호 및 보안 > 화면 기록 권한이 필요할 수 있습니다.
        Retina 환경에서는 pyautogui.position() 좌표와 screenshot 픽셀 좌표 배율이 다를 수 있어서
        전체 스크린샷 크기와 pyautogui.size()를 비교해 좌표를 보정합니다.
        """
        if not PIL_OK or pyautogui is None:
            raise RuntimeError("PIL/pyautogui is not available")

        img = pyautogui.screenshot()
        screen_w, screen_h = pyautogui.size()
        img_w, img_h = img.size

        sx = img_w / screen_w if screen_w else 1
        sy = img_h / screen_h if screen_h else 1

        px = max(0, min(img_w - 1, int(round(x * sx))))
        py = max(0, min(img_h - 1, int(round(y * sy))))

        color = img.getpixel((px, py))
        if isinstance(color, int):
            return color, color, color
        return int(color[0]), int(color[1]), int(color[2])

    def get_pixel_color(self, x, y):
        if IS_WINDOWS:
            try:
                return self._get_pixel_color_windows(x, y)
            except Exception as e:
                print(f"[ColorPicker Warning] Windows GDI failed, fallback to screenshot: {e}")

        return self._get_pixel_color_screenshot(x, y)

    async def on_key_down(self, context, incoming_settings):
        if not context or not PIL_OK:
            print("[ColorPicker Error] PIL/pyautogui is not available")
            return

        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **(incoming_settings or {})})
        self.context_settings[context] = settings

        x, y = pyautogui.position()

        try:
            r, g, b = self.get_pixel_color(x, y)
            hex_val = f"#{r:02x}{g:02x}{b:02x}".upper()

            color_img = Image.new("RGB", (128, 128), (r, g, b))
            buffer = io.BytesIO()
            color_img.save(buffer, format="PNG")
            b64_str = base64.b64encode(buffer.getvalue()).decode()

            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": {"image": f"data:image/png;base64,{b64_str}"}
            })

            if settings.get("sync_title_on_pick", False):
                settings["title"] = hex_val
                self.context_settings[context] = settings

                await self.runner.send_message({
                    "event": "setSettings",
                    "context": context,
                    "payload": settings
                })

                await self.runner.send_message({
                    "event": "setTitle",
                    "context": context,
                    "payload": {"title": hex_val}
                })

            if settings.get("sync_led", False):
                await self.runner.send_message({
                    "event": "sendToPlugin",
                    "context": context,
                    "payload": {
                        "command": "direct_serial",
                        "serial_cmd": 0xC0,
                        "serial_data": [255, r, g, b]
                    }
                })

            print(f"[ColorPicker] Picked: {hex_val} at ({x}, {y}) on {sys.platform}")

        except Exception as e:
            print(f"[ColorPicker Error] {e}")
