import asyncio
import json
import os
import sys
import traceback
import aiohttp
import websockets

class TwitchPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.twitch"
        self.uri = "ws://localhost:8765"
        self.cd_ws = None
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_file = os.path.join(self.plugin_dir, "twitch_config.json")

        self.last_valid_settings = {}
        self.config = {"client_id": "", "access_token": "", "broadcaster_id": ""}
        self.load_config()

        self.icon_map = {
            "create_marker": "STATE_CREATE_MARKER",
            "create_clip": "STATE_CREATE_CLIP",
            "run_commercial_30": "STATE_RUN_COMMERCIAL_30",
            "run_commercial_60": "STATE_RUN_COMMERCIAL_60",
            "send_chat": "STATE_SEND_CHAT",
            "clear_chat": "STATE_CLEAR_CHAT",
            "emote_only_on": "STATE_EMOTE_ONLY_ON",
            "emote_only_off": "STATE_EMOTE_ONLY_OFF",
            "change_title": "STATE_CHANGE_TITLE",
        }

    def log(self, message: str):
        try:
            print(message, flush=True)
        except Exception:
            pass

    def _default_action(self):
        return "create_marker"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "target_text": "",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or self._default_action()
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("target_text"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False),
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        if not self.cd_ws or not context:
            return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.cd_ws.send(json.dumps({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            }))

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.last_valid_settings[context] = defaults.copy()
            if self.cd_ws:
                await self.cd_ws.send(json.dumps({
                    "event": "setSettings",
                    "context": context,
                    "payload": defaults
                }))
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.last_valid_settings[context] = merged
        await self._send_builtin_icon(context, merged["command"])
        return True

    def load_config(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    self.config.update(json.load(f))
            except Exception as e:
                self.log(f"[Twitch] Config load error: {e}")

    def save_config(self):
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            self.log(f"[Twitch] Save config error: {e}")

    async def twitch_api_request(self, method, endpoint, payload=None):
        url = f"https://api.twitch.tv/helix/{endpoint}"
        headers = {
            "Client-Id": self.config.get("client_id", ""),
            "Authorization": f"Bearer {self.config.get('access_token', '')}",
            "Content-Type": "application/json"
        }

        try:
            async with aiohttp.ClientSession() as session:
                if method == "POST":
                    async with session.post(url, headers=headers, json=payload) as resp:
                        return await resp.json() if resp.status in [200, 202] else None
                elif method == "PATCH":
                    async with session.patch(url, headers=headers, json=payload) as resp:
                        return resp.status == 204
                elif method == "DELETE":
                    async with session.delete(url, headers=headers, json=payload) as resp:
                        return resp.status == 204
        except Exception as e:
            self.log(f"[Twitch] API Call Error: {e}")
            return None

    async def connect_to_cookiedeck(self):
        while True:
            try:
                self.log(f"[Twitch Plugin] Connecting to CookieDeck at {self.uri}...")
                async with websockets.connect(self.uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    self.log("[Twitch Plugin] Registered!")

                    async for message in ws:
                        data = json.loads(message)
                        await self.handle_message(data)

            except Exception as e:
                self.log(f"[Twitch Plugin] Disconnected. Retrying... ({e})")
            finally:
                self.cd_ws = None
            await asyncio.sleep(3)

    async def handle_message(self, data):
        try:
            event = data.get("event")
            context = data.get("context")
            payload = data.get("payload", {}) or {}

            if event == "keyDidAppear":
                raw_settings = payload.get("settings", {}) or {}
                if context:
                    await self._initialize_default_visuals_if_new(context, raw_settings)
                return

            if event == "didReceiveSettings":
                settings = payload.get("settings", payload) or {}
                if context:
                    self.last_valid_settings[context] = self._merge_with_defaults({
                        **self.last_valid_settings.get(context, {}),
                        **settings
                    })
                return

            if event in ["keyDidDisappear", "willDisappear"]:
                if context in self.last_valid_settings:
                    self.last_valid_settings.pop(context, None)
                return

            if event == "keyDown":
                await self.on_key_down(data)
                return

            if event == "sendToPlugin":
                command = payload.get("command")
                if command == "apply_builtin_icon":
                    action_name = payload.get("action_command")
                    if not action_name and context:
                        action_name = self.last_valid_settings.get(context, {}).get("command")
                    await self._send_builtin_icon(context, action_name or self._default_action())
                elif command == "getTwitchSettings":
                    await self.cd_ws.send(json.dumps({
                        "event": "sendToPropertyInspector",
                        "context": context,
                        "payload": {"command": "twitchSettings", "settings": self.config}
                    }))
                elif command == "setTwitchSettings":
                    self.config.update(payload.get("settings", {}))
                    self.save_config()
                    self.log("[Twitch] Config updated.")
                    await self.cd_ws.send(json.dumps({"event": "closeSettings", "key": context}))

        except Exception as e:
            self.log(f"[Twitch Plugin] Error: {e}")
            self.log(traceback.format_exc())

    async def ensure_settings(self, context, payload):
        incoming_settings = payload.get("settings", {}) if isinstance(payload, dict) else {}
        if incoming_settings:
            cached = self.last_valid_settings.get(context, {})
            self.last_valid_settings[context] = self._merge_with_defaults({**cached, **incoming_settings})
        return self._merge_with_defaults(self.last_valid_settings.get(context, {}))

    async def on_key_down(self, data):
        context = data.get("context") or data.get("action")
        payload = data.get("payload", {}) or {}
        final_settings = await self.ensure_settings(context, payload)

        command = final_settings.get("command")
        target_text = final_settings.get("target_text", "")
        broadcaster_id = self.config.get("broadcaster_id")

        if not command or not broadcaster_id:
            self.log("[Twitch] Action aborted. Check settings or Broadcaster ID.")
            return

        self.log(f"[Twitch Action] Executing: {command}")

        if command == "create_marker":
            await self.twitch_api_request("POST", "streams/markers", {"user_id": broadcaster_id})

        elif command == "create_clip":
            await self.twitch_api_request("POST", f"clips?broadcaster_id={broadcaster_id}")

        elif command == "run_commercial_30":
            await self.twitch_api_request("POST", "channels/commercial", {"broadcaster_id": broadcaster_id, "length": 30})

        elif command == "run_commercial_60":
            await self.twitch_api_request("POST", "channels/commercial", {"broadcaster_id": broadcaster_id, "length": 60})

        elif command == "send_chat":
            if target_text:
                await self.twitch_api_request("POST", "chat/messages", {"broadcaster_id": broadcaster_id, "sender_id": broadcaster_id, "message": target_text})

        elif command == "clear_chat":
            await self.twitch_api_request("DELETE", f"moderation/chat?broadcaster_id={broadcaster_id}&moderator_id={broadcaster_id}")

        elif command == "emote_only_on":
            await self.twitch_api_request("PATCH", f"chat/settings?broadcaster_id={broadcaster_id}&moderator_id={broadcaster_id}", {"emote_mode": True})

        elif command == "emote_only_off":
            await self.twitch_api_request("PATCH", f"chat/settings?broadcaster_id={broadcaster_id}&moderator_id={broadcaster_id}", {"emote_mode": False})

        elif command == "change_title":
            if target_text:
                await self.twitch_api_request("PATCH", f"channels?broadcaster_id={broadcaster_id}", {"title": target_text})

    async def start(self):
        await self.connect_to_cookiedeck()

if __name__ == "__main__":
    plugin = TwitchPlugin()
    try:
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(plugin.start())
    except KeyboardInterrupt:
        print("[Twitch Plugin] Shutting down...", flush=True)
