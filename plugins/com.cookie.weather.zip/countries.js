const globalCountriesData =[
{
    "country": "South Korea",
    "cities":["Seoul", "Busan", "Incheon", "Daegu", "Daejeon", "Gwangju", "Suwon", "Ulsan", "Jeju", "Changwon", "Cheongju"]
  },
  {
    "country": "United States",
    "cities":["New York", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia", "San Antonio", "San Diego", "Dallas", "San Jose"]
  },
  {
    "country": "Japan",
    "cities":["Tokyo", "Yokohama", "Osaka", "Nagoya", "Sapporo", "Fukuoka", "Kobe", "Kyoto", "Kawasaki", "Saitama"]
  },
  {
    "country": "United Kingdom",
    "cities":["London", "Birmingham", "Glasgow", "Liverpool", "Bristol", "Manchester", "Sheffield", "Leeds", "Edinburgh", "Leicester"]
  },
  {
    "country": "France",
    "cities":["Paris", "Marseille", "Lyon", "Toulouse", "Nice", "Nantes", "Strasbourg", "Montpellier", "Bordeaux", "Lille"]
  },
  {
    "country": "Germany",
    "cities":["Berlin", "Hamburg", "Munich", "Cologne", "Frankfurt", "Essen", "Stuttgart", "Dortmund", "Düsseldorf", "Bremen"]
  },
  {
    "country": "China",
    "cities":["Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Chengdu", "Wuhan", "Tianjin", "Dongguan", "Chongqing", "Nanjing"]
  },
  {
    "country": "Canada",
    "cities":["Toronto", "Montreal", "Vancouver", "Calgary", "Edmonton", "Ottawa", "Quebec City", "Winnipeg", "Hamilton", "Kitchener"]
  },
  {
    "country": "Australia",
    "cities":["Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide", "Gold Coast", "Cranbourne", "Canberra", "Newcastle", "Wollongong"]
  }
];