import asyncio
import platform
import time
import os
import subprocess

SYSTEM_NAME = platform.system()
IS_WINDOWS = (SYSTEM_NAME == "Windows")
IS_MACOS = (SYSTEM_NAME == "Darwin")
IS_LINUX = (SYSTEM_NAME == "Linux")

libraries_ok = False
keyboard = None
pyautogui = None
win32gui = None
win32con = None

if IS_WINDOWS:
    try:
        import win32gui
        import win32con
        import keyboard
        libraries_ok = True
    except ImportError:
        print("[Discord Plugin Error] Missing 'pywin32' or 'keyboard'.")
else:
    try:
        import pyautogui
        pyautogui.PAUSE = 0.02
        libraries_ok = True
    except ImportError:
        print("[Discord Plugin Error] Missing 'pyautogui'.")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}
        self.action_map = {
            "togglemute": self.toggle_mute,
            "toggledeafen": self.toggle_deafen,
            "answercall": self.answer_call,
            "rejectcall": self.reject_call,
            "navserver_up": self.nav_server_up,
            "navserver_down": self.nav_server_down,
            "navchannel_up": self.nav_channel_up,
            "navchannel_down": self.nav_channel_down,
            "navhistory_back": self.nav_history_back,
            "navhistory_forward": self.nav_history_forward,
            "navunread_up": self.nav_unread_up,
            "navunread_down": self.nav_unread_down,
            "openemoji": self.open_emoji,
            "opengif": self.open_gif,
            "uploadfile": self.upload_file,
            "quickswitcher": self.quick_switcher,
        }
        self.icon_map = {
            "togglemute": "TOGGLEMUTE",
            "toggledeafen": "TOGGLEDEAFEN",
            "answercall": "ANSWERCALL",
            "rejectcall": "REJECTCALL",
            "navserver_up": "NAVSERVER_UP",
            "navserver_down": "NAVSERVER_DOWN",
            "navchannel_up": "NAVCHANNEL_UP",
            "navchannel_down": "NAVCHANNEL_DOWN",
            "navhistory_back": "NAVHISTORY_BACK",
            "navhistory_forward": "NAVHISTORY_FORWARD",
            "navunread_up": "NAVUNREAD_UP",
            "navunread_down": "NAVUNREAD_DOWN",
            "openemoji": "OPENEMOJI",
            "opengif": "OPENGIF",
            "uploadfile": "UPLOADFILE",
            "quickswitcher": "QUICKSWITCHER",
        }

    def _default_action(self):
        return "togglemute"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "discord_action": action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or merged.get("discord_action") or self._default_action()
        merged["command"] = action
        merged["discord_action"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("discord_action"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            current_action = action_command or settings.get("command") or settings.get("discord_action") or cached.get("command") or self._default_action()
            await self._send_builtin_icon(context, current_action)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not libraries_ok:
            print(f"[{self.uuid}] Plugin disabled: Missing required input libraries for this OS.")
            return

        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = settings

        selected_action = settings.get("command") or settings.get("discord_action") or self._default_action()

        if selected_action:
            action_func = self.action_map.get(selected_action)
            if action_func:
                await asyncio.to_thread(action_func)
            else:
                print(f"[{self.uuid}] Unknown action: {selected_action}")

    def _normalize_pyautogui_key(self, key):
        aliases = {
            "cmd": "command",
            "command": "command",
            "win": "command" if IS_MACOS else "win",
            "windows": "command" if IS_MACOS else "win",
            "ctrl": "ctrl",
            "control": "ctrl",
            "alt": "option" if IS_MACOS else "alt",
            "option": "option" if IS_MACOS else "alt",
            "shift": "shift",
            "esc": "esc",
            "escape": "esc",
            "enter": "enter",
            "return": "enter",
            "up": "up",
            "down": "down",
            "left": "left",
            "right": "right",
            "page up": "pageup",
            "page down": "pagedown",
        }
        key = str(key).strip().lower()
        return aliases.get(key, key)

    def _send_pyautogui_hotkey(self, hotkey):
        if not pyautogui:
            print(f"[{self.uuid}] pyautogui is not available.")
            return
        parts = [self._normalize_pyautogui_key(p) for p in hotkey.split('+') if p.strip()]
        if not parts:
            return
        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts)

    def _mac_get_frontmost_app(self):
        script = 'tell application "System Events" to get name of first application process whose frontmost is true'
        try:
            result = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=2)
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception as e:
            print(f"[{self.uuid} Warning] Could not read frontmost app: {e}")
        return None

    def _mac_activate_discord(self):
        script = '\n        tell application "System Events"\n            set appNames to name of every application process\n        end tell\n        if appNames contains "Discord" then\n            tell application "Discord" to activate\n        else if appNames contains "Discord PTB" then\n            tell application "Discord PTB" to activate\n        else if appNames contains "Discord Canary" then\n            tell application "Discord Canary" to activate\n        else\n            tell application "Discord" to activate\n        end if\n        '
        try:
            subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=3)
            return True
        except Exception as e:
            print(f"[{self.uuid} Warning] Discord activate failed: {e}")
            return False

    def _mac_restore_app(self, app_name):
        if not app_name or app_name in ("Discord", "Discord PTB", "Discord Canary"):
            return
        safe_name = app_name.replace('\\', '\\\\').replace('"', '\\"')
        script = f'tell application "{safe_name}" to activate'
        try:
            subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=2)
        except Exception as e:
            print(f"[{self.uuid} Warning] Restore app failed: {e}")

    def _send_hotkey_with_focus(self, windows_hotkey, mac_hotkey=None):
        try:
            if IS_WINDOWS:
                original_foreground_window = win32gui.GetForegroundWindow()
                discord_hwnd = 0

                def callback(hwnd, extra):
                    nonlocal discord_hwnd
                    title = win32gui.GetWindowText(hwnd)
                    class_name = win32gui.GetClassName(hwnd)
                    if "Discord" in title and class_name == "Chrome_WidgetWin_1":
                        discord_hwnd = hwnd

                win32gui.EnumWindows(callback, None)

                if discord_hwnd == 0:
                    keyboard.send(windows_hotkey)
                    return

                win32gui.ShowWindow(discord_hwnd, win32con.SW_RESTORE)
                win32gui.SetForegroundWindow(discord_hwnd)
                time.sleep(0.15)
                keyboard.send(windows_hotkey)
                time.sleep(0.05)
                win32gui.SetForegroundWindow(original_foreground_window)
                return

            if IS_MACOS:
                previous_app = self._mac_get_frontmost_app()
                self._mac_activate_discord()
                time.sleep(0.18)
                self._send_pyautogui_hotkey(mac_hotkey or windows_hotkey)
                time.sleep(0.06)
                self._mac_restore_app(previous_app)
                return

            # Linux / 기타 환경: 포커스 이동은 하지 않고 현재 포커스에만 전송합니다.
            self._send_pyautogui_hotkey(windows_hotkey)

        except Exception as e:
            print(f"[{self.uuid} ERROR] Focus switch failed: {e}")

    def toggle_mute(self): self._send_hotkey_with_focus("ctrl+shift+m", "command+shift+m")
    def toggle_deafen(self): self._send_hotkey_with_focus("ctrl+shift+d", "command+shift+d")
    def answer_call(self): self._send_hotkey_with_focus("ctrl+enter", "command+enter")
    def reject_call(self): self._send_hotkey_with_focus("esc", "esc")
    def nav_server_up(self): self._send_hotkey_with_focus("ctrl+alt+up", "command+option+up")
    def nav_server_down(self): self._send_hotkey_with_focus("ctrl+alt+down", "command+option+down")
    def nav_channel_up(self): self._send_hotkey_with_focus("alt+up", "option+up")
    def nav_channel_down(self): self._send_hotkey_with_focus("alt+down", "option+down")
    def nav_history_back(self): self._send_hotkey_with_focus("alt+left", "option+left")
    def nav_history_forward(self): self._send_hotkey_with_focus("alt+right", "option+right")
    def nav_unread_up(self): self._send_hotkey_with_focus("alt+shift+up", "command+shift+option+up")
    def nav_unread_down(self): self._send_hotkey_with_focus("alt+shift+down", "command+shift+option+down")
    def quick_switcher(self): self._send_hotkey_with_focus("ctrl+k", "command+k")
    def open_emoji(self): self._send_hotkey_with_focus("ctrl+e", "command+e")
    def open_gif(self): self._send_hotkey_with_focus("ctrl+g", "command+g")
    def upload_file(self): self._send_hotkey_with_focus("ctrl+shift+u", "command+shift+u")
