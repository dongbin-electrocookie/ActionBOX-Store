#target aftereffects
(function () {
    var comp = app.project && app.project.activeItem;
    if (!(comp instanceof CompItem)) {
        alert("Open or select a composition first.");
        return;
    }
    app.beginUndoGroup("Add Composition to Render Queue");
    app.project.renderQueue.items.add(comp);
    app.endUndoGroup();
}());
