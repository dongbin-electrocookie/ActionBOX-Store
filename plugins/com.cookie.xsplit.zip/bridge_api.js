/* XSplit-hosted adapter. No eval, guessed hotkeys, or arbitrary host commands. */
(function (root) {
    "use strict";
    function failure(code, detail) {
        const error = new Error(detail || code);
        error.code = code;
        return error;
    }
    function create(xjs) {
        const app = new xjs.App();
        const recordingName = "Local Recording"; // XJS's canonical host channel.
        const isRecording = name => /^Local Recording(?:$|[:&])/i.test(name);
        const accepted = value => {
            if (value === false) throw failure("ERR_API", "XSplit rejected the operation.");
            return value;
        };
        async function scene(id) {
            if (!id) throw failure("ERR_SELECT_TARGET");
            if (String(id).startsWith("index:")) {
                const index = Number(String(id).slice(6));
                const count = await xjs.Scene.getSceneCount();
                if (!Number.isInteger(index) || index < 0 || index >= count) throw failure("ERR_TARGET_MISSING");
                return xjs.Scene.getBySceneIndex(index);
            }
            const result = await xjs.Scene.getBySceneUid(String(id));
            if (!result) throw failure("ERR_TARGET_MISSING");
            return result;
        }
        async function outputs() {
            const list = await xjs.Output.getOutputList();
            const result = await Promise.all(list.map(async output => {
                const id = await output.getName();
                // Display-name lookup is optional; some host versions never
                // answer it. Do not let that leave the whole list loading.
                let timer;
                const name = await Promise.race([
                    output.getDisplayName().catch(() => id),
                    new Promise(resolve => { timer = setTimeout(() => resolve(id), 1500); })
                ]).finally(() => clearTimeout(timer));
                return {id, name: name || id, kind: isRecording(id) ? "record" : "stream", output};
            }));
            // Older XJS hosts expose recording only through the static methods.
            if (!result.some(entry => entry.kind === "record")) {
                result.push({id: recordingName, name: recordingName, kind: "record", output: null});
            }
            return result;
        }
        async function activeNames() {
            const streams = await xjs.StreamInfo.getActiveStreamChannels();
            return Promise.all(streams.map(stream => stream.getName()));
        }
        const commands = {
            async getAllScenes() {
                const count = await xjs.Scene.getSceneCount();
                const scenes = await Promise.all(Array.from({length: count}, async (_, index) => {
                    const current = await xjs.Scene.getBySceneIndex(index);
                    const name = await current.getName();
                    const uid = await current.getSceneUid();
                    return {id: uid || "index:" + index, name: name || "Scene " + (index + 1)};
                }));
                return {scenes};
            },
            async getSceneSources(args) {
                const current = await scene(args.sceneId);
                // Visibility belongs to a scene ITEM, not the shared source.
                const items = await current.getItems();
                const sources = await Promise.all(items.map(async item => ({
                    id: await item.getId(), name: await item.getName()
                })));
                return {sources};
            },
            async getScenePresets(args) {
                return {presets: await (await scene(args.sceneId)).getPresets()};
            },
            async getAllOutputs() {
                return {outputs: (await outputs()).map(({id, name, kind}) => ({id, name, kind}))};
            },
            async setActiveScene(args, guard) {
                const current = await scene(args.id);
                guard();
                accepted(await xjs.Scene.setActiveScene(current));
                return {};
            },
            async toggleSourceState(args, guard) {
                const items = await (await scene(args.sceneId)).getItems();
                const ids = await Promise.all(items.map(item => item.getId()));
                const item = items[ids.indexOf(args.sourceId)];
                if (!item) throw failure("ERR_TARGET_MISSING");
                const visible = await item.isVisible();
                guard();
                accepted(await item.setVisible(!visible));
                return {};
            },
            async setActivePreset(args, guard) {
                const current = await scene(args.sceneId);
                if (!(await current.getPresets()).includes(args.presetId)) throw failure("ERR_TARGET_MISSING");
                guard();
                accepted(await current.switchToPreset(args.presetId));
                return {};
            },
            async toggleOutputState(args, guard) {
                const selected = (await outputs()).find(entry => entry.id === args.id && entry.kind === args.kind);
                if (!selected) throw failure("ERR_TARGET_MISSING");
                const names = await activeNames();
                const active = names.some(name => name === selected.id || name.startsWith(selected.id + "&output:"));
                guard();
                if (selected.output) {
                    accepted(await (active ? selected.output.stopBroadcast() : selected.output.startBroadcast()));
                } else {
                    accepted(await (active ? xjs.Output.stopLocalRecording() : xjs.Output.startLocalRecording()));
                }
                return {};
            },
            async toggleMicrophoneState(args, guard) {
                const device = await app.getPrimaryMic();
                if (!device) throw failure("ERR_TARGET_MISSING");
                guard();
                accepted(await app.setPrimaryMicEnabled(!device.isEnabled()));
                return {};
            },
            async toggleSpeakerState(args, guard) {
                const device = await app.getPrimarySpeaker();
                if (!device) throw failure("ERR_TARGET_MISSING");
                guard();
                accepted(await app.setPrimarySpeakerEnabled(!device.isEnabled()));
                return {};
            },
            async doPushToLive(args, guard) {
                // These are the same host properties used by official XJS
                // Scene.getActiveScene/setActiveScene in split mode.
                const split = await xjs.exec("GetGlobalProperty", "splitmode");
                if (String(split) !== "1") throw failure("ERR_SPLIT_MODE");
                const index = await new Promise(resolve => xjs.exec("AppGetPropertyAsync", "scene:1", resolve));
                const count = await xjs.Scene.getSceneCount();
                if (!/^\d+$/.test(String(index)) || Number(index) >= count) throw failure("ERR_TARGET_MISSING");
                guard();
                const result = await new Promise(resolve =>
                    xjs.exec("AppSetPropertyAsync", "scene:0", String(index), resolve));
                if (Number(result) < 0) throw failure("ERR_API");
                return {};
            },
            async doScreenshot() {
                // XJS 2.14.1 has no supported screenshot API. Never substitute
                // a foreground hotkey or a desktop/thumbnail capture.
                throw failure("ERR_SCREENSHOT_UNSUPPORTED");
            }
        };
        return {
            async execute(command, args, guard) {
                if (!Object.prototype.hasOwnProperty.call(commands, command)) throw failure("ERR_UNSUPPORTED");
                const check = guard || (() => {});
                check();
                return commands[command](args || {}, check);
            }
        };
    }
    root.ComboXXSplitAPI = {create};
    if (typeof module !== "undefined" && module.exports) module.exports = {create};
})(typeof globalThis !== "undefined" ? globalThis : window);
