import asyncio
try:
    import keyboard
except ImportError:
    keyboard = None

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # Unreal Engine 5 Windows 기본 단축키 맵
        self.hotkey_map = {
            # Play / Build
            "play_in_editor": "alt+p",
            "stop_play": "esc",
            "build_all": "ctrl+shift+;",
            "build_lighting": "ctrl+shift+l",
            
            # Viewport
            "view_perspective": "alt+g",
            "view_top": "alt+j",
            "view_front": "alt+h",
            "view_left": "alt+k",
            "mode_lit": "alt+4",
            "mode_unlit": "alt+3",
            "mode_wireframe": "alt+2",
            "toggle_fullscreen": "f11",
            "focus_selected": "f",
            
            # Transform
            "tool_select": "q",
            "tool_translate": "w",
            "tool_rotate": "e",
            "tool_scale": "r",
            "snap_to_floor": "end",
            
            # Blueprint
            "bp_compile": "f7",
            "bp_find_node": "ctrl+f",
            "bp_add_comment": "c",
            
            # Edit
            "undo": "ctrl+z",
            "redo": "ctrl+y",
            "duplicate": "ctrl+d",
            "save_all": "ctrl+shift+s",
            "content_browser": "ctrl+space"
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard: return

        settings = data.get("payload", {}).get("settings", {})
        action = settings.get("ue_hotkey")

        if action and action in self.hotkey_map:
            hotkey = self.hotkey_map[action]
            await asyncio.to_thread(keyboard.send, hotkey)
            print(f"[{self.uuid}] Unreal Engine Hotkey Sent: {hotkey}")