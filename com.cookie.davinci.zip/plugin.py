import asyncio
import os
import sys

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        # Windows/Linux 기본 DaVinci Resolve 단축키
        self.windows_action_map = {
            "file_save": "ctrl+s",
            "edit_undo": "ctrl+z",
            "edit_redo": "ctrl+shift+z",
            "edit_ripple_delete": "ctrl+backspace",

            "tool_selection": "a",
            "tool_blade": "b",
            "tool_snapping": "n",
            "tool_linked_selection": "ctrl+shift+l",

            "timeline_split": "ctrl+\\",

            "play_toggle": "space",
            "play_reverse": "j",
            "play_stop": "k",
            "play_forward": "l",
            "play_prev_clip": "up",
            "play_next_clip": "down",

            "mark_in": "i",
            "mark_out": "o",
            "mark_clear": "alt+x",
            "marker_add": "m",

            "view_zoom_in": "ctrl+=",
            "view_zoom_out": "ctrl+-",
            "view_fit": "shift+z",
            "view_fullscreen": "ctrl+f"
        }

        # macOS DaVinci Resolve 기본 키맵. 편집/저장 계열은 Command, Alt 계열은 Option으로 변환.
        # 도구/재생/마킹 단일키는 Windows와 동일하게 유지.
        self.macos_action_map = {
            "file_save": "command+s",
            "edit_undo": "command+z",
            "edit_redo": "command+shift+z",
            "edit_ripple_delete": "command+backspace",

            "tool_selection": "a",
            "tool_blade": "b",
            "tool_snapping": "n",
            "tool_linked_selection": "command+shift+l",

            "timeline_split": "command+\\",

            "play_toggle": "space",
            "play_reverse": "j",
            "play_stop": "k",
            "play_forward": "l",
            "play_prev_clip": "up",
            "play_next_clip": "down",

            "mark_in": "i",
            "mark_out": "o",
            "mark_clear": "option+x",
            "marker_add": "m",

            "view_zoom_in": "command+=",
            "view_zoom_out": "command+-",
            "view_fit": "shift+z",
            "view_fullscreen": "command+f"
        }

        self.action_map = self.macos_action_map if IS_MACOS else self.windows_action_map

        self.icon_map = {
            "file_save": "FILE_SAVE",
            "edit_undo": "EDIT_UNDO",
            "edit_redo": "EDIT_REDO",
            "edit_ripple_delete": "EDIT_RIPPLE_DELETE",
            "tool_selection": "TOOL_SELECTION",
            "tool_blade": "TOOL_BLADE",
            "tool_snapping": "TOOL_SNAPPING",
            "tool_linked_selection": "TOOL_LINKED_SELECTION",
            "timeline_split": "TIMELINE_SPLIT",
            "play_toggle": "PLAY_TOGGLE",
            "play_reverse": "PLAY_REVERSE",
            "play_stop": "PLAY_STOP",
            "play_forward": "PLAY_FORWARD",
            "play_prev_clip": "PLAY_PREV_CLIP",
            "play_next_clip": "PLAY_NEXT_CLIP",
            "mark_in": "MARK_IN",
            "mark_out": "MARK_OUT",
            "mark_clear": "MARK_CLEAR",
            "marker_add": "MARKER_ADD",
            "view_zoom_in": "VIEW_ZOOM_IN",
            "view_zoom_out": "VIEW_ZOOM_OUT",
            "view_fit": "VIEW_FIT",
            "view_fullscreen": "VIEW_FULLSCREEN",
        }

    def _default_action(self):
        return "timeline_split"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or self._default_action()
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    def _normalize_key_token(self, token):
        token = str(token).strip().lower()
        aliases = {
            "cmd": "command",
            "win": "command" if IS_MACOS else "windows",
            "windows": "command" if IS_MACOS else "windows",
            "control": "ctrl",
            "option": "option" if IS_MACOS else "alt",
            "alt": "option" if IS_MACOS else "alt",
            "page up": "pageup",
            "page down": "pagedown",
            "return": "enter",
            "escape": "esc",
            "plus": "+",
            "minus": "-",
        }
        return aliases.get(token, token)

    def _send_hotkey_sync(self, hotkey):
        if not hotkey:
            return

        # Windows에서는 기존 keyboard 모듈을 우선 사용한다.
        if IS_WINDOWS and keyboard_available:
            keyboard.send(hotkey)
            return

        if not pyautogui_available:
            return

        parts = [self._normalize_key_token(part) for part in hotkey.split("+") if part.strip()]
        if not parts:
            return

        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            current_action = action_command or settings.get("command") or cached.get("command") or self._default_action()
            await self._send_builtin_icon(context, current_action)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = settings

        selected_action = settings.get("command") or self._default_action()
        hotkey = self.action_map.get(selected_action)
        if hotkey:
            await asyncio.to_thread(self._send_hotkey_sync, hotkey)
