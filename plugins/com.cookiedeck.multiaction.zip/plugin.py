import asyncio
import json
import keyboard
import os
import subprocess
import sys

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.toggle_states = {}

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")

        if event == "keyDidAppear":
            self.toggle_states[context] = 1
        elif event == "keyDidDisappear":
            self.toggle_states.pop(context, None)
        elif event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        settings = data.get("payload", {}).get("settings", {})
        
        current_state = self.toggle_states.get(context, 1)
        action_list_key = f"actions_{current_state}"
        action_list = settings.get(action_list_key, [])
        
        if not action_list:
            print(f"  > No actions for state {current_state}")
        
        for action_to_run in action_list:
            action_id = action_to_run.get("action_id")
            delay_ms = action_to_run.get("delay_ms", 0)
            custom_data = action_to_run.get("custom_data", "") # 경로 또는 텍스트

            # 딜레이
            if delay_ms > 0:
                await asyncio.sleep(delay_ms / 1000.0)
            
            if action_id:
                # 1. 단축키 실행
                if action_id == "__hotkey__":
                    if custom_data:
                        try:
                            keys = custom_data.lower().replace("arrow", "")
                            keyboard.send(keys)
                        except Exception as e: print(f"Hotkey Error: {e}")

                # 2. [추가] 텍스트 입력
                elif action_id == "__text__":
                    if custom_data:
                        try:
                            keyboard.write(custom_data)
                        except Exception as e: print(f"Text Error: {e}")

                # 3. [추가] 파일/폴더/URL 열기
                elif action_id == "__open__":
                    if custom_data:
                        # Blocking 방지를 위해 스레드로 실행
                        await asyncio.to_thread(self.open_path, custom_data)

                # 4. 외부 플러그인 액션 실행
                else:
                    await self.runner.send_message({
                        "event": "requestActionExecution",
                        "payload": { "key": context, "action_id": action_id }
                    })
        
        self.toggle_states[context] = 2 if current_state == 1 else 1

    # [헬퍼] 파일/URL 열기 함수
    def open_path(self, path):
        try:
            if sys.platform == "win32":
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.run(['open', path])
            else:
                subprocess.run(['xdg-open', path])
        except Exception as e:
            print(f"Open Path Error: {e}")