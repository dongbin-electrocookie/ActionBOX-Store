'use strict';

// A refresh is a message, not a settings change. Use the host's shared-runner
// sendToPlugin route and leave the saved target/title untouched.
class TikTokInspectorSync {
    constructor(socket, context, onData, texts) {
        this.socket = socket;
        this.context = context;
        this.onData = onData;
        this.texts = texts;
        this.timer = null;
        this.lastPayload = null;
        this.failure = '';
        socket.addEventListener('close', () => this.fail('STATUS_HOST_DISCONNECTED'));
        socket.addEventListener('error', () => this.fail('STATUS_HOST_DISCONNECTED'));
    }

    refresh(settings, language) {
        clearTimeout(this.timer);
        if (this.socket.readyState !== WebSocket.OPEN) {
            this.fail('STATUS_HOST_DISCONNECTED');
            return;
        }
        this.failure = '';
        this.timer = setTimeout(() => this.fail('STATUS_REFRESH_TIMEOUT'), 12000);
        const snapshot = {...settings, _lang: language};
        delete snapshot.pi_command;
        this.socket.send(JSON.stringify({
            event: 'sendToPlugin', context: this.context,
            payload: {command: 'refresh', settings: snapshot}
        }));
    }

    receive(payload) {
        if (!payload || payload.command !== 'syncData') return;
        clearTimeout(this.timer);
        this.timer = null;
        this.failure = '';
        this.lastPayload = payload;
        this.onData(payload);
        this.renderStatus();
    }

    fail(key) {
        clearTimeout(this.timer);
        this.timer = null;
        this.failure = key;
        if (!this.lastPayload) this.onData({scene_list: [], sync: {}});
        this.renderStatus();
    }

    renderStatus() {
        const payload = this.lastPayload || {};
        const pack = this.texts();
        const key = this.failure || payload.status_key;
        const fallback = {
            STATUS_REFRESH_TIMEOUT: 'No response. Check the connection and refresh again.',
            STATUS_HOST_DISCONNECTED: 'Disconnected from ComboX. Reopen these settings.'
        };
        let text = pack[key] || fallback[key] || payload.status || pack.STATUS_WAITING || 'Waiting...';
        for (const [name, value] of Object.entries(payload.status_params || {})) {
            text = text.replaceAll(`{${name}}`, String(value));
        }
        document.getElementById('status').innerText = text;
    }
}
