import asyncio
try:
    import keyboard
except ImportError:
    keyboard = None

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # Pro Tools Windows 기본 단축키 맵 (Keyboard Focus 'a...z' 활성화 기준)
        self.hotkey_map = {
            # Transport
            "play_stop": "space",
            "record": "f12",         # F12 또는 Numpad 3
            "return_zero": "enter",  # Return 키 (숫자패드 엔터/일반 엔터)
            "loop_toggle": "4",      # Numpad 4
            "click_toggle": "7",     # Numpad 7
            
            # Tools
            "tool_zoom": "f5",
            "tool_trim": "f6",
            "tool_select": "f7",
            "tool_grabber": "f8",
            "tool_scrub": "f9",
            "tool_pencil": "f10",
            # 프로툴 스마트 툴은 F6+F7+F8을 동시에 눌러야 켜집니다!
            "tool_smart": "f6+f7+f8", 
            
            # Editing (Keyboard Focus 기준 단일 키)
            "separate": "b",
            "heal": "ctrl+h",
            "fade_in": "d",
            "fade_out": "g",
            "crossfade": "f",
            "undo": "z",
            "redo": "shift+z",
            "copy": "c",
            "paste": "v",
            "cut": "x",
            
            # View / Zoom
            "toggle_mix_edit": "ctrl+=",
            "zoom_in": "t",
            "zoom_out": "r",
            "zoom_vertical_in": "alt+shift+]",
            "zoom_vertical_out": "alt+shift+[",
            "fit_to_window": "alt+a",
            
            # Track
            "new_track": "ctrl+shift+n",
            "group_tracks": "ctrl+g",
            # 솔로 클리어 같은 고급 기능은 매크로 조합이 필요할 수 있으나 기본 지원 범위 내에서 매핑
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard: return

        settings = data.get("payload", {}).get("settings", {})
        action = settings.get("pt_hotkey")

        if action and action in self.hotkey_map:
            hotkey = self.hotkey_map[action]
            
            # 스마트 툴처럼 3개 키 동시 입력이 필요한 경우
            if action == "tool_smart":
                # F6, F7, F8을 순서대로 누르고 동시에 떼는 방식으로 확실하게 전송
                await asyncio.to_thread(self._send_smart_tool)
            else:
                await asyncio.to_thread(keyboard.send, hotkey)
            
            print(f"[{self.uuid}] Pro Tools Hotkey Sent: {hotkey}")

    def _send_smart_tool(self):
        """프로툴 스마트 툴(F6+F7+F8)을 켜기 위한 특수 입력 함수"""
        keyboard.press('f6')
        keyboard.press('f7')
        keyboard.press('f8')
        keyboard.release('f8')
        keyboard.release('f7')
        keyboard.release('f6')