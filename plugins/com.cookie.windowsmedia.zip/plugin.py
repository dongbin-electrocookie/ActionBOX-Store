import asyncio
import sys

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 윈도우 기본 미디어 특수키 매핑
        self.media_map = {
            "play_pause": "play/pause media",
            "next": "next track",
            "prev": "previous track",
            "stop": "stop media",
            "vol_up": "volume up",
            "vol_down": "volume down",
            "mute": "volume mute"
        }

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return
        
        if sys.platform != "win32":
            print(f"[{self.uuid}] Ignored: Supported only on Windows.")
            return

        settings = data.get("payload", {}).get("settings", {})
        
        # 🚀 [표준화] 'command'를 먼저 확인하고, 없으면 기존 'media_action'을 씁니다.
        # 멀티액션에서 #vol_up 같은 신호가 오면 여기서 즉시 낚아챕니다.
        action = settings.get("command") or settings.get("media_action", "play_pause")
        
        hotkey_to_send = self.media_map.get(action)
        
        if hotkey_to_send:
            # 게임 중이거나 무거운 작업 중에도 씹히지 않도록 스레드로 발사
            await asyncio.to_thread(keyboard.send, hotkey_to_send)
            print(f"[{self.uuid}] Media Command Sent: {action}")