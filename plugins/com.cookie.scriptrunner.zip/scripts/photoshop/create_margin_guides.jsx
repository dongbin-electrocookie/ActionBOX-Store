#target photoshop

// === 사용자 설정 ===
var margin_mm = 5;  // 여백 (mm) — 원하는 수치로 변경 가능
var dpi = 300;      // 해상도에 맞게 조절 (보통 인쇄용은 300dpi)

// === 내부 계산 ===
var margin_px = (margin_mm / 25.4) * dpi; // mm → px

var doc = app.activeDocument;
var width = doc.width.as("px");
var height = doc.height.as("px");

// === 가이드 추가 ===
function addGuide(position, direction) {
  var idMk = charIDToTypeID("Mk  ");
  var desc = new ActionDescriptor();
  var idNw = charIDToTypeID("Nw  ");
  var desc2 = new ActionDescriptor();
  var idPstn = charIDToTypeID("Pstn");
  var idPxl = charIDToTypeID("#Pxl");
  desc2.putUnitDouble(idPstn, idPxl, position);
  var idOrnt = charIDToTypeID("Ornt");
  var idOrntType = charIDToTypeID("Ornt");
  var directionType = (direction === "V") ? charIDToTypeID("Vrtc") : charIDToTypeID("Hrzn");
  desc2.putEnumerated(idOrnt, idOrntType, directionType);
  var idGd = charIDToTypeID("Gd  ");
  desc.putObject(idNw, idGd, desc2);
  executeAction(idMk, desc, DialogModes.NO);
}

// === 실행 ===
addGuide(margin_px, "V");                   // Left
addGuide(width - margin_px, "V");           // Right
addGuide(margin_px, "H");                   // Top
addGuide(height - margin_px, "H");          // Bottom

//alert("✅ 상하좌우 여백 가이드가 추가되었습니다.\n여백: " + margin_mm + "mm (" + Math.round(margin_px) + "px)");
