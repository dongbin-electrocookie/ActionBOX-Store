import asyncio
import json
import os
import subprocess
import sys

# Windows 레지스트리 접근용 (Adobe 경로 찾기)
if sys.platform == "win32":
    import winreg

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner 
        self.uuid = manifest['UUID']
        # 🚀 [대통합 규격] 프로그램 경로와 스크립트 경로를 기억합니다.
        self.last_valid_settings = {}

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)
        elif event == "sendToPlugin":
            await self.on_pi_request(data)

    async def on_key_down(self, data):
        incoming_settings = data.get("payload", {}).get("settings", {})
        
        # 🚀 1. 유효한 경로 정보가 들어오면 기억해둡니다.
        if incoming_settings:
            # 값이 있는 설정만 골라서 업데이트 (캐시)
            filtered = {k: v for k, v in incoming_settings.items() if v}
            self.last_valid_settings.update(filtered)

        # 🚀 2. 메모리와 현재 데이터를 합칩니다.
        final_settings = {**self.last_valid_settings, **incoming_settings}
        
        exe_path = final_settings.get("exe_path")
        
        # 🚀 3. [표준화] 멀티액션의 #데이터(command)가 있다면 그것을 스크립트 경로로 우선 사용합니다.
        # 이렇게 하면 멀티액션에서 특정 JSX 파일을 직접 지정해서 실행할 수 있습니다.
        script_path = final_settings.get("command") or final_settings.get("script_path")

        if not exe_path or not os.path.exists(exe_path):
            print(f"[{self.uuid}] 실행 프로그램 경로가 올바르지 않습니다: '{exe_path}'")
            return
            
        if not script_path or not os.path.exists(script_path):
            print(f"[{self.uuid}] 스크립트 경로가 올바르지 않습니다: '{script_path}'")
            return

        # subprocess 실행 (비동기 처리를 위해 스레드 분리)
        creationflags = 0
        if sys.platform == "win32":
            creationflags = subprocess.CREATE_NO_WINDOW
            
        print(f"[{self.uuid}] 실행 중: {os.path.basename(exe_path)} + {os.path.basename(script_path)}")
        await asyncio.to_thread(subprocess.run, [exe_path, script_path], creationflags=creationflags)

    async def on_pi_request(self, data):
        context = data.get("context")
        payload = data.get("payload", {})
        command = payload.get("command")

        if command == "getDefaultPath":
            action_id = payload.get("actionId", "")
            exe_name = "Photoshop.exe" if 'photoshop' in action_id else "Illustrator.exe" if 'illustrator' in action_id else None
            
            if exe_name:
                found_path = self._find_adobe_path(exe_name)
                if found_path:
                    await self.runner.send_message({
                        "event": "sendToPropertyInspector",
                        "context": context,
                        "payload": {"command": "defaultPathFound", "path": found_path}
                    })

    def _find_adobe_path(self, exe_name):
        if sys.platform != "win32": return None
        app_paths_key = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"
        for hkey in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
            try:
                key = winreg.OpenKey(hkey, os.path.join(app_paths_key, exe_name))
                path, _ = winreg.QueryValueEx(key, None)
                winreg.CloseKey(key)
                return path
            except FileNotFoundError: continue
        return None