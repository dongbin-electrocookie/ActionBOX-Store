"""Stdlib-only Windows layout UI / macOS native-worker supervisor.

The owning runner supplies commands on stdin. EOF, explicit quit, or owner exit
stops the worker. Importing this file does not open windows or start a process.
"""
import argparse
import ctypes
import json
import os
import queue
import subprocess
import sys
import tempfile
import threading
import time


def zones(name):
    r = lambda x, y, w, h: (x, y, w, h)
    grid = lambda columns, rows: [r(x / columns, y / rows, 1 / columns, 1 / rows)
                                 for y in range(rows) for x in range(columns)]
    return {
        "halves": [r(0, 0, .5, 1), r(.5, 0, .5, 1)],
        "thirds": grid(3, 1), "rows": grid(1, 2), "quarters": grid(2, 2),
        "wide-center": [r(0, 0, .25, 1), r(.25, 0, .5, 1), r(.75, 0, .25, 1)],
        "left-main": [r(0, 0, .65, 1), r(.65, 0, .35, .5), r(.65, .5, .35, .5)],
        "right-main": [r(0, 0, .35, .5), r(0, .5, .35, .5), r(.35, 0, .65, 1)],
        "six": grid(3, 2), "nine": grid(3, 3),
        "focus": [r(0, 0, .2, 1), r(.2, 0, .6, 1), r(.8, 0, .2, 1)],
    }.get(name, [r(0, 0, .5, 1), r(.5, 0, .5, 1)])


def pixel_zones(area, name):
    x, y, width, height = area
    return [(x + round(width * zx) + 5, y + round(height * zy) + 5,
             max(40, round(width * zw) - 10), max(40, round(height * zh) - 10))
            for zx, zy, zw, zh in zones(name)]


class Owner:
    def __init__(self, pid, direct=True):
        self.pid, self.handle = pid, None
        self.direct = direct
        if sys.platform == "win32":
            from ctypes import wintypes as w
            self.kernel = ctypes.WinDLL("kernel32", use_last_error=True)
            self.kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
            self.kernel.OpenProcess.restype = w.HANDLE
            self.kernel.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]
            self.kernel.CloseHandle.argtypes = [w.HANDLE]
            self.handle = self.kernel.OpenProcess(0x100000, False, pid)

    def alive(self):
        if sys.platform == "win32":
            return bool(self.handle) and self.kernel.WaitForSingleObject(self.handle, 0) == 258
        if self.direct:
            return os.getppid() == self.pid
        try:
            os.kill(self.pid, 0)  # POSIX only; Windows uses the handle above.
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True

    def close(self):
        if self.handle:
            self.kernel.CloseHandle(self.handle)
            self.handle = None


def read_commands(commands):
    try:
        for line in sys.stdin:
            try:
                data = json.loads(line)
                if isinstance(data, dict):
                    commands.put(data)
            except (ValueError, TypeError):
                continue
    finally:
        commands.put({"quit": True})


class MacWorker:
    def __init__(self, helper):
        self.helper, self.process, self.layout = helper, None, None
        self.hold_file = os.path.join(tempfile.gettempdir(), "com.cookie.hpdisplayquicksettings.layout_hold")

    def command(self, data):
        layout = data.get("layout", "halves")
        if layout not in LAYOUTS:
            layout = "halves"
        if data.get("active"):
            with open(self.hold_file, "w", encoding="utf-8") as stream:
                stream.write(f"{layout}|alt_f17|{time.time() + 15:.3f}")
        else:
            self._clear_hold()
        if data.get("active") or data.get("preview"):
            if self.process is None or self.process.poll() is not None or layout != self.layout:
                self.close_child()
                self.process = subprocess.Popen(
                    [self.helper, layout, "alt_f17"], cwd=os.getcwd(), close_fds=True,
                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.layout = layout

    def tick(self):
        pass

    def _clear_hold(self):
        try:
            os.remove(self.hold_file)
        except FileNotFoundError:
            pass

    def close_child(self):
        if self.process is not None:
            pid = self.process.pid
            if self.process.poll() is None:
                self.process.terminate()
                try:
                    self.process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait(timeout=2)
            self.process = None
            if sys.platform == "darwin":
                record = "/tmp/com.cookie.hpdisplayquicksettings.layout.pid"
                try:
                    if (not os.path.islink(record) and os.stat(record).st_uid == os.getuid()):
                        with open(record, encoding="utf-8") as stream:
                            matches = stream.read().strip() == str(pid)
                        if matches:
                            os.remove(record)
                except FileNotFoundError:
                    pass

    def close(self):
        try:
            self._clear_hold()
        finally:
            self.close_child()


LAYOUTS = ("halves", "thirds", "wide-center", "rows", "quarters",
           "left-main", "right-main", "six", "nine", "focus")


class WindowsWorker:
    def __init__(self):
        from ctypes import wintypes as w
        self.w = w
        self.user = ctypes.WinDLL("user32", use_last_error=True)
        self.gdi = ctypes.WinDLL("gdi32", use_last_error=True)
        self.kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        ptr = ctypes.c_ssize_t
        self.callback_type = ctypes.WINFUNCTYPE(ptr, w.HWND, w.UINT, w.WPARAM, w.LPARAM)
        class WNDCLASS(ctypes.Structure):
            _fields_ = [("style", w.UINT), ("proc", self.callback_type), ("clsExtra", ctypes.c_int),
                        ("wndExtra", ctypes.c_int), ("instance", w.HINSTANCE), ("icon", w.HICON),
                        ("cursor", w.HANDLE), ("brush", w.HBRUSH), ("menu", w.LPCWSTR), ("name", w.LPCWSTR)]
        class PAINTSTRUCT(ctypes.Structure):
            _fields_ = [("dc", w.HDC), ("erase", w.BOOL), ("rect", w.RECT),
                        ("restore", w.BOOL), ("update", w.BOOL), ("reserved", ctypes.c_byte * 32)]
        class MONITORINFO(ctypes.Structure):
            _fields_ = [("size", w.DWORD), ("monitor", w.RECT), ("work", w.RECT), ("flags", w.DWORD)]
        self.Paint, self.MonitorInfo = PAINTSTRUCT, MONITORINFO
        signatures = {
            "GetForegroundWindow": ([], w.HWND), "GetCursorPos": ([ctypes.POINTER(w.POINT)], w.BOOL),
            "GetAsyncKeyState": ([ctypes.c_int], ctypes.c_short),
            "IsWindowVisible": ([w.HWND], w.BOOL), "IsIconic": ([w.HWND], w.BOOL),
            "IsZoomed": ([w.HWND], w.BOOL), "ShowWindow": ([w.HWND, ctypes.c_int], w.BOOL),
            "MoveWindow": ([w.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, w.BOOL], w.BOOL),
            "MonitorFromPoint": ([w.POINT, w.DWORD], w.HANDLE),
            "GetMonitorInfoW": ([w.HANDLE, ctypes.POINTER(MONITORINFO)], w.BOOL),
            "DefWindowProcW": ([w.HWND, w.UINT, w.WPARAM, w.LPARAM], ptr),
            "RegisterClassW": ([ctypes.POINTER(WNDCLASS)], w.ATOM),
            "CreateWindowExW": ([w.DWORD, w.LPCWSTR, w.LPCWSTR, w.DWORD, ctypes.c_int, ctypes.c_int,
                                ctypes.c_int, ctypes.c_int, w.HWND, w.HMENU, w.HINSTANCE, w.LPVOID], w.HWND),
            "SetWindowPos": ([w.HWND, w.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, w.UINT], w.BOOL),
            "SetLayeredWindowAttributes": ([w.HWND, w.DWORD, w.BYTE, w.DWORD], w.BOOL),
            "GetWindow": ([w.HWND, w.UINT], w.HWND),
            "GetWindowLongPtrW": ([w.HWND, ctypes.c_int], ptr),
            "InvalidateRect": ([w.HWND, ctypes.POINTER(w.RECT), w.BOOL], w.BOOL),
            "BeginPaint": ([w.HWND, ctypes.POINTER(PAINTSTRUCT)], w.HDC),
            "EndPaint": ([w.HWND, ctypes.POINTER(PAINTSTRUCT)], w.BOOL),
            "FillRect": ([w.HDC, ctypes.POINTER(w.RECT), w.HBRUSH], ctypes.c_int),
            "FrameRect": ([w.HDC, ctypes.POINTER(w.RECT), w.HBRUSH], ctypes.c_int),
            "PeekMessageW": ([ctypes.POINTER(w.MSG), w.HWND, w.UINT, w.UINT, w.UINT], w.BOOL),
            "TranslateMessage": ([ctypes.POINTER(w.MSG)], w.BOOL),
            "DispatchMessageW": ([ctypes.POINTER(w.MSG)], ptr),
            "DestroyWindow": ([w.HWND], w.BOOL),
            "UnregisterClassW": ([w.LPCWSTR, w.HINSTANCE], w.BOOL),
        }
        for name, (args, result) in signatures.items():
            function = getattr(self.user, name)
            function.argtypes, function.restype = args, result
        self.gdi.CreateSolidBrush.argtypes, self.gdi.CreateSolidBrush.restype = [w.DWORD], w.HBRUSH
        self.gdi.DeleteObject.argtypes = [w.HANDLE]
        self.gdi.CreateCompatibleDC.argtypes, self.gdi.CreateCompatibleDC.restype = [w.HDC], w.HDC
        self.gdi.CreateCompatibleBitmap.argtypes = [w.HDC, ctypes.c_int, ctypes.c_int]
        self.gdi.CreateCompatibleBitmap.restype = w.HBITMAP
        self.gdi.SelectObject.argtypes, self.gdi.SelectObject.restype = [w.HDC, w.HANDLE], w.HANDLE
        self.gdi.DeleteDC.argtypes = [w.HDC]
        self.gdi.BitBlt.argtypes = [w.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                   w.HDC, ctypes.c_int, ctypes.c_int, w.DWORD]
        self.gdi.BitBlt.restype = w.BOOL
        self.kernel.GetModuleHandleW.argtypes, self.kernel.GetModuleHandleW.restype = [w.LPCWSTR], w.HINSTANCE
        try:
            self.user.SetProcessDpiAwarenessContext.argtypes = [ctypes.c_void_p]
            self.user.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        except AttributeError:
            pass
        self.layout, self.active, self.preview_until = "halves", False, 0
        self.gesture, self.mouse_was_down, self.modifier_was_down = False, False, False
        self.dragged, self.pending, self.hover = None, None, -1
        self.rects, self.area = [], (0, 0, 0, 0)
        self.overlay_visible = False
        self.overlay_area = None
        self.render_state = None
        self.callback = self.callback_type(self._wndproc)
        self.class_name = "ComboXHPLayoutPython" + str(os.getpid())
        self.instance = self.kernel.GetModuleHandleW(None)
        window_class = WNDCLASS(proc=self.callback, instance=self.instance, name=self.class_name)
        if not self.user.RegisterClassW(ctypes.byref(window_class)):
            raise ctypes.WinError(ctypes.get_last_error())
        # Layered, click-through, tool window, no activation. Never take focus.
        self.hwnd = self.user.CreateWindowExW(
            0x080800A8, self.class_name, "ComboX Window Layout", 0x80000000,
            0, 0, 0, 0, None, None, self.instance, None)
        if not self.hwnd:
            raise ctypes.WinError(ctypes.get_last_error())
        self.user.SetLayeredWindowAttributes(self.hwnd, 0, 184, 2)

    def _wndproc(self, hwnd, message, wp, lp):
        if message == 0x84:
            return -1  # HTTRANSPARENT
        if message == 0x21:
            return 3  # MA_NOACTIVATE
        if message == 0x14:
            return 1  # WM_ERASEBKGND: the buffered frame covers the client area.
        if message == 0x0F:
            paint = self.Paint()
            dc = self.user.BeginPaint(hwnd, ctypes.byref(paint))
            try:
                self._paint_buffered(dc)
            finally:
                self.user.EndPaint(hwnd, ctypes.byref(paint))
            return 0
        return self.user.DefWindowProcW(hwnd, message, wp, lp)

    def _paint_buffered(self, dc):
        x, y, width, height = self.area
        if width <= 0 or height <= 0:
            return
        buffer = self.gdi.CreateCompatibleDC(dc)
        bitmap = self.gdi.CreateCompatibleBitmap(dc, width, height)
        if not buffer or not bitmap:
            if bitmap:
                self.gdi.DeleteObject(bitmap)
            if buffer:
                self.gdi.DeleteDC(buffer)
            raise ctypes.WinError(ctypes.get_last_error())
        old_bitmap = self.gdi.SelectObject(buffer, bitmap)
        try:
            self._fill(buffer, (0, 0, width, height), (20, 25, 36))
            for index, (rx, ry, rw, rh) in enumerate(self.rects):
                local = (rx - x, ry - y, rw, rh)
                self._fill(buffer, local, (65, 125, 255) if index == self.hover else (55, 95, 175))
                self._fill(buffer, local, (155, 185, 255), frame=True)
            self.gdi.BitBlt(dc, 0, 0, width, height, buffer, 0, 0, 0x00CC0020)
        finally:
            self.gdi.SelectObject(buffer, old_bitmap)
            self.gdi.DeleteObject(bitmap)
            self.gdi.DeleteDC(buffer)

    def _fill(self, dc, rect, rgb, frame=False):
        x, y, width, height = rect
        native = self.w.RECT(x, y, x + width, y + height)
        brush = self.gdi.CreateSolidBrush(rgb[0] | rgb[1] << 8 | rgb[2] << 16)
        try:
            (self.user.FrameRect if frame else self.user.FillRect)(dc, ctypes.byref(native), brush)
        finally:
            self.gdi.DeleteObject(brush)

    def command(self, data):
        self.layout = data.get("layout") if data.get("layout") in LAYOUTS else "halves"
        self.active = bool(data.get("active"))
        self.preview_until = time.monotonic() + 1.6 if data.get("preview") else 0

    def _hide(self):
        if self.overlay_visible:
            self.user.ShowWindow(self.hwnd, 0)
            self.overlay_visible = False
        self.hover = -1

    def _present(self, area, rects, hover):
        changed = (tuple(area), tuple(rects), hover)
        showing = not self.overlay_visible
        self.area, self.rects, self.hover = area, rects, hover
        if showing or self.overlay_area != area:
            self.user.SetWindowPos(self.hwnd, self.w.HWND(-1), *area, 0x10 | 0x40)
            self.overlay_area = area
            self.overlay_visible = True
        else:
            # Preserve the topmost band and repair occlusion without moving or
            # resizing the overlay during a window drag.
            above = self.user.GetWindow(self.hwnd, 3)
            for _ in range(64):
                if not above or self.user.IsWindowVisible(above):
                    break
                above = self.user.GetWindow(above, 3)
            if (not self.user.GetWindowLongPtrW(self.hwnd, -20) & 0x8
                    or (above and self.user.IsWindowVisible(above))):
                self.user.SetWindowPos(self.hwnd, self.w.HWND(-1), 0, 0, 0, 0,
                                       0x10 | 0x1 | 0x2)
        if showing or self.render_state != changed:
            self.user.InvalidateRect(self.hwnd, None, False)
            self.render_state = changed

    def tick(self):
        message = self.w.MSG()
        while self.user.PeekMessageW(ctypes.byref(message), None, 0, 0, 1):
            self.user.TranslateMessage(ctypes.byref(message))
            self.user.DispatchMessageW(ctypes.byref(message))
        now = time.monotonic()
        if self.pending and now >= self.pending[2]:
            window, rect, _ = self.pending
            if self.user.IsIconic(window) or self.user.IsZoomed(window):
                self.user.ShowWindow(window, 9)
            self.user.MoveWindow(window, *rect, True)
            self.pending = None
        cursor = self.w.POINT()
        self.user.GetCursorPos(ctypes.byref(cursor))
        down = lambda key: bool(self.user.GetAsyncKeyState(key) & 0x8000)
        mouse = down(1)
        modifier = self.active or (down(0xA5) and down(0x80))
        preview = now < self.preview_until
        if self.modifier_was_down and not modifier:
            self.gesture, self.dragged, self.preview_until, preview = False, None, 0, False
            self._hide()
        if mouse and modifier and (not self.mouse_was_down or not self.modifier_was_down) and not self.gesture:
            candidate = self.user.GetForegroundWindow()
            if candidate and candidate != self.hwnd and self.user.IsWindowVisible(candidate):
                self.dragged, self.gesture = candidate, True
        monitor = self.MonitorInfo()
        monitor.size = ctypes.sizeof(monitor)
        self.user.GetMonitorInfoW(self.user.MonitorFromPoint(cursor, 2), ctypes.byref(monitor))
        area = monitor.work
        self.area = (area.left, area.top, area.right - area.left, area.bottom - area.top)
        if (self.gesture and mouse) or preview:
            rects = pixel_zones(self.area, self.layout)
            hover = next((i for i, (x, y, w, h) in enumerate(rects)
                               if self.gesture and mouse and x <= cursor.x < x + w and y <= cursor.y < y + h), -1)
            self._present(self.area, rects, hover)
        if not mouse and self.gesture:
            if self.dragged and self.hover >= 0:
                rects = pixel_zones(self.area, self.layout)
                self.pending = (self.dragged, rects[self.hover], now + .08)
            self.gesture, self.dragged = False, None
            self._hide()
        elif not self.gesture and not preview:
            self._hide()
        self.mouse_was_down, self.modifier_was_down = mouse, modifier

    def close(self):
        self.user.DestroyWindow(self.hwnd)
        self.user.UnregisterClassW(self.class_name, self.instance)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent-pid", type=int, required=True)
    parser.add_argument("--app-pid", type=int, default=0)
    parser.add_argument("--mac-helper")
    parser.add_argument("--headless", action="store_true", help="Lifecycle test: never create an overlay")
    parser.add_argument("--check-ui", action="store_true", help="Create and destroy a hidden overlay, then exit")
    args = parser.parse_args()
    commands, owner = queue.Queue(), Owner(args.parent_pid)
    app_owner = Owner(args.app_pid, direct=False) if args.app_pid > 1 else None
    threading.Thread(target=read_commands, args=(commands,), daemon=True).start()
    worker = None
    try:
        if not args.headless:
            worker = MacWorker(args.mac_helper) if args.mac_helper else WindowsWorker()
        if args.check_ui:
            return
        while owner.alive() and (app_owner is None or app_owner.alive()):
            try:
                data = commands.get(timeout=.025)
                if data.get("quit"):
                    break
                if worker:
                    worker.command(data)
            except queue.Empty:
                pass
            if worker:
                worker.tick()
    finally:
        try:
            if worker:
                worker.close()
        finally:
            owner.close()
            if app_owner:
                app_owner.close()


if __name__ == "__main__":
    main()
