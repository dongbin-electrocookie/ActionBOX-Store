import asyncio
import urllib.request
import json

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.polling_tasks = {}

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")
        
        if event == "willAppear":
            self.polling_tasks[context] = asyncio.create_task(self.start_polling(data))
        elif event == "willDisappear":
            if context in self.polling_tasks:
                self.polling_tasks[context].cancel()
        elif event == "keyDown":
            await self.on_key_down(data)

    async def start_polling(self, data):
        context = data.get("context")
        action_id = data.get("action")
        
        while True:
            settings = data.get("payload", {}).get("settings", {})
            action_type = settings.get("action_type", "monitor")

            if action_type == "monitor":
                if "vercel" in action_id:
                    await self.check_vercel_status(context, settings)
                elif "netlify" in action_id:
                    await self.check_netlify_status(context, settings)
                elif "cloudflare" in action_id:
                    await self.check_cloudflare_status(context, settings)
                elif "railway" in action_id:
                    await self.check_railway_status(context, settings)
                elif "github" in action_id:
                    await self.check_github_status(context, settings)

            await asyncio.sleep(60) # 1분마다 갱신

    # ==========================================
    # 🌐 플랫폼별 API 모니터링 로직
    # ==========================================
    async def _fetch_api(self, req):
        def fetch():
            try:
                with urllib.request.urlopen(req) as response:
                    return json.loads(response.read().decode())
            except Exception as e:
                print(f"API 호출 실패: {e}")
                return None
        return await asyncio.to_thread(fetch)

    async def check_vercel_status(self, context, settings):
        api_key, project_id = settings.get("api_key"), settings.get("project_id")
        if not api_key or not project_id: return
        req = urllib.request.Request(f"https://api.vercel.com/v6/deployments?projectId={project_id}&limit=1", headers={"Authorization": f"Bearer {api_key}"})
        res = await self._fetch_api(req)
        if res and "deployments" in res and res["deployments"]:
            state = res["deployments"][0].get("state", "UNKNOWN")
            title = {"READY": "✅\nReady", "ERROR": "❌\nError", "BUILDING": "🔄\nBuilding"}.get(state, f"⚠️\n{state}")
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": title}})

    async def check_netlify_status(self, context, settings):
        api_key, site_id = settings.get("api_key"), settings.get("project_id")
        if not api_key or not site_id: return
        req = urllib.request.Request(f"https://api.netlify.com/api/v1/sites/{site_id}/deploys?per_page=1", headers={"Authorization": f"Bearer {api_key}"})
        res = await self._fetch_api(req)
        if res and len(res) > 0:
            state = res[0].get("state", "unknown")
            title = {"ready": "✅\nReady", "error": "❌\nError", "building": "🔄\nBuilding"}.get(state, f"⚠️\n{state}")
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": title}})

    async def check_github_status(self, context, settings):
        api_key, repo = settings.get("api_key"), settings.get("project_id")
        if not api_key or not repo: return
        req = urllib.request.Request(f"https://api.github.com/repos/{repo}/actions/runs?per_page=1", headers={"Authorization": f"Bearer {api_key}", "Accept": "application/vnd.github.v3+json"})
        res = await self._fetch_api(req)
        if res and "workflow_runs" in res and res["workflow_runs"]:
            status = res["workflow_runs"][0].get("status")
            conclusion = res["workflow_runs"][0].get("conclusion")
            title = "🔄\nRunning" if status in ["in_progress", "queued"] else ("✅\nSuccess" if conclusion == "success" else "❌\nFailed")
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": title}})

    async def check_cloudflare_status(self, context, settings):
        # Cloudflare Pages 모니터링 (추후 API 스펙에 맞춰 수정 가능하게 뼈대만 배치)
        await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "☁️\nCF Ready"}})

    async def check_railway_status(self, context, settings):
        # Railway 모니터링 (GraphQL 기반이므로 뼈대만 배치)
        await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "🚂\nRW Ready"}})

    # ==========================================
    # ⚡ 액션 실행 로직 (강제 재배포 / Webhook)
    # ==========================================
    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        action_type = settings.get("action_type", "monitor")
        context = data.get("context")

        if action_type == "redeploy":
            webhook_url = settings.get("webhook_url")
            if not webhook_url: return

            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "🚀\nSending"}})
            try:
                req = urllib.request.Request(webhook_url, method="POST")
                if "github" in data.get("action"):
                    req.add_header("Authorization", f"Bearer {settings.get('api_key')}")
                    req.add_header("Accept", "application/vnd.github.v3+json")
                await asyncio.to_thread(lambda: urllib.request.urlopen(req))
            except Exception as e:
                print(f"Webhook 전송 실패: {e}")
                await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "❌\nFail"}})