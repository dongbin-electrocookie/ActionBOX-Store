import asyncio
import os
import subprocess
import sys
import glob

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

if IS_WINDOWS:
    import winreg

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.last_valid_settings = {}

        self.action_to_exe = {
            "photoshop": "Photoshop.exe",
            "illustrator": "Illustrator.exe",
            "aftereffects": "AfterFX.exe",
            "premiere": "Adobe Premiere Pro.exe",
            "indesign": "InDesign.exe",
        }

        self.action_to_macos_app_patterns = {
            "photoshop": ["/Applications/Adobe Photoshop*/Adobe Photoshop*.app"],
            "illustrator": ["/Applications/Adobe Illustrator*/Adobe Illustrator*.app"],
            "aftereffects": ["/Applications/Adobe After Effects*/Adobe After Effects*.app"],
            "premiere": ["/Applications/Adobe Premiere Pro*/Adobe Premiere Pro*.app"],
            "indesign": ["/Applications/Adobe InDesign*/Adobe InDesign*.app"],
        }

        self.action_to_icon = {
            "photoshop": "APP_PHOTOSHOP",
            "illustrator": "APP_ILLUSTRATOR",
            "aftereffects": "APP_AFTEREFFECTS",
            "premiere": "APP_PREMIERE",
            "indesign": "APP_INDESIGN",
        }

    def _get_action_key(self, action_id: str) -> str:
        action_id = (action_id or "").lower()
        for key in self.action_to_exe.keys():
            if key in action_id:
                return key
        return "photoshop"

    def _get_icon_path(self, action_id: str) -> str:
        action_key = self._get_action_key(action_id)
        icon_name = self.action_to_icon.get(action_key, "APP_PHOTOSHOP")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id):
        icon_path = self._get_icon_path(action_id)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "exe_path", "script_path", "command", "builtin_icon_name",
            "default_visuals_initialized", "sync_title_on_script_change", "title"
        ])
        if meaningful:
            return

        action_key = self._get_action_key(action_id)
        new_settings = {
            "exe_path": "",
            "script_path": "",
            "command": "",
            "action_id": action_id or "",
            "_lang": "en",
            "sync_title_on_script_change": False,
            "builtin_icon_name": self.action_to_icon.get(action_key, "APP_PHOTOSHOP"),
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        # Initial placement: icon only, never overwrite title
        await self._send_builtin_icon(context, action_id)

    async def handle_message(self, data):
        event = data.get("event")
        action_id = data.get("action", "")
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if event == "keyDown":
            await self.on_key_down(data)
        elif event == "sendToPlugin":
            await self.on_pi_request(data)

    async def on_key_down(self, data):
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}

        if incoming_settings:
            filtered = {k: v for k, v in incoming_settings.items() if v not in ("", None)}
            self.last_valid_settings.update(filtered)

        final_settings = {**self.last_valid_settings, **incoming_settings}

        exe_path = final_settings.get("exe_path")
        script_path = final_settings.get("command") or final_settings.get("script_path")

        if not exe_path or not os.path.exists(exe_path):
            print(f"[{self.uuid}] Invalid executable path: '{exe_path}'")
            return

        if not script_path or not os.path.exists(script_path):
            print(f"[{self.uuid}] Invalid script path: '{script_path}'")
            return

        print(f"[{self.uuid}] Running: {os.path.basename(exe_path)} + {os.path.basename(script_path)}")
        await asyncio.to_thread(self._run_script_sync, exe_path, script_path)

    async def on_pi_request(self, data):
        context = data.get("context")
        action_id = data.get("action", "")
        payload = data.get("payload", {}) or {}
        command = payload.get("command")

        if command == "getDefaultPath":
            action_id_for_lookup = payload.get("actionId") or action_id or ""
            exe_name = None
            for key, value in self.action_to_exe.items():
                if key in action_id_for_lookup.lower():
                    exe_name = value
                    break

            if exe_name:
                found_path = self._find_adobe_path(exe_name)
                if found_path:
                    await self.runner.send_message({
                        "event": "sendToPropertyInspector",
                        "context": context,
                        "payload": {"command": "defaultPathFound", "path": found_path}
                    })

        elif command == "apply_builtin_icon":
            action_id_for_icon = payload.get("actionId") or action_id or ""
            await self._send_builtin_icon(context, action_id_for_icon)

    def _run_script_sync(self, exe_path, script_path):
        if IS_MACOS:
            # Adobe macOS apps are usually .app bundles, not executable files.
            # The most compatible lightweight launch method is to ask LaunchServices
            # to open the script file with the selected Adobe app.
            try:
                if exe_path.lower().endswith(".app") or os.path.isdir(exe_path):
                    return subprocess.run(["open", "-a", exe_path, script_path], check=False)
                return subprocess.run([exe_path, script_path], check=False)
            except Exception as e:
                print(f"[{self.uuid}] macOS open failed: {e}")
                return None

        creationflags = subprocess.CREATE_NO_WINDOW if IS_WINDOWS else 0
        return subprocess.run([exe_path, script_path], creationflags=creationflags, check=False)

    def _find_adobe_path(self, exe_name):
        if IS_MACOS:
            action_key = None
            for key, value in self.action_to_exe.items():
                if value == exe_name:
                    action_key = key
                    break

            for pattern in self.action_to_macos_app_patterns.get(action_key, []):
                candidates = sorted(glob.glob(pattern), reverse=True)
                for path in candidates:
                    if os.path.exists(path):
                        return path
            return None

        if not IS_WINDOWS:
            return None

        app_paths_key = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"
        for hkey in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
            try:
                key = winreg.OpenKey(hkey, os.path.join(app_paths_key, exe_name))
                path, _ = winreg.QueryValueEx(key, None)
                winreg.CloseKey(key)
                return path
            except FileNotFoundError:
                continue
        return None
