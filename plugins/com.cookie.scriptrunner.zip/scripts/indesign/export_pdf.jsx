#target indesign
(function () {
    if (app.documents.length === 0) {
        alert("Open a document first.");
        return;
    }
    var doc = app.activeDocument;
    var destination = File.saveDialog("Export PDF", "*.pdf");
    if (destination) {
        doc.exportFile(ExportFormat.PDF_TYPE, destination, true);
    }
}());
