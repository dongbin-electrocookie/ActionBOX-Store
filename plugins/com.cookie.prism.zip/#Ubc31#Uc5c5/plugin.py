import asyncio, base64, hashlib, json, os, sys, time, traceback
from pathlib import Path
import websockets

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

def get_user_data_dir():
    if IS_WINDOWS:
        base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Roaming")
    elif IS_MACOS:
        base = os.path.join(os.path.expanduser("~"), "Library", "Application Support")
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    path = os.path.join(base, "CookieDeck", "com_cookie_prism")
    os.makedirs(path, exist_ok=True)
    return path

class PRISMPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.prism"
        self.uri = "ws://localhost:8765"
        self.cd_ws = None
        self.obs_ws = None
        self.obs_connected = False
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.user_data_dir = get_user_data_dir()
        self.legacy_config_file = os.path.join(self.plugin_dir, "prism_config.json")
        self.config_file = os.path.join(self.user_data_dir, "prism_config.json")
        self.desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
        self.last_valid_settings = {}
        self.pending_requests = {}
        self.config = {"ip": "localhost", "port": 4455, "password": ""}
        self.load_config()
        self.scene_list_contexts = set()
        self.input_list_contexts = set()
        self.transition_list_contexts = set()
        self.cached_scenes = []
        self.cached_inputs = []
        self.cached_transitions = []
        self.post_connect_refresh_task = None

    def log(self, message):
        try: print(message, flush=True)
        except Exception: pass

    def load_config(self):
        source = self.config_file if os.path.exists(self.config_file) else self.legacy_config_file
        if os.path.exists(source):
            try:
                with open(source, "r", encoding="utf-8") as f:
                    self.config.update(json.load(f))
                if source == self.legacy_config_file and source != self.config_file:
                    self.save_config()
            except Exception as e:
                self.log(f"[PRISM] Config load error: {e}")

    def save_config(self):
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            self.log(f"[PRISM] Save config error: {e}")

    def is_obs_connected(self):
        return self.obs_ws is not None and self.obs_connected

    async def send_to_pi(self, context, payload):
        if not self.cd_ws or not context: return
        try:
            await self.cd_ws.send(json.dumps({"event":"sendToPropertyInspector","context":context,"payload":payload}))
        except Exception as e:
            self.log(f"[PRISM] sendToPI error: {e}")

    async def fetch_scene_list(self):
        if not self.is_obs_connected(): return self.cached_scenes
        res = await self.send_to_obs("GetSceneList")
        if self._response_ok(res): self.cached_scenes = self._response_data(res).get("scenes", [])
        return self.cached_scenes

    async def fetch_input_list(self):
        if not self.is_obs_connected(): return self.cached_inputs
        res = await self.send_to_obs("GetInputList")
        if self._response_ok(res): self.cached_inputs = self._response_data(res).get("inputs", [])
        return self.cached_inputs

    async def fetch_transition_list(self):
        if not self.is_obs_connected(): return self.cached_transitions
        res = await self.send_to_obs("GetSceneTransitionList")
        if self._response_ok(res): self.cached_transitions = self._response_data(res).get("transitions", [])
        return self.cached_transitions

    async def broadcast_scene_list(self):
        for context in list(self.scene_list_contexts):
            await self.send_to_pi(context, {"command":"sceneList","scenes":self.cached_scenes})

    async def broadcast_input_list(self):
        for context in list(self.input_list_contexts):
            await self.send_to_pi(context, {"command":"inputList","inputs":self.cached_inputs})

    async def broadcast_transition_list(self):
        for context in list(self.transition_list_contexts):
            await self.send_to_pi(context, {"command":"transitionList","transitions":self.cached_transitions})

    async def refresh_all_lists_and_broadcast(self):
        if not self.is_obs_connected(): return
        await self.fetch_scene_list()
        await self.fetch_input_list()
        await self.fetch_transition_list()
        await self.broadcast_scene_list()
        await self.broadcast_input_list()
        await self.broadcast_transition_list()
        self.log("[PRISM] Property Inspector lists refreshed after connect/reconnect")

    async def delayed_refresh_after_connect(self):
        for idx, delay in enumerate((0.8,1.5,3.0), start=1):
            await asyncio.sleep(delay)
            if not self.is_obs_connected(): return
            try:
                await self.refresh_all_lists_and_broadcast()
                self.log(f"[PRISM] Delayed auto-refresh pass {idx} completed")
            except Exception as e:
                self.log(f"[PRISM] Delayed auto-refresh pass {idx} failed: {e}")

    async def connect_to_obs(self):
        while True:
            try:
                if self.obs_ws is not None:
                    try: await self.obs_ws.close()
                    except Exception: pass
                self.obs_ws = None
                self.obs_connected = False
                obs_uri = f"ws://{self.config['ip']}:{self.config['port']}"
                self.log(f"[PRISM] Connecting to PRISM Live Studio at {obs_uri}...")
                async with websockets.connect(obs_uri) as ws:
                    self.obs_ws = ws
                    hello_msg = json.loads(await ws.recv())
                    if hello_msg.get("op") != 0:
                        raise RuntimeError(f"Unexpected hello packet: {hello_msg}")
                    auth_data = hello_msg.get("d", {}).get("authentication")
                    identify_payload = {"op":1,"d":{"rpcVersion":1,"eventSubscriptions":0}}
                    if auth_data:
                        password = self.config.get("password", "")
                        if not password: raise RuntimeError("PRISM password is empty in prism_config.json")
                        secret = base64.b64encode(hashlib.sha256((password + auth_data["salt"]).encode("utf-8")).digest()).decode("utf-8")
                        auth_response = base64.b64encode(hashlib.sha256((secret + auth_data["challenge"]).encode("utf-8")).digest()).decode("utf-8")
                        identify_payload["d"]["authentication"] = auth_response
                    await ws.send(json.dumps(identify_payload))
                    identified_msg = json.loads(await ws.recv())
                    if identified_msg.get("op") != 2:
                        raise RuntimeError(f"PRISM identify/auth failed: {identified_msg}")
                    self.obs_connected = True
                    self.log("[PRISM] Successfully Connected & Authenticated!")
                    if self.post_connect_refresh_task and not self.post_connect_refresh_task.done():
                        self.post_connect_refresh_task.cancel()
                    self.post_connect_refresh_task = asyncio.create_task(self.delayed_refresh_after_connect())
                    async for message in ws:
                        try: msg_data = json.loads(message)
                        except Exception: continue
                        if msg_data.get("op") == 7:
                            req_id = msg_data.get("d", {}).get("requestId")
                            future = self.pending_requests.get(req_id)
                            if future and not future.done():
                                future.set_result(msg_data)
            except Exception as e:
                self.log(f"[PRISM] Connection Error: {e}")
            finally:
                self.obs_connected = False
                self.obs_ws = None
                if self.post_connect_refresh_task and not self.post_connect_refresh_task.done():
                    self.post_connect_refresh_task.cancel()
                self.post_connect_refresh_task = None
                for _, fut in list(self.pending_requests.items()):
                    if not fut.done(): fut.cancel()
                self.pending_requests.clear()
            await asyncio.sleep(5)

    async def send_to_obs(self, request_type, request_data=None, request_id=None):
        if not self.is_obs_connected():
            self.log(f"[PRISM] Not connected. Cannot send {request_type}")
            return None
        request_data = request_data or {}
        request_id = request_id or f"{request_type}-{time.time()}"
        payload = {"op":6,"d":{"requestType":request_type,"requestId":request_id,"requestData":request_data}}
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        self.pending_requests[request_id] = future
        try:
            await self.obs_ws.send(json.dumps(payload))
            response = await asyncio.wait_for(future, timeout=4.0)
            status = response.get("d", {}).get("requestStatus", {})
            if not status.get("result", False):
                self.log(f"[PRISM] Request failed: {request_type} code={status.get('code')} comment={status.get('comment')}")
            return response
        except asyncio.TimeoutError:
            self.log(f"[PRISM] Request Timeout: {request_type}")
            return None
        except asyncio.CancelledError:
            self.log(f"[PRISM] Request Cancelled: {request_type}")
            return None
        except Exception as e:
            self.log(f"[PRISM] Send Error: {request_type} -> {e}")
            self.obs_connected = False
            return None
        finally:
            self.pending_requests.pop(request_id, None)

    def _response_ok(self, response):
        return bool(response and response.get("d", {}).get("requestStatus", {}).get("result", False))

    def _response_data(self, response):
        return {} if not response else (response.get("d", {}).get("responseData", {}) or {})

    async def connect_to_cookiedeck(self):
        while True:
            try:
                self.log(f"[PRISM Plugin] Connecting to CookieDeck at {self.uri}...")
                async with websockets.connect(self.uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event":"register","uuid":self.PLUGIN_UUID}))
                    self.log("[PRISM Plugin] Registered to CookieDeck!")
                    async for message in ws:
                        await self.handle_message(json.loads(message))
            except Exception as e:
                self.log(f"[PRISM Plugin] Disconnected. Retrying... ({e})")
            finally:
                self.cd_ws = None
            await asyncio.sleep(3)

    async def handle_message(self, data):
        try:
            event = data.get("event")
            context = data.get("context")
            payload = data.get("payload", {}) or {}
            if event == "keyDidAppear":
                settings = payload.get("settings", {}) or {}
                if context and settings:
                    self.last_valid_settings[context] = settings
                return
            if event == "didReceiveSettings":
                settings = payload.get("settings", payload) or {}
                if context and settings:
                    self.last_valid_settings.setdefault(context, {}).update(settings)
                return
            if event == "keyDown":
                await self.on_key_down(data); return
            if event == "sendToPlugin":
                command = payload.get("command")
                if not command:
                    payload = payload.get("payload", {}) or {}
                    command = payload.get("command")
                if command in ("getPrismSettings","getObsSettings"):
                    await self.send_to_pi(context, {"command":"prismSettings","settings":self.config})
                elif command in ("setPrismSettings","setObsSettings"):
                    new_settings = payload.get("settings", {}) or {}
                    self.config.update(new_settings)
                    self.save_config()
                    try:
                        if self.obs_ws is not None: await self.obs_ws.close()
                    except Exception: pass
                    if self.cd_ws and context:
                        await self.cd_ws.send(json.dumps({"event":"closeSettings","key":context}))
                elif command == "getSceneList":
                    if context: self.scene_list_contexts.add(context)
                    if self.cached_scenes:
                        await self.send_to_pi(context, {"command":"sceneList","scenes":self.cached_scenes})
                    if self.is_obs_connected():
                        await self.fetch_scene_list()
                        await self.send_to_pi(context, {"command":"sceneList","scenes":self.cached_scenes})
                elif command == "getInputList":
                    if context: self.input_list_contexts.add(context)
                    if self.cached_inputs:
                        await self.send_to_pi(context, {"command":"inputList","inputs":self.cached_inputs})
                    if self.is_obs_connected():
                        await self.fetch_input_list()
                        await self.send_to_pi(context, {"command":"inputList","inputs":self.cached_inputs})
                elif command == "getTransitionList":
                    if context: self.transition_list_contexts.add(context)
                    if self.cached_transitions:
                        await self.send_to_pi(context, {"command":"transitionList","transitions":self.cached_transitions})
                    if self.is_obs_connected():
                        await self.fetch_transition_list()
                        await self.send_to_pi(context, {"command":"transitionList","transitions":self.cached_transitions})
        except Exception as e:
            self.log(f"[PRISM Plugin] Message Handling Error: {e}")
            self.log(traceback.format_exc())

    async def ensure_settings(self, context, payload):
        incoming_settings = payload.get("settings", {}) if isinstance(payload, dict) else {}
        if incoming_settings:
            self.last_valid_settings[context] = incoming_settings
        final_settings = self.last_valid_settings.get(context, {})
        if final_settings:
            return final_settings
        if self.cd_ws and context:
            await self.cd_ws.send(json.dumps({"event":"getSettings","context":context}))
            for _ in range(15):
                await asyncio.sleep(0.1)
                if self.last_valid_settings.get(context):
                    return self.last_valid_settings[context]
        return final_settings

    async def toggle_studio_mode(self):
        state_res = await self.send_to_obs("GetStudioModeEnabled")
        if not self._response_ok(state_res): return False
        enabled = bool(self._response_data(state_res).get("studioModeEnabled", False))
        set_res = await self.send_to_obs("SetStudioModeEnabled", {"studioModeEnabled": not enabled})
        return self._response_ok(set_res)

    async def toggle_scene_item(self, scene_name, source_name):
        item_res = await self.send_to_obs("GetSceneItemId", {"sceneName":scene_name,"sourceName":source_name})
        if not self._response_ok(item_res): return False
        scene_item_id = self._response_data(item_res).get("sceneItemId")
        if scene_item_id is None: return False
        enabled_res = await self.send_to_obs("GetSceneItemEnabled", {"sceneName":scene_name,"sceneItemId":scene_item_id})
        if not self._response_ok(enabled_res): return False
        current = bool(self._response_data(enabled_res).get("sceneItemEnabled", False))
        set_res = await self.send_to_obs("SetSceneItemEnabled", {"sceneName":scene_name,"sceneItemId":scene_item_id,"sceneItemEnabled":not current})
        return self._response_ok(set_res)

    async def media_play_pause(self, input_name):
        status_res = await self.send_to_obs("GetMediaInputStatus", {"inputName":input_name})
        if not self._response_ok(status_res): return False
        media_state = self._response_data(status_res).get("mediaState")
        action = "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_PAUSE" if media_state in ("OBS_MEDIA_STATE_PLAYING","OBS_MEDIA_STATE_OPENING","OBS_MEDIA_STATE_BUFFERING") else "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_PLAY"
        act_res = await self.send_to_obs("TriggerMediaInputAction", {"inputName":input_name,"mediaAction":action})
        return self._response_ok(act_res)

    async def screenshot_source(self, source_name):
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"OBS_{source_name}_{timestamp}.png".replace(" ", "_")
        save_path = os.path.join(self.desktop_path, filename).replace("\\\\", "/")
        res = await self.send_to_obs("SaveSourceScreenshot", {"sourceName":source_name,"imageFormat":"png","imageFilePath":save_path})
        return self._response_ok(res)

    async def on_key_down(self, data):
        context = data.get("context") or data.get("action")
        if not context: return
        payload = data.get("payload", {}) or {}
        final_settings = await self.ensure_settings(context, payload)
        obs_action = final_settings.get("command") or final_settings.get("obs_action")
        if not obs_action: return
        req_type, req_data = None, {}
        if obs_action == "stream_toggle": req_type = "ToggleStream"
        elif obs_action == "record_toggle": req_type = "ToggleRecord"
        elif obs_action == "virtual_cam_toggle": req_type = "ToggleVirtualCam"
        elif obs_action == "replay_buffer_toggle": req_type = "ToggleReplayBuffer"
        elif obs_action == "replay_buffer_save": req_type = "SaveReplayBuffer"
        elif obs_action == "record_chapter":
            req_type = "CreateRecordChapter"; req_data = {"chapterName":"CookieDeck Marker"}
        elif obs_action == "stream_marker":
            self.log("[PRISM] stream_marker is not supported in this build"); return
        elif obs_action == "studio_mode_toggle":
            await self.toggle_studio_mode(); return
        elif obs_action == "trigger_transition": req_type = "TriggerStudioModeTransition"
        elif obs_action == "set_transition":
            target_trans = final_settings.get("target_transition")
            if target_trans:
                req_type = "SetCurrentSceneTransition"; req_data = {"transitionName":target_trans}
        elif obs_action == "change_scene":
            target_sc = final_settings.get("target_scene") or final_settings.get("scene_name")
            if target_sc:
                req_type = "SetCurrentProgramScene"; req_data = {"sceneName":target_sc}
        elif obs_action == "toggle_source":
            target_nm = final_settings.get("target_name", "")
            parts = [p.strip() for p in target_nm.split(";",1)]
            if len(parts) == 2 and parts[0] and parts[1]:
                await self.toggle_scene_item(parts[0], parts[1]); return
        elif obs_action == "filter_control":
            src, flt = final_settings.get("target_input"), final_settings.get("filter_name")
            state = final_settings.get("enable_state","true") == "true"
            if src and flt:
                req_type = "SetSourceFilterEnabled"; req_data = {"sourceName":src,"filterName":flt,"filterEnabled":state}
        elif obs_action == "media_play_pause":
            inp = final_settings.get("target_input")
            if inp: await self.media_play_pause(inp); return
        elif obs_action == "media_restart":
            inp = final_settings.get("target_input")
            if inp:
                req_type = "TriggerMediaInputAction"; req_data = {"inputName":inp,"mediaAction":"OBS_WEBSOCKET_MEDIA_INPUT_ACTION_RESTART"}
        elif obs_action == "toggle_mute":
            inp = final_settings.get("target_input")
            if inp:
                req_type = "ToggleInputMute"; req_data = {"inputName":inp}
        elif obs_action == "screenshot_source":
            src = final_settings.get("target_input")
            if src:
                await self.screenshot_source(src); return
        if req_type:
            await self.send_to_obs(req_type, req_data, f"{obs_action}-{context}")

    async def start(self):
        asyncio.create_task(self.connect_to_obs())
        await self.connect_to_cookiedeck()

if __name__ == "__main__":
    plugin = PRISMPlugin()
    try:
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(plugin.start())
    except KeyboardInterrupt:
        print("[PRISM Plugin] Shutting down...", flush=True)
