import asyncio
import html
import json
import os
import re
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import urllib.error
import webbrowser
from pathlib import Path

try:
    import requests
    REQUESTS_AVAILABLE = True
except Exception:
    REQUESTS_AVAILABLE = False

try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except Exception:
    BS4_AVAILABLE = False

try:
    import pyperclip
    PYPERCLIP_AVAILABLE = True
except Exception:
    PYPERCLIP_AVAILABLE = False

try:
    from youtube_transcript_api import YouTubeTranscriptApi
    YT_TRANSCRIPT_AVAILABLE = True
except Exception:
    YT_TRANSCRIPT_AVAILABLE = False


IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

def _user_data_dir():
    """Return a writable per-user config directory for this plugin."""
    if IS_WINDOWS:
        base = os.environ.get("APPDATA") or os.path.expanduser(r"~\\AppData\\Roaming")
        path = os.path.join(base, "CookieDeck", "com_cookie_linksummary")
    elif IS_MACOS:
        path = os.path.expanduser("~/Library/Application Support/CookieDeck/com_cookie_linksummary")
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
        path = os.path.join(base, "CookieDeck", "com_cookie_linksummary")
    os.makedirs(path, exist_ok=True)
    return path


DEFAULT_MODEL = "gemini-3.1-flash-lite"
DEPRECATED_MODELS = {
    "gemini-3.1-flash-lite-preview",
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite",
}
SUPPORTED_LANGS = ["de", "en", "es", "fr", "it", "ja", "ko", "pt", "pt-PT", "ru"]
LANG_ALIASES = {"kr": "ko", "jp": "ja", "pt_BR": "pt", "pt-BR": "pt", "pt_PT": "pt-PT"}
LANGUAGE_NAMES = {"ko": "Korean", "en": "English", "ja": "Japanese", "de": "German", "es": "Spanish", "fr": "French", "it": "Italian", "pt": "Portuguese", "pt-PT": "Portuguese", "ru": "Russian"}

FALLBACK = {
    "URL_EMPTY": "URL is empty. Enter a URL or copy one to clipboard.",
    "API_KEY_EMPTY": "Gemini API Key is empty.",
    "POPUP_TITLE": "ActionBOX AI Link Summary",
}

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.default_icon_name = "ACTION_SUMMARY"
        self.user_data_dir = _user_data_dir()
        self.log_file = os.path.join(self.user_data_dir, "linksummary_debug_log.txt")
        self._migrate_legacy_files()

    def _migrate_legacy_files(self):
        """Copy old writable files out of the plugin directory when possible."""
        legacy_log = os.path.join(self.plugin_dir, "linksummary_debug_log.txt")
        if os.path.exists(legacy_log) and not os.path.exists(self.log_file):
            try:
                with open(legacy_log, "r", encoding="utf-8", errors="replace") as src:
                    data = src.read()
                with open(self.log_file, "w", encoding="utf-8") as dst:
                    dst.write(data)
            except Exception:
                pass

    def _log(self, msg):
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
        except Exception:
            pass

    def _normalize_lang(self, lang):
        raw = str(lang or "en")
        raw = LANG_ALIASES.get(raw, raw)
        if raw in SUPPORTED_LANGS:
            return raw
        short = raw.split("-")[0]
        return short if short in SUPPORTED_LANGS else "en"

    def _settings_lang(self, settings):
        return self._normalize_lang((settings or {}).get("_lang") or "en")

    def _load_locale_data(self, lang):
        lang = self._normalize_lang(lang)
        for path in [Path(self.plugin_dir) / "locales" / f"{lang}.json", Path(self.plugin_dir) / "locales" / "en.json"]:
            try:
                if path.exists():
                    return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
        return {}

    def _tr(self, key, lang="en"):
        return self._load_locale_data(lang).get(key) or FALLBACK.get(key) or key

    def _normalize_settings(self, settings):
        s = dict(settings or {})
        s.setdefault("gemini_api_key", "")
        s.setdefault("target_url", "")
        s.setdefault("gemini_model", DEFAULT_MODEL)
        s.setdefault("gemini_model_preset", DEFAULT_MODEL)
        s.setdefault("gemini_model_custom", "")
        if s.get("gemini_model") in DEPRECATED_MODELS:
            s["gemini_model"] = DEFAULT_MODEL
        if s.get("gemini_model_preset") in DEPRECATED_MODELS:
            s["gemini_model_preset"] = DEFAULT_MODEL
        if s.get("gemini_model_custom") in DEPRECATED_MODELS:
            s["gemini_model_custom"] = ""
        s.setdefault("summary_language", "auto")
        s.setdefault("summary_style", "three_lines")
        s.setdefault("open_popup", True)
        s.setdefault("_lang", "en")
        return s

    async def _set_title(self, context, title):
        if context:
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": title or ""}})

    async def _send_to_pi(self, context, payload):
        if context:
            await self.runner.send_message({"event": "sendToPropertyInspector", "context": context, "payload": payload or {}})

    async def _send_builtin_icon(self, context):
        icon_path = os.path.join(self.plugin_dir, "icon", "ACTION_SUMMARY.png")
        if context and os.path.exists(icon_path):
            await self.runner.send_message({"event": "setIcon", "context": context, "payload": {"icon_path": icon_path}})

    async def _initialize_default_visuals_if_new(self, context, settings):
        settings = dict(settings or {})
        if not settings.get("default_visuals_initialized"):
            new_settings = {
                **settings,
                "gemini_model": DEFAULT_MODEL,
                "gemini_model_preset": DEFAULT_MODEL,
                "summary_language": "auto",
                "summary_style": "three_lines",
                "open_popup": True,
                "builtin_icon_name": "ACTION_SUMMARY",
                "default_visuals_initialized": True
            }
            await self.runner.send_message({"event": "setSettings", "context": context, "payload": new_settings})
            await self._set_title(context, "AI\nSummary")
        await self._send_builtin_icon(context)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        command = data.get("command") or payload.get("command")
        context = data.get("context") or payload.get("context")
        settings = payload.get("settings") if isinstance(payload.get("settings"), dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return
        if command == "apply_builtin_icon":
            await self._send_builtin_icon(context)
            return
        if command == "test_summary":
            await self.run_summary(context, settings)
            return
        if event == "keyDown":
            await self.run_summary(context, data.get("payload", {}).get("settings", {}) or settings)

    def _get_clipboard_url(self):
        if not PYPERCLIP_AVAILABLE:
            return ""
        try:
            text = (pyperclip.paste() or "").strip()
            return text if re.match(r"^https?://", text, re.I) else ""
        except Exception:
            return ""

    def _extract_youtube_id(self, url):
        try:
            parsed = urllib.parse.urlparse(url)
            host = parsed.netloc.lower().replace("www.", "")
            if host == "youtu.be":
                return parsed.path.strip("/").split("/")[0]
            if "youtube.com" in host:
                query = urllib.parse.parse_qs(parsed.query)
                if query.get("v"):
                    return query["v"][0]
                match = re.search(r"/(shorts|embed|live)/([^/?#]+)", parsed.path)
                if match:
                    return match.group(2)
        except Exception:
            pass
        return ""

    def _fetch_youtube_transcript(self, video_id, lang):
        if not YT_TRANSCRIPT_AVAILABLE:
            raise RuntimeError("youtube-transcript-api is not installed. Install requirements.txt first.")

        preferred = [lang, lang.split("-")[0], "ko", "en", "ja", "de", "es", "fr", "it", "pt", "ru"]
        seen = []
        langs = []
        for item in preferred:
            if item and item not in seen:
                langs.append(item)
                seen.append(item)

        try:
            items = YouTubeTranscriptApi.get_transcript(video_id, languages=langs)
            return "\n".join([i.get("text", "") for i in items if i.get("text")]), "YouTube transcript"
        except Exception as first_error:
            try:
                transcript_list = YouTubeTranscriptApi.list_transcripts(video_id)
                try:
                    transcript = transcript_list.find_transcript(langs)
                except Exception:
                    try:
                        transcript = transcript_list.find_generated_transcript(langs)
                    except Exception:
                        transcript = next(iter(transcript_list))
                fetched = transcript.fetch()
                texts = []
                for item in fetched:
                    if isinstance(item, dict):
                        texts.append(item.get("text", ""))
                    else:
                        texts.append(getattr(item, "text", ""))
                return "\n".join([t for t in texts if t]), "YouTube transcript"
            except Exception:
                raise first_error

    def _fetch_youtube_metadata(self, url):
        if not REQUESTS_AVAILABLE:
            return "", "YouTube metadata fallback"
        title = ""
        desc = ""
        try:
            response = requests.get("https://www.youtube.com/oembed", params={"url": url, "format": "json"}, timeout=8)
            if response.ok:
                title = (response.json().get("title") or "").strip()
        except Exception:
            pass
        try:
            response = requests.get(url, timeout=10, headers={"User-Agent": "Mozilla/5.0"})
            if response.ok and BS4_AVAILABLE:
                soup = BeautifulSoup(response.text, "html.parser")
                meta = soup.find("meta", attrs={"name": "description"}) or soup.find("meta", property="og:description")
                if meta:
                    desc = (meta.get("content") or "").strip()
                if not title:
                    og_title = soup.find("meta", property="og:title")
                    title = ((og_title.get("content") if og_title else "") or (soup.title.string if soup.title else "") or "").strip()
        except Exception:
            pass
        return f"Title: {title}\nDescription: {desc}".strip(), "YouTube title/description fallback"

    def _fetch_webpage_text(self, url):
        if not REQUESTS_AVAILABLE or not BS4_AVAILABLE:
            raise RuntimeError("requests and beautifulsoup4 are required. Install requirements.txt first.")
        response = requests.get(url, timeout=12, headers={"User-Agent": "Mozilla/5.0"})
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        for tag in soup(["script", "style", "nav", "footer", "header", "aside", "noscript"]):
            tag.decompose()
        title = (soup.title.string.strip() if soup.title and soup.title.string else "")
        desc = ""
        meta = soup.find("meta", attrs={"name": "description"}) or soup.find("meta", property="og:description")
        if meta:
            desc = (meta.get("content") or "").strip()
        parts = [p.get_text(" ", strip=True) for p in soup.find_all(["h1", "h2", "h3", "p", "li"])]
        parts = [x for x in parts if len(x) > 20]
        return "\n".join([f"Title: {title}", f"Description: {desc}", "", *parts]), "webpage text"

    def _collect_source_text(self, url, lang):
        video_id = self._extract_youtube_id(url)
        if video_id:
            try:
                text, note = self._fetch_youtube_transcript(video_id, lang)
                if text.strip():
                    return text, note
            except Exception as e:
                self._log(f"youtube transcript fallback: {e}")
                metadata, note = self._fetch_youtube_metadata(url)
                if metadata.strip():
                    return metadata, note
                raise RuntimeError(f"Could not fetch YouTube transcript or metadata: {e}")
        return self._fetch_webpage_text(url)

    def _output_language_name(self, settings):
        selected = settings.get("summary_language") or "auto"
        if selected == "source":
            return "the same language as the source content"
        if selected == "auto":
            selected = self._settings_lang(settings)
        return LANGUAGE_NAMES.get(self._normalize_lang(selected), "English")

    def _build_prompt(self, source_text, source_note, url, settings):
        output_language = self._output_language_name(settings)
        style = settings.get("summary_style") or "three_lines"
        if style == "detailed":
            instruction = "Write a concise but slightly detailed summary with 5 to 7 bullet points."
        elif style == "worth":
            instruction = "Judge whether this is worth watching or reading. Give a score from 1 to 10, then summarize the key points."
        elif style == "actions":
            instruction = "Extract practical action items, steps, decisions, or checklist items. If none exist, say so clearly."
        else:
            instruction = "Summarize only the core points in 3 short lines."
        truncated = source_text[:70000]
        trunc_note = "\n\n[Note: Source text was truncated for length.]" if len(source_text) > len(truncated) else ""
        return f"""You are an assistant for ActionBOX. Summarize the following URL content for a user.

Output language: {output_language}
Source type: {source_note}
URL: {url}

Rules:
- {instruction}
- If the source is only title/description fallback, clearly mention that the summary is inferred from limited metadata.
- Do not invent details not supported by the source.
- Keep the answer useful and quick to read.

Source text:
{truncated}{trunc_note}
"""

    def _call_gemini(self, api_key, model, prompt):
        if not api_key.strip():
            raise RuntimeError("Gemini API Key is empty.")
        model = (model or DEFAULT_MODEL).strip()
        if model.startswith("models/"):
            model = model.split("/", 1)[1]
        endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(model)}:generateContent?key={urllib.parse.quote(api_key.strip())}"
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.2, "maxOutputTokens": 1200}
        }
        data = json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(endpoint, data=data, method="POST", headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(request, timeout=45) as response:
                obj = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Gemini API HTTP {e.code}: {body[:1200]}")
        parts = obj.get("candidates", [{}])[0].get("content", {}).get("parts", [])
        text = "".join([p.get("text", "") for p in parts])
        if not text.strip():
            raise RuntimeError("Gemini API returned an empty response.")
        return text.strip()

    def _open_popup(self, result_text, url, source_note):
        title = FALLBACK["POPUP_TITLE"]
        safe = html.escape(result_text).replace("\n", "<br>")
        doc = f"""<!doctype html><html><head><meta charset="utf-8"><title>{html.escape(title)}</title><style>body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;background:#0f172a;color:#e5e7eb;margin:0;padding:28px}}.card{{max-width:900px;margin:auto;background:#111827;border:1px solid #374151;border-radius:18px;padding:24px;box-shadow:0 15px 40px rgba(0,0,0,.35)}}h1{{margin-top:0;font-size:22px}}.meta{{color:#9ca3af;font-size:13px;margin-bottom:16px;word-break:break-all}}.body{{font-size:16px;line-height:1.65}}</style></head><body><div class="card"><h1>{html.escape(title)}</h1><div class="meta">{html.escape(source_note)}<br>{html.escape(url)}</div><div class="body">{safe}</div></div></body></html>"""
        path = Path(tempfile.gettempdir()) / f"actionbox_link_summary_{int(time.time())}.html"
        path.write_text(doc, encoding="utf-8")
        webbrowser.open(path.as_uri())

    async def run_summary(self, context, settings):
        settings = self._normalize_settings(settings)
        lang = self._settings_lang(settings)
        try:
            await self._set_title(context, "요약\n중...")
            api_key = settings.get("gemini_api_key", "").strip()
            if not api_key:
                raise RuntimeError(self._tr("API_KEY_EMPTY", lang))
            url = (settings.get("target_url") or "").strip() or self._get_clipboard_url()
            if not url:
                raise RuntimeError(self._tr("URL_EMPTY", lang))
            source_text, source_note = await asyncio.to_thread(self._collect_source_text, url, lang)
            prompt = self._build_prompt(source_text, source_note, url, settings)
            result = await asyncio.to_thread(self._call_gemini, api_key, settings.get("gemini_model"), prompt)
            await self._send_to_pi(context, {"command": "summary_result", "ok": True, "text": result, "url": url, "source_note": source_note})
            if settings.get("open_popup", True):
                await asyncio.to_thread(self._open_popup, result, url, source_note)
            await self._set_title(context, "요약\n완료")
        except Exception as e:
            self._log(f"summary error: {e}")
            await self._send_to_pi(context, {"command": "summary_result", "ok": False, "message": str(e)})
            await self._set_title(context, "요약\nError")
            await self._send_builtin_icon(context)
