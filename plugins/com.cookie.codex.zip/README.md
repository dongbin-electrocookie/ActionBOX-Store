# Codex for COMBO-X (v1.0.0)

The Codex plugin monitors Codex Desktop/CLI session state and provides Codex-specific voice and reasoning controls.

## Actions

- **Codex Status** — Idle, Thinking, Complete, Permission and Error artwork with matching status LED
- **Talk to Codex** — activates Codex and taps `globalDictationSingleTap` once per press; Codex starts/stops dictation itself
- The unpublished legacy **Codex Push to Talk** action uses `globalDictationHold` while pressed
- **Codex Reasoning Down / Up** — adjusts the focused Codex composer's reasoning effort
- **Approve / Reject** — activates Codex and sends `Enter` or `Esc`, respectively.

Existing Codex shortcuts are preserved. Missing voice/reasoning bindings are assigned an unused reserved chord and written atomically with a backup. Codex hooks are automatically installed or repaired; local rollout JSONL is also monitored as a read-only Desktop fallback.

macOS exception: **Talk to Codex** uses **Command+Option+Shift+I** as
requested. Only its `globalDictationSingleTap` binding is replaced (with a
backup); reasoning, approvals, Hold, and unrelated user bindings are preserved.
If another command already owns the same chord, setup reports the conflict
instead of overwriting it. The sole recovery exception is a legacy Hold/Toggle
entry on the exact requested chord that COMBO-X previously recorded as its managed
SingleTap binding: that colliding entry is explicitly cleared (with a backup)
before restoring SingleTap. Other Hold keys and unrelated conflicts are retained.
Windows retains its existing preserve-or-create flow.
The former Mac F14 SingleTap binding is replaced by the I chord; plain I typing
and other commands are unchanged. This allows direct physical-keyboard testing.
Mac dictation presses Option, Shift, Command, then I and releases in reverse
order (I, Command, Shift, Option). Only this action's emission order is changed;
the equivalent Command+Option+Shift+I binding does not need to be rewritten.
Mac Talk to Codex holds the chord for 150 ms before releasing it. Other tap
actions and Windows retain their 40 ms timing; key ordering/release code is unchanged.

On macOS, focus is handled directly from Python using AppKit, not AppleScript
or `osascript`. The active Codex/ChatGPT app is reused without a fixed delay;
otherwise the plugin requests activation and verifies the foreground process
directly through the macOS process API, not NSWorkspace's cached foreground
property (the asyncio plugin runner has no Cocoa main run loop).
A rejected/timed-out activation sends no keys and does not
fall back to AppleScript. The embedded Python must include PyObjC/Cocoa.

Status monitoring remembers completed turn IDs. Late tool callbacks cannot reopen
a completed, interrupted or ended turn, and callbacks for an older turn cannot
change the current one. A matching rollout completion is accepted even when a
tool hook arrived later; rollout record timestamps retain subsecond precision.
Completion fences are saved and restored across plugin restarts. There is no
inactivity timeout: silent, long-running work stays Thinking until an actual
lifecycle signal arrives. Recent-session mode follows recorded Codex chats.

On ComboX startup the Codex status starts Idle (white LED). Starts from earlier
logs do not restore Thinking, and completion callbacks without a start observed
in this runtime stay Idle. A new observed turn follows Thinking (blue) then
Complete (green). Completion fences survive restart, but the observed-start flag
is reset; historical completion can never earn the green LED on a fresh launch.

Automatic hook monitoring follows chats with a local rollout record. Codex's
ephemeral approvals_reviewer sessions also emit lifecycle hooks but are not user
chats and do not change the status key. Hooks arriving before a new chat's rollout
are retained for up to ten seconds, with a bounded queue, then discarded if no
recorded chat appears. No Codex database schema or private control API is used.
Periodic display retries do not resend an unchanged desktop preview or LED;
hardware-only animation continues, and frames loaded for an old state are dropped.

After updating the plugin, restart COMBO-X so it reads/prepares the current
dictation binding. Then fully quit and reopen Codex to register any newly added
global shortcut. On Windows, existing `globalDictationSingleTap` bindings take precedence;
the former `globalDictationToggle` name is reused only when Codex would normalize
it to SingleTap (a Hold entry exists and no explicit SingleTap entry). Existing user/global bindings and
reasoning shortcuts are never deleted. The retired `composer.startDictation`
binding is not used on current Windows/macOS builds. Window activation remains
in place; this does not guarantee composer text-field focus or microphone access.

Approve/Reject use fixed Enter/Esc keys and do not create or read Codex approval
command bindings. Existing saved shortcut fields are ignored for these actions.
The keys act on the currently focused control after Codex is activated.
Questionnaire/multiple-choice navigation remains outside these two actions.

The inspector shows hook installation as a red/green **Codex Hook** button,
with an equally sized **Remove Codex Hook** button alongside it.
Clicking it keeps the existing install/repair action and opens a localized
full-quit/restart notice. **Remove hooks** remains available; the manual status
refresh button and lower diagnostic/session details are no longer displayed.
Inspector labels and restart notices support English, Korean, Japanese, German,
Spanish, French, Italian, Portuguese and Russian. Installation status indicates
configuration presence, not whether Codex has trusted or executed the hooks.

Async question requests stay in Permission until an actual answer, cancellation,
or a new turn. Their immediate `accepted` result is not a user answer, and results
from other tools do not resolve the pending question. Normal command/file approvals
still use the `PermissionRequest` hook. Explicit app-server approval/resolution
records are also understood when exposed by the monitored log source; not every
Codex build writes those records to rollout JSONL.

Questions, choices and permission approvals share the existing Permission
animation and LED. A narrowly matched PreToolUse hook also observes questions
called inside code mode, even when the outer rollout only records the code
tool. Partial answers to a multi-question request keep Permission until all
question items are answered. Unrelated tool output cannot resolve another
request. Hook setup automatically repairs older configurations; after updating
the plugin, show its status action and fully quit/reopen Codex so it loads the
updated hooks. Existing Codex hook trust/security settings are never bypassed.

For approval compatibility tests, state-only diagnostics appear as
`[Codex Approval]` in the COMBO-X console and in `approval_trace.jsonl` inside this
plugin's user-data directory. The file is capped at 2 MiB and never includes
questions, answers or command arguments. Set `COMBOX_CODEX_APPROVAL_TRACE=0` to
disable these diagnostics. This monitoring never approves requests, changes
Codex security/trust settings or sends automatic replies.

The former `com.cookie.ai_monitor` action IDs are retained so existing COMBO-X button assignments continue working after the plugin split. Existing AI Monitor user data is copied into the new `com.cookie.codex` data directory on first run.


Permission display takes priority over Thinking while a detected question or
approval is still pending. This includes blocking/async question tools,
request_permissions and exposed app-server approval/user-input wait flags.
A newer unrelated tool hook or duplicate start for the same turn cannot hide
that pending request. Delayed requests/answers from the active turn are reconciled
by call ID without reopening a request already answered by a live hook.
A genuine new turn, interruption or matched resolution still clears the relevant
waiting state. Plain assistant prose has no structured question signal; arbitrary
sentences or question marks are not interpreted as approval requests.
