import asyncio
import sys
import os

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.media_map = {
            "play_pause": "play/pause media",
            "next": "next track",
            "prev": "previous track",
            "stop": "stop media",
            "vol_up": "volume up",
            "vol_down": "volume down",
            "mute": "volume mute"
        }

        self.icon_map = {
            "play_pause": "STATE_PLAY_PAUSE",
            "next": "STATE_NEXT",
            "prev": "STATE_PREV",
            "stop": "STATE_STOP",
            "vol_up": "STATE_VOL_UP",
            "vol_down": "STATE_VOL_DOWN",
            "mute": "STATE_MUTE"
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "play_pause", "STATE_PLAY_PAUSE")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if context and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "command", "media_action", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "play_pause"
        new_settings = {
            "media_action": default_action,
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })
        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or settings.get("media_action") or "play_pause")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available:
            return

        if sys.platform != "win32":
            print(f"[{self.uuid}] Ignored: Supported only on Windows.")
            return

        settings = data.get("payload", {}).get("settings", {})
        action = settings.get("command") or settings.get("media_action", "play_pause")
        hotkey_to_send = self.media_map.get(action)

        if hotkey_to_send:
            await asyncio.to_thread(keyboard.send, hotkey_to_send)
            print(f"[{self.uuid}] Media Command Sent: {action}")
