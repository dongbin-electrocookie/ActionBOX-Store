import asyncio
import urllib.request
import urllib.error
import json

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        # 🚀 [대통합 규격] 멀티액션 시 누락되는 URL, Method, Payload를 기억합니다.
        self.last_valid_settings = {}

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    def send_webhook(self, url, method, payload):
        if not url:
            print(f"[{self.uuid}] ⚠️ URL이 비어 있습니다.")
            return

        try:
            # POST나 PUT일 경우 데이터를 바이트로 변환
            req_data = payload.encode('utf-8') if payload and method in ['POST', 'PUT'] else None
            
            req = urllib.request.Request(url, data=req_data, method=method)
            if req_data:
                req.add_header('Content-Type', 'application/json')
                
            with urllib.request.urlopen(req, timeout=3) as response:
                print(f"[{self.uuid}] ✅ 웹훅 전송 성공 ({response.status}): {url}")
                
        except Exception as e:
            print(f"[{self.uuid}] ❌ 웹훅 전송 실패: {e}")

    async def on_key_down(self, data):
        incoming_settings = data.get("payload", {}).get("settings", {})
        
        # 1. 유효한 설정이 들어오면 기억해둡니다 (캐시 업데이트)
        if incoming_settings.get("webhook_url"):
            self.last_valid_settings.update(incoming_settings)

        # 2. 마지막 유효 설정과 현재 데이터를 병합 (멀티액션 대응)
        final_settings = {**self.last_valid_settings, **incoming_settings}

        # 🚀 [표준화] 'command'에 주소가 있으면 그것을 우선 사용합니다.
        url = final_settings.get("command") or final_settings.get("webhook_url", "").strip()
        method = final_settings.get("webhook_method", "GET")
        payload = final_settings.get("webhook_payload", "").strip()

        if url:
            await asyncio.to_thread(self.send_webhook, url, method, payload)
        else:
            print(f"[{self.uuid}] ⚠️ 요청할 URL이 없습니다.")