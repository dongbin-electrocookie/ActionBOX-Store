import asyncio
import os
import platform
import subprocess
import tempfile

IS_WINDOWS = (platform.system() == "Windows")
IS_MACOS = (platform.system() == "Darwin")
IS_LINUX = (platform.system() == "Linux")

win32_available = False
if IS_WINDOWS:
    try:
        import win32com.client
        win32_available = True
    except ImportError:
        print("[Word Plugin Error] 'pywin32' library is missing.")

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.word = None
        self.win32 = win32com.client if win32_available else None

        self.action_map = {
            "togglebold": self.apply_bold,
            "togglehighlight": self.toggle_highlight,
            "formatheader": self.format_as_header,
            "addtable": self.add_table,
            "pasteunformatted": self.paste_unformatted,
            "insertpagebreak": self.insert_pagebreak,
            "togglebullet": self.toggle_bullet,
            "saveaspdf": self.save_doc_as_pdf
        }

        self.icon_map = {
            "togglebold": "STATE_TOGGLE_BOLD",
            "togglehighlight": "STATE_TOGGLE_HIGHLIGHT",
            "formatheader": "STATE_FORMAT_HEADER",
            "togglebullet": "STATE_TOGGLE_BULLET",
            "pasteunformatted": "STATE_PASTE_UNFORMATTED",
            "insertpagebreak": "STATE_INSERT_PAGEBREAK",
            "addtable": "STATE_ADD_TABLE",
            "saveaspdf": "STATE_SAVE_AS_PDF"
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "togglebold", "STATE_TOGGLE_BOLD")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if context and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "command", "word_action", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "togglebold"
        new_settings = {
            "word_action": default_action,
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })
        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or settings.get("word_action") or "togglebold")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("command") or settings.get("word_action")

        if selected_action and selected_action in self.action_map:
            await asyncio.to_thread(self.action_map[selected_action])

    # ------------------------------------------------------------------
    # Platform helpers
    # ------------------------------------------------------------------
    def _connect_to_word(self):
        if not (IS_WINDOWS and self.win32):
            return False
        try:
            self.word = self.win32.GetActiveObject("Word.Application")
            return True
        except Exception:
            return False

    def _run_word_vba_macos(self, vba_code):
        """Run VBA in the active Microsoft Word instance on macOS using AppleScript."""
        if not IS_MACOS:
            return False

        escaped_vba = vba_code.replace('\\', '\\\\').replace('"', '\\"')
        apple_script = f'''
        tell application "Microsoft Word"
            activate
            do Visual Basic "{escaped_vba}"
        end tell
        '''
        try:
            result = subprocess.run(
                ["osascript", "-e", apple_script],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True,
                timeout=8,
            )
            if result.returncode != 0:
                print(f"[{self.uuid}] AppleScript/VBA error: {result.stderr.strip()}")
                return False
            return True
        except Exception as e:
            print(f"[{self.uuid}] AppleScript/VBA exception: {e}")
            return False

    def _send_hotkey_fallback(self, *keys):
        if not pyautogui_available:
            return False
        try:
            if len(keys) == 1:
                pyautogui.press(keys[0])
            else:
                pyautogui.hotkey(*keys)
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def apply_bold(self):
        if IS_WINDOWS:
            if self._connect_to_word():
                try:
                    self.word.Selection.Font.Bold = not self.word.Selection.Font.Bold
                except Exception:
                    pass
        elif IS_MACOS:
            self._run_word_vba_macos("Selection.Font.Bold = wdToggle") or self._send_hotkey_fallback("command", "b")
        else:
            self._send_hotkey_fallback("ctrl", "b")

    def toggle_highlight(self):
        if IS_WINDOWS:
            if self._connect_to_word():
                try:
                    current = self.word.Selection.Range.HighlightColorIndex
                    self.word.Selection.Range.HighlightColorIndex = 0 if current == 7 else 7
                except Exception:
                    pass
        elif IS_MACOS:
            self._run_word_vba_macos(
                "If Selection.Range.HighlightColorIndex = wdYellow Then "
                "Selection.Range.HighlightColorIndex = wdNoHighlight Else "
                "Selection.Range.HighlightColorIndex = wdYellow End If"
            )
        else:
            self._send_hotkey_fallback("ctrl", "alt", "h")

    def format_as_header(self):
        if IS_WINDOWS:
            if self._connect_to_word():
                try:
                    self.word.Selection.Style = -2
                except Exception:
                    pass
        elif IS_MACOS:
            self._run_word_vba_macos("Selection.Style = ActiveDocument.Styles(wdStyleHeading1)") or self._send_hotkey_fallback("command", "option", "1")
        else:
            self._send_hotkey_fallback("ctrl", "alt", "1")

    def add_table(self):
        if IS_WINDOWS:
            if self._connect_to_word():
                try:
                    self.word.ActiveDocument.Tables.Add(Range=self.word.Selection.Range, NumRows=3, NumColumns=3)
                except Exception:
                    pass
        elif IS_MACOS:
            self._run_word_vba_macos("ActiveDocument.Tables.Add Range:=Selection.Range, NumRows:=3, NumColumns:=3")

    def paste_unformatted(self):
        if IS_WINDOWS:
            if self._connect_to_word():
                try:
                    self.word.Selection.PasteSpecial(DataType=22)
                except Exception:
                    pass
        elif IS_MACOS:
            # wdPasteText = 2. If VBA fails, try the common Word Mac shortcut.
            self._run_word_vba_macos("Selection.PasteSpecial DataType:=wdPasteText") or self._send_hotkey_fallback("command", "option", "shift", "v")
        else:
            self._send_hotkey_fallback("ctrl", "shift", "v")

    def insert_pagebreak(self):
        if IS_WINDOWS:
            if self._connect_to_word():
                try:
                    self.word.Selection.InsertBreak(Type=7)
                except Exception:
                    pass
        elif IS_MACOS:
            self._run_word_vba_macos("Selection.InsertBreak Type:=wdPageBreak") or self._send_hotkey_fallback("command", "enter")
        else:
            self._send_hotkey_fallback("ctrl", "enter")

    def toggle_bullet(self):
        if IS_WINDOWS:
            if self._connect_to_word():
                try:
                    self.word.Selection.Range.ListFormat.ApplyBulletDefault()
                except Exception:
                    pass
        elif IS_MACOS:
            self._run_word_vba_macos("Selection.Range.ListFormat.ApplyBulletDefault") or self._send_hotkey_fallback("command", "shift", "l")
        else:
            self._send_hotkey_fallback("ctrl", "shift", "l")

    def save_doc_as_pdf(self):
        if IS_WINDOWS:
            if self._connect_to_word():
                try:
                    doc = self.word.ActiveDocument
                    if doc:
                        pdf_path = os.path.splitext(doc.FullName)[0] + ".pdf"
                        doc.SaveAs(pdf_path, FileFormat=17)
                        print(f"[{self.uuid}] PDF saved: {pdf_path}")
                except Exception:
                    pass
        elif IS_MACOS:
            self._run_word_vba_macos(
                "If ActiveDocument.Path <> \"\" Then "
                "Dim p As String: "
                "p = Left(ActiveDocument.FullName, InStrRev(ActiveDocument.FullName, \".\") - 1) & \".pdf\": "
                "ActiveDocument.ExportAsFixedFormat OutputFileName:=p, ExportFormat:=wdExportFormatPDF "
                "End If"
            )
