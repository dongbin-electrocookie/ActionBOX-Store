import asyncio
import sys
import os

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

lib_path = os.path.join(os.path.dirname(__file__), 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

try:
    import spotipy
    from spotipy.oauth2 import SpotifyOAuth
    SPOTIPY_AVAILABLE = True
except ImportError:
    SPOTIPY_AVAILABLE = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.sp = None
        self.last_valid_settings = {}

        self.icon_map = {
            "play_pause": "STATE_PLAY_PAUSE",
            "next": "STATE_NEXT",
            "prev": "STATE_PREV",
            "like": "STATE_LIKE"
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "play_pause", "STATE_PLAY_PAUSE")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "client_id", "client_secret", "sp_action", "command",
            "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "play_pause"
        new_settings = {
            "client_id": "",
            "client_secret": "",
            "sp_action": default_action,
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        # Initial placement: icon only, never overwrite title
        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        settings = payload.get("settings", {}) or {}
        command = payload.get("command")
        action_command = payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "sendToPlugin" and command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or settings.get("sp_action") or "play_pause")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    def _get_user_cache_dir(self):
        app_name = "CookieDeck"
        plugin_name = self.uuid.replace(".", "_")

        if IS_WINDOWS:
            root = os.environ.get("APPDATA") or os.path.expanduser("~\\AppData\\Roaming")
            cache_dir = os.path.join(root, app_name, plugin_name)
        elif IS_MACOS:
            cache_dir = os.path.expanduser(os.path.join("~", "Library", "Application Support", app_name, plugin_name))
        else:
            root = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser(os.path.join("~", ".config"))
            cache_dir = os.path.join(root, app_name, plugin_name)

        os.makedirs(cache_dir, exist_ok=True)
        return cache_dir

    def init_spotify(self, client_id, client_secret):
        if not SPOTIPY_AVAILABLE:
            print(f"[{self.uuid}] Missing 'spotipy' library.")
            return False

        if not client_id or not client_secret:
            print(f"[{self.uuid}] Missing Client ID or Secret.")
            return False

        try:
            cache_path = os.path.join(self._get_user_cache_dir(), ".spotify_cache")
            auth_manager = SpotifyOAuth(
                client_id=client_id,
                client_secret=client_secret,
                redirect_uri="http://localhost:8080/callback",
                scope="user-modify-playback-state user-read-playback-state user-library-modify user-read-currently-playing",
                open_browser=True,
                cache_path=cache_path
            )
            self.sp = spotipy.Spotify(auth_manager=auth_manager)
            return True
        except Exception as e:
            print(f"[{self.uuid}] Auth error: {e}")
            return False

    def control_spotify(self, settings):
        action = settings.get("command") or settings.get("sp_action", "play_pause")

        if not self.sp:
            c_id = settings.get("client_id", "").strip()
            c_secret = settings.get("client_secret", "").strip()
            if not self.init_spotify(c_id, c_secret):
                return

        try:
            if action == "play_pause":
                curr = self.sp.current_playback()
                if curr and curr.get('is_playing'):
                    self.sp.pause_playback()
                    print(f"[{self.uuid}] Pause")
                else:
                    self.sp.start_playback()
                    print(f"[{self.uuid}] Play")
            elif action == "next":
                self.sp.next_track()
                print(f"[{self.uuid}] Next track")
            elif action == "prev":
                self.sp.previous_track()
                print(f"[{self.uuid}] Previous track")
            elif action == "like":
                curr = self.sp.current_user_playing_track()
                if curr and curr.get('item'):
                    track_id = curr['item']['id']
                    self.sp.current_user_saved_tracks_add([track_id])
                    print(f"[{self.uuid}] Added to liked songs")
        except Exception as e:
            print(f"[{self.uuid}] Runtime error: {e}")

    async def on_key_down(self, data):
        incoming_settings = data.get("payload", {}).get("settings", {})

        if incoming_settings.get("client_id"):
            self.last_valid_settings.update(incoming_settings)

        final_settings = {**self.last_valid_settings, **incoming_settings}
        await asyncio.to_thread(self.control_spotify, final_settings)
