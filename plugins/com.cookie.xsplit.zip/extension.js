/* Run only as an XSplit custom extension; no commands execute on startup. */
(function () {
    "use strict";
    const protocol = "combox-xsplit-v1";
    const status = document.getElementById("status");
    let socket = null, stopped = false, reconnect = null, xjs, api;
    let actions = Promise.resolve();
    let texts = {};
    function text(key, fallback) { return texts[key] || fallback; }
    function show(key, fallback, detail) {
        status.textContent = text(key, fallback) + (detail ? "\n" + detail : "");
    }
    async function respond(message, peer) {
        const guard = () => {
            if (socket !== peer || peer.readyState !== WebSocket.OPEN || Date.now() >= message.deadline) {
                const error = new Error("Request expired or disconnected.");
                error.code = "ERR_TIMEOUT";
                throw error;
            }
        };
        let response = {event: "response", asyncId: message.asyncId};
        try {
            const payload = await api.execute(message.command, message.payload, guard);
            response = {...response, ok: true, payload};
        } catch (error) {
            response = {...response, ok: false, errorCode: error.code || "ERR_API", detail: String(error.message || error)};
            show(error.code || "ERR_API", "XSplit API error", response.detail);
        }
        if (socket === peer && peer.readyState === WebSocket.OPEN) peer.send(JSON.stringify(response));
    }
    function connect() {
        if (stopped) return;
        show("BRIDGE_WAITING", "Waiting for COMBO-X…");
        const peer = new WebSocket("ws://127.0.0.1:47653/combox-xsplit");
        socket = peer;
        peer.onopen = () => peer.send(JSON.stringify({
            event: "hello", protocol, role: "xsplit-extension"
        }));
        peer.onmessage = event => {
            let message;
            try { message = JSON.parse(event.data); } catch (_) { return; }
            if (message.event === "welcome" && message.protocol === protocol) {
                show("BRIDGE_CONNECTED", "Connected to COMBO-X");
            } else if (message.event === "request" && Number.isInteger(message.asyncId)
                    && typeof message.command === "string" && Number.isFinite(message.deadline)) {
                if (message.command.startsWith("get")) {
                    respond(message, peer);
                } else {
                    // Mutations are serialized, and expiry is checked again
                    // immediately before writing host state.
                    actions = actions.then(() => respond(message, peer)).catch(error => {
                        show("ERR_API", "XSplit API error", String(error));
                    });
                }
            }
        };
        peer.onerror = () => show("BRIDGE_WAITING", "Waiting for COMBO-X…");
        peer.onclose = () => {
            if (socket === peer) socket = null;
            if (!stopped) {
                show("BRIDGE_WAITING", "Waiting for COMBO-X…");
                reconnect = setTimeout(connect, 2000);
            }
        };
    }
    window.addEventListener("beforeunload", () => {
        stopped = true;
        clearTimeout(reconnect);
        if (socket) socket.close();
    });
    (async function () {
        try {
            xjs = window.require("xjs");
            await Promise.race([
                xjs.ready(),
                new Promise((_, reject) => setTimeout(() => reject(new Error("XSplit API initialization timed out.")), 15000))
            ]);
            if (!xjs.Environment.isExtension()) throw new Error("Open Combo-X Extend.html as a custom extension inside XSplit.");
            xjs.ExtensionWindow.resize(440, 140);
            xjs.ExtensionWindow.setTitle("COMBO-X Extend").catch(error => console.warn(error));
            try {
                const raw = await xjs.LanguageInfo.getCode();
                const language = String(raw || "en").replace("_", "-").split("-")[0];
                const code = language === "pt" ? "pt-PT" : language;
                texts = await (await fetch("./locales/" + code + ".json")).json();
            } catch (_) { /* English fallback if this host cannot read local JSON. */ }
            api = ComboXXSplitAPI.create(xjs);
            connect();
        } catch (error) {
            show("ERR_API", "Could not initialize the XSplit extension.", String(error.message || error));
        }
    })();
})();
