import asyncio
import platform

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 다빈치 리졸브 기본 단축키 맵 (Windows 기준)
        self.action_map = {
            # 1. 파일 및 기본 편집
            "file_save": "ctrl+s",
            "edit_undo": "ctrl+z",
            "edit_redo": "ctrl+shift+z",
            "edit_ripple_delete": "ctrl+backspace", # 다빈치 기본 잔물결 삭제

            # 2. 도구 (Tools & Modes)
            "tool_selection": "a",
            "tool_blade": "b",
            "tool_snapping": "n",
            "tool_linked_selection": "ctrl+shift+l",

            # 3. 타임라인 편집 (Timeline)
            "timeline_split": "ctrl+\\", # 플레이헤드 위치에서 클립 자르기

            # 4. 재생 및 탐색 (Playback - J/K/L 시스템)
            "play_toggle": "space",
            "play_reverse": "j",
            "play_stop": "k",
            "play_forward": "l",
            "play_prev_clip": "up",
            "play_next_clip": "down",

            # 5. 마커 및 인/아웃 (Markers)
            "mark_in": "i",
            "mark_out": "o",
            "mark_clear": "alt+x",
            "marker_add": "m",

            # 6. 화면 보기 (View)
            "view_zoom_in": "ctrl+=",
            "view_zoom_out": "ctrl+-",
            "view_fit": "shift+z", # 다빈치 리졸브 특유의 타임라인 맞춤 단축키
            "view_fullscreen": "ctrl+f"
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("dv_action", "tool_selection")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)