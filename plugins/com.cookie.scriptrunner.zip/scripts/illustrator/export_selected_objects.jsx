#target illustrator

function safeFileName(name, fallback) {
    var value = String(name || "").replace(/[\\\/:*?"<>|]/g, "_").replace(/^\s+|\s+$/g, "");
    return value || fallback;
}

function uniqueBasePath(folder, name) {
    var basePath = folder.fsName + "/" + name;
    var index = 2;
    while (new File(basePath + ".ai").exists || new File(basePath + ".svg").exists || new File(basePath + ".png").exists) {
        basePath = folder.fsName + "/" + name + "_" + index;
        index++;
    }
    return basePath;
}

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else if (app.activeDocument.selection.length === 0) {
    alert("선택된 객체가 없습니다.");
} else {
    var doc = app.activeDocument;
    var selection = doc.selection;
    var exportFolder = Folder.selectDialog("저장할 폴더를 선택하세요");

    if (exportFolder) {
        var exported = 0;
        var skipped = 0;
        for (var i = 0; i < selection.length; i++) {
            var tempDoc = null;
            try {
                var item = selection[i];
                if (item.locked || item.hidden) throw new Error("잠기거나 숨겨진 객체");

                var bounds = item.visibleBounds;
                var width = Math.max(1, bounds[2] - bounds[0]);
                var height = Math.max(1, bounds[1] - bounds[3]);
                tempDoc = app.documents.add(DocumentColorSpace.RGB, width, height);
                var copy = item.duplicate(tempDoc, ElementPlacement.PLACEATBEGINNING);
                tempDoc.artboards[0].artboardRect = copy.visibleBounds;

                var objectName = safeFileName(item.name, "export_" + (i + 1));
                var basePath = uniqueBasePath(exportFolder, objectName);

                tempDoc.saveAs(new File(basePath + ".ai"), new IllustratorSaveOptions());

                var svgOptions = new ExportOptionsSVG();
                svgOptions.embedRasterImages = true;
                tempDoc.exportFile(new File(basePath + ".svg"), ExportType.SVG, svgOptions);

                var pngOptions = new ExportOptionsPNG24();
                pngOptions.transparency = true;
                pngOptions.artBoardClipping = true;
                pngOptions.horizontalScale = 100;
                pngOptions.verticalScale = 100;
                tempDoc.exportFile(new File(basePath + ".png"), ExportType.PNG24, pngOptions);
                exported++;
            } catch (e) {
                skipped++;
            } finally {
                if (tempDoc) tempDoc.close(SaveOptions.DONOTSAVECHANGES);
            }
        }
        alert(exported + "개 객체 저장 완료" + (skipped ? ", " + skipped + "개 건너뜀." : "."));
    }
}
