import asyncio
import os
import shutil
import subprocess
import sys
import time

try:
    import keyboard
    keyboard_available = True
except Exception:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except Exception:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

if IS_WINDOWS:
    try:
        import ctypes
    except Exception:
        ctypes = None
else:
    ctypes = None

VK_MAP = {
    0x11: 'ctrl', 0x10: 'shift', 0x12: 'alt', 0x5B: 'windows', 0x5C: 'windows',
    0x25: 'left', 0x26: 'up', 0x27: 'right', 0x28: 'down',
    0x0D: 'enter', 0x20: 'space', 0x1B: 'esc', 0x08: 'backspace', 0x09: 'tab',
    0x2E: 'delete', 0x2D: 'insert', 0x24: 'home', 0x23: 'end', 0x21: 'page up', 0x22: 'page down',
    0xBA: ';', 0xBB: '=', 0xBC: ',', 0xBD: '-', 0xBE: '.', 0xBF: '/', 0xC0: '`',
    0xDB: '[', 0xDC: '\\', 0xDD: ']', 0xDE: "'"
}
for i in range(65, 91):
    VK_MAP[i] = chr(i).lower()
for i in range(48, 58):
    VK_MAP[i] = chr(i)
for i in range(112, 124):
    VK_MAP[i] = f"f{i-111}"


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.is_recording = False
        self.context_settings = {}
        base_path = os.environ.get("ACTIONBOX_BASE_PATH") or os.path.dirname(os.path.dirname(os.path.dirname(self.plugin_dir)))
        self.log_file = os.path.join(base_path, "logs", "shortcuts_debug.log")

        self.action_icon_map = {
            "hotkey": "ACTION_HOTKEY",
            "typetext": "ACTION_TYPETEXT"
        }

    def _log(self, msg):
        if os.environ.get("COMBOX_FILE_LOGS", "0").strip().lower() not in {"1", "true", "yes", "on"}:
            return
        try:
            os.makedirs(os.path.dirname(self.log_file), exist_ok=True)
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(msg + "\n")
        except Exception:
            pass

    def _get_action_key(self, action_id):
        action_id = (action_id or "").lower()
        if action_id.endswith(".hotkey"):
            return "hotkey"
        if action_id.endswith(".typetext"):
            return "typetext"
        return None

    def _get_icon_path(self, action_id, icon_name=None):
        if not icon_name:
            action_key = self._get_action_key(action_id)
            if not action_key:
                return None
            icon_name = self.action_icon_map.get(action_key)

        if not icon_name:
            return None

        icon_name = os.path.basename(str(icon_name)).replace(".png", "")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id, icon_name=None):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        if not icon_name and context:
            cached_settings = self.context_settings.get(context, {}) or {}
            icon_name = cached_settings.get("builtin_icon_name")

        icon_path = self._get_icon_path(action_id, icon_name)
        if icon_path and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return

        settings = dict(settings or {})
        action_key = self._get_action_key(action_id)
        if not action_key:
            return

        if action_key == "hotkey":
            meaningful_keys = ["hotkey", "hotkey_custom", "command", "builtin_icon_name", "default_visuals_initialized", "sync_title_on_hotkey_change", "title"]
            default_settings = {
                "hotkey": "custom",
                "hotkey_custom": "",
                "command": "",
                "_lang": "en",
                "sync_title_on_hotkey_change": False,
                "builtin_icon_name": self.action_icon_map["hotkey"],
                "default_visuals_initialized": True
            }
        elif action_key == "typetext":
            meaningful_keys = ["text_to_type", "command", "builtin_icon_name", "default_visuals_initialized", "sync_title_on_text_change", "title"]
            default_settings = {
                "text_to_type": "",
                "command": "",
                "_lang": "en",
                "sync_title_on_text_change": False,
                "builtin_icon_name": self.action_icon_map["typetext"],
                "default_visuals_initialized": True
            }
        meaningful = any(settings.get(k) not in ("", None, False) for k in meaningful_keys)
        if meaningful:
            self.context_settings[context] = settings.copy()
            return

        self.context_settings[context] = default_settings.copy()
        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": default_settings
        })
        await self._send_builtin_icon(context, action_id)

    def _normalize_hotkey(self, hotkey):
        s = (hotkey or "").strip().lower()
        if not s:
            return ""
        parts = [p.strip() for p in s.split("+") if p.strip()]
        alias = {
            "cmd": "command" if IS_MACOS else "windows",
            "command": "command" if IS_MACOS else "windows",
            "win": "command" if IS_MACOS else "windows",
            "windows": "command" if IS_MACOS else "windows",
            "control": "ctrl",
            "option": "option" if IS_MACOS else "alt",
            "escape": "esc",
            "return": "enter",
            "pgup": "pageup",
            "page up": "pageup",
            "pgdn": "pagedown",
            "page down": "pagedown",
            "del": "delete",
            "ins": "insert"
        }
        return "+".join(alias.get(p, p) for p in parts)

    def _translate_hotkey_for_platform(self, hotkey):
        hk = self._normalize_hotkey(hotkey)
        if not hk or not IS_MACOS:
            return hk

        mac_specific = {
            "windows+r": "command+space",
            "command+r": "command+space",
            "windows+e": "command+option+space",
            "command+e": "command+option+space",
            "windows+l": "ctrl+command+q",
            "command+l": "ctrl+command+q",
            "windows+d": "command+f3",
            "command+d": "command+f3",
            "windows+shift+s": "command+shift+5",
            "command+shift+s": "command+shift+5",
            "windows+v": "command+v",
            "command+v": "command+v",
            "ctrl+shift+esc": "command+option+esc",
            "ctrl+shift+escape": "command+option+esc",
            "alt+f4": "command+w",
            "option+f4": "command+w",
            "alt+tab": "command+tab",
            "option+tab": "command+tab",
        }
        if hk in mac_specific:
            return mac_specific[hk]

        parts = hk.split("+")
        converted = []
        for p in parts:
            if p == "ctrl":
                converted.append("command")
            elif p == "alt":
                converted.append("option")
            elif p in ("windows", "win"):
                converted.append("command")
            else:
                converted.append(p)
        return "+".join(converted)

    def _translate_hotkey_for_keyboard_lib(self, hotkey):
        hk = self._normalize_hotkey(hotkey)
        if not hk:
            return ""
        # The Windows `keyboard` module uses spaced names for paging keys,
        # while pyautogui uses pageup/pagedown. Keep both backends happy.
        keyboard_alias = {
            "pageup": "page up",
            "pagedown": "page down",
            "esc": "esc",
        }
        return "+".join(keyboard_alias.get(p, p) for p in hk.split("+"))

    def _send_windows_virtual_hotkey(self, hotkey):
        """Send modifier-only and Windows/navigation chords with real VK events."""
        if not (IS_WINDOWS and ctypes):
            return False

        parts = [p.strip().lower() for p in self._normalize_hotkey(hotkey).split("+") if p.strip()]
        if not parts:
            return False

        modifier_vk = {
            "ctrl": 0x11,
            "shift": 0x10,
            "alt": 0x12,
            "windows": 0x5B,
            "win": 0x5B,
        }
        named_vk = {
            "space": 0x20,
            "enter": 0x0D,
            "return": 0x0D,
            "tab": 0x09,
            "esc": 0x1B,
            "escape": 0x1B,
            "backspace": 0x08,
            "pageup": 0x21,
            "pagedown": 0x22,
            "home": 0x24,
            "end": 0x23,
            "insert": 0x2D,
            "delete": 0x2E,
            "up": 0x26,
            "down": 0x28,
            "left": 0x25,
            "right": 0x27,
        }

        def resolve_vk(token):
            if token in named_vk:
                return named_vk[token]
            if len(token) == 1 and "a" <= token <= "z":
                return ord(token.upper())
            if len(token) == 1 and "0" <= token <= "9":
                return ord(token)
            if token.startswith("f") and token[1:].isdigit():
                number = int(token[1:])
                if 1 <= number <= 24:
                    return 0x70 + number - 1
            return None

        modifiers = [p for p in parts if p in modifier_vk]
        key_parts = [p for p in parts if p not in modifier_vk]

        if len(key_parts) > 1:
            return False
        if not key_parts and not modifiers:
            return False

        key_vk = resolve_vk(key_parts[0]) if key_parts else None
        if key_parts and key_vk is None:
            return False

        navigation_vks = {
            0x21, 0x22, 0x23, 0x24,
            0x25, 0x26, 0x27, 0x28,
            0x2D, 0x2E,
        }
        owns_chord = (
            key_vk is None
            or any(modifier_vk[p] in (0x5B, 0x5C) for p in modifiers)
            or key_vk in navigation_vks
        )
        if not owns_chord:
            return False

        user32 = ctypes.windll.user32
        KEYEVENTF_EXTENDEDKEY = 0x0001
        KEYEVENTF_KEYUP = 0x0002
        MAPVK_VK_TO_VSC = 0
        extended_vks = {
            0x5B, 0x5C,
            0x21, 0x22, 0x23, 0x24,
            0x25, 0x26, 0x27, 0x28,
            0x2D, 0x2E,
        }

        def emit(vk, is_up=False):
            scan = user32.MapVirtualKeyW(vk, MAPVK_VK_TO_VSC)
            flags = 0
            if vk in extended_vks:
                flags |= KEYEVENTF_EXTENDEDKEY
            if is_up:
                flags |= KEYEVENTF_KEYUP
            user32.keybd_event(vk, scan, flags, 0)

        pressed_modifiers = []
        try:
            for part in parts:
                if part in modifier_vk:
                    vk = modifier_vk[part]
                    emit(vk, False)
                    pressed_modifiers.append(vk)
                    time.sleep(0.012)

            if key_vk is not None:
                emit(key_vk, False)
                time.sleep(0.045)
                emit(key_vk, True)
            else:
                time.sleep(0.045)

            for vk in reversed(pressed_modifiers):
                time.sleep(0.012)
                emit(vk, True)
            return True
        except Exception as e:
            self._log(f"[hotkey] Win32 virtual key failed: {e}")
            for vk in reversed(pressed_modifiers):
                try:
                    emit(vk, True)
                except Exception:
                    pass
            return False

    def _send_hotkey_blocking(self, hotkey):
        hk = self._translate_hotkey_for_platform(hotkey)
        if not hk:
            self._log("[hotkey] empty")
            return
        self._log(f"[hotkey] send -> {hk}")

        if self._send_windows_virtual_hotkey(hk):
            return

        if IS_MACOS and self._send_macos_native_hotkey(hk):
            return

        if IS_WINDOWS and keyboard_available:
            keyboard_hk = self._translate_hotkey_for_keyboard_lib(hk)
            try:
                keyboard.press_and_release(keyboard_hk)
                return
            except Exception as e:
                self._log(f"[hotkey] press_and_release failed: {e}")
            try:
                keyboard.send(keyboard_hk)
                return
            except Exception as e:
                self._log(f"[hotkey] send failed: {e}")

        if not pyautogui_available:
            self._log("[hotkey] pyautogui unavailable")
            return
        try:
            parts = [p.strip() for p in hk.split("+") if p.strip()]
            if len(parts) == 1:
                pyautogui.press(parts[0])
            else:
                pyautogui.hotkey(*parts)
        except Exception as e:
            self._log(f"[hotkey] pyautogui failed: {e}")

    def _send_macos_native_hotkey(self, hotkey):
        """Send a macOS chord using the event route accepted by Mission Control."""
        if not IS_MACOS:
            return False
        parts = [
            part.strip().lower()
            for part in str(hotkey).split("+")
            if part.strip()
        ]
        if len(parts) == 2 and parts[0] in ("ctrl", "control"):
            if parts[1] == "right":
                return self._switch_macos_space(1)
            if parts[1] == "left":
                return self._switch_macos_space(-1)
            if parts[1] == "up":
                try:
                    return subprocess.run(
                        ["open", "-a", "Mission Control"],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        timeout=3,
                    ).returncode == 0
                except Exception:
                    pass
        try:
            import Quartz
        except Exception as exc:
            self._log(f"[hotkey] Quartz unavailable: {exc}")
            return False

        keycode_map = {
            "a": 0, "s": 1, "d": 2, "f": 3, "h": 4, "g": 5, "z": 6, "x": 7,
            "c": 8, "v": 9, "b": 11, "q": 12, "w": 13, "e": 14, "r": 15,
            "y": 16, "t": 17, "1": 18, "2": 19, "3": 20, "4": 21, "6": 22,
            "5": 23, "=": 24, "9": 25, "7": 26, "-": 27, "8": 28, "0": 29,
            "]": 30, "o": 31, "u": 32, "[": 33, "i": 34, "p": 35,
            "enter": 36, "return": 36, "l": 37, "j": 38, "'": 39, "k": 40,
            ";": 41, "\\": 42, ",": 43, "/": 44, "n": 45, "m": 46,
            ".": 47, "tab": 48, "space": 49, "`": 50, "backspace": 51,
            "esc": 53, "escape": 53, "left": 123, "right": 124,
            "down": 125, "up": 126, "home": 115, "end": 119,
            "pageup": 116, "pagedown": 121, "delete": 117,
            "f1": 122, "f2": 120, "f3": 99, "f4": 118, "f5": 96,
            "f6": 97, "f7": 98, "f8": 100, "f9": 101, "f10": 109,
            "f11": 103, "f12": 111,
        }
        modifier_map = {
            "ctrl": (59, Quartz.kCGEventFlagMaskControl),
            "control": (59, Quartz.kCGEventFlagMaskControl),
            "command": (55, Quartz.kCGEventFlagMaskCommand),
            "cmd": (55, Quartz.kCGEventFlagMaskCommand),
            "option": (58, Quartz.kCGEventFlagMaskAlternate),
            "alt": (58, Quartz.kCGEventFlagMaskAlternate),
            "shift": (56, Quartz.kCGEventFlagMaskShift),
        }
        key_parts = [part for part in parts if part not in modifier_map]
        if len(key_parts) != 1 or key_parts[0] not in keycode_map:
            return False

        source = Quartz.CGEventSourceCreate(Quartz.kCGEventSourceStatePrivate)
        if source is None:
            return False
        flags = Quartz.kCGEventFlagMaskNonCoalesced
        modifier_keycodes = []
        for part in parts:
            if part in modifier_map:
                modifier_keycode, modifier_flag = modifier_map[part]
                flags |= modifier_flag
                modifier_keycodes.append(modifier_keycode)

        for modifier_keycode in modifier_keycodes:
            event = Quartz.CGEventCreateKeyboardEvent(source, modifier_keycode, True)
            Quartz.CGEventSetFlags(event, flags)
            Quartz.CGEventPost(Quartz.kCGSessionEventTap, event)
            time.sleep(0.02)

        keycode = keycode_map[key_parts[0]]
        down = Quartz.CGEventCreateKeyboardEvent(source, keycode, True)
        up = Quartz.CGEventCreateKeyboardEvent(source, keycode, False)
        Quartz.CGEventSetFlags(down, flags)
        Quartz.CGEventSetFlags(up, flags)
        Quartz.CGEventPost(Quartz.kCGSessionEventTap, down)
        time.sleep(0.08)
        Quartz.CGEventPost(Quartz.kCGSessionEventTap, up)
        time.sleep(0.04)

        for modifier_keycode in reversed(modifier_keycodes):
            event = Quartz.CGEventCreateKeyboardEvent(source, modifier_keycode, False)
            Quartz.CGEventSetFlags(event, Quartz.kCGEventFlagMaskNonCoalesced)
            Quartz.CGEventPost(Quartz.kCGSessionEventTap, event)
            time.sleep(0.01)
        return True

    def _switch_macos_space(self, direction):
        """Switch adjacent macOS Spaces through the WindowServer API."""
        if not IS_MACOS or direction not in (-1, 1):
            return False
        try:
            import ctypes as mac_ctypes
            import objc

            sky = mac_ctypes.CDLL(
                "/System/Library/PrivateFrameworks/SkyLight.framework/SkyLight"
            )
            sky.CGSMainConnectionID.argtypes = []
            sky.CGSMainConnectionID.restype = mac_ctypes.c_uint32
            sky.CGSCopyManagedDisplaySpaces.argtypes = [mac_ctypes.c_uint32]
            sky.CGSCopyManagedDisplaySpaces.restype = mac_ctypes.c_void_p
            sky.CGSGetActiveSpace.argtypes = [mac_ctypes.c_uint32]
            sky.CGSGetActiveSpace.restype = mac_ctypes.c_uint64
            setter = sky.CGSManagedDisplaySetCurrentSpace
            setter.argtypes = [
                mac_ctypes.c_uint32,
                mac_ctypes.c_void_p,
                mac_ctypes.c_uint64,
            ]
            setter.restype = mac_ctypes.c_int32

            connection = sky.CGSMainConnectionID()
            rows_pointer = sky.CGSCopyManagedDisplaySpaces(connection)
            if not rows_pointer:
                return False
            displays = objc.objc_object(c_void_p=rows_pointer)
            active = int(sky.CGSGetActiveSpace(connection))
            display = next(
                (
                    row for row in displays
                    if int((row.get("Current Space") or {}).get("ManagedSpaceID", 0))
                    == active
                ),
                displays[0] if displays else None,
            )
            if display is None:
                return False
            spaces = [
                int(space.get("ManagedSpaceID", 0))
                for space in (display.get("Spaces") or [])
                if int(space.get("ManagedSpaceID", 0)) > 0
            ]
            if active not in spaces:
                return False
            target_index = spaces.index(active) + int(direction)
            if not 0 <= target_index < len(spaces):
                return True
            identifier = display.get("Display Identifier")
            objc_identifier = getattr(identifier, "__pyobjc_object__", None)
            if objc_identifier is None:
                import Foundation
                identifier = Foundation.NSString.stringWithString_(str(identifier))
                objc_identifier = getattr(identifier, "__pyobjc_object__", None)
            if objc_identifier is None:
                return False
            return int(setter(
                connection,
                objc.pyobjc_id(objc_identifier),
                spaces[target_index],
            )) == 0
        except Exception as exc:
            self._log(f"[hotkey] direct Space switch failed: {exc}")
            return False

    def _set_windows_clipboard_text(self, text):
        if ctypes is None:
            return False

        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        user32.OpenClipboard.argtypes = [ctypes.c_void_p]
        user32.OpenClipboard.restype = ctypes.c_int
        user32.EmptyClipboard.restype = ctypes.c_int
        user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
        user32.SetClipboardData.restype = ctypes.c_void_p
        kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
        kernel32.GlobalAlloc.restype = ctypes.c_void_p
        kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
        kernel32.GlobalLock.restype = ctypes.c_void_p
        kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
        kernel32.GlobalFree.argtypes = [ctypes.c_void_p]

        opened = False
        memory_handle = None
        try:
            for _ in range(10):
                if user32.OpenClipboard(None):
                    opened = True
                    break
                time.sleep(0.02)
            if not opened or not user32.EmptyClipboard():
                return False

            encoded = (str(text) + "\0").encode("utf-16-le")
            memory_handle = kernel32.GlobalAlloc(0x0002, len(encoded))
            if not memory_handle:
                return False
            memory_pointer = kernel32.GlobalLock(memory_handle)
            if not memory_pointer:
                return False
            try:
                ctypes.memmove(memory_pointer, encoded, len(encoded))
            finally:
                kernel32.GlobalUnlock(memory_handle)

            if not user32.SetClipboardData(13, memory_handle):  # CF_UNICODETEXT
                return False
            memory_handle = None  # Clipboard now owns the allocated memory.
            return True
        finally:
            if memory_handle:
                kernel32.GlobalFree(memory_handle)
            if opened:
                user32.CloseClipboard()

    def _set_clipboard_text_blocking(self, text):
        try:
            if IS_WINDOWS:
                return self._set_windows_clipboard_text(text)
            if IS_MACOS:
                subprocess.run(
                    ["pbcopy"], input=str(text), text=True, encoding="utf-8", check=True
                )
                return True

            clipboard_commands = (
                (["wl-copy"], "wl-copy"),
                (["xclip", "-selection", "clipboard"], "xclip"),
                (["xsel", "--clipboard", "--input"], "xsel"),
            )
            for command, executable in clipboard_commands:
                if shutil.which(executable):
                    subprocess.run(
                        command, input=str(text), text=True, encoding="utf-8", check=True
                    )
                    return True
        except Exception as e:
            self._log(f"[type] clipboard set failed: {e}")
        return False

    def _type_text_blocking(self, text):
        if not text:
            return
        if self._set_clipboard_text_blocking(text):
            time.sleep(0.03)
            self._send_hotkey_blocking("cmd+v" if IS_MACOS else "ctrl+v")
            return
        self._log("[type] clipboard unavailable; falling back to simulated typing")
        if IS_WINDOWS and keyboard_available:
            try:
                keyboard.write(text, delay=0.01)
                return
            except TypeError:
                keyboard.write(text, 0.01)
                return
            except Exception as e:
                self._log(f"[type] keyboard failed: {e}")
        if pyautogui_available:
            try:
                pyautogui.write(text, interval=0.01)
            except Exception as e:
                self._log(f"[type] pyautogui failed: {e}")

    async def handle_message(self, data):
        event = data.get("event")
        action_id = data.get("action", "")
        command = data.get("command") or data.get("payload", {}).get("command")
        context = data.get("context") or data.get("payload", {}).get("context")
        payload = data.get("payload", {}) or {}
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                merged = dict(cached)
                merged.update(settings or {})
                self.context_settings[context] = merged
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_id, payload.get("builtin_icon_name"))
            return

        if event == "keyDown":
            await self.on_key_down(data)
        elif command == "start_recording":
            if not self.is_recording:
                self.is_recording = True

                async def _record_task():
                    try:
                        hotkey = await asyncio.to_thread(self._poll_hardware_keys)
                        await self.runner.send_message({
                            "event": "sendToPropertyInspector",
                            "context": context,
                            "payload": {"command": "recording_finished", "hotkey": hotkey}
                        })
                    finally:
                        self.is_recording = False
                asyncio.create_task(_record_task())

    def _poll_hardware_keys_windows(self):
        if not ctypes:
            return ""
        start_time = time.time()
        modifiers_set = {'ctrl', 'shift', 'alt', 'windows'}
        modifier_order = ['ctrl', 'shift', 'alt', 'windows']
        captured_mods = []
        captured_keys = []
        capture_started = False
        all_released_at = None

        while time.time() - start_time < 10.0:
            pressed_keys = []
            for vk, name in VK_MAP.items():
                if ctypes.windll.user32.GetAsyncKeyState(vk) & 0x8000:
                    if name not in pressed_keys:
                        pressed_keys.append(name)

            if pressed_keys:
                # Any key starts a recording, including Ctrl/Shift/Alt/Win.
                capture_started = True
                all_released_at = None

                for mod in modifier_order:
                    if mod in pressed_keys and mod not in captured_mods:
                        captured_mods.append(mod)

                non_mods = [k for k in pressed_keys if k not in modifiers_set]
                for key in non_mods:
                    if key not in captured_keys:
                        captured_keys.append(key)
            elif capture_started:
                # Finish only after the whole chord has been released. This
                # makes modifier-only chords behave exactly like Ctrl+A etc.
                if all_released_at is None:
                    all_released_at = time.time()
                elif time.time() - all_released_at >= 0.12:
                    return "+".join(captured_mods + captured_keys)

            time.sleep(0.01)

        return "+".join(captured_mods + captured_keys) if (captured_mods or captured_keys) else ""

    def _poll_hardware_keys_pynput(self):
        try:
            from pynput import keyboard as pynput_keyboard
        except Exception as e:
            self._log(f"[record] pynput unavailable: {e}")
            return ""

        captured = {"value": "", "released_at": None, "started": False}
        active_keys = set()
        modifiers = set()
        captured_mods = []
        captured_keys = []
        start_time = time.time()

        def key_to_name(key):
            if key in (pynput_keyboard.Key.ctrl, pynput_keyboard.Key.ctrl_l, pynput_keyboard.Key.ctrl_r):
                return "ctrl"
            if key in (pynput_keyboard.Key.shift, pynput_keyboard.Key.shift_l, pynput_keyboard.Key.shift_r):
                return "shift"
            if key in (pynput_keyboard.Key.alt, pynput_keyboard.Key.alt_l, pynput_keyboard.Key.alt_r):
                return "option" if IS_MACOS else "alt"
            if key in (pynput_keyboard.Key.cmd, pynput_keyboard.Key.cmd_l, pynput_keyboard.Key.cmd_r):
                return "command" if IS_MACOS else "windows"
            special = {
                pynput_keyboard.Key.enter: "enter",
                pynput_keyboard.Key.esc: "esc",
                pynput_keyboard.Key.backspace: "backspace",
                pynput_keyboard.Key.tab: "tab",
                pynput_keyboard.Key.space: "space",
                pynput_keyboard.Key.delete: "delete",
                pynput_keyboard.Key.home: "home",
                pynput_keyboard.Key.end: "end",
                pynput_keyboard.Key.page_up: "pageup",
                pynput_keyboard.Key.page_down: "pagedown",
                pynput_keyboard.Key.left: "left",
                pynput_keyboard.Key.right: "right",
                pynput_keyboard.Key.up: "up",
                pynput_keyboard.Key.down: "down",
            }
            if key in special:
                return special[key]
            name = getattr(key, "char", None)
            if name:
                return name.lower()
            text = str(key).replace("Key.", "").lower()
            return text

        def on_press(key):
            name = key_to_name(key)
            active_keys.add(key)
            # Any key, including a modifier by itself, starts recording.
            captured["started"] = True
            captured["released_at"] = None

            if name in {"ctrl", "shift", "alt", "option", "windows", "command"}:
                modifiers.add(name)
                if name not in captured_mods:
                    captured_mods.append(name)
                return True

            if name not in captured_keys:
                captured_keys.append(name)
            return True

        def on_release(key):
            name = key_to_name(key)
            active_keys.discard(key)
            modifiers.discard(name)
            return True

        try:
            with pynput_keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
                while listener.running and time.time() - start_time < 10.0:
                    if captured["started"] and not active_keys:
                        if captured["released_at"] is None:
                            captured["released_at"] = time.time()
                        elif time.time() - captured["released_at"] >= 0.12:
                            order = ["ctrl", "shift", "alt", "option", "windows", "command"]
                            mods = [m for m in order if m in captured_mods]
                            captured["value"] = "+".join(mods + captured_keys)
                            break
                    elif active_keys:
                        captured["released_at"] = None
                    time.sleep(0.02)
                listener.stop()
        except Exception as e:
            self._log(f"[record] listener failed: {e}")
            return ""
        if captured["value"]:
            return captured["value"]
        order = ["ctrl", "shift", "alt", "option", "windows", "command"]
        mods = [m for m in order if m in captured_mods]
        return "+".join(mods + captured_keys) if (mods or captured_keys) else ""

    def _poll_hardware_keys(self):
        if IS_WINDOWS:
            return self._poll_hardware_keys_windows()
        return self._poll_hardware_keys_pynput()

    async def on_key_down(self, data):
        action_id = data.get("action")
        context = data.get("context")
        payload_settings = data.get("payload", {}).get("settings")
        incoming_settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = dict(cached)
        settings.update(incoming_settings or {})
        if context:
            self.context_settings[context] = settings

        command = settings.get("command")
        if action_id == "com.cookie.shortcuts.typetext":
            self._log(
                f"[keyDown] action={action_id} context={context} "
                f"chars={len(str(command or settings.get('text_to_type') or ''))}"
            )
        else:
            self._log(f"[keyDown] action={action_id} context={context} command={command} settings={settings}")

        if action_id == "com.cookie.shortcuts.hotkey":
            hotkey_preset = settings.get("hotkey")
            hotkey_custom = settings.get("hotkey_custom")

            # The selected preset/custom value is authoritative. `command` is
            # only a backward-compatibility mirror and may be stale in older
            # saved mappings.
            if hotkey_preset == "custom":
                hotkey_to_send = hotkey_custom or command
            else:
                hotkey_to_send = hotkey_preset or command
            if hotkey_to_send:
                await asyncio.to_thread(self._send_hotkey_blocking, hotkey_to_send)
            else:
                self._log("[hotkey] missing hotkey_to_send")

        elif action_id == "com.cookie.shortcuts.typetext":
            text = command or settings.get("text_to_type")
            if text:
                await asyncio.to_thread(self._type_text_blocking, text)
