# DevOps Toolbox 연결 및 테스트

상태 기능은 아이콘 그림을 교체하지 않고 **버튼 제목**으로 실제 API 응답을 표시합니다.
배치/설정 변경 후 조회하고 60초마다 갱신하며, 상태 버튼을 눌러 수동 갱신할 수도 있습니다.
빈 결과·권한 오류·미지원 상태를 `정상`으로 처리하지 않습니다.

## 연결 정보

| 기능 | 필요한 설정 |
| --- | --- |
| Vercel 재배포 | 프로젝트에서 발급한 Deploy Hook URL |
| Netlify 상태 | 액세스 토큰, Site ID(API ID) |
| Netlify 빌드 | Build Hook URL |
| Cloudflare Pages 상태 | API 토큰, Account ID(32자리), Pages 프로젝트명, 배포 환경 |
| Cloudflare 캐시 삭제 | API 토큰, Zone ID(32자리), 삭제 범위와 URL 목록 |
| Railway 상태/재시작 | 토큰 종류, 토큰, Service ID 및 대상 프로젝트·환경 |
| GitHub 상태 | 토큰, `owner/repo`, 선택적으로 워크플로 파일명/ID |
| GitHub 워크플로 실행 | 토큰, `owner/repo`, 워크플로 파일명/ID, 선택적으로 브랜치/태그와 입력값 JSON |

### Cloudflare

- Pages 상태: 해당 계정에 대한 **Pages Read** 권한이 필요합니다.
- 캐시 삭제: 대상 Zone에 대한 **Cache Purge** 권한이 필요합니다.
- 기본 삭제 범위는 **지정한 URL만**입니다. 한 줄에 하나씩 최대 100개를 입력합니다.
- **영역 전체**를 직접 선택하면 그 Zone의 모든 캐시가 삭제됩니다.
- 이전에 저장한 공식 `.../zones/{zone_id}/purge_cache` URL에서도 Zone ID를 읽을 수 있지만,
  삭제 범위는 별도로 설정해야 합니다. 다른 호스트에 토큰을 보내지 않습니다.

### Railway

- 계정/워크스페이스 토큰: Project ID, Service ID, Environment ID를 모두 입력합니다.
- 프로젝트 토큰: 프로젝트와 환경 ID를 API에서 조회합니다. Service ID는 직접 입력합니다.
  프로젝트/환경 ID를 같이 입력했다면 토큰의 범위와 일치해야 합니다.
- 재시작은 **지정한 서비스·환경의 실행 중인 배포**를 조회한 후 요청합니다.
  실행 중인 배포가 없으면 다른 서비스나 실패한 배포를 임의로 재시작하지 않습니다.
- 기존 사용자 지정 재시작 Webhook은 Service ID가 비어 있을 때만 이전 방식으로 사용합니다.
  API 방식으로 전환하려면 새 대상 ID를 입력하세요. 기존 URL은 자동 삭제하지 않습니다.

### GitHub

- 상태 조회에는 저장소의 **Actions 읽기**, 실행에는 **Actions 쓰기** 권한이 필요합니다.
  저장소 자체에도 접근할 수 있어야 합니다. 클래식 PAT의 비공개 저장소에는 `repo` 범위가 필요합니다.
- 워크플로에 `workflow_dispatch`가 활성화되어 있어야 합니다.
- 워크플로는 `deploy.yml` 같은 파일명 또는 숫자 ID를 입력합니다.
- 브랜치/태그를 비우면 저장소 API에서 기본 브랜치를 읽습니다. `main`으로 임의 가정하지 않습니다.
- 입력값은 선택 사항이며 예: `{"target":"staging"}`. 워크플로가 요구하는 입력을 맞춰야 합니다.
- 기존 공식 workflow dispatch URL도 호환됩니다. 임의 URL로 인증 토큰을 보내지 않습니다.

## 실행 결과와 안전장치

- `요청 접수`는 API가 요청을 받아들였다는 뜻이며 **빌드/배포/재시작 완료를 뜻하지 않습니다**.
  최종 결과는 같은 대상의 상태 기능에서 확인하세요.
- 배치·설정 복원·주기 조회에서는 배포/캐시 삭제/재시작 요청을 보내지 않습니다.
- 실행 요청을 처리하는 동안 같은 버튼의 추가 누름을 대기열에 쌓지 않습니다.
- 입력 변경/버튼 제거 뒤 도착한 오래된 조회 결과는 적용하지 않습니다.
- 토큰·Webhook 주소·응답 본문을 오류 로그에 출력하지 않습니다.
- 기존 배치의 액션 ID, 아이콘과 사용자 설정을 유지하며 Vercel 모니터링은 되살리지 않습니다.

## 검증 범위

자동 테스트는 HTTP를 모의 처리합니다. 실제 계정의 권한과 운영 환경은 사용자가 확인해야 합니다.
실제 배포·캐시 삭제·재시작은 자동 테스트에서 실행하지 않습니다.

## 공식 API 근거

- [Cloudflare Pages 배포 목록](https://developers.cloudflare.com/api/resources/pages/subresources/projects/subresources/deployments/methods/list/)
- [Cloudflare 캐시 삭제](https://developers.cloudflare.com/api/resources/cache/methods/purge/)
- [Railway API 인증](https://docs.railway.com/integrations/api)
- [Railway 배포 조회·재시작 공식 예제](https://github.com/railwayapp/docs/blob/main/content/docs/integrations/api/manage-deployments.md)
- [GitHub 워크플로 API](https://docs.github.com/en/rest/actions/workflows)
- [Netlify API 안내](https://docs.netlify.com/api-and-cli-guides/api-guides/get-started-with-api/)
