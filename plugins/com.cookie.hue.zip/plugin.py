import asyncio
import urllib.request
import json
import comtypes

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        # 🚀 [추가] 멀티액션을 위해 마지막으로 성공한 설정값을 기억합니다.
        self.last_valid_settings = {}

    async def handle_message(self, data):
        event = data.get("event")
        # settings.html(PI)와 엔진에서 보낸 표준 command를 읽습니다.
        command = data.get("payload", {}).get("command")

        if event == "keyDown":
            await self.on_key_down(data)
        elif command == "register_bridge":
            ip = data.get("payload", {}).get("ip")
            context = data.get("context")
            result = await asyncio.to_thread(self._register_bridge, ip)
            await self.runner.send_message({
                "event": "sendToPropertyInspector", "context": context, "payload": result
            })

    def _register_bridge(self, ip):
        """휴 브릿지에 API 키를 요청합니다 (CORS 우회)"""
        url = f"http://{ip}/api"
        payload = json.dumps({"devicetype":"cookiedeck#pro"}).encode('utf-8')
        try:
            req = urllib.request.Request(url, data=payload, method="POST")
            with urllib.request.urlopen(req, timeout=3) as res:
                response_data = json.loads(res.read().decode())
                if isinstance(response_data, list) and "success" in response_data[0]:
                    return {"command": "bridge_registered", "username": response_data[0]["success"]["username"]}
                else:
                    return {"command": "bridge_error", "msg": "휴(Hue) 브릿지 기기의 동그란 물리 버튼을 먼저 누른 후 다시 시도하세요!"}
        except Exception as e:
            return {"command": "bridge_error", "msg": f"연결 실패. IP 주소가 정확한지 확인하세요. ({e})"}

    def control_hue(self, ip, username, light_id, settings):
        """조명 제어 핵심 로직"""
        comtypes.CoInitialize()
        try:
            if not ip or not username or not light_id:
                print(f"[{self.uuid}] ⚠️ 제어 정보가 부족합니다. (IP: {ip}, ID: {light_id})")
                return

            base_url = f"http://{ip}/api/{username}/lights/{light_id}"
            put_url = f"{base_url}/state"
            # 🚀 표준 규격 command를 사용하여 액션을 결정합니다.
            action_type = settings.get("command", "toggle")
            payload = {}

            # 현재 상태 가져오기
            current_state = {}
            if action_type in ["toggle", "adj_brightness", "adj_colortemp"]:
                with urllib.request.urlopen(base_url, timeout=2) as res:
                    current_state = json.loads(res.read().decode()).get("state", {})

            # 액션별 페이로드 생성 로직
            if action_type == "toggle":
                payload = {"on": not current_state.get("on", False)}
            elif action_type == "on":
                payload = {"on": True}
            elif action_type == "off":
                payload = {"on": False}
            elif action_type == "set_brightness":
                payload = {"on": True, "bri": int(settings.get("hue_brightness", 128))}
            elif action_type == "adj_brightness":
                current_bri = current_state.get("bri", 128)
                adj_val = int(254 * (int(settings.get("hue_adj_brightness_val", 20)) / 100))
                new_bri = max(1, min(254, current_bri + adj_val))
                payload = {"on": True, "bri": new_bri}
            elif action_type == "set_colortemp":
                payload = {"on": True, "ct": int(settings.get("hue_ct", 366))}
            elif action_type == "adj_colortemp":
                current_ct = current_state.get("ct", 366)
                adj_val = int(settings.get("hue_adj_ct_val", 30))
                new_ct = max(153, min(500, current_ct + adj_val))
                payload = {"on": True, "ct": new_ct}
            elif action_type == "set_color":
                colors = {"red":[0.675,0.322], "green":[0.409,0.518], "blue":[0.167,0.04], "yellow":[0.432,0.499], "white":[0.3127,0.329], "purple":[0.24,0.1], "pink":[0.4, 0.2]}
                payload = {"on": True, "xy": colors.get(settings.get("hue_color", "white"))}
            elif action_type == "cycle_color":
                if current_state.get("effect") == "colorloop":
                    payload = {"effect": "none"}
                else:
                    payload = {"on": True, "effect": "colorloop"}

            if payload:
                req = urllib.request.Request(put_url, data=json.dumps(payload).encode(), method="PUT")
                with urllib.request.urlopen(req, timeout=2):
                    print(f"[{self.uuid}] Hue 명령 '{action_type}' 전송 성공.")

        except Exception as e:
            print(f"[{self.uuid}] Control Error: {e}")
        finally:
            comtypes.CoUninitialize()

    async def on_key_down(self, data):
        # 🚀 [표준화 핵심] 엔진에서 들어온 현재 데이터
        incoming_settings = data.get("payload", {}).get("settings", {})
        
        # 1. IP 정보가 포함되어 있다면(일반 버튼 클릭), 캐시를 업데이트합니다.
        if incoming_settings.get("hue_ip"):
            self.last_valid_settings.update(incoming_settings)
        
        # 2. 마지막 유효 설정과 현재 명령을 병합합니다. (멀티액션 대응)
        # 멀티액션의 경우 incoming_settings에는 {"command": "on"}만 들어있으므로,
        # 기존에 저장된 IP, ID 정보와 합쳐서 완벽한 페이로드를 만듭니다.
        final_settings = {**self.last_valid_settings, **incoming_settings}
        
        ip = final_settings.get("hue_ip")
        username = final_settings.get("hue_username")
        light_id = final_settings.get("hue_light_id")
        
        # 3. 병합된 전체 설정을 바탕으로 제어 함수 호출
        await asyncio.to_thread(self.control_hue, ip, username, light_id, final_settings)