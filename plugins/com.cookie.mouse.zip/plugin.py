import asyncio
from pynput.mouse import Button, Controller
import os

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.mouse = Controller()
        self.is_dragging = False
        self.NORMAL_STEP = 10
        self.SLOW_STEP = 1
        self.SCROLL_STEP = 2
        self.context_settings = {}
        
        # 🚀 [추가됨] 소수점 픽셀 누적용 변수 (부드러운 아날로그 이동을 위해 필수!)
        self.analog_remainder_x = 0.0
        self.analog_remainder_y = 0.0

        self.action_map = {
            "click_left": lambda: self.mouse.click(Button.left, 1),
            "click_right": lambda: self.mouse.click(Button.right, 1),
            "click_middle": lambda: self.mouse.click(Button.middle, 1),
            "click_back": lambda: self.mouse.click(Button.x1, 1),
            "click_forward": lambda: self.mouse.click(Button.x2, 1),
            "double_click": lambda: self.mouse.click(Button.left, 2),
            "toggle_drag": self.handle_drag_toggle,
            "scroll_up": lambda: self.mouse.scroll(0, self.SCROLL_STEP),
            "scroll_down": lambda: self.mouse.scroll(0, -self.SCROLL_STEP),
            "scroll_left": lambda: self.mouse.scroll(-self.SCROLL_STEP, 0),
            "scroll_right": lambda: self.mouse.scroll(self.SCROLL_STEP, 0),
            "move_up": lambda: self.mouse.move(0, -self.NORMAL_STEP),
            "move_down": lambda: self.mouse.move(0, self.NORMAL_STEP),
            "move_left": lambda: self.mouse.move(-self.NORMAL_STEP, 0),
            "move_right": lambda: self.mouse.move(self.NORMAL_STEP, 0),
            "move_up_slow": lambda: self.mouse.move(0, -self.SLOW_STEP),
            "move_down_slow": lambda: self.mouse.move(0, self.SLOW_STEP),
            "move_left_slow": lambda: self.mouse.move(-self.SLOW_STEP, 0),
            "move_right_slow": lambda: self.mouse.move(self.SLOW_STEP, 0),
            "analog_mouse": lambda: None, # 아날로그는 on_axis_moved에서 별도 처리됨
        }

        self.icon_map = {
            "analog_mouse": "MOVE_UP", # 아날로그 전용 아이콘이 없으므로 MOVE_UP 재사용
            "click_left": "CLICK_LEFT",
            "click_right": "CLICK_RIGHT",
            "double_click": "DOUBLE_CLICK",
            "toggle_drag": "TOGGLE_DRAG",
            "click_middle": "CLICK_MIDDLE",
            "click_back": "CLICK_BACK",
            "click_forward": "CLICK_FORWARD",
            "scroll_up": "SCROLL_UP",
            "scroll_down": "SCROLL_DOWN",
            "scroll_left": "SCROLL_LEFT",
            "scroll_right": "SCROLL_RIGHT",
            "move_up": "MOVE_UP",
            "move_down": "MOVE_DOWN",
            "move_left": "MOVE_LEFT",
            "move_right": "MOVE_RIGHT",
            "move_up_slow": "MOVE_UP_SLOW",
            "move_down_slow": "MOVE_DOWN_SLOW",
            "move_left_slow": "MOVE_LEFT_SLOW",
            "move_right_slow": "MOVE_RIGHT_SLOW",
        }

    def _default_action(self):
        return "click_left"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or self._default_action()
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        # 🚀 [핵심 추가] 아날로그 데이터 수신 시 처리
        if event == "axisMoved":
            # 등록된 버튼들 중 하나라도 'analog_mouse' 모드인지 확인
            is_analog_enabled = any(
                s.get("command") == "analog_mouse" 
                for s in self.context_settings.values()
            )
            if is_analog_enabled:
                await self.on_axis_moved(data)
            return

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            await self._send_builtin_icon(context, action_command or settings.get("command") or cached.get("command") or self._default_action())
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        final_settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = final_settings

        selected_action = final_settings.get("command") or self._default_action()
        action_func = self.action_map.get(selected_action)

        if action_func and selected_action != "analog_mouse":
            await asyncio.to_thread(action_func)

    # 🚀 [핵심 추가] 아날로그 마우스 커서 이동 엔진
    async def on_axis_moved(self, data):
        payload = data.get("payload", {})
        x_val = payload.get("x", 0)
        y_val = payload.get("y", 0)
        
        # 데드존(0,0)에 들어오면 누적된 소수점 초기화
        if x_val == 0 and y_val == 0:
            self.analog_remainder_x = 0.0
            self.analog_remainder_y = 0.0
            return
            
        def calc_speed(val):
            if val == 0: return 0.0
            sign = 1 if val > 0 else -1
            # 127로 정규화 (0.0 ~ 1.0)
            norm = abs(val) / 127.0
            # 제곱(Square) 곡선을 사용하여, 살짝 밀면 정밀하게, 끝까지 밀면 휙휙 움직이게 함
            # 숫자(35.0)를 높이면 마우스 최대 속도가 더 빨라집니다.
            return sign * (norm ** 2) * 35.0 
            
        # 1. 이론적인 이동 픽셀 계산 (소수점 포함)
        dx_float = calc_speed(x_val) + self.analog_remainder_x
        dy_float = calc_speed(y_val) + self.analog_remainder_y
        
        # 2. 실제로 이동할 정수(int) 픽셀
        dx_int = int(dx_float)
        dy_int = int(dy_float)
        
        # 3. 소수점 버려진 값(Remainder) 저장해뒀다가 다음 턴에 합산 (매끄러운 이동의 핵심)
        self.analog_remainder_x = dx_float - dx_int
        self.analog_remainder_y = dy_float - dy_int
        
        # 4. 마우스 이동
        if dx_int != 0 or dy_int != 0:
            self.mouse.move(dx_int, dy_int)

    def handle_drag_toggle(self):
        if self.is_dragging:
            self.mouse.release(Button.left)
            self.is_dragging = False
            print(f"[{self.uuid}] Drag Released")
        else:
            self.mouse.press(Button.left)
            self.is_dragging = True
            print(f"[{self.uuid}] Drag Started")