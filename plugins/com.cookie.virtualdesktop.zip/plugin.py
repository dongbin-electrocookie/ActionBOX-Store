import asyncio
import ctypes
import sys
import time
import os

VK_CONTROL = 0x11
VK_LWIN = 0x5B
VK_LEFT = 0x25
VK_RIGHT = 0x27
VK_D = 0x44
VK_F4 = 0x73
VK_TAB = 0x09

KEYEVENTF_KEYDOWN = 0x0000
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_EXTENDEDKEY = 0x0001

def press_hardware_key(vk, is_arrow=False):
    scan = ctypes.windll.user32.MapVirtualKeyA(vk, 0)
    flags = KEYEVENTF_KEYDOWN
    if is_arrow:
        flags |= KEYEVENTF_EXTENDEDKEY
    ctypes.windll.user32.keybd_event(vk, scan, flags, 0)

def release_hardware_key(vk, is_arrow=False):
    scan = ctypes.windll.user32.MapVirtualKeyA(vk, 0)
    flags = KEYEVENTF_KEYUP
    if is_arrow:
        flags |= KEYEVENTF_EXTENDEDKEY
    ctypes.windll.user32.keybd_event(vk, scan, flags, 0)

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.icon_map = {
            "next": "STATE_NEXT",
            "prev": "STATE_PREV",
            "new": "STATE_NEW",
            "close": "STATE_CLOSE",
            "view": "STATE_VIEW",
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "next", "STATE_NEXT")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "command", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        state_val = None
        if "#" in (action_id or ""):
            state_val = action_id.split("#")[-1]

        default_action = state_val or "next"
        if default_action not in self.icon_map:
            default_action = "next"

        new_settings = {
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        # Initial placement: icon only, never overwrite title
        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        action_id = data.get("action", "")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or "next")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if sys.platform != "win32":
            return

        action_id = data.get("action", "")
        state_val = None
        if "#" in action_id:
            state_val = action_id.split("#")[-1]

        settings = data.get("payload", {}).get("settings", {})
        action = settings.get("command") or state_val or "next"

        def run_vd_command():
            press_hardware_key(VK_CONTROL)
            press_hardware_key(VK_LWIN)
            time.sleep(0.05)

            if action == "next":
                press_hardware_key(VK_RIGHT, is_arrow=True)
                time.sleep(0.05)
                release_hardware_key(VK_RIGHT, is_arrow=True)
            elif action == "prev":
                press_hardware_key(VK_LEFT, is_arrow=True)
                time.sleep(0.05)
                release_hardware_key(VK_LEFT, is_arrow=True)
            elif action == "new":
                press_hardware_key(VK_D)
                time.sleep(0.05)
                release_hardware_key(VK_D)
            elif action == "close":
                press_hardware_key(VK_F4)
                time.sleep(0.05)
                release_hardware_key(VK_F4)
            elif action == "view":
                release_hardware_key(VK_CONTROL)
                press_hardware_key(VK_TAB)
                time.sleep(0.05)
                release_hardware_key(VK_TAB)

            time.sleep(0.05)
            release_hardware_key(VK_LWIN)
            release_hardware_key(VK_CONTROL)

        await asyncio.to_thread(run_vd_command)
