#target indesign
(function () {
    if (app.documents.length === 0) {
        alert("Open a document first.");
        return;
    }
    var stories = app.activeDocument.stories;
    var firstFrame = null;
    var count = 0;
    for (var i = 0; i < stories.length; i++) {
        if (stories[i].overflows) {
            count++;
            if (!firstFrame && stories[i].textContainers.length > 0) {
                firstFrame = stories[i].textContainers[0];
            }
        }
    }
    if (firstFrame) {
        app.select(firstFrame);
    }
    alert(count === 0 ? "No overset text found." : "Overset stories found: " + count);
}());
