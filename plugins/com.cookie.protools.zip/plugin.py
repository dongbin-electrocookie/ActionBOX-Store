import asyncio
import os
import sys

try:
    from utility.native_hotkeys import send_windows_hotkey
except ModuleNotFoundError:
    # The shared runner is also launched with utility/ as its import root.
    from native_hotkeys import send_windows_hotkey

try:
    import keyboard
except ImportError:
    keyboard = None

IS_WINDOWS = sys.platform.startswith("win")

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        # Windows defaults: Avid Pro Tools Shortcuts 2025.10, Transport/Edit/Zoom.
        # https://resources.avid.com/SupportFiles/PT/Pro_Tools_Shortcuts_2025.10.pdf
        self.hotkey_map = {
            "play_stop": "space",
            "record": "f12",
            "return_zero": "enter",
            "loop_toggle": "4",
            # Numeric Keypad mode must be Transport in Pro Tools preferences.
            "click_toggle": "num7",
            "tool_zoom": "f5",
            "tool_trim": "f6",
            "tool_select": "f7",
            "tool_grabber": "f8",
            "tool_scrub": "f9",
            "tool_pencil": "f10",
            "tool_smart": "f6+f7+f8",
            "separate": "b",
            "heal": "ctrl+h",
            "fade_in": "d",
            "fade_out": "g",
            "crossfade": "f",
            "undo": "z",
            "redo": "shift+z",
            "copy": "c",
            "paste": "ctrl+v",
            "cut": "x",
            "toggle_mix_edit": "ctrl+=",
            "zoom_in": "t",
            "zoom_out": "r",
            "zoom_vertical_in": "ctrl+alt+]",
            "zoom_vertical_out": "ctrl+alt+[",
            "fit_to_window": "alt+a",
            "new_track": "ctrl+shift+n",
            "group_tracks": "ctrl+g",
            # Non-Windows legacy Solo Clear remains unmapped.
        }

        # Match the four Windows defaults corrected from the 2026-10-23 report.
        # Keep the legacy non-Windows route and every other action unchanged.
        if IS_WINDOWS:
            self.hotkey_map.update({
                "solo_clear": "shift+s",
                "fade_in": "d",
                "fade_out": "g",
                "crossfade": "ctrl+f",
            })

        self.icon_map = {
            "play_stop": "Play - Stop",
            "record": "Record",
            "return_zero": "Return to Zero",
            "loop_toggle": "Loop Play Toggle",
            "click_toggle": "Click Toggle",
            "tool_smart": "Smart Tool",
            "tool_zoom": "Zoom Tool",
            "tool_trim": "Trim Tool",
            "tool_select": "Selector Tool",
            "tool_grabber": "Grabber Tool",
            "tool_scrub": "Scrubber Tool",
            "tool_pencil": "Pencil Tool",
            "separate": "Separate",
            "heal": "Heal",
            "fade_in": "Fade In",
            "fade_out": "Fade Out",
            "crossfade": "Crossfade",
            "undo": "Undo",
            "redo": "Redo",
            "copy": "Copy",
            "paste": "Paste",
            "cut": "Cut",
            "toggle_mix_edit": "Toggle Mix - Edit Window",
            "zoom_in": "Horizontal Zoom In",
            "zoom_out": "Horizontal Zoom Out",
            "zoom_vertical_in": "Vertical Waveform Zoom In",
            "zoom_vertical_out": "Vertical Waveform Zoom Out",
            "fit_to_window": "Fit to Window",
            "new_track": "New Track",
            "group_tracks": "Group Tracks",
            "solo_clear": "Solo Clear",
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "play_stop", "Play - Stop")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "pt_hotkey", "command", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "play_stop"
        new_settings = {
            "pt_hotkey": default_action,
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        # Initial placement: icon only, never overwrite title
        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("pt_hotkey") or settings.get("command") or "play_stop")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        payload = data.get("payload") or {}
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}
        action = settings.get("pt_hotkey") or settings.get("command")

        if action and action in self.hotkey_map:
            hotkey = self.hotkey_map[action]

            try:
                sent = await asyncio.to_thread(self._send_hotkey, action, hotkey)
            except Exception as exc:
                # Never retry a partial chord: a toggle could execute twice.
                print(f"[{self.uuid}] Pro Tools Hotkey Failed ({hotkey}): {exc}")
                return
            if sent:
                print(f"[{self.uuid}] Pro Tools Hotkey Sent: {hotkey}")

    def _send_hotkey(self, action, hotkey):
        if action == "tool_smart":
            return self._send_smart_tool()
        if IS_WINDOWS:
            # Preserve VK + physical scan code, including a real keypad 7.
            # No keyboard.send fallback after unsupported/failed native input.
            sent = send_windows_hotkey(hotkey.split("+"))
            if not sent:
                print(f"[{self.uuid}] Unsupported Pro Tools Hotkey: {hotkey}")
            return sent
        if not keyboard:
            return False
        # Keep the previous non-Windows route; this repair targets Windows.
        legacy_keys = {
            "click_toggle": "7", "paste": "v",
            "zoom_vertical_in": "alt+shift+]",
            "zoom_vertical_out": "alt+shift+[",
        }
        keyboard.send(legacy_keys.get(action, hotkey))
        return True

    def _send_smart_tool(self):
        # The common chord sender deliberately accepts only one ordinary key.
        if not keyboard:
            return False
        pressed = []
        try:
            for key in ('f6', 'f7', 'f8'):
                pressed.append(key)
                keyboard.press(key)
        finally:
            for key in reversed(pressed):
                try:
                    keyboard.release(key)
                except Exception as exc:
                    print(f"[{self.uuid}] Pro Tools Key Release Failed ({key}): {exc}")
        return True
