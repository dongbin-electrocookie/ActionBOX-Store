import asyncio
import os

try:
    import keyboard
except ImportError:
    keyboard = None

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.hotkey_map = {
            "play_in_editor": "alt+p",
            "stop_play": "esc",
            "build_all": "ctrl+shift+;",
            "build_lighting": "ctrl+shift+l",
            "view_perspective": "alt+g",
            "view_top": "alt+j",
            "view_front": "alt+h",
            "view_left": "alt+k",
            "mode_lit": "alt+4",
            "mode_unlit": "alt+3",
            "mode_wireframe": "alt+2",
            "toggle_fullscreen": "f11",
            "focus_selected": "f",
            "tool_select": "q",
            "tool_translate": "w",
            "tool_rotate": "e",
            "tool_scale": "r",
            "snap_to_floor": "end",
            "bp_compile": "f7",
            "bp_find_node": "ctrl+f",
            "bp_add_comment": "c",
            "undo": "ctrl+z",
            "redo": "ctrl+y",
            "duplicate": "ctrl+d",
            "save_all": "ctrl+shift+s",
            "content_browser": "ctrl+space"
        }

        self.icon_map = {
            "play_in_editor": "STATE_PLAY_IN_EDITOR",
            "stop_play": "STATE_STOP_PLAY",
            "build_all": "STATE_BUILD_ALL",
            "build_lighting": "STATE_BUILD_LIGHTING",
            "view_perspective": "STATE_VIEW_PERSPECTIVE",
            "view_top": "STATE_VIEW_TOP",
            "view_front": "STATE_VIEW_FRONT",
            "view_left": "STATE_VIEW_LEFT",
            "mode_lit": "STATE_MODE_LIT",
            "mode_unlit": "STATE_MODE_UNLIT",
            "mode_wireframe": "STATE_MODE_WIREFRAME",
            "toggle_fullscreen": "STATE_TOGGLE_FULLSCREEN",
            "focus_selected": "STATE_FOCUS_SELECTED",
            "tool_select": "STATE_TOOL_SELECT",
            "tool_translate": "STATE_TOOL_TRANSLATE",
            "tool_rotate": "STATE_TOOL_ROTATE",
            "tool_scale": "STATE_TOOL_SCALE",
            "snap_to_floor": "STATE_SNAP_TO_FLOOR",
            "bp_compile": "STATE_BP_COMPILE",
            "bp_find_node": "STATE_BP_FIND_NODE",
            "bp_add_comment": "STATE_BP_ADD_COMMENT",
            "undo": "STATE_UNDO",
            "redo": "STATE_REDO",
            "duplicate": "STATE_DUPLICATE",
            "save_all": "STATE_SAVE_ALL",
            "content_browser": "STATE_CONTENT_BROWSER"
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "play_in_editor", "STATE_PLAY_IN_EDITOR")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "ue_hotkey", "command", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "play_in_editor"
        new_settings = {
            "ue_hotkey": default_action,
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })
        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or settings.get("ue_hotkey") or "play_in_editor")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard:
            return

        settings = data.get("payload", {}).get("settings", {})
        action = settings.get("command") or settings.get("ue_hotkey")

        if action and action in self.hotkey_map:
            hotkey = self.hotkey_map[action]
            await asyncio.to_thread(keyboard.send, hotkey)
            print(f"[{self.uuid}] Unreal Engine hotkey sent: {hotkey}")
