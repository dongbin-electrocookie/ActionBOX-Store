import asyncio

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.current_octave_shift = 0

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.process_midi(data, is_pressed=True)
        elif event == "keyUp":
            await self.process_midi(data, is_pressed=False)

    async def process_midi(self, data, is_pressed):
        context = data.get("context")
        settings = data.get("payload", {}).get("settings", {})
        
        # HTML에서 콤보박스로 선택한 기능 가져오기
        midi_type = settings.get("midi_type", "note")
        channel = int(settings.get("channel", 1)) - 1
        
        status = 0
        d1 = 0
        d2 = 0

        # 1. MIDI Note
        if midi_type == "note":
            d1 = int(settings.get("d1", 60))
            d1 = max(0, min(127, d1 + self.current_octave_shift)) # 옥타브 적용
            if is_pressed:
                status = 0x90 | channel
                d2 = int(settings.get("d2", 100))
            else:
                status = 0x80 | channel # 떼면 Note Off
                d2 = 0

        # 2. MIDI CC
        elif midi_type == "cc":
            if not is_pressed: return
            status = 0xB0 | channel
            d1 = int(settings.get("d1", 60))
            d2 = int(settings.get("d2", 127))
            
        # 3. MIDI PC
        elif midi_type == "pc":
            if not is_pressed: return
            status = 0xC0 | channel
            d1 = int(settings.get("d1", 0))
            d2 = 0

        # 4. Octave Shift
        elif midi_type == "octave":
            if not is_pressed: return
            direction = settings.get("octave_dir", "up")
            if direction == "up":
                self.current_octave_shift = min(48, self.current_octave_shift + 12)
            else:
                self.current_octave_shift = max(-48, self.current_octave_shift - 12)
                
            oct_text = f"Octave\n{'+' if self.current_octave_shift > 0 else ''}{self.current_octave_shift // 12}"
            if self.current_octave_shift == 0: oct_text = "Octave\n0"
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": oct_text}})
            return # 미디 데이터 전송 안함

        # 5. Transport 제어
        elif midi_type == "transport":
            t_action = settings.get("transport_action", "play")
            t_map = {"rewind": 91, "fastforward": 92, "stop": 93, "play": 94, "record": 95, "cycle": 86}
            d1 = t_map.get(t_action, 94)
            d2 = 127 if is_pressed else 0
            status = 0x90 | channel

        # 6. Track Select
        elif midi_type == "track":
            track_dir = settings.get("track_dir", "next")
            d1 = 48 if track_dir == "prev" else 49
            d2 = 127 if is_pressed else 0
            status = 0x90 | channel

        else:
            return

        # 하드웨어 전송 패킷 생성
        payload = {
            "event": "sendToPlugin",
            "context": context,
            "payload": {
                "command": "direct_serial",
                "serial_cmd": 0x70,
                "serial_data": [status, d1, d2]
            }
        }
        await self.runner.send_message(payload)