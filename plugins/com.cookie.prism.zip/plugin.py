import asyncio
import websockets
import json
import os
import hashlib
import base64
import platform
import time

class OBSPlugin:
    def __init__(self):
        # 🚀 프리즘을 사용하신다면 com.cookie.prism으로, OBS라면 com.cookie.obs로 수정하세요.
        self.PLUGIN_UUID = "com.cookie.obs" 
        self.uri = "ws://localhost:8765"
        self.websocket = None
        
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_file = os.path.join(self.plugin_dir, 'obs_config.json')
        
        self.obs_request_queue = asyncio.Queue()
        self.obs_connection_task = None
        self.is_obs_connected = False
        
        self.desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")

        # 🚀 [대통합 표준] 버튼별(context) 설정값을 기억하기 위한 저장소
        # 멀티액션 신호(#데이터)가 올 때 누락된 장면/소스 정보를 여기서 꺼내 씁니다.
        self.last_valid_settings = {}

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.uri) as websocket:
                    self.websocket = websocket
                    await self.register()
                    await self.listen()
            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] CookieDeck connection failed: {e}. Retrying...")
                await asyncio.sleep(5)

    async def register(self):
        await self.websocket.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
        print(f"[{self.PLUGIN_UUID}] Registered with CookieDeck.")
        self.start_obs_connection()

    async def listen(self):
        async for message in self.websocket:
            try:
                data = json.loads(message)
                event = data.get("event")
                context = data.get("context") or data.get("key")
                payload = data.get("payload") or {}

                if event == "keyDidAppear":
                    # 버튼이 나타날 때 기존 설정을 메모리에 로드
                    settings = payload.get("settings", {})
                    if settings:
                        self.last_valid_settings[context] = settings
                
                elif event == "didReceiveSettings":
                    # 설정창(PI)에서 값이 바뀌면 메모리 업데이트
                    if context not in self.last_valid_settings:
                        self.last_valid_settings[context] = {}
                    self.last_valid_settings[context].update(payload)

                elif event == "keyDown":
                    await self.on_key_down(data)

                elif event == "sendToPlugin":
                    await self.on_pi_request(payload, context)

                # 명령어 형태의 직접 메시지 처리
                if isinstance(data, dict) and data.get("command") and not event:
                    await self.on_pi_request(data, context)

            except Exception as e:
                print(f"[{self.PLUGIN_UUID} ERROR] Listen Loop: {e}")

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {})
        
        # 🚀 1. 유효한 설정이 들어오면 버튼별 메모리에 저장
        if incoming_settings:
            if context not in self.last_valid_settings:
                self.last_valid_settings[context] = {}
            # 값이 있는 설정만 선별적으로 업데이트 (캐시)
            filtered = {k: v for k, v in incoming_settings.items() if v is not None and v != ""}
            self.last_valid_settings[context].update(filtered)

        # 🚀 2. 메모리(과거)와 현재 데이터를 합쳐서 최종 실행 명령 생성 (멀티액션 대응 핵심)
        saved = self.last_valid_settings.get(context, {})
        final_settings = {**saved, **incoming_settings}
        
        # 🚀 3. [표준화] 'command'를 우선 확인하고, 없으면 기존 'obs_action'을 사용
        obs_action = final_settings.get("command") or final_settings.get("obs_action", "stream_toggle")
        
        req_type = None
        req_data = {}

        # --- 액션 매핑 로직 (OBS WebSocket 5.x 규격) ---
        
        # 1. 방송/녹화/가상카메라
        if obs_action == "stream_toggle": req_type = "ToggleStream"
        elif obs_action == "record_toggle": req_type = "ToggleRecord"
        elif obs_action == "virtual_cam_toggle": req_type = "ToggleVirtualCam"
        
        # 2. 리플레이 버퍼
        elif obs_action == "replay_buffer_toggle": req_type = "ToggleReplayBuffer"
        elif obs_action == "replay_buffer_save": req_type = "SaveReplayBuffer"
        
        # 3. 마커/챕터
        elif obs_action == "stream_marker": req_type = "CreateStreamMarker"
        elif obs_action == "record_chapter": 
            req_type = "CreateRecordChapter"
            req_data = {"chapterName": "CookieDeck Marker"}

        # 4. 스튜디오 모드 & 트랜지션
        elif obs_action == "studio_mode_toggle": req_type = "ToggleStudioMode"
        elif obs_action == "trigger_transition": req_type = "TriggerStudioModeTransition"
        elif obs_action == "set_transition":
            trans_name = final_settings.get("target_transition")
            if trans_name:
                req_type = "SetCurrentSceneTransition"
                req_data = {"transitionName": trans_name}

        # 5. 장면/소스 제어 (캐시된 데이터 활용)
        elif obs_action == "change_scene":
            scene_name = final_settings.get("target_scene")
            if scene_name: 
                req_type = "SetCurrentProgramScene"
                req_data = {"sceneName": scene_name}

        elif obs_action == "toggle_source":
            target_nm = final_settings.get("target_name", "")
            parts = target_nm.split(';')
            if len(parts) == 2:
                req_type = "ToggleSceneItemEnabled"
                req_data = {"sceneName": parts[0].strip(), "sceneItemName": parts[1].strip()}

        elif obs_action == "filter_control":
            src = final_settings.get("target_input")
            flt = final_settings.get("filter_name")
            state = final_settings.get("enable_state", "true") == "true"
            if src and flt:
                req_type = "SetSourceFilterEnabled"
                req_data = {"sourceName": src, "filterName": flt, "filterEnabled": state}

        # 6. 미디어/오디오/스크린샷
        elif obs_action == "media_play_pause":
            inp = final_settings.get("target_input")
            if inp: 
                req_type = "TriggerMediaInputAction"
                req_data = {"inputName": inp, "mediaAction": "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_PLAY_PAUSE"}
        
        elif obs_action == "toggle_mute":
            inp = final_settings.get("target_input")
            if inp: req_type = "ToggleInputMute", req_data = {"inputName": inp}

        elif obs_action == "screenshot_source":
            src = final_settings.get("target_input")
            if src:
                req_type = "SaveSourceScreenshot"
                timestamp = time.strftime("%Y%m%d_%H%M%S")
                filename = f"OBS_{src}_{timestamp}.png".replace(" ", "_")
                save_path = os.path.join(self.desktop_path, filename).replace("\\", "/")
                req_data = {"sourceName": src, "imageFormat": "png", "imageFilePath": save_path}

        if req_type:
            await self.send_to_obs(req_type, req_data, f"{obs_action}-{context}")

    async def on_pi_request(self, payload, context):
        command = payload.get("command")
        
        if command == "getSceneList":
            await self.send_to_obs("GetSceneList", {}, f"get-scenes-{context}")
        elif command == "getInputList":
            await self.send_to_obs("GetInputList", {}, f"get-inputs-{context}")
        elif command == "getTransitionList":
            await self.send_to_obs("GetSceneTransitionList", {}, f"get-transitions-{context}")
            
        elif command == "getObsSettings":
            settings = {}
            if os.path.exists(self.config_file):
                try:
                    with open(self.config_file, 'r') as f: settings = json.load(f)
                except: pass
            await self.websocket.send(json.dumps({
                "event": "sendToPropertyInspector", "context": context, "payload": {"command": "obsSettings", "settings": settings}
            }))
            
        elif command == "setObsSettings":
            try:
                with open(self.config_file, 'w', encoding='utf-8') as f: 
                    json.dump(payload.get("settings", {}), f, indent=4)
                self.start_obs_connection()
                await self.websocket.send(json.dumps({"event": "closeSettings", "key": context}))
            except: pass

    # --- OBS WebSocket 연결 및 관리 로직 ---

    def start_obs_connection(self):
        if self.obs_connection_task and not self.obs_connection_task.done():
            self.obs_connection_task.cancel()
        self.obs_connection_task = asyncio.create_task(self.obs_reconnect_loop())

    async def obs_reconnect_loop(self):
        while True:
            settings = {}
            if os.path.exists(self.config_file):
                try:
                    with open(self.config_file, 'r') as f: settings = json.load(f)
                except: pass
            
            obs_url = f"ws://{settings.get('ip', 'localhost')}:{settings.get('port', 4455)}"
            if not self.is_obs_connected:
                await self.obs_task(obs_url, settings.get("password", ""))
            await asyncio.sleep(3)

    async def send_to_obs(self, req_type, req_data, req_id):
        if self.is_obs_connected:
            await self.obs_request_queue.put({
                "op": 6, "d": {"requestType": req_type, "requestId": req_id, "requestData": req_data}
            })

    async def obs_task(self, obs_url, password):
        self.is_obs_connected = False
        try:
            async with websockets.connect(obs_url, open_timeout=2) as ws:
                hello = json.loads(await ws.recv())
                if hello['d'].get('authentication'):
                    secret = base64.b64encode(hashlib.sha256((password + hello['d']['authentication']['salt']).encode()).digest()).decode()
                    auth = base64.b64encode(hashlib.sha256((secret + hello['d']['authentication']['challenge']).encode()).digest()).decode()
                    await ws.send(json.dumps({"op": 1, "d": {"rpcVersion": 1, "authentication": auth}}))
                    if (json.loads(await ws.recv()))['op'] != 2: return
                
                print(f"[{self.PLUGIN_UUID}] ✅ Connected to OBS.")
                self.is_obs_connected = True
                await asyncio.gather(self.obs_consumer(ws), self.obs_producer(ws))
        except: pass
        finally: self.is_obs_connected = False

    async def obs_consumer(self, ws):
        async for message in ws:
            data = json.loads(message)
            if data.get('op') == 7: # RequestResponse
                d = data.get('d', {})
                req_id = d.get('requestId', '')
                res_data = d.get('responseData', {})
                
                # PI로 목록 전달 (장면, 소스, 트랜지션)
                for key_type, cmd_name in [("get-scenes-", "sceneList"), ("get-inputs-", "inputList"), ("get-transitions-", "transitionList")]:
                    if key_type in req_id:
                        ctx = req_id.replace(key_type, "")
                        data_key = "scenes" if "scenes" in cmd_name else "inputs" if "inputs" in cmd_name else "transitions"
                        await self.websocket.send(json.dumps({
                            "event": "sendToPropertyInspector", "context": ctx, 
                            "payload": {"command": cmd_name, data_key: res_data.get(data_key, [])}
                        }))

    async def obs_producer(self, ws):
        while True:
            request = await self.obs_request_queue.get()
            await ws.send(json.dumps(request))
            self.obs_request_queue.task_done()

async def main():
    plugin = OBSPlugin()
    await plugin.connect()

if __name__ == "__main__":
    asyncio.run(main())