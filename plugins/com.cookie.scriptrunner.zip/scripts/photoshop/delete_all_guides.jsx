#target photoshop

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else if (app.activeDocument.guides.length === 0) {
    alert("삭제할 가이드가 없습니다.");
} else if (confirm("현재 문서의 가이드를 모두 삭제할까요?")) {
    app.activeDocument.guides.removeAll();
}
