import sys
import os
import asyncio
import json
import subprocess
import threading

# --- OS 확인 및 라이브러리 임포트 ---
IS_WINDOWS = (sys.platform == "win32")
sc = None
ToastNotifier = None
libraries_ok = False

if IS_WINDOWS:
    try:
        import soundcard as sc
        from win10toast import ToastNotifier
        libraries_ok = True
    except ImportError:
        print("[Audio Switcher Error] Required libraries (soundcard, win10toast) missing.")
        # sys.exit(1) <--- 절대 금지 (러너 전체가 죽음)

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.toaster = ToastNotifier() if (IS_WINDOWS and libraries_ok) else None
        
        # EndpointController.exe 경로 설정
        self.endpoint_controller_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "EndpointController.exe"
        )
        
        if IS_WINDOWS and not os.path.exists(self.endpoint_controller_path):
            print(f"[{self.uuid} ERROR] EndpointController.exe not found!")
            self.endpoint_controller_path = None

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not libraries_ok or not IS_WINDOWS:
            print(f"[{self.uuid}] Plugin disabled: libraries missing or not Windows.")
            return

        action_id = data.get("action")
        # print(f"[{self.uuid}] Action triggered: {action_id}")
        
        is_output = (action_id == "com.cookie.audioswitcher.cycle_output")
        
        # 오디오 장치 변경은 Blocking I/O (시스템 호출)가 포함되므로
        # 반드시 스레드로 분리하여 실행해야 다른 플러그인이 멈추지 않습니다.
        await asyncio.to_thread(self.cycle_default_device, is_output)

    def cycle_default_device(self, is_output=True):
        """오디오 장치를 순환하고 사용자에게 알림을 표시합니다."""
        if not self.endpoint_controller_path:
            return

        try:
            # 1. 장치 목록 조회 (soundcard)
            if is_output:
                all_devices, current_default = sc.all_speakers(), sc.default_speaker()
            else:
                all_devices, current_default = sc.all_microphones(), sc.default_microphone()
            
            if len(all_devices) < 2:
                print(f"[{self.uuid}] Not enough devices to cycle.")
                return
            
            # 2. 다음 장치 인덱스 계산
            device_names = [dev.name for dev in all_devices]
            try:
                current_index = device_names.index(current_default.name)
            except ValueError:
                current_index = -1 
            
            next_index = (current_index + 1) % len(all_devices)
            next_device = all_devices[next_index]
            
            # 3. 외부 프로그램으로 장치 변경 (EndpointController)
            command = [self.endpoint_controller_path, str(next_index + 1)]
            result = subprocess.run(command, capture_output=True, text=True, check=False, creationflags=subprocess.CREATE_NO_WINDOW)
            
            if result.returncode == 0:
                # 4. 알림 표시 (Toast)
                # ToastNotifier는 자체적으로 스레드 처리가 까다로울 수 있으나,
                # 이 함수 자체가 이미 to_thread로 실행 중이므로 여기서는 바로 호출해도 됩니다.
                # 다만, Toast가 너무 오래 걸리면 이 스레드가 늦게 끝나므로, 
                # Toast만 별도 스레드로 띄우는 기존 로직을 유지하는 것도 안전합니다.
                
                device_type = "출력 장치" if is_output else "입력 장치"
                title = "오디오 장치 변경"
                message = f"활성 {device_type}:\n{next_device.name}"
                
                if self.toaster:
                    threading.Thread(
                        target=self.toaster.show_toast,
                        args=(title, message),
                        kwargs={"duration": 3, "threaded": False},
                        daemon=True
                    ).start()
                
                print(f"[{self.uuid}] Switched to: {next_device.name}")
            else:
                print(f"[{self.uuid}] Failed to switch. Error: {result.stderr.strip()}")

        except Exception as e:
            print(f"[{self.uuid} CRITICAL] cycle_default_device failed: {e}")