import asyncio
import os

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.last_valid_settings = {}

        self.action_map = {
            "file_save": "ctrl+s",
            "file_save_as": "ctrl+shift+s",
            "brush_size_down": "[",
            "brush_size_up": "]",
            "brush_hard_down": "shift+[",
            "brush_hard_up": "shift+]",
            "edit_fill_fg": "alt+delete",
            "edit_fill_bg": "ctrl+delete",
            "tool_move": "v",
            "tool_marquee": "m",
            "tool_zoom": "z",
            "tool_lasso": "l",
            "tool_magic": "w",
            "tool_crop": "c",
            "tool_eyedropper": "i",
            "tool_brush": "b",
            "tool_eraser": "e",
            "tool_pen": "p",
            "tool_type": "t",
            "layer_new": "ctrl+shift+n",
            "layer_copy": "ctrl+j",
            "layer_merge": "ctrl+e",
            "layer_group": "ctrl+g",
            "select_all": "ctrl+a",
            "select_deselect": "ctrl+d",
            "select_invert": "ctrl+shift+i",
            "edit_undo": "ctrl+z",
            "edit_redo": "ctrl+shift+z",
            "edit_transform": "ctrl+t",
            "adj_levels": "ctrl+l",
            "adj_curves": "ctrl+m",
            "adj_hue": "ctrl+u",
            "adj_balance": "ctrl+b",
            "view_zoom_in": "ctrl+=",
            "view_zoom_out": "ctrl+-",
            "view_fit": "ctrl+0"
        }

        self.icon_map = {
            "file_save": "STATE_FILE_SAVE",
            "file_save_as": "STATE_FILE_SAVE_AS",
            "brush_size_down": "STATE_BRUSH_SIZE_DOWN",
            "brush_size_up": "STATE_BRUSH_SIZE_UP",
            "brush_hard_down": "STATE_BRUSH_HARD_DOWN",
            "brush_hard_up": "STATE_BRUSH_HARD_UP",
            "edit_fill_fg": "STATE_EDIT_FILL_FG",
            "edit_fill_bg": "STATE_EDIT_FILL_BG",
            "tool_move": "STATE_TOOL_MOVE",
            "tool_marquee": "STATE_TOOL_MARQUEE",
            "tool_zoom": "STATE_TOOL_ZOOM",
            "tool_lasso": "STATE_TOOL_LASSO",
            "tool_magic": "STATE_TOOL_MAGIC",
            "tool_crop": "STATE_TOOL_CROP",
            "tool_eyedropper": "STATE_TOOL_EYEDROPPER",
            "tool_brush": "STATE_TOOL_BRUSH",
            "tool_eraser": "STATE_TOOL_ERASER",
            "tool_pen": "STATE_TOOL_PEN",
            "tool_type": "STATE_TOOL_TYPE",
            "layer_new": "STATE_LAYER_NEW",
            "layer_copy": "STATE_LAYER_COPY",
            "layer_merge": "STATE_LAYER_MERGE",
            "layer_group": "STATE_LAYER_GROUP",
            "select_all": "STATE_SELECT_ALL",
            "select_deselect": "STATE_SELECT_DESELECT",
            "select_invert": "STATE_SELECT_INVERT",
            "edit_undo": "STATE_EDIT_UNDO",
            "edit_redo": "STATE_EDIT_REDO",
            "edit_transform": "STATE_EDIT_TRANSFORM",
            "adj_levels": "STATE_ADJ_LEVELS",
            "adj_curves": "STATE_ADJ_CURVES",
            "adj_hue": "STATE_ADJ_HUE",
            "adj_balance": "STATE_ADJ_BALANCE",
            "view_zoom_in": "STATE_VIEW_ZOOM_IN",
            "view_zoom_out": "STATE_VIEW_ZOOM_OUT",
            "view_fit": "STATE_VIEW_FIT"
        }

    def _default_action(self):
        return "tool_brush"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or self._default_action()
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.last_valid_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.last_valid_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")

        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.last_valid_settings.get(context, {})
                self.last_valid_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.last_valid_settings:
                self.last_valid_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            current_action = action_command or settings.get("command") or self.last_valid_settings.get(context, {}).get("command") or self._default_action()
            await self._send_builtin_icon(context, current_action)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available:
            return

        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.last_valid_settings.get(context, {})
        final_settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.last_valid_settings[context] = final_settings

        selected_action = final_settings.get("command", self._default_action())
        if selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)
