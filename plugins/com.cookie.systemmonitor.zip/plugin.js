// plugin.js (중복 실행 방지 기능 탑재 버전)

const WebSocket = require('ws');
const { Worker, isMainThread, parentPort } = require('worker_threads');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

// CookieDeck 인자 파싱
const args = {};
for (let i = 2; i < process.argv.length; i += 2) {
    args[process.argv[i]] = process.argv[i + 1];
}
const port = args['-port'] || '8765';
const pluginUUID = args['-pluginUUID'] || 'com.cookie.systemmonitor';
const registerEvent = args['-registerEvent'] || 'register';
const uri = `ws://localhost:${port}`;

let activeKeys = {};
let cookieDeckSocket = null;

let reconnectAttempts = 0;     
const MAX_RETRIES = 5;         

// LHM 경로
const lhmPath = path.resolve(__dirname, 'LibreHardwareMonitor', 'LibreHardwareMonitor.exe');
const exeName = "LibreHardwareMonitor.exe";

// --- [메인 스레드] ---
if (isMainThread) {
    
    // ★★★ [핵심 수정] LHM이 이미 실행 중인지 확인하고, 없을 때만 켜는 함수 ★★★
    function launchLHM() {
        if (fs.existsSync(lhmPath)) {
            // 윈도우 tasklist 명령어로 LHM 프로세스가 있는지 검색
            exec(`tasklist /FI "IMAGENAME eq ${exeName}" /NH`, (err, stdout, stderr) => {
                // 검색 결과에 LHM 이름이 포함되어 있다면 이미 켜져 있는 것!
                if (stdout && stdout.includes(exeName)) {
                    console.log("[SysMon] LibreHardwareMonitor is already running. Skipping launch.");
                } else {
                    // 꺼져있다면 새로 실행
                    console.log("[SysMon] LibreHardwareMonitor not found. Launching now...");
                    exec(`start "" "${lhmPath}"`, (error) => {
                        if (error) console.log("LHM Start Error:", error.message);
                    });
                }
            });
        }
    }
    
    // 프로그램 시작 시 체크 후 실행
    launchLHM();

    // 2. 워커 생성 루프 (1초 주기)
    setInterval(() => {
        if (Object.keys(activeKeys).length > 0) {
            const worker = new Worker(__filename);
            worker.on('message', (data) => {
                if (data.error) return;
                if (cookieDeckSocket && cookieDeckSocket.readyState === WebSocket.OPEN && data.result) {
                    updateDynamicContent(data.result);
                }
            });
        }
    }, 1000);

    function connectToCookieDeck() {
        cookieDeckSocket = new WebSocket(uri);
        
        cookieDeckSocket.on('open', () => {
            console.log("[SysMon] Connected to CookieDeck!");
            reconnectAttempts = 0; 
            cookieDeckSocket.send(JSON.stringify({ event: registerEvent, uuid: pluginUUID }));
        });
        
        cookieDeckSocket.on('message', (message) => {
            const data = JSON.parse(message);
            const context = data.context;
            if (data.event === 'keyDidAppear') {
                const settings = data.payload.settings || {};
                activeKeys[context] = { page: data.payload.page, metric: settings.selected_metric || 'cpu_usage' };
            } else if (data.event === 'keyDidDisappear') {
                delete activeKeys[context];
            } else if (data.event === 'didReceiveSettings') {
                if (activeKeys[context]) {
                    const settings = data.payload || {};
                    activeKeys[context].metric = settings.selected_metric || 'cpu_usage';
                }
            }
        });

        // 파이썬 서버 꺼지면 플러그인만 조용히 종료 (LHM은 놔둠)
        cookieDeckSocket.on('close', () => {
            reconnectAttempts++;
            console.log(`[SysMon] Connection lost. Retry attempt ${reconnectAttempts}/${MAX_RETRIES}`);
            
            if (reconnectAttempts > MAX_RETRIES) {
                console.log("[SysMon] CookieDeck is definitely closed. Exiting plugin...");
                process.exit(0); // 나(Node.js)만 죽는다!
            } else {
                setTimeout(connectToCookieDeck, 2000);
            }
        });

        cookieDeckSocket.on('error', () => {});
    }

    function updateDynamicContent(parsedData) {
        for (const context in activeKeys) {
            const keyInfo = activeKeys[context];
            const metric = keyInfo.metric;
            let textContent = "N/A";

            if (metric === "cpu_usage") textContent = `CPU\n${parsedData.cpu_load}%`;
            else if (metric === "memory_usage") textContent = `RAM\n${parsedData.mem_percent}%`;
            else if (metric === "gpu_temp") textContent = `GPU\n${parsedData.gpu_temp}°C`;
            else if (metric === "gpu_usage") textContent = `GPU\n${parsedData.gpu_load}%`;
            else if (metric === "cpu_temp") textContent = `CPU\n${parsedData.cpu_temp}°C`;
            else if (metric === "cpu_power") textContent = `CPU\n${parsedData.cpu_power}W`;
            else if (metric === "gpu_power") textContent = `GPU\n${parsedData.gpu_power}W`;
            else if (metric === "network_upload") textContent = `UP\n${parsedData.net_upload}`;
            else if (metric === "network_download") textContent = `DN\n${parsedData.net_download}`;

            cookieDeckSocket.send(JSON.stringify({
                event: "setDynamicText",
                context: context,
                payload: {
                    "text": textContent,
                    "font_size": "24px",
                    "color": "#FFFFFF",
                    "page": keyInfo.page
                }
            }));
        }
    }
    
    connectToCookieDeck();

    process.on('SIGINT', () => process.exit(0));
    process.on('SIGTERM', () => process.exit(0));

} else {
    // --- [워커 스레드: 파싱 로직] --- (수정 없음)
    const axios = require('axios');

    function getLocalIpAddress() {
        try {
            const interfaces = os.networkInterfaces();
            for (const name in interfaces) {
                for (const iface of interfaces[name]) {
                    if (iface.family === 'IPv4' && !iface.internal) {
                        return iface.address;
                    }
                }
            }
        } catch (e) {
            console.log("[SysMon] Failed to get local IP:", e.message);
        }
        return 'localhost'; 
    }

    const cleanValue = (valStr) => {
        if (!valStr || valStr === "-" || valStr === "N/A") return "0";
        const num = parseFloat(valStr);
        return isNaN(num) ? "0" : num.toFixed(0);
    };

    const findValue = (hardwareNodes, imgKeywords, categoryText, sensorKeywords) => {
        for (const hw of hardwareNodes) {
            const img = (hw.ImageURL || "").toLowerCase();
            if (imgKeywords.some(k => img.includes(k))) {
                if (hw.Children) {
                    for (const cat of hw.Children) {
                        if (cat.Text === categoryText && cat.Children) {
                            for (const keyword of sensorKeywords) {
                                const sensor = cat.Children.find(s => s.Text.includes(keyword));
                                if (sensor) return sensor.Value;
                            }
                        }
                    }
                }
            }
        }
        return "0";
    };

    const findNetwork = (hardwareNodes, type) => {
        for (const hw of hardwareNodes) {
            if ((hw.ImageURL || "").includes("nic")) {
                if (hw.Children) {
                    for (const cat of hw.Children) {
                        if (cat.Text === "Throughput" && cat.Children) {
                            const sensor = cat.Children.find(s => s.Text.includes(type));
                            if (sensor) return sensor.Value.split('/')[0].replace(" ", "");
                        }
                    }
                }
            }
        }
        return "0";
    };

    const fetchData = async () => {
        try {
            const ipAddress = getLocalIpAddress(); 
            const url = `http://${ipAddress}:8085/data.json`;
            const response = await axios.get(url, { timeout: 900 });
            
            if (!response.data || !response.data.Children || response.data.Children.length === 0) {
                return;
            }

            const computerNode = response.data.Children[0];
            const hardwareNodes = computerNode ? computerNode.Children : [];

            let result = {};

            result.cpu_load = cleanValue(findValue(hardwareNodes, ['cpu'], 'Load', ['CPU Total', 'Core Max']));
            result.mem_percent = cleanValue(findValue(hardwareNodes, ['ram', 'memory'], 'Load', ['Memory']));
            result.gpu_temp = cleanValue(findValue(hardwareNodes, ['ati', 'nvidia', 'gpu'], 'Temperatures', ['GPU Core', 'Hot Spot']));
            result.gpu_load = cleanValue(findValue(hardwareNodes, ['ati', 'nvidia', 'gpu'], 'Load', ['GPU Core', 'D3D 3D']));
            result.cpu_temp = cleanValue(findValue(hardwareNodes, ['cpu'], 'Temperatures', ['Package', 'Core Max', 'Core #1']));
            result.cpu_power = cleanValue(findValue(hardwareNodes, ['cpu'], 'Powers', ['Package', 'Total']));
            result.gpu_power = cleanValue(findValue(hardwareNodes, ['ati', 'nvidia'], 'Powers', ['GPU Package', 'GPU Power']));
            result.net_upload = findNetwork(hardwareNodes, 'Upload');
            result.net_download = findNetwork(hardwareNodes, 'Download');

            parentPort.postMessage({ result });
        } catch (e) {
            parentPort.postMessage({ error: e.message });
        }
    };
    fetchData();
}