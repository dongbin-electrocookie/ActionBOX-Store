import sys
import os
import asyncio

# 라이브러리 경로 설정
lib_path = os.path.join(os.path.dirname(__file__), 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

try:
    import requests
    import pyperclip
    import pyautogui
    DEPENDENCIES_OK = True
except ImportError:
    DEPENDENCIES_OK = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        # 🚀 [대통합 규격] 멀티액션 시 누락되는 API 키와 ID를 기억하기 위한 저장소
        self.last_valid_settings = {}

        # 단축키 데이터베이스
        self.shortcuts_db = {
            "new_page": ['ctrl', 'n'],
            "new_window": ['ctrl', 'shift', 'n'],
            "search": ['ctrl', 'p'],
            "sidebar": ['ctrl', '\\'],
            "darkmode": ['ctrl', 'shift', 'l'],
            "go_back": ['ctrl', '['],
            "go_forward": ['ctrl', ']'],
            "go_up": ['ctrl', 'shift', 'u'],
            "bold": ['ctrl', 'b'],
            "italic": ['ctrl', 'i'],
            "strikethrough": ['ctrl', 'shift', 's'],
            "code": ['ctrl', 'e'],
            "link": ['ctrl', 'k'],
            "text": ['ctrl', 'shift', '0'],
            "h1": ['ctrl', 'shift', '1'],
            "h2": ['ctrl', 'shift', '2'],
            "h3": ['ctrl', 'shift', '3'],
            "todo": ['ctrl', 'shift', '4'],
            "bullet": ['ctrl', 'shift', '5'],
            "number": ['ctrl', 'shift', '6'],
            "toggle": ['ctrl', 'shift', '7'],
            "code_block": ['ctrl', 'shift', '8'],
            "page_block": ['ctrl', 'shift', '9']
        }

    async def show_feedback(self, context, text):
        """버튼 위에 상태 메시지 표시"""
        if hasattr(self.runner, "send_message"):
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": text}
            })

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not DEPENDENCIES_OK:
            await self.show_feedback(data.get("context"), "모듈오류")
            return

        action = data.get("action")
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {})

        # 🚀 1. 유효한 설정이 들어오면 기억해둡니다 (API Key, DB ID, command 등)
        if incoming_settings:
            # 값이 비어있지 않은 것들만 골라서 업데이트
            filtered_settings = {k: v for k, v in incoming_settings.items() if v}
            self.last_valid_settings.update(filtered_settings)

        # 🚀 2. 현재 실행을 위해 메모리와 현재 데이터를 합칩니다 (멀티액션 대응)
        final_settings = {**self.last_valid_settings, **incoming_settings}

        # --- [기능 A] 퀵 캡처 (API 방식) ---
        if "quickcapture" in action:
            api_key = final_settings.get("api_key", "").strip()
            db_id = final_settings.get("db_id", "").strip()

            if not api_key or not db_id:
                await self.show_feedback(context, "API 설정\n안됨!")
                return

            await self.show_feedback(context, "복사중...✂️")
            pyautogui.hotkey('ctrl', 'c')
            await asyncio.sleep(0.3) 

            try:
                clipboard_text = pyperclip.paste().strip()
            except Exception:
                clipboard_text = ""

            if not clipboard_text:
                await self.show_feedback(context, "드래그\n없음!")
                return

            await self.show_feedback(context, "전송중...⏳")
            success, err_msg = await self.send_to_notion(api_key, db_id, clipboard_text)
            
            if success:
                await self.show_feedback(context, "✅ 저장됨!")
                await asyncio.sleep(1.5)
                await self.show_feedback(context, "Quick\nCapture") 
            else:
                await self.show_feedback(context, "❌ 오류발생")

        # --- [기능 B] 콤보박스 단축키 (표준 규격 command 적용) ---
        elif "shortcuts" in action:
            # 🚀 표준 키 'command'를 먼저 찾고, 없으면 구버전 'shortcut'을 찾습니다.
            selected_shortcut = final_settings.get("command") or final_settings.get("shortcut", "new_page")
            
            if selected_shortcut in self.shortcuts_db:
                keys = self.shortcuts_db[selected_shortcut]
                # 단축키 실행은 OS 레벨 동작이므로 스레드로 분리
                await asyncio.to_thread(pyautogui.hotkey, *keys)
                print(f"[{self.uuid}] 실행된 단축키: {selected_shortcut} ({keys})")

    async def send_to_notion(self, api_key, db_id, text):
        """노션 API를 사용하여 페이지 추가"""
        url = "https://api.notion.com/v1/pages"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Notion-Version": "2022-06-28"
        }
        payload = {
            "parent": {"database_id": db_id},
            "properties": {
                "이름": { "title": [{"text": {"content": text}}] }
            }
        }
        try:
            # requests는 동기 함수이므로 스레드에서 실행
            res = await asyncio.to_thread(requests.post, url, headers=headers, json=payload)
            if res.status_code == 200:
                return True, ""
            else:
                return False, res.text
        except Exception as e:
            return False, str(e)