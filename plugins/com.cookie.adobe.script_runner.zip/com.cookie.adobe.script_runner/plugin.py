import asyncio
import json
import os
import subprocess
import sys
import glob
import re
import importlib.util

# Load the sibling helper by exact path: embedded Python need not put plugin
# folders on sys.path, and downloaded plugins must remain self-contained.
_bridge_spec = importlib.util.spec_from_file_location(
    'combox_adobe_premiere_bridge', os.path.join(os.path.dirname(__file__), 'premiere_bridge.py'))
_bridge_module = importlib.util.module_from_spec(_bridge_spec)
_bridge_spec.loader.exec_module(_bridge_module)

class ScriptExecutionError(Exception):
    def __init__(self, status, detail=""):
        super().__init__(status)
        self.status = status
        self.detail = str(detail)[:400]


IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

if IS_WINDOWS:
    import winreg

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.scripts_dir = os.path.join(self.plugin_dir, "scripts")
        self.builtin_scripts = self._load_builtin_scripts()
        self.app_paths_file = os.path.join(self.plugin_dir, "app_paths.json")
        self.selected_app_paths = self._load_selected_app_paths()
        self.last_valid_settings = {}
        self.last_results = {}
        self._locale_cache = {}
        self.premiere_bridge = _bridge_module.PremiereBridge(self.plugin_dir)

        self.action_to_exe = {
            "photoshop": "Photoshop.exe",
            "illustrator": "Illustrator.exe",
            "aftereffects": "AfterFX.exe",
            "premiere": "Adobe Premiere Pro.exe",
            "indesign": "InDesign.exe",
        }

        self.action_to_macos_app_patterns = {
            "photoshop": ["/Applications/Adobe Photoshop*/Adobe Photoshop*.app"],
            "illustrator": ["/Applications/Adobe Illustrator*/Adobe Illustrator*.app"],
            "aftereffects": ["/Applications/Adobe After Effects*/Adobe After Effects*.app"],
            "premiere": ["/Applications/Adobe Premiere Pro*/Adobe Premiere Pro*.app"],
            "indesign": ["/Applications/Adobe InDesign*/Adobe InDesign*.app"],
        }

        self.action_to_windows_patterns = {
            "photoshop": [r"C:\Program Files\Adobe\Adobe Photoshop *\Photoshop.exe"],
            "illustrator": [r"C:\Program Files\Adobe\Adobe Illustrator *\Support Files\Contents\Windows\Illustrator.exe"],
            "aftereffects": [r"C:\Program Files\Adobe\Adobe After Effects *\Support Files\AfterFX.exe"],
            "premiere": [r"C:\Program Files\Adobe\Adobe Premiere Pro *\Adobe Premiere Pro.exe"],
            "indesign": [r"C:\Program Files\Adobe\Adobe InDesign *\InDesign.exe"],
        }

        self.action_to_icon = {
            "photoshop": "photoshop script",
            "illustrator": "illustrator script",
            "aftereffects": "aftereffects script",
            "premiere": "premiere script",
            "indesign": "indesign script",
        }

    def _load_builtin_scripts(self):
        catalog_path = os.path.join(self.scripts_dir, "catalog.json")
        try:
            with open(catalog_path, "r", encoding="utf-8") as catalog_file:
                entries = json.load(catalog_file)
            return {
                entry["id"]: entry
                for entry in entries
                if isinstance(entry, dict) and entry.get("id") and entry.get("file")
            }
        except Exception as error:
            print(f"[{self.uuid}] Failed to load built-in script catalog: {error}")
            return {}

    def _load_selected_app_paths(self):
        try:
            with open(self.app_paths_file, "r", encoding="utf-8") as settings_file:
                values = json.load(settings_file)
            return values if isinstance(values, dict) else {}
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return {}

    def _save_selected_app_paths(self):
        temp_path = self.app_paths_file + ".tmp"
        with open(temp_path, "w", encoding="utf-8") as settings_file:
            json.dump(self.selected_app_paths, settings_file, ensure_ascii=False, indent=2)
        os.replace(temp_path, self.app_paths_file)

    def _get_action_key(self, action_id: str) -> str:
        suffix = str(action_id or "").split("#", 1)[0].lower().rsplit(".", 1)[-1]
        return suffix if suffix in self.action_to_exe else None

    @staticmethod
    def _message_settings(data):
        payload = data.get("payload")
        payload = payload if isinstance(payload, dict) else {}
        for candidate in (payload.get("settings"), data.get("settings")):
            if isinstance(candidate, dict):
                return candidate
        return payload if data.get("event") == "didReceiveSettings" else {}

    def _cache_settings(self, context, incoming, action_id=""):
        cached = self.last_valid_settings.get(context, {})
        action_id = action_id or incoming.get("action_id") or cached.get("action_id", "")
        if cached.get("action_id") and action_id != cached["action_id"]:
            cached = {}  # Reassigned physical slot must not inherit the previous script.
        settings = {**cached, **incoming, "action_id": action_id}
        if "builtin_script_id" in incoming and "command" not in incoming and settings.get("script_source") != "custom":
            selected = incoming.get("builtin_script_id")
            settings["command"] = "builtin:" + selected if selected else ""
            settings["script_source"] = "builtin"
        if "script_path" in incoming and "command" not in incoming and settings.get("script_source") != "builtin":
            settings["command"] = incoming["script_path"]
        command = incoming.get("command")
        if isinstance(command, str) and command.startswith("builtin:"):
            settings["script_source"] = "builtin"
            settings["builtin_script_id"] = command[len("builtin:"):]
        elif isinstance(command, str) and command and incoming.get("script_source") != "builtin":
            settings["script_source"] = "custom"
            settings["builtin_script_id"] = ""
            settings["script_path"] = command
        elif "command" in incoming and settings.get("script_source") != "builtin":
            settings["script_path"] = ""
        elif "command" in incoming and not command and "builtin_script_id" not in incoming:
            settings["builtin_script_id"] = ""
        if any(settings.get(key) != cached.get(key) for key in ("action_id", "command", "script_source", "builtin_script_id")):
            self.last_results.pop(context, None)
        if context:
            self.last_valid_settings[context] = settings
        return settings

    async def _report_result(self, context, status, settings, detail=""):
        lang = settings.get("_lang", "en")
        lang = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}.get(lang, lang)
        if lang not in ("en", "ko", "ja", "de", "es", "fr", "it", "pt-PT", "ru"):
            lang = "en"
        if lang not in self._locale_cache:
            try:
                with open(os.path.join(self.plugin_dir, "locales", lang + ".json"), encoding="utf-8") as file:
                    self._locale_cache[lang] = json.load(file)
            except (OSError, ValueError):
                self._locale_cache[lang] = {}
        key = "RUN_" + status.upper()
        message = self._locale_cache[lang].get(key, status)
        result = {"command": "scriptResult", "status": status, "messageKey": key,
                  "message": message, "detail": str(detail)[:400]}
        print(f"[{self.uuid}] {message}" + (f" ({result['detail']})" if detail else ""))
        if context:
            self.last_results[context] = result
            await self.runner.send_message({"event": "sendToPropertyInspector", "context": context, "payload": result})

    def _get_icon_path(self, action_id: str) -> str:
        action_key = self._get_action_key(action_id)
        icon_name = self.action_to_icon.get(action_key, "photoshop script")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_id)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "exe_path", "script_path", "command", "script_source",
            "builtin_script_id", "builtin_icon_name",
            "default_visuals_initialized", "sync_title_on_script_change", "title"
        ])
        if meaningful:
            return settings

        action_key = self._get_action_key(action_id)
        new_settings = {
            "exe_path": "",
            "script_path": "",
            "command": "",
            "script_source": "builtin",
            "builtin_script_id": "",
            "action_id": action_id or "",
            "_lang": "en",
            "sync_title_on_script_change": False,
            "builtin_icon_name": self.action_to_icon.get(action_key, "photoshop script"),
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        # Initial placement: icon only, never overwrite title
        await self._send_builtin_icon(context, action_id)
        return new_settings

    async def handle_message(self, data):
        event = data.get("event")
        action_id = data.get("action", "")
        payload = data.get("payload")
        payload = payload if isinstance(payload, dict) else {}
        context = data.get("context") or payload.get("context")
        settings = self._message_settings(data)

        if event in ["willAppear", "keyDidAppear"]:
            initialized = await self._initialize_default_visuals_if_new(context, action_id, settings)
            if context:
                self.last_results.pop(context, None)
                self.last_valid_settings[context] = {}  # New lifecycle, not a partial settings update.
                self._cache_settings(context, initialized or settings, action_id)
            if self._get_action_key(action_id) == 'premiere':
                try:
                    changed = await asyncio.to_thread(self.premiere_bridge.prepare)
                    if changed:
                        await self._report_result(context, 'bridge_restart_required', initialized or settings)
                except _bridge_module.BridgeError as error:
                    await self._report_result(context, error.status, initialized or settings, error.detail)
            return

        if event == "didReceiveSettings":
            self._cache_settings(context, settings, action_id)
            return
        if event in ("willDisappear", "keyDidDisappear"):
            self.last_valid_settings.pop(context, None)
            self.last_results.pop(context, None)
            return

        if event == "keyDown":
            await self.on_key_down(data)
        elif event == "sendToPlugin":
            await self.on_pi_request(data)

    async def on_key_down(self, data):
        payload = data.get("payload")
        payload = payload if isinstance(payload, dict) else {}
        context = data.get("context") or payload.get("context")
        if not context:
            return
        final_settings = self._cache_settings(context, self._message_settings(data), data.get("action", ""))
        action_key = self._get_action_key(final_settings.get("action_id", ""))
        if not action_key:
            await self._report_result(context, "invalid_app", final_settings)
            return
        exe_path = self._resolve_exe_path(action_key, final_settings.get("exe_path"))
        script_path = self._resolve_script_path(final_settings, action_key)

        if not exe_path or not os.path.exists(exe_path):
            await self._report_result(context, "app_path_missing", final_settings)
            return

        if not script_path or not os.path.isfile(script_path) or os.path.splitext(script_path)[1].lower() not in (".jsx", ".jsxbin", ".js"):
            await self._report_result(context, "script_missing", final_settings)
            return

        print(f"[{self.uuid}] Running: {os.path.basename(exe_path)} + {os.path.basename(script_path)}")
        try:
            status = await asyncio.to_thread(self._run_script_sync, exe_path, os.path.abspath(script_path), action_key)
            await self._report_result(context, status, final_settings)
        except ScriptExecutionError as error:
            await self._report_result(context, error.status, final_settings, error.detail)
        except Exception as error:
            await self._report_result(context, "execution_failed", final_settings, type(error).__name__)

    def _resolve_exe_path(self, action_key, legacy_path=None):
        selected_path = self.selected_app_paths.get(action_key)
        if selected_path and os.path.exists(selected_path):
            return selected_path
        if legacy_path and os.path.exists(legacy_path):
            return legacy_path
        candidates = self._find_adobe_candidates(action_key)
        return candidates[0]["path"] if candidates else None

    def _resolve_script_path(self, settings, action_key):
        source = settings.get("script_source")
        command = settings.get("command") or ""
        if not isinstance(command, str):
            return None
        builtin_id = settings.get("builtin_script_id") or ""

        if source == "custom":
            return (command if not command.startswith("builtin:") else "") or settings.get("script_path")
        if command.startswith("builtin:"):
            source = "builtin"
            builtin_id = command[len("builtin:"):]

        if source == "builtin" or builtin_id:
            entry = self.builtin_scripts.get(builtin_id)
            if not entry or entry.get("app") != action_key:
                return None

            scripts_root = os.path.realpath(self.scripts_dir)
            script_path = os.path.realpath(os.path.join(scripts_root, entry["file"]))
            try:
                if os.path.commonpath([scripts_root, script_path]) != scripts_root:
                    return None
            except ValueError:
                return None
            return script_path

        return command or settings.get("script_path")

    async def on_pi_request(self, data):
        context = data.get("context")
        action_id = data.get("action", "")
        payload = data.get("payload", {}) or {}
        command = payload.get("command")

        if command == "getScriptStatus":
            result = self.last_results.get(context)
            if result:
                await self.runner.send_message({"event": "sendToPropertyInspector", "context": context, "payload": result})
            return

        if command in ("getDefaultPath", "getAppCandidates"):
            action_id_for_lookup = payload.get("actionId") or action_id or ""
            action_key = self._get_action_key(action_id_for_lookup)
            if not action_key:
                return
            candidates = self._find_adobe_candidates(action_key)
            selected_path = self.selected_app_paths.get(action_key, "")
            if selected_path and not os.path.exists(selected_path):
                selected_path = ""
                self.selected_app_paths.pop(action_key, None)
            if not selected_path and candidates:
                selected_path = candidates[0]["path"]
                self.selected_app_paths[action_key] = selected_path
                self._save_selected_app_paths()
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {
                    "command": "appCandidatesFound",
                    "app": action_key,
                    "candidates": candidates,
                    "selectedPath": selected_path
                }
            })

        elif command == "setAppPath":
            action_key = self._get_action_key(payload.get("actionId") or action_id or "")
            if not action_key:
                return
            selected_path = payload.get("path") or ""
            if selected_path and os.path.exists(selected_path):
                self.selected_app_paths[action_key] = os.path.normpath(selected_path)
                self._save_selected_app_paths()
            elif not selected_path:
                self.selected_app_paths.pop(action_key, None)
                self._save_selected_app_paths()

        elif command == "apply_builtin_icon":
            action_id_for_icon = payload.get("actionId") or action_id or ""
            await self._send_builtin_icon(context, action_id_for_icon)

    @staticmethod
    def _registry_text(subkey):
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, subkey) as key:
            value, _ = winreg.QueryValueEx(key, None)
        return str(value)

    def _com_server_path(self, progid):
        # Resolve CurVer aliases without assuming a version/year => COM mapping.
        visited = set()
        while progid not in visited:
            visited.add(progid)
            try:
                progid = self._registry_text(progid + r"\CurVer")
                continue
            except OSError:
                break
        try:
            clsid = self._registry_text(progid + r"\CLSID")
            command = self._registry_text("CLSID" + chr(92) + clsid + r"\LocalServer32")
        except OSError:
            return None
        match = re.match(r'^\s*"([^"\r\n]+)"|^\s*(.+?\.exe)(?:\s|$)', command, re.IGNORECASE)
        return (match.group(1) or match.group(2)) if match else None

    def _com_progids(self, action_key, exe_path):
        prefix = {"illustrator": "Illustrator.Application", "indesign": "InDesign.Application"}[action_key]
        names = {prefix}
        try:
            with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, "") as root:
                index = 0
                while True:
                    try:
                        name = winreg.EnumKey(root, index)
                    except OSError:
                        break
                    index += 1
                    if name.lower() == prefix.lower() or name.lower().startswith(prefix.lower() + "."):
                        names.add(name)
        except OSError:
            pass
        target = os.path.normcase(os.path.realpath(exe_path)).casefold()
        matches = []
        for name in sorted(names, key=self._candidate_sort_key, reverse=True):
            server = self._com_server_path(name)
            if server and os.path.normcase(os.path.realpath(server)).casefold() == target:
                matches.append(name)
        return matches

    def _run_windows_com(self, action_key, exe_path, script_path):
        try:
            import pythoncom
            import win32com.client as com_client
        except ImportError:
            raise ScriptExecutionError("automation_unavailable", "pywin32") from None
        progids = self._com_progids(action_key, exe_path)
        if not progids:
            raise ScriptExecutionError("automation_unavailable", "Selected version has no matching COM registration")
        # Prefer an existing ROT object. Some Adobe versions expose automation
        # only via CoCreateInstance; permit that solely for an already-running,
        # exact selected executable and its matching registered ProgID.
        pythoncom.CoInitialize()
        application = None
        try:
            for progid in progids:
                try:
                    application = com_client.GetActiveObject(progid)
                    break
                except Exception:
                    continue
            if application is None:
                if not self._selected_windows_app_running(exe_path):
                    raise ScriptExecutionError("app_not_running")
                try:
                    application = com_client.Dispatch(progids[0])
                except Exception as error:
                    raise ScriptExecutionError("automation_unavailable", type(error).__name__) from None
            try:
                if action_key == "illustrator":
                    application.DoJavaScriptFile(script_path)
                else:
                    # A COM string must be JavaScript source, not a document path.
                    # evalFile preserves JSX relative includes and $.fileName.
                    source = "$.evalFile(new File(" + json.dumps(script_path, ensure_ascii=False) + "));"
                    application.DoScript(source, 0x4A534C67)  # ScriptLanguage.JAVASCRIPT
            except Exception as error:
                detail = type(error).__name__ + " / HRESULT=" + str(getattr(error, "hresult", "unknown"))
                raise ScriptExecutionError("execution_failed", detail) from None
            return "executed"
        finally:
            application = None
            pythoncom.CoUninitialize()

    @staticmethod
    def _selected_windows_app_running(exe_path):
        try:
            import psutil
        except ImportError:
            raise ScriptExecutionError("automation_unavailable", "psutil") from None
        target = os.path.normcase(os.path.realpath(exe_path)).casefold()
        for process in psutil.process_iter(["exe"]):
            try:
                path = process.info.get("exe")
                if path and os.path.normcase(os.path.realpath(path)).casefold() == target:
                    return True
            except (psutil.Error, OSError):
                continue
        return False

    @staticmethod
    def _applescript_string(value):
        if any(char in value for char in ("\x00", "\r", "\n")):
            raise ScriptExecutionError("invalid_app", "Invalid path characters")
        return '"' + value.replace('\\', '\\\\').replace('"', '\\"') + '"'

    def _mac_app_bundle(self, exe_path):
        candidate = os.path.abspath(exe_path)
        while candidate and candidate != os.path.dirname(candidate):
            if candidate.lower().endswith(".app") and os.path.isdir(candidate):
                return candidate
            candidate = os.path.dirname(candidate)
        raise ScriptExecutionError("invalid_app", "Select the Adobe .app bundle")

    def _mac_script_source(self, action_key, bundle, script_path):
        app = self._applescript_string(bundle)
        path = self._applescript_string(script_path)
        commands = {
            "illustrator": "do javascript (POSIX file " + path + ")",
            "aftereffects": "DoScriptFile " + path,
            "indesign": "do script (POSIX file " + path + ") language javascript",
        }
        # Check the built-in AppleScript application property outside the Adobe
        # terminology scope: bare `running` can resolve to an Adobe enum.
        return ("with timeout of 300 seconds\n"
                'if not (application ' + app + ' is running) then error "COMBO-X_APP_NOT_RUNNING" number -600\n' +
                "tell application " + app + "\n" +
                commands[action_key] + "\nend tell\nend timeout\n")

    @staticmethod
    def _mac_aftereffects_jxa_source(bundle, script_path):
        # AE may reject AppleScript DoScriptFile at parse time (-2741), even though
        # Illustrator/InDesign AppleScript commands work. The JXA equivalent is
        # reported working by users affected by recent AE scripting regressions.
        # Target the selected version by .app name rather than a generic bundle ID
        # (multiple AE versions often share the same bundle identifier).
        app_name = os.path.splitext(os.path.basename(bundle))[0]
        if any(char in value for value in (app_name, script_path)
               for char in ("\x00", "\r", "\n")):
            raise ScriptExecutionError("invalid_app", "Invalid path characters")
        app = json.dumps(app_name, ensure_ascii=False)
        path = json.dumps(script_path, ensure_ascii=False)
        return ("var ae = Application(" + app + ");\n"
                'if (!ae.running()) { throw new Error("COMBO-X_APP_NOT_RUNNING"); }\n'
                "ae.activate();\n"
                "ae.doscriptfile(" + path + ");\n")

    def _run_macos_script(self, action_key, exe_path, script_path):
        bundle = self._mac_app_bundle(exe_path)
        if action_key == "aftereffects":
            source = self._mac_aftereffects_jxa_source(bundle, script_path)
            cmd = ["/usr/bin/osascript", "-l", "JavaScript", "-"]
        else:
            source = self._mac_script_source(action_key, bundle, script_path)
            cmd = ["/usr/bin/osascript", "-"]
        try:
            result = subprocess.run(cmd, input=source, text=True,
                                    capture_output=True, timeout=305, check=False)
        except subprocess.TimeoutExpired:
            # The Adobe script might still be running; never retry or kill Adobe.
            raise ScriptExecutionError("timed_out") from None
        if result.returncode:
            detail = (result.stderr or "")[:400]
            status = "mac_permission" if "-1743" in detail else (
                "app_not_running" if "COMBO-X_APP_NOT_RUNNING" in detail or "(-600)" in detail else "execution_failed")
            raise ScriptExecutionError(status, detail)
        return "executed"

    def _run_script_sync(self, exe_path, script_path, action_key):
        if action_key == "premiere" and (IS_WINDOWS or IS_MACOS):
            try:
                return self.premiere_bridge.execute(exe_path, script_path)
            except _bridge_module.BridgeError as error:
                raise ScriptExecutionError(error.status, error.detail) from None
        if IS_WINDOWS:
            if action_key in ("illustrator", "indesign"):
                return self._run_windows_com(action_key, exe_path, script_path)
            if action_key not in ("aftereffects", "photoshop"):
                raise ScriptExecutionError("invalid_app")
            # AfterFX requires -r. Keep Photoshop's existing file argument route.
            args = [exe_path, "-r", script_path] if action_key == "aftereffects" else [exe_path, script_path]
            # Do not wait for the lifetime of a newly launched GUI application,
            # or set hidden/minimized startup flags. Launch != script completion.
            subprocess.Popen(args, close_fds=True)
            return "submitted"
        if IS_MACOS:
            if action_key in ("illustrator", "aftereffects", "indesign"):
                return self._run_macos_script(action_key, exe_path, script_path)
            if action_key == "photoshop":
                result = subprocess.run(["/usr/bin/open", "-a", exe_path, script_path],
                                        capture_output=True, text=True, timeout=30, check=False)
                if result.returncode:
                    raise ScriptExecutionError("execution_failed", (result.stderr or "")[:400])
                return "submitted"
        raise ScriptExecutionError("platform_unsupported")

    def _find_adobe_path(self, exe_name):
        action_key = next((key for key, value in self.action_to_exe.items() if value == exe_name), None)
        candidates = self._find_adobe_candidates(action_key) if action_key else []
        return candidates[0]["path"] if candidates else None

    def _find_adobe_candidates(self, action_key):
        candidates = []

        if IS_MACOS:
            for pattern in self.action_to_macos_app_patterns.get(action_key, []):
                for path in glob.glob(pattern):
                    if os.path.exists(path):
                        candidates.append(path)

        elif IS_WINDOWS:
            for pattern in self.action_to_windows_patterns.get(action_key, []):
                candidates.extend(path for path in glob.glob(pattern) if os.path.isfile(path))

            exe_name = self.action_to_exe.get(action_key)
            app_paths_key = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"
            if exe_name:
                for hkey in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
                    try:
                        key = winreg.OpenKey(hkey, os.path.join(app_paths_key, exe_name))
                        path, _ = winreg.QueryValueEx(key, None)
                        winreg.CloseKey(key)
                        if os.path.isfile(path):
                            candidates.append(path)
                    except FileNotFoundError:
                        continue

        unique_paths = list(dict.fromkeys(os.path.normpath(path) for path in candidates))
        unique_paths.sort(key=self._candidate_sort_key, reverse=True)
        return [{"label": self._candidate_label(action_key, path), "path": path} for path in unique_paths]

    def _candidate_sort_key(self, path):
        numbers = re.findall(r"\d+", path)
        return tuple(int(number) for number in numbers) if numbers else (0,)

    def _candidate_label(self, action_key, path):
        app_names = {
            "photoshop": "Photoshop",
            "illustrator": "Illustrator",
            "aftereffects": "After Effects",
            "premiere": "Premiere Pro",
            "indesign": "InDesign",
        }
        version_match = re.findall(r"20\d{2}", path)
        version = version_match[-1] if version_match else ""
        return f"{app_names.get(action_key, action_key.title())} {version}".strip()
