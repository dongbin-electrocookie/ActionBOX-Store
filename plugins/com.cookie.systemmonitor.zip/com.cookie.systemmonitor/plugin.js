const WebSocket = require('ws');
const { Worker, isMainThread, parentPort } = require('worker_threads');
const { execFile, execFileSync, spawn, spawnSync } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

const args = {};
for (let i = 2; i < process.argv.length; i += 2) args[process.argv[i]] = process.argv[i + 1];
const port = args['-port'] || '8765';
const pluginUUID = args['-pluginUUID'] || 'com.cookie.systemmonitor';
const registerEvent = args['-registerEvent'] || 'register';
const uri = `ws://127.0.0.1:${port}`;

const IS_WINDOWS = process.platform === 'win32';
const IS_MACOS = process.platform === 'darwin';
const IS_APPLE_SILICON = IS_MACOS && process.arch === 'arm64';
const IS_SENSOR_PLATFORM = IS_WINDOWS || IS_APPLE_SILICON;
const DEFAULT_METRIC = 'cpu_usage';
const POLL_INTERVAL_MS = 1000;
const WORKER_TIMEOUT_MS = 2800;
const STARTUP_QUIET_MS = 6500;
const PAGE_APPEAR_SETTLE_MS = 250;
const ERROR_DISPLAY_THRESHOLD = 3;
const MACMON_PORT = 19779;
const MACMON_ENDPOINTS = [
  `http://127.0.0.1:${MACMON_PORT}/json`
];

const lhmPath = path.resolve(__dirname, 'LibreHardwareMonitor', 'LibreHardwareMonitor.exe');
const exeName = 'LibreHardwareMonitor.exe';

const iconMap = {
  cpu_usage: 'STATE_CPU_USAGE',
  memory_usage: 'STATE_MEMORY_USAGE',
  gpu_temp: 'STATE_GPU_TEMP',
  gpu_usage: 'STATE_GPU_USAGE',
  network_upload: 'STATE_NETWORK_UPLOAD',
  network_download: 'STATE_NETWORK_DOWNLOAD',
  cpu_power: 'STATE_CPU_POWER',
  gpu_power: 'STATE_GPU_POWER'
};

const i18n = {
  en: { cpu_usage:'CPU', memory_usage:'RAM', gpu_temp:'GPU', gpu_usage:'GPU', cpu_power:'CPU', gpu_power:'GPU', network_upload:'UP', network_download:'DN' },
  ko: { cpu_usage:'CPU', memory_usage:'RAM', gpu_temp:'GPU', gpu_usage:'GPU', cpu_power:'CPU', gpu_power:'GPU', network_upload:'업', network_download:'다운' },
  ja: { cpu_usage:'CPU', memory_usage:'RAM', gpu_temp:'GPU', gpu_usage:'GPU', cpu_power:'CPU', gpu_power:'GPU', network_upload:'UP', network_download:'DN' },
  de: { cpu_usage:'CPU', memory_usage:'RAM', gpu_temp:'GPU', gpu_usage:'GPU', cpu_power:'CPU', gpu_power:'GPU', network_upload:'UP', network_download:'DN' },
  es: { cpu_usage:'CPU', memory_usage:'RAM', gpu_temp:'GPU', gpu_usage:'GPU', cpu_power:'CPU', gpu_power:'GPU', network_upload:'SUB', network_download:'BAJ' },
  fr: { cpu_usage:'CPU', memory_usage:'RAM', gpu_temp:'GPU', gpu_usage:'GPU', cpu_power:'CPU', gpu_power:'GPU', network_upload:'UP', network_download:'DL' },
  ru: { cpu_usage:'CPU', memory_usage:'RAM', gpu_temp:'GPU', gpu_usage:'GPU', cpu_power:'CPU', gpu_power:'GPU', network_upload:'ВВ', network_download:'ЗАГ' },
  it: { cpu_usage:'CPU', memory_usage:'RAM', gpu_temp:'GPU', gpu_usage:'GPU', cpu_power:'CPU', gpu_power:'GPU', network_upload:'UP', network_download:'DN' },
  'pt-PT': { cpu_usage:'CPU', memory_usage:'RAM', gpu_temp:'GPU', gpu_usage:'GPU', cpu_power:'CPU', gpu_power:'GPU', network_upload:'UP', network_download:'DN' }
};

const unsupportedText = {
  en: 'Apple\nSilicon', ko: 'Apple\nSilicon', ja: 'Apple\nSilicon', de: 'Apple\nSilicon',
  es: 'Apple\nSilicon', fr: 'Apple\nSilicon', ru: 'Apple\nSilicon', it: 'Apple\nSilicon', 'pt-PT': 'Apple\nSilicon'
};

function compactRateBytes(bytes) {
  if (bytes === null || bytes === undefined || !Number.isFinite(bytes)) return null;
  if (bytes < 1024) return `${Math.max(0, Math.round(bytes))}B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(bytes < 10 * 1024 ? 1 : 0)}K`;
  if (bytes < 1024 ** 3) return `${(bytes / (1024 ** 2)).toFixed(bytes < 10 * 1024 ** 2 ? 1 : 0)}M`;
  return `${(bytes / (1024 ** 3)).toFixed(bytes < 10 * 1024 ** 3 ? 1 : 0)}G`;
}

function findMacmonBinary() {
  if (!IS_MACOS) return null;
  const candidate = path.resolve(__dirname, 'macmon', 'macmon');
  try {
    if (!fs.existsSync(candidate) || !fs.statSync(candidate).isFile()) return null;
    // ZIP extraction can lose executable bits depending on the installer.
    // Restore owner/group/world execute permission before launch.
    try { fs.chmodSync(candidate, 0o755); } catch (error) {}
    return candidate;
  } catch (error) {
    return null;
  }
}

function normLang(value) {
  const raw = String(value || 'en');
  const lower = raw.toLowerCase();
  if (lower === 'pt' || lower.startsWith('pt-')) return 'pt-PT';
  if (lower === 'kr' || lower.startsWith('ko')) return 'ko';
  if (lower === 'jp' || lower.startsWith('ja')) return 'ja';
  return i18n[lower] ? lower : 'en';
}

function getDefaultSettings() {
  return {
    title: 'CPU Usage',
    selected_metric: DEFAULT_METRIC,
    command: DEFAULT_METRIC,
    _lang: 'en',
    sync_title_on_action_change: false,
    default_visuals_initialized: true
  };
}

function mergeWithDefaults(settings) {
  const merged = { ...getDefaultSettings(), ...(settings || {}) };
  const metric = iconMap[merged.command] ? merged.command
    : (iconMap[merged.selected_metric] ? merged.selected_metric : DEFAULT_METRIC);
  merged.selected_metric = metric;
  merged.command = metric;
  merged.builtin_icon_name = iconMap[metric];
  return merged;
}

function settingsFromPayload(payload) {
  if (payload && payload.settings && typeof payload.settings === 'object') return payload.settings;
  return (payload && typeof payload === 'object') ? payload : {};
}

function hasMeaningfulSettings(settings) {
  const s = settings || {};
  return !!(s.command || s.selected_metric || s.title || s.default_visuals_initialized);
}

function resolveContext(context, payload = {}) {
  let page = Number.isInteger(payload.page) ? payload.page : null;
  let key = String(context || '');
  const match = /^p(\d+):(.+)$/.exec(key);
  if (match) {
    page = Number(match[1]);
    key = match[2];
  }
  return {
    context: String(context || ''),
    key,
    page: Number.isInteger(page) ? page : null
  };
}

function getIconPath(metric) {
  const iconName = iconMap[metric] || iconMap[DEFAULT_METRIC];
  return path.join(__dirname, 'icon', `${iconName}.png`);
}

function launchLHM() {
  if (!IS_WINDOWS || !fs.existsSync(lhmPath)) return;
  execFile('tasklist', ['/FI', `IMAGENAME eq ${exeName}`, '/NH'], (err, stdout) => {
    if (!err && stdout && stdout.toLowerCase().includes(exeName.toLowerCase())) {
      console.log('[SysMon] LibreHardwareMonitor is already running.');
      return;
    }
    try {
      const child = spawn(lhmPath, [], {
        detached: true,
        stdio: 'ignore',
        windowsHide: true
      });
      child.on('error', (error) => console.warn('[SysMon] LHM launch failed:', error.message));
      child.unref();
      console.log('[SysMon] LibreHardwareMonitor launch requested.');
    } catch (error) {
      console.warn('[SysMon] LHM launch failed:', error.message);
    }
  });
}

let macmonChild = null;

function launchMacmon() {
  if (!IS_APPLE_SILICON) return;
  const binary = findMacmonBinary();
  if (!binary) {
    console.warn('[SysMon] bundled macmon binary not found: macmon/macmon');
    return;
  }
  try {
    macmonChild = spawn(binary, ['serve', '--host', '127.0.0.1', '-p', String(MACMON_PORT), '-i', '1000'], {
      stdio: 'ignore'
    });
    macmonChild.on('error', (error) => console.warn('[SysMon] macmon launch failed:', error.message));
    macmonChild.on('exit', (code, signal) => {
      if (code && code !== 0) console.warn(`[SysMon] macmon exited with code ${code}${signal ? ` (${signal})` : ''}.`);
      macmonChild = null;
    });
    console.log(`[SysMon] macmon launch requested: ${binary}`);
  } catch (error) {
    console.warn('[SysMon] macmon launch failed:', error.message);
  }
}

function stopMacmon() {
  if (!macmonChild) return;
  try { macmonChild.kill('SIGTERM'); } catch (error) {}
  macmonChild = null;
}

if (isMainThread) {
  let activeKeys = new Map();
  let cookieDeckSocket = null;
  let reconnectTimer = null;
  let reconnectAttempts = 0;
  let pollInFlight = false;
  let currentWorker = null;
  let lastResult = null;
  let errorStreak = 0;
  let startupQuietUntil = 0;
  let lastEndpoint = null;
  let macNetworkBaseline = null;

  launchLHM();
  launchMacmon();

  if (IS_MACOS) {
    process.once('SIGINT', () => { stopMacmon(); process.exit(0); });
    process.once('SIGTERM', () => { stopMacmon(); process.exit(0); });
    process.once('exit', stopMacmon);
  }

  function safeSend(message) {
    if (!cookieDeckSocket || cookieDeckSocket.readyState !== WebSocket.OPEN) return false;
    try {
      cookieDeckSocket.send(JSON.stringify(message));
      return true;
    } catch (error) {
      return false;
    }
  }

  const hardwareButtonIndexMap = {
    F15: 0, F16: 1, F17: 2, F18: 3, F19: 4,
    F20: 5, F21: 6, F22: 7, F23: 8, F24: 9,
  };

  function sendDynamicText(entry, text, fontSize = '18px') {
    if (!entry || entry.page === null || !entry.context) return;
    safeSend({
      event: 'setDynamicText',
      context: entry.context,
      payload: {
        text: String(text ?? ''),
        font_size: fontSize,
        color: '#FFFFFF',
        page: entry.page
      }
    });
  }

  function sendHardwareDynamicText(entry, text) {
    if (!entry || entry.page === null || !entry.key) return;
    const idx = hardwareButtonIndexMap[entry.key];
    if (!Number.isInteger(idx)) return;
    safeSend({
      event: 'sendToPlugin',
      context: entry.context,
      payload: {
        command: 'direct_serial',
        serial_cmd: 0xDD,
        serial_data: [entry.page, idx, ...Buffer.from(String(text ?? ''), 'utf8')]
      }
    });
  }

  // COMBO-X changes current_page before keyDidDisappear is delivered.  A bare
  // physical-key clear therefore targets the newly visible page and removes a
  // stale live-text label left in that slot by an earlier page.  The next
  // dynamic plugin on that slot can immediately draw its own text afterwards.
  function clearCurrentVisibleSlot(entry) {
    if (!entry || !entry.key || Date.now() < startupQuietUntil) return;
    safeSend({
      event: 'setDynamicText',
      context: entry.key,
      payload: { text: '', font_size: '18px', color: '#FFFFFF' }
    });
  }

  function removeContext(context, clearVisual = true) {
    const entry = activeKeys.get(context);
    if (entry && clearVisual && Date.now() >= startupQuietUntil) {
      sendDynamicText(entry, '');
      clearCurrentVisibleSlot(entry);
    }
    activeKeys.delete(context);
  }

  function sendBuiltinIcon(context, metric, page) {
    const iconPath = getIconPath(metric);
    if (!context || !fs.existsSync(iconPath)) return;
    const payload = { icon_path: iconPath, source: 'plugin' };
    if (Number.isInteger(page)) payload.page = page;
    safeSend({ event: 'setIcon', context, payload });
  }

  function makeEntry(context, payload, settings) {
    const resolved = resolveContext(context, payload || {});
    if (!resolved.context || resolved.page === null) {
      console.warn(`[SysMon] Ignoring unscoped context: ${context}`);
      return null;
    }
    const merged = mergeWithDefaults(settings);
    return {
      context: resolved.context,
      key: resolved.key,
      page: resolved.page,
      metric: merged.command,
      lang: normLang(merged._lang),
      lastText: null,
      readyAt: Math.max(Date.now() + PAGE_APPEAR_SETTLE_MS, startupQuietUntil)
    };
  }

  function initializeContext(context, payload) {
    const incomingSettings = settingsFromPayload(payload);
    const entry = makeEntry(context, payload, incomingSettings);
    if (!entry) return;

    activeKeys.set(context, entry);
    // Clear a stale live label in this physical slot before first paint, but
    // never inject 0xDD traffic while the host is doing its initial full sync.
    const clearDelay = Math.max(0, startupQuietUntil - Date.now() + 40);
    setTimeout(() => {
      if (activeKeys.get(context) === entry) clearCurrentVisibleSlot(entry);
    }, clearDelay);

    if (!hasMeaningfulSettings(incomingSettings)) {
      const defaults = getDefaultSettings();
      entry.metric = defaults.command;
      entry.lang = normLang(defaults._lang);
      safeSend({ event: 'setSettings', context, payload: defaults });
    }

    if (!IS_SENSOR_PLATFORM) {
      const text = unsupportedText[entry.lang] || unsupportedText.en;
      const wait = Math.max(0, entry.readyAt - Date.now());
      setTimeout(() => {
        if (activeKeys.get(context) !== entry) return;
        sendHardwareDynamicText(entry, text);
        entry.lastText = text;
      }, wait);
    } else if (lastResult && Date.now() >= entry.readyAt) {
      updateOneContext(entry, lastResult);
    }
  }

  function updateContextSettings(context, payload) {
    const entry = activeKeys.get(context);
    if (!entry) {
      // keyDidAppear is the authority for whether an instance is visible.  A
      // delayed PI/settings packet must never resurrect a hidden page context.
      return;
    }

    const merged = mergeWithDefaults(settingsFromPayload(payload));
    const resolved = resolveContext(context, payload || {});
    const previousMetric = entry.metric;
    entry.metric = merged.command;
    entry.lang = normLang(merged._lang);
    if (resolved.page !== null) entry.page = resolved.page;
    entry.lastText = null;

    if (previousMetric !== entry.metric) {
      sendBuiltinIcon(entry.context, entry.metric, entry.page);
    }

    if (!IS_SENSOR_PLATFORM) {
      const text = unsupportedText[entry.lang] || unsupportedText.en;
      const wait = Math.max(0, entry.readyAt - Date.now());
      setTimeout(() => {
        if (activeKeys.get(context) !== entry) return;
        sendHardwareDynamicText(entry, text);
        entry.lastText = text;
      }, wait);
    } else if (lastResult && Date.now() >= entry.readyAt) {
      updateOneContext(entry, lastResult);
    }
  }

  function displayValue(value, suffix = '') {
    if (value === null || value === undefined || value === '' || value === 'N/A') return 'N/A';
    return `${value}${suffix}`;
  }

  function buildMetricText(entry, data) {
    const labels = i18n[entry.lang] || i18n.en;
    switch (entry.metric) {
      case 'cpu_usage': return `${labels.cpu_usage}\n${displayValue(data.cpu_load, '%')}`;
      case 'memory_usage': return `${labels.memory_usage}\n${displayValue(data.mem_percent, '%')}`;
      case 'gpu_temp': return `${labels.gpu_temp}\n${displayValue(data.gpu_temp, '°C')}`;
      case 'gpu_usage': return `${labels.gpu_usage}\n${displayValue(data.gpu_load, '%')}`;
      case 'cpu_power': return `${labels.cpu_power}\n${displayValue(data.cpu_power, 'W')}`;
      case 'gpu_power': return `${labels.gpu_power}\n${displayValue(data.gpu_power, 'W')}`;
      case 'network_upload': return `${labels.network_upload}\n${displayValue(data.net_upload)}`;
      case 'network_download': return `${labels.network_download}\n${displayValue(data.net_download)}`;
      default: return 'N/A';
    }
  }

  function updateOneContext(entry, data) {
    if (!entry || !activeKeys.has(entry.context)) return;
    if (Date.now() < entry.readyAt) return;
    const text = buildMetricText(entry, data);
    if (entry.lastText === text) return;
    sendHardwareDynamicText(entry, text);
    entry.lastText = text;
  }

  function updateDynamicContent(data) {
    for (const entry of activeKeys.values()) updateOneContext(entry, data);
  }

  function updateUnavailableContent() {
    for (const entry of activeKeys.values()) {
      if (Date.now() < entry.readyAt) continue;
      const labels = i18n[entry.lang] || i18n.en;
      const label = labels[entry.metric] || 'SYS';
      const text = `${label}\nN/A`;
      if (entry.lastText !== text) {
        sendHardwareDynamicText(entry, text);
        entry.lastText = text;
      }
    }
  }

  function stopCurrentWorker() {
    if (currentWorker) {
      try { currentWorker.terminate(); } catch (error) {}
      currentWorker = null;
    }
    pollInFlight = false;
  }

  function scheduleReconnect() {
    if (reconnectTimer) return;
    const delay = Math.min(10000, 1000 * Math.max(1, reconnectAttempts));
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      connectToCookieDeck();
    }, delay);
  }

  function connectToCookieDeck() {
    if (cookieDeckSocket && (
      cookieDeckSocket.readyState === WebSocket.OPEN ||
      cookieDeckSocket.readyState === WebSocket.CONNECTING
    )) return;

    cookieDeckSocket = new WebSocket(uri);

    cookieDeckSocket.on('open', () => {
      reconnectAttempts = 0;
      activeKeys.clear();
      lastResult = null;
      errorStreak = 0;
      macNetworkBaseline = null;
      startupQuietUntil = Date.now() + STARTUP_QUIET_MS;
      safeSend({ event: registerEvent, uuid: pluginUUID });
      console.log('[SysMon] Connected to COMBO-X.');
    });

    cookieDeckSocket.on('message', (message) => {
      let data;
      try { data = JSON.parse(message.toString()); }
      catch (error) { return; }

      const context = String(data.context || '');
      const payload = data.payload || {};

      if (data.event === 'keyDidAppear' || data.event === 'willAppear') {
        initializeContext(context, payload);
        return;
      }

      if (data.event === 'keyDidDisappear' || data.event === 'willDisappear') {
        removeContext(context, true);
        return;
      }

      if (data.event === 'didReceiveSettings') {
        updateContextSettings(context, payload);
        return;
      }

      if (data.event === 'applicationDidLaunch' || data.event === 'didReceiveGlobalSettings') {
        const language = payload.language;
        if (language) {
          for (const entry of activeKeys.values()) {
            entry.lang = normLang(language);
            entry.lastText = null;
          }
          if (lastResult) updateDynamicContent(lastResult);
        }
        return;
      }

      if (data.event === 'sendToPlugin') {
        const inner = payload.payload || payload;
        if (inner.command === 'apply_builtin_icon') {
          const entry = activeKeys.get(context);
          const metric = iconMap[inner.metric] ? inner.metric : (entry ? entry.metric : DEFAULT_METRIC);
          const resolved = entry || makeEntry(context, payload, { command: metric });
          if (resolved) sendBuiltinIcon(context, metric, resolved.page);
        }
        return;
      }

      if (data.event === 'keyDown') {
        // A missed appearance event should not break the button forever, but
        // normal repeated keyDown events never create duplicate contexts.
        if (!activeKeys.has(context)) initializeContext(context, payload);
        else updateContextSettings(context, payload);
      }
    });

    cookieDeckSocket.on('close', () => {
      reconnectAttempts += 1;
      activeKeys.clear();
      stopCurrentWorker();
      scheduleReconnect();
    });

    cookieDeckSocket.on('error', () => {});
  }

  function applyMacNetworkRate(result) {
    if (!IS_APPLE_SILICON || !result) return result;
    const inBytes = Number(result.net_total_in);
    const outBytes = Number(result.net_total_out);
    const iface = result.net_iface || '';
    const now = Date.now();

    let downRate = 0;
    let upRate = 0;
    if (
      macNetworkBaseline &&
      macNetworkBaseline.iface === iface &&
      Number.isFinite(inBytes) && Number.isFinite(outBytes) &&
      inBytes >= macNetworkBaseline.inBytes &&
      outBytes >= macNetworkBaseline.outBytes
    ) {
      const seconds = Math.max(0.05, (now - macNetworkBaseline.time) / 1000);
      downRate = (inBytes - macNetworkBaseline.inBytes) / seconds;
      upRate = (outBytes - macNetworkBaseline.outBytes) / seconds;
    }

    if (Number.isFinite(inBytes) && Number.isFinite(outBytes)) {
      macNetworkBaseline = { iface, inBytes, outBytes, time: now };
    }

    result.net_download = compactRateBytes(downRate) || '0B';
    result.net_upload = compactRateBytes(upRate) || '0B';
    delete result.net_total_in;
    delete result.net_total_out;
    delete result.net_iface;
    return result;
  }

  setInterval(() => {
    if (!IS_SENSOR_PLATFORM || pollInFlight || activeKeys.size === 0) return;
    if (Date.now() < startupQuietUntil) return;

    pollInFlight = true;
    const worker = new Worker(__filename);
    currentWorker = worker;
    const timer = setTimeout(() => {
      try { worker.terminate(); } catch (error) {}
    }, WORKER_TIMEOUT_MS);

    worker.on('message', (data) => {
      if (data && data.result) {
        errorStreak = 0;
        if (data.endpoint && data.endpoint !== lastEndpoint) {
          lastEndpoint = data.endpoint;
          const providerName = IS_WINDOWS ? 'LibreHardwareMonitor' : 'macmon';
          console.log(`[SysMon] ${providerName} endpoint: ${data.endpoint}`);
        }
        const normalizedResult = applyMacNetworkRate(data.result);
        lastResult = normalizedResult;
        updateDynamicContent(normalizedResult);
      } else if (data && data.error) {
        errorStreak += 1;
        if (errorStreak >= ERROR_DISPLAY_THRESHOLD) updateUnavailableContent();
      }
    });

    worker.on('error', () => {
      errorStreak += 1;
      if (errorStreak >= ERROR_DISPLAY_THRESHOLD) updateUnavailableContent();
    });

    worker.on('exit', () => {
      clearTimeout(timer);
      if (currentWorker === worker) currentWorker = null;
      pollInFlight = false;
    });
  }, POLL_INTERVAL_MS);

  connectToCookieDeck();

} else {
  const axios = require('axios');

  function numericValue(value) {
    if (value === null || value === undefined) return null;
    const normalized = String(value).replace(',', '.');
    const match = normalized.match(/-?\d+(?:\.\d+)?/);
    if (!match) return null;
    const number = Number(match[0]);
    return Number.isFinite(number) ? Math.round(number) : null;
  }

  function findCategory(hardware, categoryText) {
    return (hardware.Children || []).find(child => child && child.Text === categoryText);
  }

  function findSensorValue(hardwareNodes, imageKeywords, categoryText, sensorKeywords) {
    for (const hardware of hardwareNodes) {
      const image = String(hardware && hardware.ImageURL || '').toLowerCase();
      if (!imageKeywords.some(keyword => image.includes(keyword))) continue;
      const category = findCategory(hardware, categoryText);
      if (!category || !Array.isArray(category.Children)) continue;
      for (const keyword of sensorKeywords) {
        const lowerKeyword = keyword.toLowerCase();
        const sensor = category.Children.find(item =>
          String(item && item.Text || '').toLowerCase().includes(lowerKeyword)
        );
        if (sensor && sensor.Value !== undefined) return numericValue(sensor.Value);
      }
    }
    return null;
  }

  function parseRateToBytes(value) {
    const text = String(value || '').trim();
    const match = text.match(/([\d.,]+)\s*([KMGT]?B)\s*(?:\/\s*s)?/i);
    if (!match) return null;
    const amount = Number(match[1].replace(',', '.'));
    if (!Number.isFinite(amount)) return null;
    const unit = match[2].toUpperCase();
    const multipliers = { B:1, KB:1024, MB:1024**2, GB:1024**3, TB:1024**4 };
    return amount * (multipliers[unit] || 1);
  }

  function findNetworkRate(hardwareNodes, direction) {
    let best = null;
    for (const hardware of hardwareNodes) {
      const image = String(hardware && hardware.ImageURL || '').toLowerCase();
      if (!image.includes('nic')) continue;
      const category = findCategory(hardware, 'Throughput');
      if (!category || !Array.isArray(category.Children)) continue;
      const sensor = category.Children.find(item =>
        String(item && item.Text || '').toLowerCase().includes(direction.toLowerCase())
      );
      if (!sensor) continue;
      const bytes = parseRateToBytes(sensor.Value);
      if (bytes !== null && (best === null || bytes > best)) best = bytes;
    }
    return compactRateBytes(best);
  }

  function readConfiguredListener() {
    try {
      const configPath = path.resolve(__dirname, 'LibreHardwareMonitor', 'LibreHardwareMonitor.config');
      const xml = fs.readFileSync(configPath, 'utf8');
      const ipMatch = xml.match(/<add\s+key=["']listenerIp["']\s+value=["']([^"']+)["']/i);
      const portMatch = xml.match(/<add\s+key=["'](?:listenerPort|HttpServerPort)["']\s+value=["'](\d+)["']/i);
      return {
        ip: ipMatch ? ipMatch[1].trim() : null,
        port: portMatch ? Number(portMatch[1]) : 8085
      };
    } catch (error) {
      return { ip: null, port: 8085 };
    }
  }

  function currentIpv4Addresses() {
    const out = [];
    const interfaces = os.networkInterfaces();
    for (const values of Object.values(interfaces)) {
      for (const iface of values || []) {
        const family = typeof iface.family === 'string' ? iface.family : (iface.family === 4 ? 'IPv4' : String(iface.family));
        if (family === 'IPv4' && !iface.internal && iface.address) out.push(iface.address);
      }
    }
    return out;
  }

  function endpointCandidates() {
    const configured = readConfiguredListener();
    const port = configured.port || 8085;
    const hosts = [];
    const add = (host) => {
      if (!host || hosts.includes(host)) return;
      hosts.push(host);
    };

    // IMPORTANT: LibreHardwareMonitor can be configured to listen on one
    // specific LAN address.  The bundled config used by this plugin does that,
    // so forcing 127.0.0.1 breaks otherwise-working installations.
    add(configured.ip);
    for (const ip of currentIpv4Addresses()) add(ip);
    add('127.0.0.1');
    add('localhost');
    return hosts.map(host => `http://${host}:${port}/data.json`);
  }

  async function fetchLhmJson() {
    const errors = [];
    for (const url of endpointCandidates()) {
      try {
        const response = await axios.get(url, {
          timeout: 650,
          proxy: false
        });
        if (response && response.data) return { data: response.data, url };
      } catch (error) {
        errors.push(`${url}: ${error.code || error.message || error}`);
      }
    }
    throw new Error(errors.join(' | ') || 'LibreHardwareMonitor web server unavailable');
  }

  function finiteNumber(value) {
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  }

  function firstFinite(...values) {
    for (const value of values) {
      const number = finiteNumber(value);
      if (number !== null) return number;
    }
    return null;
  }

  function ratioToPercent(value) {
    const number = finiteNumber(value);
    if (number === null) return null;
    const percent = Math.abs(number) <= 1.5 ? number * 100 : number;
    return Math.round(Math.max(0, Math.min(100, percent)));
  }

  function rounded(value, digits = 0) {
    const number = finiteNumber(value);
    if (number === null) return null;
    const factor = 10 ** digits;
    return Math.round(number * factor) / factor;
  }

  function parseDefaultInterface() {
    const candidates = ['/sbin/route', '/usr/sbin/route', 'route'];
    for (const command of candidates) {
      try {
        const output = execFileSync(command, ['-n', 'get', 'default'], {
          encoding: 'utf8', timeout: 700, stdio: ['ignore', 'pipe', 'ignore']
        });
        const match = String(output || '').match(/^\s*interface:\s*(\S+)/m);
        if (match) return match[1];
      } catch (error) {}
    }
    return null;
  }

  function parseMacNetworkTotals() {
    const commands = ['/usr/sbin/netstat', '/usr/bin/netstat', 'netstat'];
    let output = null;
    for (const command of commands) {
      try {
        output = execFileSync(command, ['-ibn'], {
          encoding: 'utf8', timeout: 900, stdio: ['ignore', 'pipe', 'ignore']
        });
        if (output) break;
      } catch (error) {}
    }
    if (!output) return { iface: null, inBytes: null, outBytes: null };

    const lines = String(output).split(/\r?\n/).filter(Boolean);
    let header = null;
    let headerIndex = -1;
    for (let i = 0; i < lines.length; i++) {
      const tokens = lines[i].trim().split(/\s+/);
      if (tokens.includes('Name') && tokens.includes('Ibytes') && tokens.includes('Obytes')) {
        header = tokens;
        headerIndex = i;
        break;
      }
    }
    if (!header) return { iface: null, inBytes: null, outBytes: null };

    const nameIndex = header.indexOf('Name');
    const inIndex = header.indexOf('Ibytes');
    const outIndex = header.indexOf('Obytes');
    const requiredIndex = Math.max(nameIndex, inIndex, outIndex);
    const byInterface = new Map();

    for (let i = headerIndex + 1; i < lines.length; i++) {
      const tokens = lines[i].trim().split(/\s+/);
      if (tokens.length <= requiredIndex) continue;
      const name = tokens[nameIndex];
      const inBytes = Number(tokens[inIndex]);
      const outBytes = Number(tokens[outIndex]);
      if (!name || !Number.isFinite(inBytes) || !Number.isFinite(outBytes)) continue;
      const previous = byInterface.get(name);
      if (!previous || inBytes + outBytes > previous.inBytes + previous.outBytes) {
        byInterface.set(name, { iface: name, inBytes, outBytes });
      }
    }

    const defaultIface = parseDefaultInterface();
    if (defaultIface && byInterface.has(defaultIface)) return byInterface.get(defaultIface);

    let best = null;
    for (const value of byInterface.values()) {
      if (value.iface === 'lo0' || value.iface.startsWith('llw')) continue;
      if (!best || value.inBytes + value.outBytes > best.inBytes + best.outBytes) best = value;
    }
    return best || { iface: null, inBytes: null, outBytes: null };
  }

  async function fetchMacmonJson() {
    const errors = [];
    for (const url of MACMON_ENDPOINTS) {
      try {
        const response = await axios.get(url, { timeout: 800, proxy: false });
        if (response && response.data) return { data: response.data, url };
      } catch (error) {
        errors.push(`${url}: ${error.code || error.message || error}`);
      }
    }
    throw new Error(errors.join(' | ') || 'macmon server unavailable');
  }

  function normalizeMacmon(data) {
    const memory = data && data.memory || {};
    const temp = data && data.temp || {};
    const gpuTupleRatio = Array.isArray(data && data.gpu_usage) ? data.gpu_usage[1] : null;
    const cpuRatio = firstFinite(
      data && data.cpu_active_ratio,
      data && data.cpu_usage_pct,
      data && data.cpu_scaled_ratio
    );
    const gpuRatio = firstFinite(
      data && data.gpu_active_ratio,
      data && data.gpu_scaled_ratio,
      gpuTupleRatio
    );
    const ramTotal = finiteNumber(memory.ram_total);
    const ramUsage = finiteNumber(memory.ram_usage);
    const network = parseMacNetworkTotals();

    return {
      cpu_load: ratioToPercent(cpuRatio),
      mem_percent: ramTotal && ramTotal > 0 && ramUsage !== null
        ? Math.round(Math.max(0, Math.min(100, (ramUsage / ramTotal) * 100)))
        : null,
      gpu_temp: rounded(temp.gpu_temp_avg, 0),
      gpu_load: ratioToPercent(gpuRatio),
      cpu_power: rounded(data && data.cpu_power, 1),
      gpu_power: rounded(data && data.gpu_power, 1),
      net_total_in: network.inBytes,
      net_total_out: network.outBytes,
      net_iface: network.iface
    };
  }

  async function fetchWindowsData() {
    const response = await fetchLhmJson();
    const hardwareNodes = response.data?.Children?.[0]?.Children || [];
    return {
      endpoint: response.url,
      result: {
        // Keep the same sensor names that the original working plugin used,
        // with a couple of harmless fallbacks for newer LHM builds.
        cpu_load: findSensorValue(hardwareNodes, ['cpu'], 'Load', ['CPU Total', 'Total']),
        mem_percent: findSensorValue(hardwareNodes, ['ram'], 'Load', ['Memory']),
        gpu_temp: findSensorValue(hardwareNodes, ['gpu'], 'Temperatures', ['GPU Core', 'Core', 'Hot Spot']),
        gpu_load: findSensorValue(hardwareNodes, ['gpu'], 'Load', ['GPU Core', 'Core']),
        cpu_power: findSensorValue(hardwareNodes, ['cpu'], 'Powers', ['Package', 'CPU Package']),
        gpu_power: findSensorValue(hardwareNodes, ['gpu'], 'Powers', ['GPU Power', 'Board Power', 'Package']),
        net_upload: findNetworkRate(hardwareNodes, 'Upload'),
        net_download: findNetworkRate(hardwareNodes, 'Download')
      }
    };
  }

  async function fetchMacData() {
    const response = await fetchMacmonJson();
    return { endpoint: response.url, result: normalizeMacmon(response.data) };
  }

  async function fetchData() {
    try {
      if (IS_WINDOWS) {
        parentPort.postMessage(await fetchWindowsData());
      } else if (IS_APPLE_SILICON) {
        parentPort.postMessage(await fetchMacData());
      } else {
        parentPort.postMessage({ error: 'System Monitor requires Windows or Apple Silicon macOS.' });
      }
    } catch (error) {
      parentPort.postMessage({ error: error.message || String(error) });
    }
  }

  fetchData();
}
