import asyncio
import websockets
import json
import subprocess
import os
import shlex
import sys


try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

class VSCodeDevToolsPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.vscodedevtools"
        self.uri = "ws://localhost:8765"
        self.websocket = None
        self.last_valid_settings = {}
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.action_default_icon = {
            "com.cookie.vscodedevtools.hotkey": "ACTION_HOTKEY",
            "com.cookie.vscodedevtools.git": "ACTION_GIT",
        }

        self.hotkey_icon_map = {
            "ctrl+shift+p": "STATE_COMMAND_PALETTE",
            "command+shift+p": "STATE_COMMAND_PALETTE",
            "ctrl+`": "STATE_TERMINAL",
            "ctrl+b": "STATE_SIDEBAR",
            "command+b": "STATE_SIDEBAR",
            "ctrl+,": "STATE_SETTINGS",
            "command+,": "STATE_SETTINGS",
            "f5": "STATE_DEBUG_START",
            "shift+f5": "STATE_DEBUG_STOP",
            "f10": "STATE_STEP_OVER",
            "f11": "STATE_STEP_INTO",
            "alt+shift+f": "STATE_FORMAT",
            "option+shift+f": "STATE_FORMAT",
            "ctrl+/": "STATE_COMMENT",
            "command+/": "STATE_COMMENT",
            "ctrl+d": "STATE_SELECT_WORD",
            "command+d": "STATE_SELECT_WORD",
        }

        self.git_icon_map = {
            "pull": "STATE_GIT_PULL",
            "push": "STATE_GIT_PUSH",
            "status": "STATE_GIT_STATUS",
            "add .": "STATE_GIT_ADD_ALL",
            "commit -m 'Update'": "STATE_GIT_QUICK_COMMIT",
            "fetch": "STATE_GIT_FETCH",
        }

    def _default_settings_for_action(self, action_id):
        base = {
            "action_uuid": action_id,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "default_visuals_initialized": True,
        }
        if action_id == "com.cookie.vscodedevtools.hotkey":
            base.update({
                "keys": "",
                "command": "",
                "builtin_icon_name": self.action_default_icon[action_id],
            })
        else:
            base.update({
                "git_command": "",
                "project_path": "",
                "command": "",
                "builtin_icon_name": self.action_default_icon["com.cookie.vscodedevtools.git"],
            })
        return base

    def _merge_with_defaults(self, action_id, settings):
        merged = self._default_settings_for_action(action_id)
        merged.update(settings or {})
        merged["action_uuid"] = action_id
        if action_id == "com.cookie.vscodedevtools.hotkey":
            cmd = merged.get("command") or merged.get("keys") or ""
            merged["keys"] = cmd
            merged["command"] = cmd
        else:
            cmd = merged.get("command") or merged.get("git_command") or ""
            merged["git_command"] = cmd
            merged["command"] = cmd
        merged["builtin_icon_name"] = self._get_icon_name(action_id, cmd)
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("keys"),
            s.get("git_command"),
            s.get("project_path"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False),
        ])

    def _get_icon_name(self, action_id, command_value):
        cmd = (command_value or "").strip()
        if action_id == "com.cookie.vscodedevtools.hotkey":
            return self.hotkey_icon_map.get(cmd, self.action_default_icon[action_id])
        return self.git_icon_map.get(cmd, self.action_default_icon["com.cookie.vscodedevtools.git"])

    def _get_icon_path(self, action_id, command_value):
        icon_name = self._get_icon_name(action_id, command_value)
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id, command_value=""):
        if not self.websocket or not context:
            return
        icon_path = self._get_icon_path(action_id, command_value)
        if os.path.exists(icon_path):
            await self.websocket.send(json.dumps({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            }))

    async def _initialize_default_visuals_if_new(self, context, action_id, incoming_settings):
        if not context or not action_id:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings_for_action(action_id)
            self.last_valid_settings[context] = defaults.copy()
            if self.websocket:
                await self.websocket.send(json.dumps({
                    "event": "setSettings",
                    "context": context,
                    "payload": defaults
                }))
            await self._send_builtin_icon(context, action_id, "")
            return False

        merged = self._merge_with_defaults(action_id, incoming_settings)
        self.last_valid_settings[context] = merged
        await self._send_builtin_icon(context, action_id, merged.get("command", ""))
        return True

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.uri) as websocket:
                    self.websocket = websocket
                    await self.register()
                    await self.listen()
            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] Connection failed: {e}. Retrying in 5s...", flush=True)
                await asyncio.sleep(5)
            finally:
                self.websocket = None

    async def register(self):
        await self.websocket.send(json.dumps({
            "event": "register",
            "uuid": self.PLUGIN_UUID
        }))
        print(f"[{self.PLUGIN_UUID}] Registered.", flush=True)

    async def listen(self):
        async for message in self.websocket:
            try:
                data = json.loads(message)
                event = data.get("event")
                context = data.get("context")
                payload = data.get("payload", {}) or {}
                action_id = data.get("action") or payload.get("action") or payload.get("action_uuid")

                if event == "keyDidAppear":
                    raw_settings = payload.get("settings", {}) or {}
                    action_id = data.get("action") or raw_settings.get("action_uuid")
                    if context and action_id:
                        await self._initialize_default_visuals_if_new(context, action_id, raw_settings)

                elif event == "didReceiveSettings":
                    settings = payload.get("settings", payload) or {}
                    action_id = settings.get("action_uuid") or action_id or self.last_valid_settings.get(context, {}).get("action_uuid")
                    if context and action_id:
                        merged = self._merge_with_defaults(action_id, {**self.last_valid_settings.get(context, {}), **settings})
                        self.last_valid_settings[context] = merged

                elif event in ["keyDidDisappear", "willDisappear"]:
                    if context in self.last_valid_settings:
                        self.last_valid_settings.pop(context, None)

                elif event == "sendToPlugin":
                    await self.on_pi_request(data)

                elif event == "keyDown":
                    await self.on_key_down(data)

            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] Error: {e}", flush=True)

    async def ensure_settings(self, context, data):
        payload = data.get("payload", {}) or {}
        incoming_settings = payload.get("settings", {}) or {}
        action_id = data.get("action") or incoming_settings.get("action_uuid") or self.last_valid_settings.get(context, {}).get("action_uuid")
        if not action_id:
            return None, {}
        cached = self.last_valid_settings.get(context, {})
        merged = self._merge_with_defaults(action_id, {**cached, **incoming_settings})
        self.last_valid_settings[context] = merged
        return action_id, merged


    def _mac_hotkey_for_vscode(self, keys):
        """Translate Windows-style VS Code defaults to macOS VS Code shortcuts."""
        key = (keys or "").strip().lower()
        mac_map = {
            "ctrl+shift+p": "command+shift+p",
            # VS Code on macOS commonly keeps Ctrl+` for integrated terminal.
            "ctrl+`": "ctrl+`",
            "ctrl+b": "command+b",
            "ctrl+,": "command+,",
            "f5": "f5",
            "shift+f5": "shift+f5",
            "f10": "f10",
            "f11": "f11",
            "alt+shift+f": "option+shift+f",
            "ctrl+/": "command+/",
            "ctrl+d": "command+d",
        }
        return mac_map.get(key, key)

    def _normalize_pyautogui_key(self, key_name):
        key = (key_name or "").strip().lower()
        aliases = {
            "cmd": "command" if IS_MACOS else "win",
            "command": "command" if IS_MACOS else "win",
            "meta": "command" if IS_MACOS else "win",
            "win": "command" if IS_MACOS else "win",
            "windows": "command" if IS_MACOS else "win",
            "option": "option" if IS_MACOS else "alt",
            "alt": "option" if IS_MACOS else "alt",
            "control": "ctrl",
            "return": "enter",
            "escape": "esc",
            "plus": "+",
        }
        return aliases.get(key, key)

    def _send_hotkey_sync(self, keys):
        hotkey = self._mac_hotkey_for_vscode(keys) if IS_MACOS else (keys or "")
        parts = [self._normalize_pyautogui_key(p) for p in hotkey.split('+') if p.strip()]
        if not parts:
            return

        if IS_WINDOWS and keyboard_available:
            keyboard.send(keys)
            return

        if not pyautogui_available:
            print(f"[Hotkey Error] pyautogui is not available. Cannot send: {hotkey}", flush=True)
            return

        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts)

    async def on_key_down(self, data):
        context = data.get("context")
        action_id, final_settings = await self.ensure_settings(context, data)
        if not action_id:
            return

        cmd_value = final_settings.get("command", "")

        if action_id == "com.cookie.vscodedevtools.hotkey":
            keys = cmd_value or final_settings.get("keys")
            if keys:
                send_keys = self._mac_hotkey_for_vscode(keys) if IS_MACOS else keys
                print(f"[Hotkey] Sending: {send_keys}", flush=True)
                await asyncio.sleep(0.05)
                await asyncio.to_thread(self._send_hotkey_sync, keys)

        elif action_id == "com.cookie.vscodedevtools.git":
            git_cmd = cmd_value or final_settings.get("git_command")
            project_path = (final_settings.get("project_path") or "").strip()

            if git_cmd and project_path:
                if os.path.exists(project_path):
                    await asyncio.to_thread(self.run_git, git_cmd, project_path)
                else:
                    print(f"[Git Error] Path not found: {project_path}", flush=True)

    def run_git(self, command, cwd):
        try:
            print(f"[Git] Running 'git {command}' in '{cwd}'", flush=True)
            startupinfo = None
            if os.name == 'nt':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

            full_cmd = ["git"] + shlex.split(command)
            result = subprocess.run(
                full_cmd, cwd=cwd, capture_output=True, text=True,
                startupinfo=startupinfo
            )

            if result.returncode == 0:
                print(f"[Git Success] {result.stdout.strip()}", flush=True)
            else:
                print(f"[Git Error] {result.stderr.strip()}", flush=True)
        except Exception as e:
            print(f"[Git Exception] {e}", flush=True)

    async def on_pi_request(self, data):
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        command = payload.get("command")
        action_id = payload.get("action_uuid") or self.last_valid_settings.get(context, {}).get("action_uuid")

        if command == "apply_builtin_icon" and action_id:
            action_command = payload.get("action_command", "")
            await self._send_builtin_icon(context, action_id, action_command)

if __name__ == "__main__":
    plugin = VSCodeDevToolsPlugin()
    asyncio.run(plugin.connect())
