import asyncio
import glob
import io
import json
import os
import plistlib
import subprocess
import sys
import webbrowser
from html.parser import HTMLParser
from urllib.parse import unquote, urljoin, urlparse

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

if IS_WINDOWS:
    try:
        import ctypes
    except Exception:
        ctypes = None
else:
    ctypes = None

libraries_ok = False
requests = None
winreg = None
Image = None

try:
    import requests
except ImportError as e:
    print(f"[Launch Plugin Warning] requests is unavailable: {e}")

try:
    from PIL import Image
except ImportError as e:
    print(f"[Launch Plugin Warning] Pillow is unavailable: {e}")

if IS_WINDOWS:
    try:
        import winreg
    except ImportError:
        winreg = None

libraries_ok = requests is not None and Image is not None


class _FaviconLinkParser(HTMLParser):
    """Collect favicon candidates without requiring BeautifulSoup."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.icons = []

    def handle_starttag(self, tag, attrs):
        if str(tag).lower() != "link":
            return
        values = {
            str(name).lower(): value
            for name, value in attrs
            if name
        }
        rel = str(values.get("rel") or "").lower()
        href = str(values.get("href") or "").strip()
        if "icon" not in rel or not href:
            return

        sizes = str(values.get("sizes") or "")
        largest_size = 0
        for token in sizes.lower().split():
            if "x" not in token:
                continue
            try:
                width, height = token.split("x", 1)
                largest_size = max(largest_size, int(width), int(height))
            except (TypeError, ValueError):
                continue

        # Prefer explicitly large regular favicons, while retaining every
        # candidate so an unsupported SVG can fall through to PNG/ICO.
        regular_icon = 1 if rel in ("icon", "shortcut icon") else 0
        self.icons.append((regular_icon, largest_size, href))


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}
        self.app_list_cache = None
        self._app_list_lock = asyncio.Lock()
        self.available_browsers = self.find_installed_browsers() if libraries_ok else {}
        base_path = os.environ.get("ACTIONBOX_BASE_PATH") or os.path.dirname(os.path.dirname(os.path.dirname(self.plugin_dir)))
        self.log_file = os.path.join(base_path, "logs", "launch_debug.log")
        self.texts = {
            "en": {"timeout": "Scan timed out", "error": "Error while loading app list"},
            "ko": {"timeout": "스캔 시간 초과", "error": "목록을 불러오는 중 오류 발생"},
            "ja": {"timeout": "スキャン時間切れ", "error": "一覧読み込み中にエラーが発生しました"},
            "de": {"timeout": "Scan-Zeitüberschreitung", "error": "Fehler beim Laden der App-Liste"},
            "es": {"timeout": "Tiempo de escaneo agotado", "error": "Error al cargar la lista de apps"},
            "fr": {"timeout": "Délai d’analyse dépassé", "error": "Erreur lors du chargement de la liste des applications"},
            "ru": {"timeout": "Время сканирования истекло", "error": "Ошибка при загрузке списка приложений"},
            "it": {"timeout": "Timeout scansione", "error": "Errore durante il caricamento dell'elenco app"},
            "pt-PT": {"timeout": "Tempo de análise esgotado", "error": "Erro ao carregar a lista de apps"}
        }
        self.action_icon_map = {
            "open": "ACTION_OPEN",
            "runapp": "ACTION_RUNAPP",
            "website": "ACTION_WEB",
        }

    def _get_action_key(self, action_id):
        base_id = str(action_id or "").split("#", 1)[0]
        if base_id == "com.cookie.shortcuts.open":
            return "open"
        if base_id == "com.cookie.shortcuts.runapp":
            return "runapp"
        if base_id == "com.cookie.web.open_url":
            return "website"
        return None

    def _get_icon_path(self, action_id="", icon_name=None):
        if not icon_name:
            icon_name = self.action_icon_map.get(self._get_action_key(action_id), "ACTION_WEB")
        icon_name = os.path.basename(str(icon_name)).replace(".png", "")
        icon_path = os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")
        if os.path.exists(icon_path):
            return icon_path
        fallback = os.path.join(self.plugin_dir, "default.png")
        return fallback if os.path.exists(fallback) else None

    def _app_data_dir(self):
        if IS_WINDOWS:
            root = os.environ.get("APPDATA") or os.path.expanduser("~\\AppData\\Roaming")
        elif IS_MACOS:
            root = os.path.expanduser("~/Library/Application Support")
        else:
            root = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
        path = os.path.join(root, "ComboX", "com_cookie_launch")
        os.makedirs(path, exist_ok=True)
        return path

    async def _send_builtin_icon(self, context, action_id="", icon_name=None):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        if not icon_name and context:
            icon_name = (self.context_settings.get(context, {}) or {}).get("builtin_icon_name")
        icon_path = self._get_icon_path(action_id, icon_name)
        if context and icon_path and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _send_application_icon(self, context, payload):
        """Apply the icon belonging to the newly selected application."""
        if not context:
            return

        payload = payload or {}
        app_id = str(payload.get("appid") or "").strip()
        icon_path = str(payload.get("icon_path") or "").strip()

        # Windows app discovery normally prepares a PNG in app_icons.  If icon
        # extraction failed, replace the previous app artwork with the Run App
        # fallback instead of leaving a stale icon from the old selection.
        if not icon_path or not os.path.isfile(icon_path):
            icon_path = self._get_icon_path("com.cookie.shortcuts.runapp")
        if not icon_path or not os.path.isfile(icon_path):
            return

        await self.runner.send_message({
            "event": "setIcon",
            "context": context,
            "payload": {
                "icon_path": os.path.abspath(icon_path),
                "source": "application_icon",
                "appid": app_id,
            }
        })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return
        action_key = self._get_action_key(action_id)
        if not action_key:
            return
        settings = dict(settings or {})

        if action_key == "open":
            meaningful_keys = ["path", "command", "builtin_icon_name", "default_visuals_initialized", "title"]
            defaults = {
                "path": "", "command": "", "_lang": "en",
                "sync_title_on_path_change": False,
                "builtin_icon_name": "ACTION_OPEN", "default_visuals_initialized": True
            }
        elif action_key == "runapp":
            meaningful_keys = ["appid", "appname", "command", "builtin_icon_name", "default_visuals_initialized", "title", "app_icon_source", "app_icon_path"]
            defaults = {
                "appid": "", "appname": "", "command": "", "_lang": "en",
                "sync_title_on_app_change": False,
                "builtin_icon_name": "ACTION_RUNAPP", "default_visuals_initialized": True,
                "app_icon_source": "", "app_icon_path": ""
            }
        else:
            meaningful_keys = ["url", "browser", "command", "builtin_icon_name", "default_visuals_initialized", "title"]
            defaults = {
                "url": "", "browser": "default", "command": "", "_lang": "en",
                "sync_title_on_url_change": False,
                "builtin_icon_name": "ACTION_WEB", "default_visuals_initialized": True
            }

        if any(settings.get(key) not in ("", None, False) for key in meaningful_keys):
            self.context_settings[context] = settings.copy()
            if not (settings.get("command") or settings.get("path") or settings.get("appid") or settings.get("url")):
                await self._send_builtin_icon(context, action_id)
            return

        self.context_settings[context] = defaults.copy()
        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": defaults
        })
        await self._send_builtin_icon(context, action_id)

    async def handle_message(self, data):
        event = data.get("event")
        action_id = data.get("action", "")
        payload = data.get("payload", {}) or {}
        command = data.get("command") or payload.get("command")
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ("willAppear", "keyDidAppear"):
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if event == "didReceiveSettings":
            if context:
                merged = dict(self.context_settings.get(context, {}))
                merged.update(settings or {})
                self.context_settings[context] = merged
            return

        if event in ("keyDidDisappear", "willDisappear"):
            self.context_settings.pop(context, None)
            return

        if command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_id, payload.get("builtin_icon_name"))
            return
        if command == "apply_application_icon":
            await self._send_application_icon(context, payload)
            return

        if event == "keyDown":
            await self.on_key_down(data)
        elif command in ("get_app_list", "refresh_app_list"):
            lang_code = payload.get("lang", "en")
            apps = await self._load_installed_apps(
                lang_code,
                force_refresh=(command == "refresh_app_list"),
            )
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {"command": "app_list_result", "apps": apps}
            })
        elif event == "fetchIcon" or payload.get("event") == "fetchIcon" or command == "fetchIcon":
            await self.on_fetch_icon(data)
        elif event == "getAvailableBrowsers" or payload.get("event") == "getAvailableBrowsers" or command == "getAvailableBrowsers":
            await self.on_get_browsers(data)

    async def on_key_down(self, data):
        action_id = data.get("action", "")
        context = data.get("context")
        incoming = data.get("payload", {}).get("settings", {}) or {}
        settings = dict(self.context_settings.get(context, {}))
        settings.update(incoming)
        if context:
            self.context_settings[context] = settings

        action_key = self._get_action_key(action_id)
        command = settings.get("command")
        if action_key == "open":
            path = command or settings.get("path")
            if path:
                await asyncio.to_thread(self.open_path, path)
        elif action_key == "runapp":
            app_id = command or settings.get("appid")
            if app_id:
                await asyncio.to_thread(self.run_application, app_id)
        elif action_key == "website":
            url = self.normalize_url_or_shortcut(command or settings.get("url"))
            if url:
                await asyncio.to_thread(self._open_url, url, settings.get("browser", "default"))

    def _log(self, msg):
        if os.environ.get("COMBOX_FILE_LOGS", "0").strip().lower() not in {"1", "true", "yes", "on"}:
            return
        try:
            os.makedirs(os.path.dirname(self.log_file), exist_ok=True)
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(msg + "\n")
        except Exception:
            pass

    def _lang(self, code):
        code = (code or "en").lower()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        code = alias.get(code, code)
        return code if code in self.texts else "en"

    def _get_installed_apps_windows(self, lang):
        try:
            ps_script = r"""
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Drawing | Out-Null
$iconDir = Join-Path $env:LOCALAPPDATA 'ComboX\app_icons'
New-Item -ItemType Directory -Force -Path $iconDir | Out-Null
$sha1 = [System.Security.Cryptography.SHA1]::Create()

function Get-HashName([string]$text) {
    $bytes = [Text.Encoding]::UTF8.GetBytes($text)
    $hash = $sha1.ComputeHash($bytes)
    return -join ($hash | ForEach-Object { $_.ToString('x2') })
}

function Save-Icon([string]$source) {
    if (-not $source -or -not (Test-Path -LiteralPath $source)) { return '' }
    try {
        $hash = Get-HashName $source
        $out = Join-Path $iconDir ($hash + '.png')
        if (-not (Test-Path -LiteralPath $out)) {
            $ico = [System.Drawing.Icon]::ExtractAssociatedIcon($source)
            if ($ico) {
                $bmp = $ico.ToBitmap()
                $bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
                $bmp.Dispose()
                $ico.Dispose()
            }
        }
        if (Test-Path -LiteralPath $out) { return $out }
    } catch {}
    return ''
}

$wsh = New-Object -ComObject WScript.Shell
$dirs = @(
    [pscustomobject]@{ Path = [Environment]::GetFolderPath('CommonPrograms'); Recurse = $true },
    [pscustomobject]@{ Path = [Environment]::GetFolderPath('Programs'); Recurse = $true },
    [pscustomobject]@{ Path = [Environment]::GetFolderPath('CommonDesktopDirectory'); Recurse = $false },
    [pscustomobject]@{ Path = [Environment]::GetFolderPath('DesktopDirectory'); Recurse = $false }
) | Where-Object { $_.Path -and (Test-Path -LiteralPath $_.Path) }

$items = @{}
foreach ($dirInfo in $dirs) {
    $gciArgs = @{
        LiteralPath = $dirInfo.Path
        File = $true
        ErrorAction = 'SilentlyContinue'
    }
    if ($dirInfo.Recurse) {
        $gciArgs.Recurse = $true
    }
    Get-ChildItem @gciArgs |
        Where-Object { $_.Extension -ieq '.lnk' -or $_.Extension -ieq '.exe' } |
        ForEach-Object {
            $name = [IO.Path]::GetFileNameWithoutExtension($_.Name)
            $appid = $_.FullName
            $iconSource = $_.FullName
            $includeItem = $true
            if ($_.Extension -ieq '.lnk') {
                try {
                    $sc = $wsh.CreateShortcut($_.FullName)
                    if ($sc.TargetPath -and (Test-Path -LiteralPath $sc.TargetPath)) {
                        $iconSource = $sc.TargetPath
                        $targetExt = [IO.Path]::GetExtension($sc.TargetPath).ToLowerInvariant()
                        $allowedTargetExts = @('.exe', '.bat', '.cmd', '.com', '.msc')
                        if ($allowedTargetExts -notcontains $targetExt) {
                            $includeItem = $false
                        }
                        $targetName = [IO.Path]::GetFileName($sc.TargetPath).ToLowerInvariant()
                        if (($targetName -eq 'control.exe') -and (($sc.Arguments -as [string]) -match '^\s*/name\s+')) {
                            $includeItem = $false
                        }
                    } else {
                        $includeItem = $false
                    }
                } catch {
                    $includeItem = $false
                }
            }
            if ($includeItem) {
                $iconPath = Save-Icon $iconSource
                $key = ($name + '|' + $appid).ToLowerInvariant()
                if (-not $items.ContainsKey($key)) {
                    $items[$key] = [pscustomobject]@{
                        Name = $name
                        AppID = $appid
                        IconSource = $iconSource
                        IconPath = $iconPath
                    }
                }
            }
        }
}

try {
    $startApps = @(
        Get-StartApps |
            Where-Object { $_.Name -and $_.AppID } |
            ForEach-Object {
                [pscustomobject]@{
                    Name = $_.Name
                    AppID = $_.AppID
                    IconSource = ''
                    IconPath = ''
                }
            }
    )
} catch {
    $startApps = @()
}

$combined = @($items.Values) + @($startApps)
if ($combined.Count -eq 0) {
    '[]'
} else {
    $combined | Sort-Object Name | ConvertTo-Json -Compress
}
"""
            cmd = ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps_script]
            creation_flags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0
            result = subprocess.run(cmd, capture_output=True, text=True, creationflags=creation_flags,
                                    encoding='utf-8', errors='ignore', timeout=30)
            output = result.stdout.strip()
            if not output:
                return []
            apps = json.loads(output)
            if isinstance(apps, dict):
                apps = [apps]
            if isinstance(apps, list):
                return sorted(apps, key=lambda x: x.get('Name', '').lower())
            return []
        except subprocess.TimeoutExpired:
            return [{"Name": self.texts[lang]["timeout"], "AppID": ""}]
        except Exception as e:
            self._log(f"[apps/windows] failed: {e}")
            return [{"Name": self.texts[lang]["error"], "AppID": ""}]

    def _get_installed_apps_macos(self, lang):
        apps = []
        seen = set()
        patterns = [
            "/Applications/*.app",
            "/Applications/*/*.app",
            os.path.expanduser("~/Applications/*.app"),
            os.path.expanduser("~/Applications/*/*.app"),
        ]
        for pattern in patterns:
            for path in glob.glob(pattern):
                if not os.path.isdir(path):
                    continue
                real = os.path.realpath(path)
                if real in seen:
                    continue
                seen.add(real)
                name = os.path.splitext(os.path.basename(path))[0]
                apps.append({"Name": name, "AppID": path, "IconSource": path, "IconPath": ""})
        return sorted(apps, key=lambda x: x.get("Name", "").lower())

    def _get_installed_apps_linux(self, lang):
        apps = []
        seen = set()
        desktop_dirs = ["/usr/share/applications", "/usr/local/share/applications", os.path.expanduser("~/.local/share/applications")]
        for directory in desktop_dirs:
            for path in glob.glob(os.path.join(directory, "*.desktop")):
                if path in seen:
                    continue
                seen.add(path)
                name = os.path.splitext(os.path.basename(path))[0]
                try:
                    with open(path, "r", encoding="utf-8", errors="ignore") as f:
                        for line in f:
                            if line.startswith("Name="):
                                name = line.split("=", 1)[1].strip()
                                break
                except Exception:
                    pass
                apps.append({"Name": name, "AppID": path, "IconSource": path, "IconPath": ""})
        return sorted(apps, key=lambda x: x.get("Name", "").lower())

    def _deduplicate_apps(self, apps):
        """Collapse Start-menu/Desktop aliases that launch the same program."""
        if not isinstance(apps, list):
            return []

        unique = {}

        def prefer_candidate(existing, candidate):
            existing_icon_path = str(existing.get("IconPath") or "")
            candidate_icon_path = str(candidate.get("IconPath") or "")
            existing_has_icon = bool(existing_icon_path and os.path.isfile(existing_icon_path))
            candidate_has_icon = bool(candidate_icon_path and os.path.isfile(candidate_icon_path))
            if candidate_has_icon != existing_has_icon:
                return candidate if candidate_has_icon else existing

            existing_score = (
                len(str(existing.get("Name") or "")),
                len(str(existing.get("AppID") or "")),
            )
            candidate_score = (
                len(str(candidate.get("Name") or "")),
                len(str(candidate.get("AppID") or "")),
            )
            return candidate if candidate_score < existing_score else existing

        for app in apps:
            if not isinstance(app, dict):
                continue

            app_id = str(app.get("AppID") or "").strip()
            name = str(app.get("Name") or app_id).strip()
            icon_source = str(app.get("IconSource") or "").strip()

            # A .lnk in the Start menu and another on the Desktop have different
            # shortcut paths but the same resolved executable in IconSource.
            # Use that real target as the primary identity.
            identity = icon_source or app_id or name
            if IS_WINDOWS:
                identity = os.path.normcase(os.path.normpath(identity))
            else:
                identity = os.path.normpath(identity).casefold()

            candidate = dict(app)
            candidate["Name"] = name
            candidate["AppID"] = app_id

            existing = unique.get(identity)
            unique[identity] = candidate if existing is None else prefer_candidate(existing, candidate)

        # Get-StartApps also returns traditional Start-menu applications. Merge
        # those aliases by display name, preferring the entry whose icon was
        # already extracted from a shortcut or executable.
        by_name = {}
        for candidate in unique.values():
            name_key = " ".join(str(candidate.get("Name") or "").casefold().split())
            identity = name_key or str(candidate.get("AppID") or "").casefold()
            existing = by_name.get(identity)
            by_name[identity] = candidate if existing is None else prefer_candidate(existing, candidate)

        return sorted(by_name.values(), key=lambda item: str(item.get("Name") or "").casefold())

    async def _load_installed_apps(self, lang_code="en", force_refresh=False):
        """Serialize scans so multiple property inspectors share one cached result."""
        async with self._app_list_lock:
            if force_refresh:
                self.app_list_cache = None
            return await asyncio.to_thread(self._get_installed_apps, lang_code)

    def _get_installed_apps(self, lang_code="en"):
        lang = self._lang(lang_code)
        if self.app_list_cache is not None:
            return self.app_list_cache
        if IS_WINDOWS:
            apps = self._get_installed_apps_windows(lang)
        elif IS_MACOS:
            apps = self._get_installed_apps_macos(lang)
        else:
            apps = self._get_installed_apps_linux(lang)
        is_error_result = (
            isinstance(apps, list) and len(apps) == 1 and
            not apps[0].get("AppID") and
            apps[0].get("Name") in (self.texts[lang]["timeout"], self.texts[lang]["error"])
        )
        if not is_error_result:
            apps = self._deduplicate_apps(apps)
            self.app_list_cache = apps
        return apps

    def run_application(self, app_id):
        try:
            if IS_WINDOWS:
                if "\\" in app_id or ":" in app_id or os.path.exists(app_id):
                    self.open_path(app_id)
                else:
                    os.startfile(f"shell:AppsFolder\\{app_id}")
            elif IS_MACOS:
                if app_id.endswith(".app") or os.path.exists(app_id):
                    subprocess.Popen(["open", app_id], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    subprocess.Popen(["open", "-a", app_id], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                self.open_path(app_id)
        except Exception as e:
            self._log(f"[runapp] failed: {e}")

    def _normalize_open_target(self, path):
        raw = str(path or "").strip().strip('"')
        if not raw:
            return ""
        if raw.lower().startswith("file:"):
            try:
                from urllib.parse import unquote, urlparse
                parsed = urlparse(raw)
                if parsed.netloc:
                    raw = "\\\\" + parsed.netloc + unquote(parsed.path).replace("/", "\\")
                else:
                    raw = unquote(parsed.path)
                    if IS_WINDOWS and raw.startswith("/") and len(raw) > 2 and raw[2] == ":":
                        raw = raw[1:]
                    if IS_WINDOWS:
                        raw = raw.replace("/", "\\")
            except Exception as e:
                self._log(f"[open] file url normalize failed: {e}")
        if IS_WINDOWS and raw.startswith("//"):
            raw = "\\\\" + raw.lstrip("/").replace("/", "\\")
        return os.path.expandvars(os.path.expanduser(raw))

    def _shell_open_windows(self, path):
        if ctypes is not None:
            try:
                result = ctypes.windll.shell32.ShellExecuteW(None, "open", path, None, None, 1)
                if result > 32:
                    return True
                self._log(f"[open] ShellExecuteW failed code={result} path={path}")
            except Exception as e:
                self._log(f"[open] ShellExecuteW exception: {e}")
        try:
            os.startfile(path)
            return True
        except Exception as e:
            self._log(f"[open] startfile failed: {e}")
        return False

    def open_path(self, path):
        try:
            path = self._normalize_open_target(path)
            if not path:
                return
            if IS_WINDOWS:
                self._shell_open_windows(path)
            elif IS_MACOS:
                subprocess.Popen(['open', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen(['xdg-open', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            self._log(f"[open] failed: {e}")

    def normalize_url_or_shortcut(self, value):
        """Accepts normal URLs, domains, Windows .url, macOS .webloc/.inetloc, or file:// paths."""
        if not value:
            return ""

        raw = str(value).strip().strip('"').strip("'")
        if not raw:
            return ""

        if raw.startswith("file://"):
            raw = unquote(raw[7:])

        if os.path.exists(raw):
            ext = os.path.splitext(raw)[1].lower()
            if ext == ".url":
                parsed = self._read_windows_url_file(raw)
                if parsed:
                    return parsed
            if ext in (".webloc", ".inetloc"):
                parsed = self._read_macos_url_file(raw)
                if parsed:
                    return parsed
            # If it is a local html/pdf/etc file, let the OS/browser open it.
            return raw

        if raw.startswith(("http://", "https://", "ftp://", "mailto:")):
            return raw

        return "https://" + raw

    def _read_windows_url_file(self, path):
        for enc in ("utf-8-sig", "utf-16", "cp949", "latin-1"):
            try:
                with open(path, "r", encoding=enc, errors="ignore") as f:
                    for line in f:
                        line = line.strip()
                        if line.lower().startswith("url="):
                            return line.split("=", 1)[1].strip()
            except Exception:
                continue
        return ""

    def _read_macos_url_file(self, path):
        try:
            with open(path, "rb") as f:
                data = plistlib.load(f)
            for key in ("URL", "url", "URLString"):
                if data.get(key):
                    return str(data[key]).strip()
        except Exception:
            pass

        # Some .inetloc files may appear as XML-ish or plain text in edge cases.
        try:
            text = open(path, "r", encoding="utf-8", errors="ignore").read()
            for marker in ("<string>", "URL="):
                if marker in text:
                    if marker == "<string>":
                        return text.split("<string>", 1)[1].split("</string>", 1)[0].strip()
                    return text.split("URL=", 1)[1].splitlines()[0].strip()
        except Exception:
            pass
        return ""

    def _open_url(self, url, browser_path):
        if browser_path == "default" or not browser_path:
            if IS_MACOS:
                subprocess.Popen(["open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                webbrowser.open(url)
            return

        try:
            if IS_MACOS:
                # Browser value is normally a .app bundle path.
                if browser_path.endswith(".app"):
                    subprocess.Popen(["open", "-a", browser_path, url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    subprocess.Popen(["open", "-a", browser_path, url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elif IS_WINDOWS:
                subprocess.Popen([browser_path, url])
            else:
                subprocess.Popen([browser_path, url])
        except Exception as e:
            print(f"[{self.uuid}] Browser launch failed: {e}. Falling back to default browser.")
            try:
                if IS_MACOS:
                    subprocess.Popen(["open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    webbrowser.open(url)
            except Exception:
                webbrowser.open(url)

    async def on_fetch_icon(self, data):
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        url = payload.get("url") or payload.get("payload", {}).get("url")

        if not context:
            return

        if not url:
            await self._send_builtin_icon(context)
            return

        if not libraries_ok:
            await self._send_builtin_icon(context)
            return

        normalized = self.normalize_url_or_shortcut(url)
        if not normalized or os.path.exists(normalized):
            await self._send_builtin_icon(context)
            return

        icon_path = await asyncio.to_thread(self.fetch_and_save_favicon, normalized)
        if icon_path and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {
                    "icon_path": icon_path,
                    "source": "website_favicon",
                    "url": normalized,
                }
            })
        else:
            await self._send_builtin_icon(context)

    async def on_get_browsers(self, data):
        context = data.get("context")
        if context:
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {
                    "event": "didReceiveAvailableBrowsers",
                    "browsers": self.available_browsers
                }
            })

    def find_installed_browsers(self):
        if IS_WINDOWS:
            return self._find_windows_browsers()
        if IS_MACOS:
            return self._find_macos_browsers()
        if IS_LINUX:
            return self._find_linux_browsers()
        return {}

    def _find_windows_browsers(self):
        if not winreg:
            return {}

        browser_exes = {
            "chrome.exe": "Google Chrome",
            "msedge.exe": "Microsoft Edge",
            "firefox.exe": "Mozilla Firefox",
            "opera.exe": "Opera",
            "vivaldi.exe": "Vivaldi",
            "brave.exe": "Brave",
            "whale.exe": "Naver Whale",
            "Arc.exe": "Arc Browser",
            "DuckDuckGo.exe": "DuckDuckGo Browser",
            "comet.exe": "Comet Browser"
        }

        installed_browsers = {}
        app_paths_key = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"

        for exe, name in browser_exes.items():
            for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
                try:
                    key = winreg.OpenKey(hive, os.path.join(app_paths_key, exe))
                    path, _ = winreg.QueryValueEx(key, None)
                    installed_browsers[name] = path
                    winreg.CloseKey(key)
                    break
                except FileNotFoundError:
                    pass
                except Exception:
                    pass
        return installed_browsers

    def _find_macos_browsers(self):
        candidates = {
            "Safari": ["/Applications/Safari.app"],
            "Google Chrome": ["/Applications/Google Chrome.app", os.path.expanduser("~/Applications/Google Chrome.app")],
            "Microsoft Edge": ["/Applications/Microsoft Edge.app", os.path.expanduser("~/Applications/Microsoft Edge.app")],
            "Mozilla Firefox": ["/Applications/Firefox.app", os.path.expanduser("~/Applications/Firefox.app")],
            "Brave": ["/Applications/Brave Browser.app", os.path.expanduser("~/Applications/Brave Browser.app")],
            "Opera": ["/Applications/Opera.app", os.path.expanduser("~/Applications/Opera.app")],
            "Vivaldi": ["/Applications/Vivaldi.app", os.path.expanduser("~/Applications/Vivaldi.app")],
            "Arc Browser": ["/Applications/Arc.app", os.path.expanduser("~/Applications/Arc.app")],
            "Naver Whale": ["/Applications/Whale.app", "/Applications/Naver Whale.app", os.path.expanduser("~/Applications/Whale.app")],
            "DuckDuckGo Browser": ["/Applications/DuckDuckGo.app", os.path.expanduser("~/Applications/DuckDuckGo.app")],
        }

        installed = {}
        for name, paths in candidates.items():
            for path in paths:
                if os.path.exists(path):
                    installed[name] = path
                    break
        return installed

    def _find_linux_browsers(self):
        import shutil
        candidates = {
            "Google Chrome": "google-chrome",
            "Chromium": "chromium",
            "Microsoft Edge": "microsoft-edge",
            "Mozilla Firefox": "firefox",
            "Brave": "brave-browser",
            "Opera": "opera",
            "Vivaldi": "vivaldi",
        }
        return {name: path for name, cmd in candidates.items() if (path := shutil.which(cmd))}

    def fetch_and_save_favicon(self, url):
        def get_default_icon_path():
            icon_path = self._get_icon_path()
            return icon_path if icon_path and os.path.exists(icon_path) else None

        try:
            url = self.normalize_url_or_shortcut(url)
            if not url or os.path.exists(url):
                return get_default_icon_path()

            headers = {"User-Agent": "Mozilla/5.0"}

            try:
                response = requests.get(url, headers=headers, timeout=3)
                response.raise_for_status()
            except Exception:
                return get_default_icon_path()

            parser = _FaviconLinkParser()
            try:
                parser.feed(response.text)
            except Exception:
                pass

            candidates = []
            for _regular, _size, href in sorted(
                parser.icons,
                key=lambda item: (item[0], item[1]),
                reverse=True,
            ):
                if href.lower().startswith("data:"):
                    continue
                candidates.append(urljoin(url, href))
            candidates.append(urljoin(url, "/favicon.ico"))

            seen = set()
            for icon_url in candidates:
                if not icon_url or icon_url in seen:
                    continue
                seen.add(icon_url)
                try:
                    icon_response = requests.get(
                        icon_url,
                        headers=headers,
                        timeout=5,
                    )
                    icon_response.raise_for_status()

                    with Image.open(io.BytesIO(icon_response.content)) as source:
                        img = source.convert("RGBA")

                    cache_dir = os.path.join(self._app_data_dir(), "favicon_cache")
                    os.makedirs(cache_dir, exist_ok=True)

                    domain = urlparse(url).netloc
                    safe_filename = "".join(
                        c for c in domain if c.isalnum() or c in ("-", "_")
                    ).rstrip() or "site"
                    save_path = os.path.join(cache_dir, f"{safe_filename}.png")

                    img.save(save_path, "PNG")
                    return os.path.abspath(save_path)
                except Exception:
                    continue

            return get_default_icon_path()

        except Exception as e:
            print(f"[{self.uuid}] Global error in fetch: {e}. Using default.")
            return get_default_icon_path()
