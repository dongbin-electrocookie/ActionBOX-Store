import asyncio
import os
import sys

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        self.windows_action_map = {
            "file_save": "ctrl+s",
            "file_save_as": "ctrl+shift+s",
            "edit_undo": "ctrl+z",
            "edit_redo": "ctrl+shift+z",
            "edit_paste_place": "ctrl+shift+v",
            "edit_paste_front": "ctrl+f",
            "edit_paste_back": "ctrl+b",
            "tool_select": "v",
            "tool_direct_select": "a",
            "tool_magic": "y",
            "tool_lasso": "q",
            "tool_pen": "p",
            "tool_type": "t",
            "tool_rect": "m",
            "tool_ellipse": "l",
            "tool_brush": "b",
            "tool_eraser": "shift+e",
            "tool_rotate": "r",
            "tool_scale": "s",
            "tool_transform": "e",
            "tool_gradient": "g",
            "tool_eyedropper": "i",
            "tool_zoom": "z",
            "obj_group": "ctrl+g",
            "obj_ungroup": "ctrl+shift+g",
            "obj_front": "ctrl+shift+]",
            "obj_back": "ctrl+shift+[",
            "obj_lock": "ctrl+2",
            "obj_unlock": "ctrl+alt+2",
            "obj_hide": "ctrl+3",
            "obj_show": "ctrl+alt+3",
            "mask_make": "ctrl+7",
            "mask_release": "ctrl+alt+7",
            "path_make": "ctrl+8",
            "path_release": "ctrl+alt+8",
            "view_zoom_in": "ctrl+=",
            "view_zoom_out": "ctrl+-",
            "view_fit": "ctrl+0",
            "view_outline": "ctrl+y",
            "view_guides": "ctrl+;"
        }

        self.macos_action_map = {
            "file_save": "command+s",
            "file_save_as": "command+shift+s",
            "edit_undo": "command+z",
            "edit_redo": "command+shift+z",
            "edit_paste_place": "command+shift+v",
            "edit_paste_front": "command+f",
            "edit_paste_back": "command+b",
            "tool_select": "v",
            "tool_direct_select": "a",
            "tool_magic": "y",
            "tool_lasso": "q",
            "tool_pen": "p",
            "tool_type": "t",
            "tool_rect": "m",
            "tool_ellipse": "l",
            "tool_brush": "b",
            "tool_eraser": "shift+e",
            "tool_rotate": "r",
            "tool_scale": "s",
            "tool_transform": "e",
            "tool_gradient": "g",
            "tool_eyedropper": "i",
            "tool_zoom": "z",
            "obj_group": "command+g",
            "obj_ungroup": "command+shift+g",
            "obj_front": "command+shift+]",
            "obj_back": "command+shift+[",
            "obj_lock": "command+2",
            "obj_unlock": "command+option+2",
            "obj_hide": "command+3",
            "obj_show": "command+option+3",
            "mask_make": "command+7",
            "mask_release": "command+option+7",
            "path_make": "command+8",
            "path_release": "command+option+8",
            "view_zoom_in": "command+=",
            "view_zoom_out": "command+-",
            "view_fit": "command+0",
            "view_outline": "command+y",
            "view_guides": "command+;"
        }

        self.action_map = self.macos_action_map if IS_MACOS else self.windows_action_map

        self.icon_map = {
            "file_save": "FILE_SAVE",
            "file_save_as": "FILE_SAVE_AS",
            "edit_undo": "EDIT_UNDO",
            "edit_redo": "EDIT_REDO",
            "edit_paste_place": "EDIT_PASTE_PLACE",
            "edit_paste_front": "EDIT_PASTE_FRONT",
            "edit_paste_back": "EDIT_PASTE_BACK",
            "tool_select": "TOOL_SELECT",
            "tool_direct_select": "TOOL_DIRECT_SELECT",
            "tool_magic": "TOOL_MAGIC",
            "tool_lasso": "TOOL_LASSO",
            "tool_pen": "TOOL_PEN",
            "tool_type": "TOOL_TYPE",
            "tool_rect": "TOOL_RECT",
            "tool_ellipse": "TOOL_ELLIPSE",
            "tool_brush": "TOOL_BRUSH",
            "tool_eraser": "TOOL_ERASER",
            "tool_rotate": "TOOL_ROTATE",
            "tool_scale": "TOOL_SCALE",
            "tool_transform": "TOOL_TRANSFORM",
            "tool_gradient": "TOOL_GRADIENT",
            "tool_eyedropper": "TOOL_EYEDROPPER",
            "tool_zoom": "TOOL_ZOOM",
            "obj_group": "OBJ_GROUP",
            "obj_ungroup": "OBJ_UNGROUP",
            "obj_front": "OBJ_FRONT",
            "obj_back": "OBJ_BACK",
            "obj_lock": "OBJ_LOCK",
            "obj_unlock": "OBJ_UNLOCK",
            "obj_hide": "OBJ_HIDE",
            "obj_show": "OBJ_SHOW",
            "mask_make": "MASK_MAKE",
            "mask_release": "MASK_RELEASE",
            "path_make": "PATH_MAKE",
            "path_release": "PATH_RELEASE",
            "view_zoom_in": "VIEW_ZOOM_IN",
            "view_zoom_out": "VIEW_ZOOM_OUT",
            "view_fit": "VIEW_FIT",
            "view_outline": "VIEW_OUTLINE",
            "view_guides": "VIEW_GUIDES"
        }

    def _default_action(self):
        return "tool_select"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "ai_action": action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or merged.get("ai_action") or self._default_action()
        merged["command"] = action
        merged["ai_action"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("ai_action"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    def _normalize_pyautogui_key(self, key_name):
        aliases = {
            "ctrl": "ctrl",
            "control": "ctrl",
            "alt": "option" if IS_MACOS else "alt",
            "option": "option" if IS_MACOS else "alt",
            "cmd": "command" if IS_MACOS else "win",
            "win": "command" if IS_MACOS else "win",
            "windows": "command" if IS_MACOS else "win",
            "command": "command" if IS_MACOS else "win",
            "return": "enter",
            "plus": "+",
        }
        return aliases.get(key_name, key_name)

    def _send_hotkey_sync(self, hotkey):
        parts = [self._normalize_pyautogui_key(p.strip().lower()) for p in hotkey.split('+') if p.strip()]
        if not parts:
            return

        if IS_WINDOWS and keyboard_available:
            keyboard.send(hotkey)
            return

        if not pyautogui_available:
            return

        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            current_action = action_command or settings.get("command") or settings.get("ai_action") or cached.get("command") or self._default_action()
            await self._send_builtin_icon(context, current_action)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        final_settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = final_settings

        selected_action = final_settings.get("command") or final_settings.get("ai_action") or self._default_action()
        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(self._send_hotkey_sync, hotkey)
