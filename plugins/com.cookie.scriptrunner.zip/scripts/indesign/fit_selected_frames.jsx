#target indesign
(function () {
    if (app.documents.length === 0 || app.selection.length === 0) {
        alert("Open a document and select at least one frame.");
        return;
    }
    for (var i = 0; i < app.selection.length; i++) {
        var item = app.selection[i];
        try {
            item.fit(FitOptions.FILL_PROPORTIONALLY);
            item.fit(FitOptions.CENTER_CONTENT);
        } catch (error) {
            // Ignore selected objects that are not content frames.
        }
    }
}());
