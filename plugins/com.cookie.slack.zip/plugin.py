import sys
import os
import asyncio
import json
import urllib.request

# 라이브러리 경로 설정 및 종속성 확인
lib_path = os.path.join(os.path.dirname(__file__), 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

try:
    import pyautogui
    DEPENDENCIES_OK = True
except ImportError:
    DEPENDENCIES_OK = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        # 🚀 [대통합 규격] 버튼별 설정을 기억하는 저장소
        self.last_valid_settings = {}

        # 슬랙 전용 단축키 데이터베이스
        self.shortcuts_db = {
            # --- 기존 항목 ---
            "quick_switcher": ['ctrl', 'k'],
            "focus_search": ['ctrl', 'f'],
            "toggle_sidebar": ['ctrl', 'shift', 'd'],
            "next_unread": ['alt', 'shift', 'down'],
            "mark_read": ['esc'],
            "workspace_1": ['ctrl', '1'],
            
            # --- 🚀 새로 추가할 고급 기능 ---
            "all_unreads": ['ctrl', 'shift', 'a'],
            "threads": ['ctrl', 'shift', 't'],
            "history_back": ['alt', 'left'],
            "history_forward": ['alt', 'right'],
            "huddle_mute": ['ctrl', 'shift', 'space'],
            "huddle_video": ['ctrl', 'shift', 'v'],
            "mark_all_read": ['shift', 'esc'],
            "edit_last": ['up'], # 입력창 포커스 상태여야 함
            "preferences": ['ctrl', ',']
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        action = data.get("action")
        incoming_settings = data.get("payload", {}).get("settings", {})

        # 🚀 1. 기억력 로직: 설정값 캐싱 및 병합
        if context not in self.last_valid_settings:
            self.last_valid_settings[context] = {}
        if incoming_settings:
            filtered = {k: v for k, v in incoming_settings.items() if v}
            self.last_valid_settings[context].update(filtered)
        
        final_settings = {**self.last_valid_settings.get(context, {}), **incoming_settings}

        # --- [기능 A] 슬랙 메시지 전송 (API) ---
        if "quicksend" in action:
            token = final_settings.get("slack_token", "").strip()
            channel = final_settings.get("channel_id", "").strip()
            # 🚀 표준 규격 command를 최우선 메시지로 사용
            message = final_settings.get("command") or final_settings.get("default_message")

            if token and channel and message:
                await asyncio.to_thread(self.send_slack_message, token, channel, message)

        # --- [기능 B] 슬랙 단축키 실행 ---
        elif "shortcuts" in action:
            if not DEPENDENCIES_OK: return
            # 🚀 표준 규격 command를 단축키 ID로 인식
            shortcut_id = final_settings.get("command")
            if shortcut_id in self.shortcuts_db:
                keys = self.shortcuts_db[shortcut_id]
                await asyncio.to_thread(pyautogui.hotkey, *keys)

    def send_slack_message(self, token, channel, text):
        """슬랙 API를 이용한 메시지 발송 (urllib 사용으로 추가 라이브러리 최소화)"""
        url = "https://slack.com/api/chat.postMessage"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json; charset=utf-8"
        }
        body = json.dumps({"channel": channel, "text": text}).encode('utf-8')
        try:
            req = urllib.request.Request(url, data=body, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=3) as res:
                result = json.loads(res.read().decode())
                if result.get("ok"):
                    print(f"[Slack] 전송 성공: {text}")
                else:
                    print(f"[Slack] API 에러: {result.get('error')}")
        except Exception as e:
            print(f"[Slack] 통신 에러: {e}")