import asyncio
import urllib.request
import json
import base64
import io
import os

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    pass

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get('UUID', 'com.cookie.stock')
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.active_buttons = {}
        self.loop_started = False
        
        print(f"[{self.uuid}] 📈 주식 플러그인 로드 완료! (자동 폰트 추적 탑재)")

    async def handle_message(self, data):
        if not self.loop_started:
            self.loop_started = True
            asyncio.create_task(self.update_loop())

        event = data.get("event", "")
        context = data.get("context")
        payload = data.get("payload") or {}

        if not context: return

        # 🧟 좀비 킬러
        if "disappear" in event.lower() or "delete" in event.lower() or "remove" in event.lower() or "clear" in event.lower():
            if context in self.active_buttons:
                del self.active_buttons[context]
                print(f"❌ [{context}] 주식 버튼 비활성화 - 갱신 중지")
            return

        settings = payload.get("settings") if isinstance(payload, dict) and "settings" in payload else payload

        # 1. 화면에 나타나거나 설정이 바뀌었을 때 (데이터 저장 + 페이지 꼬리표 부착)
        if event in ["willAppear", "keyDidAppear", "didReceiveSettings"]:
            if isinstance(settings, dict) and settings.get("ticker"):
                # 🚀 파이썬 본체가 알려준 '현재 페이지 번호'를 꼬리표로 저장합니다!
                settings["_target_page"] = payload.get("page")
                self.active_buttons[context] = settings
                await self.update_stock(context, settings)

        # 2. 버튼을 직접 눌렀을 때 (즉시 새로고침)
        elif event in ["button_press", "keyDown"]:
            # 이미 등록된 버튼이라면 즉시 갱신
            if context in self.active_buttons:
                await self.update_stock(context, self.active_buttons[context])
            # 등록되지 않았지만 셋팅값이 있다면 등록 후 갱신
            elif isinstance(settings, dict) and settings.get("ticker"):
                settings["_target_page"] = payload.get("page")
                self.active_buttons[context] = settings
                await self.update_stock(context, settings)
                
        # 3. 포스 업데이트 명령을 받았을 때
        elif event == "sendToPlugin" and payload.get("command") == "force_update":
            new_settings = payload.get("settings", {})
            if new_settings and new_settings.get("ticker"):
                # 🚀 포스 업데이트 시에도 페이지 꼬리표를 유지합니다.
                new_settings["_target_page"] = payload.get("page", self.active_buttons.get(context, {}).get("_target_page"))
                self.active_buttons[context] = new_settings
                await self.update_stock(context, new_settings)

    async def update_loop(self):
        while True:
            for context, settings in list(self.active_buttons.items()):
                await self.update_stock(context, settings)
                await asyncio.sleep(0.5) 
            await asyncio.sleep(60) # 주식은 1분마다 갱신

    async def update_stock(self, context, settings):
        ticker = settings.get("ticker")
        if not ticker: return

        b64_image = await asyncio.to_thread(self.get_stock_image_base64, ticker, settings)
        
        # 🛡️ [방어] 그리는 동안 버튼이 지워지거나 주식이 바뀌었는지 검사
        current_active = self.active_buttons.get(context)
        if not current_active or current_active.get("ticker") != ticker:
            return

        if b64_image and self.runner:
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": ""}})
            
            # 🚀 [추가됨] 아까 저장해둔 페이지 꼬리표를 꺼냅니다.
            target_page = settings.get("_target_page")
            
            # 🚀 [수정됨] payload 안에 "page": target_page 꼬리표를 동봉해서 파이썬으로 쏩니다!
            await self.runner.send_message({
                "event": "setImage", 
                "context": context, 
                "payload": {
                    "image": b64_image,
                    "page": target_page
                }
            })
        else:
            if self.runner:
                await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": "조회\n실패"}})

    # 🚀 [업그레이드] 윈도우 시스템 폰트까지 알아서 뒤져서 찾아옵니다!
    def get_fit_font(self, draw, text, font_name, max_width, start_size, min_size=12):
        # 폰트를 찾을 경로들 (플러그인 폴더 -> 윈도우 시스템 폴더)
        font_paths = [
            os.path.join(self.plugin_dir, font_name),
            f"C:\\Windows\\Fonts\\{font_name}",
            font_name
        ]
        
        size = start_size
        while size > min_size:
            font = None
            for fp in font_paths:
                try:
                    font = ImageFont.truetype(fp, size)
                    break # 찾으면 즉시 루프 탈출
                except:
                    pass
            
            # 다 뒤져도 없으면 그때서야 못생긴 기본 폰트 사용
            if not font:
                return ImageFont.load_default()
                
            try: w = draw.textlength(text, font=font)
            except: w = draw.textbbox((0,0), text, font=font)[2]
            
            if w <= max_width: return font
            size -= 2
        return font

    def get_stock_image_base64(self, ticker, settings):
        try:
            url = f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}?interval=1d&range=2d"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as res:
                data = json.loads(res.read().decode('utf-8'))
            
            meta = data['chart']['result'][0]['meta']
            current_price = float(meta['regularMarketPrice'])
            prev_close = float(meta['chartPreviousClose'])
            change_percent = ((current_price - prev_close) / prev_close) * 100

            # 상승 빨강, 하락 파랑, 보합 회색
            if current_price > prev_close: bg_color = (194, 53, 49)
            elif current_price < prev_close: bg_color = (44, 98, 181)
            else: bg_color = (80, 80, 80)
            
            img = Image.new('RGB', (128, 128), color=bg_color)
            draw = ImageDraw.Draw(img)
            
            display_name = settings.get("display_name", "").strip()
            if not display_name:
                display_name = ticker

            price_str = f"{current_price:,.2f}" if current_price < 1000 else f"{current_price:,.0f}"
            sign = "+" if change_percent > 0 else ""
            change_str = f"{sign}{change_percent:.2f}%"

            # 🚀 코인 플러그인과 100% 동일한 폰트 크기 세팅
            font_name = self.get_fit_font(draw, display_name, "malgunbd.ttf", 120, 24)
            font_price = self.get_fit_font(draw, price_str, "malgunbd.ttf", 124, 30)
            font_change = self.get_fit_font(draw, change_str, "malgunbd.ttf", 120, 22)

            def draw_centered(y, text, font, fill):
                try: w = draw.textlength(text, font=font)
                except: w = draw.textbbox((0,0), text, font=font)[2]
                draw.text(((128-w)/2, y), text, font=font, fill=fill)

            # 🚀 코인 플러그인과 100% 동일한 Y축 위치 세팅
            draw_centered(10, display_name, font_name, (255,255,255))
            draw_centered(48, price_str, font_price, (255,255,255))
            draw_centered(90, change_str, font_change, (255,255,0))

            buffered = io.BytesIO()
            img.save(buffered, format="PNG")
            return f"data:image/png;base64,{base64.b64encode(buffered.getvalue()).decode('utf-8')}"
            
        except Exception as e:
            print(f"[{self.uuid}] API 통신 에러 ({ticker}): {e}")
            return None