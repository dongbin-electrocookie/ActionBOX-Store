import asyncio
import json
import struct
import uuid
import platform
import os
import socket
import time
import threading
import urllib.error
import urllib.parse
import urllib.request

IS_WINDOWS = (platform.system() == "Windows")

RPC_SCOPES = ('rpc', 'rpc.voice.write')
TOKEN_URL = 'https://discord.com/api/oauth2/token'
SENSITIVE_FIELDS = frozenset(('client_secret', 'access_token', 'refresh_token', 'rpc_token'))


class DiscordError(Exception):
    """Only safe, predefined codes cross the runner/log/inspector boundary."""
    def __init__(self, code, discord_code=None):
        self.code = code
        self.discord_code = discord_code if isinstance(discord_code, int) else None
        super().__init__(code)


def rpc_error(data, closed=False):
    # Never expose Discord's raw message: it can echo codes, tokens or inputs.
    code = data.get('code') if isinstance(data, dict) else None
    names = ({4000: 'INVALID_CLIENT', 4001: 'INVALID_ORIGIN', 4002: 'RATE_LIMITED',
              4003: 'INVALID_TOKEN'} if closed else
             {4006: 'PERMISSION_DENIED', 4007: 'INVALID_CLIENT', 4008: 'INVALID_ORIGIN',
              4009: 'INVALID_TOKEN', 5000: 'OAUTH_FAILED', 5001: 'TIMEOUT', 5002: 'TIMEOUT'})
    name = names.get(code, 'RPC_REJECTED')
    return DiscordError(name, code)


class DiscordIPC:
    """Bounded, serialized RPC transport. No real OS input or Discord injection."""
    MAX_FRAME = 1024 * 1024

    def __init__(self, client_id):
        self.client_id = client_id
        self.pipe = None
        self.connected = False
        self.closed = threading.Event()

    def close(self):
        self.closed.set()
        self.connected = False
        pipe, self.pipe = self.pipe, None
        if pipe is not None:
            try:
                pipe.close()
            except OSError:
                pass

    def _open_pipe(self, path):
        if IS_WINDOWS:
            # PIPE_NOWAIT bounds reads/writes without abandoning blocked threads.
            import ctypes
            import msvcrt
            from ctypes import wintypes
            pipe = open(path, 'r+b', buffering=0)
            setter = ctypes.WinDLL('kernel32', use_last_error=True).SetNamedPipeHandleState
            setter.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD),
                               ctypes.POINTER(wintypes.DWORD), ctypes.POINTER(wintypes.DWORD))
            setter.restype = wintypes.BOOL
            mode = wintypes.DWORD(1)  # PIPE_NOWAIT, byte-read mode
            if not setter(msvcrt.get_osfhandle(pipe.fileno()), ctypes.byref(mode), None, None):
                pipe.close()
                raise OSError('Cannot configure Discord pipe')
            return pipe
        pipe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            pipe.settimeout(0.1)
            pipe.connect(path)
            return pipe
        except OSError:
            pipe.close()
            raise

    def _paths(self):
        if IS_WINDOWS:
            return [rf'\\.\pipe\discord-ipc-{n}' for n in range(10)]
        roots = [os.environ.get(k) for k in ('XDG_RUNTIME_DIR', 'TMPDIR', 'TMP', 'TEMP')]
        roots.append('/tmp')
        return [os.path.join(root, f'discord-ipc-{n}')
                for root in dict.fromkeys(r for r in roots if r) for n in range(10)]

    def connect(self):
        for path in self._paths():
            if self.closed.is_set():
                raise DiscordError('DISCONNECTED')
            try:
                self.pipe = self._open_pipe(path)
                break
            except OSError:
                continue
        else:
            raise DiscordError('DISCORD_NOT_RUNNING')
        try:
            self.send(0, {'v': 1, 'client_id': self.client_id})
            op, data = self.recv(time.monotonic() + 10)
            if op == 2 or data.get('evt') == 'ERROR':
                raise rpc_error(data.get('data', data), closed=(op == 2))
            if op != 1 or data.get('evt') != 'READY':
                raise DiscordError('BAD_HANDSHAKE')
            self.connected = True
        except Exception:
            self.close()
            raise
        return True

    def _check(self, deadline):
        if self.closed.is_set() or self.pipe is None:
            raise DiscordError('DISCONNECTED')
        if time.monotonic() >= deadline:
            raise DiscordError('TIMEOUT')

    @staticmethod
    def _would_block(error):
        return isinstance(error, (BlockingIOError, socket.timeout)) or getattr(error, 'winerror', None) == 232

    def send(self, op, payload, deadline=None):
        deadline = deadline or time.monotonic() + 10
        body = json.dumps(payload).encode('utf-8')
        if len(body) > self.MAX_FRAME:
            raise DiscordError('BAD_FRAME')
        frame = memoryview(struct.pack('<II', op, len(body)) + body)
        while frame:
            self._check(deadline)
            try:
                if IS_WINDOWS:
                    count = self.pipe.write(frame)
                else:
                    count = self.pipe.send(frame)
                if count:
                    frame = frame[count:]
                    continue
            except OSError as error:
                if not self._would_block(error):
                    raise DiscordError('DISCONNECTED') from None
            time.sleep(0.01)

    def _read_exact(self, size, deadline):
        result = bytearray()
        while len(result) < size:
            self._check(deadline)
            try:
                chunk = self.pipe.read(size - len(result)) if IS_WINDOWS else self.pipe.recv(size - len(result))
                if chunk == b'':
                    raise DiscordError('DISCONNECTED')
                if chunk:
                    result.extend(chunk)
                    continue
            except OSError as error:
                if not self._would_block(error):
                    raise DiscordError('DISCONNECTED') from None
            time.sleep(0.01)
        return bytes(result)

    def recv(self, deadline):
        op, size = struct.unpack('<II', self._read_exact(8, deadline))
        if size > self.MAX_FRAME:
            raise DiscordError('BAD_FRAME')
        try:
            data = json.loads(self._read_exact(size, deadline).decode('utf-8'))
        except (ValueError, UnicodeError):
            raise DiscordError('BAD_FRAME') from None
        if not isinstance(data, dict):
            raise DiscordError('BAD_FRAME')
        return op, data

    def request(self, command, args, timeout=10):
        if not self.connected:
            raise DiscordError('DISCONNECTED')
        nonce = str(uuid.uuid4())
        deadline = time.monotonic() + timeout
        self.send(1, {'cmd': command, 'args': args, 'nonce': nonce}, deadline)
        while True:
            op, data = self.recv(deadline)
            if op == 3:
                self.send(4, data, deadline)
                continue
            if op == 2:
                raise rpc_error(data.get('data', data), closed=True)
            if op != 1:
                raise DiscordError('BAD_FRAME')
            if data.get('nonce') != nonce:
                continue  # dispatch events and unrelated command replies
            if data.get('evt') == 'ERROR':
                raise rpc_error(data.get('data'))
            if data.get('cmd') != command or not isinstance(data.get('data'), dict):
                raise DiscordError('BAD_FRAME')
            return data['data']


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None  # Never forward a secret to a redirected endpoint.


def exchange_token(fields):
    request = urllib.request.Request(TOKEN_URL,
        data=urllib.parse.urlencode(fields).encode('utf-8'),
        headers={'Content-Type': 'application/x-www-form-urlencoded',
                 'User-Agent': 'ComboX-Discord-Pro/1.1'}, method='POST')
    try:
        with urllib.request.build_opener(_NoRedirect()).open(request, timeout=15) as response:
            token = json.loads(response.read(65536))
    except urllib.error.HTTPError as error:
        # Do not print the body, Request, code, secret or HTTP exception.
        try:
            body = json.loads(error.read(65536))
            reason = body.get('error') if isinstance(body, dict) else None
        except (OSError, ValueError):
            reason = None
        finally:
            error.close()
        code = {'invalid_client': 'SECRET_INVALID', 'invalid_scope': 'PERMISSION_DENIED',
                'unauthorized_client': 'PERMISSION_DENIED', 'access_denied': 'PERMISSION_DENIED'}.get(reason, 'OAUTH_FAILED')
        raise DiscordError(code, error.code) from None
    except (OSError, ValueError):
        raise DiscordError('TOKEN_NETWORK_ERROR') from None
    if not isinstance(token, dict) or not isinstance(token.get('access_token'), str) or not token['access_token']:
        raise DiscordError('OAUTH_FAILED')
    return token


class DiscordSession:
    """One app/session; credentials live in RAM, never in button settings."""
    def __init__(self, client_id, redirect_uri=''):
        self.client_id = client_id
        self.redirect_uri = redirect_uri
        self.ipc = None
        self.secret = ''
        self.access_token = ''
        self.refresh_token = ''
        self.expires_at = 0
        self.authenticated = False
        self.cancelled = threading.Event()

    def close(self):
        self.cancelled.set()
        self.authenticated = False
        if self.ipc:
            self.ipc.close()
        self.secret = self.access_token = self.refresh_token = ''

    def _check(self):
        if self.cancelled.is_set():
            raise DiscordError('DISCONNECTED')

    def _set_token(self, token):
        self._check()
        try:
            lifetime = max(0, min(float(token.get('expires_in', 0)), 31536000))
        except (TypeError, ValueError):
            raise DiscordError('OAUTH_FAILED') from None
        self.access_token = token['access_token']
        self.refresh_token = token.get('refresh_token', '')
        self.expires_at = time.monotonic() + lifetime

    def ensure_authenticated(self, secret='', allow_authorize=False):
        self._check()
        if secret:
            self.secret = secret
        if not self.ipc or not self.ipc.connected:
            if self.ipc:
                self.ipc.close()
            self.ipc = DiscordIPC(self.client_id)
            self.ipc.connect()
            self.authenticated = False
        if self.access_token and time.monotonic() >= self.expires_at:
            self.authenticated = False
            if self.refresh_token and self.secret:
                try:
                    self._set_token(exchange_token({'client_id': self.client_id,
                        'client_secret': self.secret, 'grant_type': 'refresh_token',
                        'refresh_token': self.refresh_token}))
                except DiscordError:
                    self.access_token = self.refresh_token = ''
                    if not allow_authorize:
                        raise
            else:
                self.access_token = ''
        if not self.access_token:
            if not allow_authorize:
                raise DiscordError('AUTH_REQUIRED')
            if not self.secret:
                raise DiscordError('SECRET_REQUIRED')
            reply = self.ipc.request('AUTHORIZE', {'client_id': self.client_id,
                'scopes': list(RPC_SCOPES)}, timeout=120)
            self._check()
            code = reply.get('code')
            if not isinstance(code, str) or not code:
                raise DiscordError('OAUTH_FAILED')
            fields = {'client_id': self.client_id, 'client_secret': self.secret,
                      'grant_type': 'authorization_code', 'code': code}
            if self.redirect_uri:
                fields['redirect_uri'] = self.redirect_uri
            self._set_token(exchange_token(fields))
        self._check()
        if not self.authenticated:
            try:
                reply = self.ipc.request('AUTHENTICATE', {'access_token': self.access_token})
            except DiscordError:
                self.access_token = self.refresh_token = ''
                raise
            self._check()
            if not set(RPC_SCOPES).issubset(reply.get('scopes') or []):
                raise DiscordError('PERMISSION_DENIED')
            self.authenticated = True

    def execute(self, action=None, secret='', allow_authorize=False):
        self.ensure_authenticated(secret, allow_authorize)
        if action is None:
            return
        args = {'mute_on': {'mute': True}, 'mute_off': {'mute': False},
                'deafen_on': {'deaf': True}, 'deafen_off': {'deaf': False}}
        if action not in args:
            raise DiscordError('INVALID_ACTION')
        self._check()
        reply = self.ipc.request('SET_VOICE_SETTINGS', args[action])
        if any(reply.get(k) is not v for k, v in args[action].items()):
            raise DiscordError('STATE_NOT_CONFIRMED')


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.ipc = None
        self.current_client_id = ""
        self.context_settings = {}
        self.session = None
        self.last_result = {'code': 'AUTH_REQUIRED', 'client_id': ''}
        self._task = None
        self._closing = False

        self.icon_map = {
            "mute_on": "STATE_MUTE_ON",
            "mute_off": "STATE_MUTE_OFF",
            "deafen_on": "STATE_DEAFEN_ON",
            "deafen_off": "STATE_DEAFEN_OFF",
        }

    def _default_action(self):
        return "mute_on"

    def _default_settings(self):
        action = self._default_action()
        return {
            "client_id": "",
            "redirect_uri": "",
            "command": action,
            "discord_action": action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        for field in SENSITIVE_FIELDS:
            merged.pop(field, None)
        action = merged.get("command") or merged.get("discord_action") or self._default_action()
        merged["command"] = action
        merged["discord_action"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("client_id"),
            s.get("command"),
            s.get("discord_action"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}
        if event == 'didReceiveSettings' and not isinstance(payload_settings, dict):
            settings = payload

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if event == 'sendToPlugin' and control_command in ('discord_connect', 'discord_disconnect', 'discord_status'):
            if control_command == 'discord_status':
                await self._publish(context, self.last_result)
            elif control_command == 'discord_disconnect':
                # Detach first: a late OAuth/IPC reply cannot revive this session.
                session, self.session = self.session, None
                if session:
                    session.close()
                self.ipc = None
                self.current_client_id = ''
                await self._publish(context, {'code': 'DISCONNECTED', 'client_id': ''})
            else:
                cached = self.context_settings.get(context, {})
                current = self._merge_with_defaults({**cached, **settings})
                await self._start(context, current, secret=payload.get('client_secret', ''), authorize=True)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            current_action = action_command or settings.get("command") or settings.get("discord_action") or cached.get("command") or self._default_action()
            await self._send_builtin_icon(context, current_action)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = settings

        await self._start(context, settings, action=settings['command'])

    async def _publish(self, context, result):
        if self._closing:
            return
        self.last_result = result
        if context:
            await self.runner.send_message({'event': 'sendToPropertyInspector',
                'context': context, 'payload': {'command': 'discord_status', 'result': result}})

    async def _start(self, context, settings, action=None, secret='', authorize=False):
        if self._closing:
            return
        client_id = str(settings.get('client_id') or '').strip()
        if not client_id.isascii() or not client_id.isdigit() or not 15 <= len(client_id) <= 22:
            await self._publish(context, {'code': 'INVALID_CLIENT', 'client_id': client_id})
            return
        if action is not None and action not in self.icon_map:
            await self._publish(context, {'code': 'INVALID_ACTION', 'client_id': client_id})
            return
        if self._task and not self._task.done():
            await self._publish(context, {'code': 'BUSY', 'client_id': client_id})
            return
        redirect_uri = str(settings.get('redirect_uri') or '').strip()
        if (not self.session or self.session.cancelled.is_set()
                or (self.session.client_id, self.session.redirect_uri) != (client_id, redirect_uri)):
            if self.session:
                self.session.close()
            self.session = DiscordSession(client_id, redirect_uri)
        session = self.session
        if authorize and not secret and not session.secret:
            await self._publish(context, {'code': 'SECRET_REQUIRED', 'client_id': client_id})
            return
        if not authorize and not session.access_token:
            await self._publish(context, {'code': 'AUTH_REQUIRED', 'client_id': client_id})
            return
        await self._publish(context, {'code': 'AUTHORIZING' if authorize else 'RUNNING', 'client_id': client_id})
        # Return to the shared runner immediately; an approval dialog must not
        # block settings/disconnect events or queue delayed hardware actions.
        self._task = asyncio.create_task(self._run(context, session, action,
                                                  str(secret or '').strip(), authorize))

    async def _run(self, context, session, action, secret, authorize):
        result = {'code': 'CONNECTED' if action is None else 'SUCCESS', 'client_id': session.client_id}
        try:
            await asyncio.to_thread(session.execute, action, secret, authorize)
        except DiscordError as error:
            result['code'] = error.code
            if error.discord_code is not None:
                result['discord_code'] = error.discord_code
            session.authenticated = False
            if session.ipc:
                session.ipc.close()
        except Exception:
            result['code'] = 'INTERNAL_ERROR'
            session.authenticated = False
            if session.ipc:
                session.ipc.close()
        if self._closing or self.session is not session or session.cancelled.is_set():
            return
        self.ipc = session.ipc
        self.current_client_id = session.client_id
        # Log only our safe code, not credentials or a raw Discord error body.
        print(f'[{self.uuid}] {result["code"]}')
        await self._publish(context, result)

    async def shutdown(self):
        self._closing = True
        if self.session:
            self.session.close()
        self.context_settings.clear()
        if self._task and not self._task.done():
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
