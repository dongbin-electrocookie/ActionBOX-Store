import asyncio
import urllib.request
import urllib.parse
import json
import os
import sys
import ssl
from PIL import Image, ImageDraw, ImageFont
import io
import base64

ssl_ctx = ssl.create_default_context()
ssl_ctx.check_hostname = False
ssl_ctx.verify_mode = ssl.CERT_NONE

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.active_buttons = {}
        self.loop_started = False
        self.default_icon_name = "ACTION_WEATHER"

        self.i18n = {
            "en": {
                "WX_CLEAR": "Clear",
                "WX_CLOUDY": "Cloudy",
                "WX_RAIN": "Rain",
                "WX_SNOW": "Snow",
                "WX_STORM": "Storm",
                "WX_UNKNOWN": "Unknown",
                "TITLE_LOADING": "Loading...",
                "TITLE_ERROR": "Weather\nError",
                "TITLE_DEFAULT": "Weather",
                "DEFAULT_CITY": "Location",
                "SEARCH_LANGUAGE": "en"
            },
            "ko": {
                "WX_CLEAR": "맑음",
                "WX_CLOUDY": "흐림",
                "WX_RAIN": "비",
                "WX_SNOW": "눈",
                "WX_STORM": "천둥",
                "WX_UNKNOWN": "알 수 없음",
                "TITLE_LOADING": "로딩중...",
                "TITLE_ERROR": "날씨\n오류",
                "TITLE_DEFAULT": "날씨",
                "DEFAULT_CITY": "위치 지정됨",
                "SEARCH_LANGUAGE": "ko"
            },
            "ja": {
                "WX_CLEAR": "晴れ",
                "WX_CLOUDY": "くもり",
                "WX_RAIN": "雨",
                "WX_SNOW": "雪",
                "WX_STORM": "雷",
                "WX_UNKNOWN": "不明",
                "TITLE_LOADING": "読込中...",
                "TITLE_ERROR": "天気\nエラー",
                "TITLE_DEFAULT": "天気",
                "DEFAULT_CITY": "位置設定",
                "SEARCH_LANGUAGE": "ja"
            },
            "de": {
                "WX_CLEAR": "Klar",
                "WX_CLOUDY": "Bewölkt",
                "WX_RAIN": "Regen",
                "WX_SNOW": "Schnee",
                "WX_STORM": "Gewitter",
                "WX_UNKNOWN": "Unbekannt",
                "TITLE_LOADING": "Lädt...",
                "TITLE_ERROR": "Wetter\nFehler",
                "TITLE_DEFAULT": "Wetter",
                "DEFAULT_CITY": "Standort",
                "SEARCH_LANGUAGE": "de"
            },
            "es": {
                "WX_CLEAR": "Despejado",
                "WX_CLOUDY": "Nublado",
                "WX_RAIN": "Lluvia",
                "WX_SNOW": "Nieve",
                "WX_STORM": "Tormenta",
                "WX_UNKNOWN": "Desconocido",
                "TITLE_LOADING": "Cargando...",
                "TITLE_ERROR": "Error\ndel clima",
                "TITLE_DEFAULT": "Clima",
                "DEFAULT_CITY": "Ubicación",
                "SEARCH_LANGUAGE": "es"
            },
            "fr": {
                "WX_CLEAR": "Clair",
                "WX_CLOUDY": "Nuageux",
                "WX_RAIN": "Pluie",
                "WX_SNOW": "Neige",
                "WX_STORM": "Orage",
                "WX_UNKNOWN": "Inconnu",
                "TITLE_LOADING": "Chargement...",
                "TITLE_ERROR": "Erreur\nmétéo",
                "TITLE_DEFAULT": "Météo",
                "DEFAULT_CITY": "Lieu",
                "SEARCH_LANGUAGE": "fr"
            },
            "ru": {
                "WX_CLEAR": "Ясно",
                "WX_CLOUDY": "Облачно",
                "WX_RAIN": "Дождь",
                "WX_SNOW": "Снег",
                "WX_STORM": "Гроза",
                "WX_UNKNOWN": "Неизвестно",
                "TITLE_LOADING": "Загрузка...",
                "TITLE_ERROR": "Ошибка\nпогоды",
                "TITLE_DEFAULT": "Погода",
                "DEFAULT_CITY": "Место",
                "SEARCH_LANGUAGE": "ru"
            },
            "it": {
                "WX_CLEAR": "Sereno",
                "WX_CLOUDY": "Nuvoloso",
                "WX_RAIN": "Pioggia",
                "WX_SNOW": "Neve",
                "WX_STORM": "Tempesta",
                "WX_UNKNOWN": "Sconosciuto",
                "TITLE_LOADING": "Caricamento...",
                "TITLE_ERROR": "Errore\nmeteo",
                "TITLE_DEFAULT": "Meteo",
                "DEFAULT_CITY": "Località",
                "SEARCH_LANGUAGE": "it"
            },
            "pt-PT": {
                "WX_CLEAR": "Céu limpo",
                "WX_CLOUDY": "Nublado",
                "WX_RAIN": "Chuva",
                "WX_SNOW": "Neve",
                "WX_STORM": "Trovoada",
                "WX_UNKNOWN": "Desconhecido",
                "TITLE_LOADING": "A carregar...",
                "TITLE_ERROR": "Erro\nmeteorológico",
                "TITLE_DEFAULT": "Tempo",
                "DEFAULT_CITY": "Localização",
                "SEARCH_LANGUAGE": "pt"
            }
        }

    def _lang(self, settings_or_lang):
        if isinstance(settings_or_lang, dict):
            code = (settings_or_lang.get("_lang") or "en").lower()
        else:
            code = (settings_or_lang or "en").lower()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        code = alias.get(code, code)
        return code if code in self.i18n else "en"

    def _t(self, settings_or_lang, key):
        lang = self._lang(settings_or_lang)
        return self.i18n.get(lang, self.i18n["en"]).get(key, key)

    def _get_icon_path(self):
        return os.path.join(self.plugin_dir, "icon", f"{self.default_icon_name}.png")

    def _target_page_for(self, context, settings=None):
        if isinstance(settings, dict) and settings.get("_target_page") is not None:
            return settings.get("_target_page")
        active = self.active_buttons.get(context, {})
        if isinstance(active, dict):
            return active.get("_target_page")
        return None

    async def _send_builtin_icon(self, context, settings=None):
        icon_path = self._get_icon_path()
        if os.path.exists(icon_path):
            target_page = self._target_page_for(context, settings)
            image_payload = {"image": None}
            icon_payload = {"icon_path": icon_path}
            if target_page is not None:
                image_payload["page"] = target_page
                icon_payload["page"] = target_page
            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": image_payload
            })
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": icon_payload
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "lat", "lon", "units", "last_query", "selected_location_name",
            "title", "sync_title_on_location_change",
            "builtin_icon_name", "default_visuals_initialized"
        ])

        if not meaningful:
            new_settings = {
                "lat": "",
                "lon": "",
                "units": "celsius",
                "last_query": "",
                "selected_location_name": "",
                "_lang": "en",
                "sync_title_on_location_change": False,
                "builtin_icon_name": self.default_icon_name,
                "default_visuals_initialized": True
            }
            visual_settings = {**new_settings, "_target_page": settings.get("_target_page")}
            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": new_settings
            })
            await self._send_builtin_icon(context, visual_settings)
            return

        if settings.get("lat") and settings.get("lon"):
            self.active_buttons[context] = settings
            await self.update_weather_action(context, settings)
        else:
            await self._send_builtin_icon(context, settings)

    async def auto_update_loop(self):
        while True:
            await asyncio.sleep(900)
            for context, settings in list(self.active_buttons.items()):
                await self.update_weather_action(context, settings)

    async def handle_message(self, data):
        try:
            event = data.get("event")
            payload = data.get("payload", {}) or {}

            command = payload.get("command") or data.get("command")
            context = payload.get("context") or data.get("context")
            settings = payload.get("settings") or data.get("settings", {}) or {}

            if not self.loop_started:
                self.loop_started = True
                asyncio.create_task(self.auto_update_loop())

            if event and ("disappear" in event.lower() or "delete" in event.lower() or "remove" in event.lower() or "clear" in event.lower()):
                if context in self.active_buttons:
                    del self.active_buttons[context]
                return

            if event in ["willAppear", "keyDidAppear"]:
                settings["_target_page"] = payload.get("page")
                await self._initialize_default_visuals_if_new(context, settings)

            elif event == "keyDown":
                if context in self.active_buttons:
                    await self.update_weather_action(context, self.active_buttons[context])
                else:
                    settings["_target_page"] = payload.get("page")
                    if settings.get("lat") and settings.get("lon"):
                        self.active_buttons[context] = settings
                        await self.update_weather_action(context, settings)
                    else:
                        await self._send_builtin_icon(context, settings)

            elif event == "sendToPlugin" or command:
                if command == "search_city":
                    query = payload.get("query") or data.get("query", "")
                    lang = payload.get("lang") or settings.get("_lang") or "en"
                    if query:
                        results = await asyncio.to_thread(self.search_location, query, lang)
                        await self.runner.send_message({
                            "event": "sendToPropertyInspector",
                            "context": context,
                            "payload": {"command": "search_results", "results": results}
                        })

                elif command == "force_update":
                    settings["_target_page"] = payload.get("page", self.active_buttons.get(context, {}).get("_target_page"))
                    if settings.get("lat") and settings.get("lon"):
                        self.active_buttons[context] = settings
                        await self.update_weather_action(context, settings)
                    else:
                        if context in self.active_buttons:
                            del self.active_buttons[context]
                        await self._send_builtin_icon(context, settings)
                        await self.runner.send_message({
                            "event": "setTitle",
                            "context": context,
                            "payload": {
                                "title": settings.get("title", ""),
                                "page": settings.get("_target_page")
                            }
                        })

                elif command == "apply_builtin_icon":
                    await self._send_builtin_icon(context, settings)

        except Exception as e:
            print(f"❌ [Weather] Internal error: {e}")

    def search_location(self, query, lang_code):
        try:
            safe_query = urllib.parse.quote(query)
            lang_param = self._t(lang_code, "SEARCH_LANGUAGE")
            url = f"https://geocoding-api.open-meteo.com/v1/search?name={safe_query}&count=5&language={lang_param}&format=json"

            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
            with urllib.request.urlopen(req, timeout=5, context=ssl_ctx) as res:
                data = json.loads(res.read().decode('utf-8'))

            results = []
            if "results" in data:
                for item in data["results"]:
                    results.append({
                        "name": item.get("name", "Unknown"),
                        "country": item.get("country", ""),
                        "lat": round(item.get("latitude", 0), 4),
                        "lon": round(item.get("longitude", 0), 4)
                    })
            return results
        except Exception as e:
            print(f"❌ [{self.uuid}] Location search error: {e}")
            return []

    def _font_paths(self, names):
        paths = []
        platform_font_dirs = []

        if sys.platform.startswith("win"):
            platform_font_dirs = [
                r"C:\Windows\Fonts"
            ]
        elif sys.platform == "darwin":
            platform_font_dirs = [
                "/System/Library/Fonts",
                "/System/Library/Fonts/Supplemental",
                "/Library/Fonts",
                os.path.expanduser("~/Library/Fonts")
            ]
        else:
            platform_font_dirs = [
                "/usr/share/fonts",
                "/usr/local/share/fonts",
                os.path.expanduser("~/.local/share/fonts")
            ]

        for name in names:
            paths.append(os.path.join(self.plugin_dir, name))
            for folder in platform_font_dirs:
                paths.append(os.path.join(folder, name))
            paths.append(name)
        return paths

    def _load_font(self, names, size):
        for path in self._font_paths(names):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
        return ImageFont.load_default()

    def _fit_font(self, draw, text, names, max_width, start_size, min_size=10):
        size = start_size
        while size >= min_size:
            font = self._load_font(names, size)
            try:
                bbox = draw.textbbox((0, 0), text, font=font)
                w = bbox[2] - bbox[0]
            except Exception:
                w = len(text) * max(size // 2, 6)
            if w <= max_width:
                return font
            size -= 2
        return self._load_font(names, min_size)

    def _weather_label_and_color(self, code, settings):
        if code == 0:
            return self._t(settings, "WX_CLEAR"), (41, 128, 185)
        elif code in [1, 2, 3, 45, 48]:
            return self._t(settings, "WX_CLOUDY"), (127, 140, 141)
        elif code in [51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82]:
            return self._t(settings, "WX_RAIN"), (52, 73, 94)
        elif code in [71, 73, 75, 77, 85, 86]:
            return self._t(settings, "WX_SNOW"), (149, 165, 166)
        elif code in [95, 96, 99]:
            return self._t(settings, "WX_STORM"), (44, 62, 80)
        else:
            return self._t(settings, "WX_UNKNOWN"), (127, 140, 141)

    def fetch_weather_image(self, lat, lon, city_name, units, settings):
        if not lat or not lon:
            return None

        try:
            url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true"
            if units == 'fahrenheit':
                url += "&temperature_unit=fahrenheit"

            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
            with urllib.request.urlopen(req, timeout=10, context=ssl_ctx) as res:
                weather_data = json.loads(res.read().decode('utf-8'))

            current = weather_data.get('current_weather', {})
            temp = current.get('temperature', 0)
            code = current.get('weathercode', 0)

            condition_label, bg_color = self._weather_label_and_color(code, settings)

            img = Image.new('RGB', (112, 112), color=bg_color)
            draw = ImageDraw.Draw(img)

            bold_fonts = [
                "malgunbd.ttf", "malgun.ttf",
                "AppleSDGothicNeo.ttc", "AppleGothic.ttf", "Helvetica.ttc",
                "YuGothB.ttc", "Yu Gothic Bold.ttf", "meiryob.ttc", "msgothic.ttc",
                "NotoSansCJK-Bold.ttc", "NotoSansCJKkr-Bold.otf", "NotoSans-Bold.ttf",
                "seguiemj.ttf", "arialbd.ttf", "arial.ttf"
            ]
            regular_fonts = [
                "malgun.ttf",
                "AppleSDGothicNeo.ttc", "AppleGothic.ttf", "Helvetica.ttc",
                "YuGothM.ttc", "Yu Gothic.ttf", "meiryo.ttc", "msgothic.ttc",
                "NotoSansCJK-Regular.ttc", "NotoSansCJKkr-Regular.otf", "NotoSans-Regular.ttf",
                "segoeui.ttf", "arial.ttf"
            ]

            display_city = (city_name or self._t(settings, "DEFAULT_CITY")).strip()
            temp_str = f"{temp}{'°C' if units == 'celsius' else '°F'}"

            font_city = self._fit_font(draw, display_city, bold_fonts, 104, 21, 11)
            font_temp = self._fit_font(draw, temp_str, bold_fonts, 108, 31, 16)
            font_cond = self._fit_font(draw, condition_label, regular_fonts, 103, 18, 10)

            def draw_centered_text(y_pos, text, font, fill_color):
                try:
                    bbox = draw.textbbox((0, 0), text, font=font)
                    w = bbox[2] - bbox[0]
                except Exception:
                    w = len(text) * 10
                x_pos = (112 - w) / 2
                draw.text((x_pos, y_pos), text, font=font, fill=fill_color)

            draw_centered_text(7, display_city, font_city, (255, 255, 255))
            draw_centered_text(39, temp_str, font_temp, (255, 255, 255))
            draw_centered_text(83, condition_label, font_cond, (241, 196, 15))

            buffered = io.BytesIO()
            img.save(buffered, format="PNG")
            return base64.b64encode(buffered.getvalue()).decode('utf-8')

        except Exception as e:
            print(f"❌ [{self.uuid}] Weather fetch error: {e}")
            return None

    async def update_weather_action(self, context, settings):
        lat = settings.get("lat", "")
        lon = settings.get("lon", "")
        units = settings.get("units", "celsius")
        city_name = settings.get("selected_location_name") or settings.get("last_query") or self._t(settings, "DEFAULT_CITY")

        if not lat or not lon:
            await self._send_builtin_icon(context, settings)
            return

        current_active = self.active_buttons.get(context)
        if not current_active or current_active.get("lat") != lat or current_active.get("lon") != lon:
            return

        await self.runner.send_message({
            "event": "setTitle",
            "context": context,
            "payload": {
                "title": self._t(settings, "TITLE_LOADING"),
                "page": settings.get("_target_page")
            }
        })

        b64_image = await asyncio.to_thread(self.fetch_weather_image, lat, lon, city_name, units, settings)

        if b64_image:
            target_page = settings.get("_target_page")
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": "", "page": target_page}
            })
            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": {
                    "image": b64_image,
                    "page": target_page
                }
            })
        else:
            await self._send_builtin_icon(context, settings)
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {
                    "title": self._t(settings, "TITLE_ERROR"),
                    "page": settings.get("_target_page")
                }
            })
