"""Persistent, native application catalogue used by the Launch plugin.

The collector deliberately avoids PowerShell.  Windows' AppsFolder is the
authoritative list, while Start-menu/Desktop shortcuts add launch targets and
custom icon locations that AppsFolder does not always expose.
"""

from __future__ import annotations

import ctypes
from ctypes import wintypes
import hashlib
import json
import os
import sys
import tempfile
import time


IS_WINDOWS = sys.platform.startswith("win")
CATALOG_VERSION = 2


def catalogue_root() -> str:
    override = os.environ.get("COMBOX_LAUNCHER_CATALOG_ROOT", "").strip()
    if override:
        path = os.path.abspath(os.path.expandvars(os.path.expanduser(override)))
    elif IS_WINDOWS:
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser(r"~\AppData\Local")
        path = os.path.join(base, "ComboX", "LauncherCatalog")
    elif sys.platform == "darwin":
        base = os.path.expanduser("~/Library/Caches")
        path = os.path.join(base, "ComboX", "LauncherCatalog")
    else:
        base = os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache")
        path = os.path.join(base, "ComboX", "LauncherCatalog")
    os.makedirs(path, exist_ok=True)
    return path


def catalogue_path() -> str:
    return os.path.join(catalogue_root(), "catalog.json")


def icon_cache_dir() -> str:
    path = os.path.join(catalogue_root(), "icons")
    os.makedirs(path, exist_ok=True)
    return path


def load_catalogue() -> list[dict]:
    try:
        with open(catalogue_path(), "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if isinstance(payload, dict):
            # Catalogue identities changed in v2 so browser-installed web apps
            # (which all share chrome_proxy.exe/msedge_proxy.exe) are not
            # collapsed into one application.  An old catalogue must be
            # rebuilt instead of being served indefinitely from disk.
            if payload.get("version") != CATALOG_VERSION:
                return []
            apps = payload.get("apps", [])
        else:  # compatibility with early development catalogues
            apps = payload
        return apps if isinstance(apps, list) else []
    except (OSError, ValueError, TypeError):
        return []


def _atomic_write_json(path: str, payload: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix="catalog-", suffix=".tmp", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        try:
            if os.path.exists(temporary):
                os.remove(temporary)
        except OSError:
            pass


def _safe_cache_name(identity: str) -> str:
    # v3 invalidates generic proxy-executable artwork cached before shortcut
    # IconLocation became authoritative for Chrome/Edge web applications.
    return hashlib.sha1(("native-v3|" + identity).encode("utf-8", "ignore")).hexdigest() + ".png"


def _split_icon_location(value: str) -> tuple[str, int]:
    value = os.path.expandvars(str(value or "").strip().strip('"'))
    if not value:
        return "", 0
    path, comma, index_text = value.rpartition(",")
    if comma:
        try:
            return path.strip().strip('"'), int(index_text.strip())
        except ValueError:
            pass
    return value, 0


def _save_hicon(hicon: int, output_path: str, size: int = 256) -> bool:
    """Render an HICON to a transparent PNG without any shortcut overlay."""
    if not hicon:
        return False
    try:
        import win32con
        import win32gui
        import win32ui
        from PIL import Image

        screen_dc = win32gui.GetDC(0)
        source_dc = win32ui.CreateDCFromHandle(screen_dc)
        memory_dc = source_dc.CreateCompatibleDC()
        bitmap = win32ui.CreateBitmap()
        bitmap.CreateCompatibleBitmap(source_dc, size, size)
        old_bitmap = memory_dc.SelectObject(bitmap)
        try:
            memory_dc.FillSolidRect((0, 0, size, size), 0)
            win32gui.DrawIconEx(
                memory_dc.GetSafeHdc(), 0, 0, hicon, size, size, 0, None, win32con.DI_NORMAL
            )
            pixels = bitmap.GetBitmapBits(True)
            image = Image.frombuffer("RGBA", (size, size), pixels, "raw", "BGRA", 0, 1)
            # Some icon resources have no usable alpha channel. Derive it from
            # the black render only in that case; normal RGBA icons are kept.
            alpha = image.getchannel("A")
            if not alpha.getbbox():
                red, green, blue, _ = image.split()
                alpha = Image.eval(
                    Image.merge("RGB", (red, green, blue)).convert("L"),
                    lambda value: 0 if value == 0 else 255,
                )
                image.putalpha(alpha)
            image.save(output_path, "PNG")
            return True
        finally:
            memory_dc.SelectObject(old_bitmap)
            win32gui.DeleteObject(bitmap.GetHandle())
            memory_dc.DeleteDC()
            source_dc.DeleteDC()
            win32gui.ReleaseDC(0, screen_dc)
    except Exception:
        return False


def _extract_resource_icon(source: str, index: int, output_path: str) -> bool:
    source = os.path.expandvars(str(source or "").strip().strip('"'))
    if not source or not os.path.isfile(source):
        return False
    try:
        handles = (wintypes.HICON * 1)()
        icon_ids = (wintypes.UINT * 1)()
        count = ctypes.windll.user32.PrivateExtractIconsW(
            source, index, 256, 256, handles, icon_ids, 1, 0
        )
        if count > 0 and handles[0]:
            try:
                return _save_hicon(handles[0], output_path, 256)
            finally:
                ctypes.windll.user32.DestroyIcon(handles[0])
    except Exception:
        pass
    return False


class _GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", wintypes.DWORD),
        ("Data2", wintypes.WORD),
        ("Data3", wintypes.WORD),
        ("Data4", ctypes.c_ubyte * 8),
    ]

    @classmethod
    def from_text(cls, text: str):
        import uuid

        raw = uuid.UUID(text).bytes_le
        return cls.from_buffer_copy(raw)


class _SIZE(ctypes.Structure):
    _fields_ = [("cx", wintypes.LONG), ("cy", wintypes.LONG)]


def _save_shell_item_image(parsing_name: str, output_path: str) -> bool:
    """Ask IShellItemImageFactory for the app's 256 px artwork."""
    if not parsing_name:
        return False
    interface = ctypes.c_void_p()
    iid = _GUID.from_text("bcc18b79-ba16-442f-80c4-8a59c30c463b")
    try:
        create_item = ctypes.windll.shell32.SHCreateItemFromParsingName
        create_item.argtypes = [wintypes.LPCWSTR, ctypes.c_void_p, ctypes.POINTER(_GUID), ctypes.POINTER(ctypes.c_void_p)]
        create_item.restype = ctypes.c_long
        if create_item(parsing_name, None, ctypes.byref(iid), ctypes.byref(interface)) != 0 or not interface:
            return False

        vtable = ctypes.cast(interface, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
        get_image = ctypes.WINFUNCTYPE(
            ctypes.c_long, ctypes.c_void_p, _SIZE, wintypes.DWORD, ctypes.POINTER(wintypes.HBITMAP)
        )(vtable[3])
        release = ctypes.WINFUNCTYPE(wintypes.ULONG, ctypes.c_void_p)(vtable[2])
        bitmap = wintypes.HBITMAP()
        # Prefer the normal Shell image, which may retain a packaged app's tile
        # background. Some packages only implement ICONONLY, so fall back to it.
        result = get_image(interface, _SIZE(256, 256), 0x1 | 0x100, ctypes.byref(bitmap))
        if result != 0 or not bitmap:
            bitmap = wintypes.HBITMAP()
            result = get_image(interface, _SIZE(256, 256), 0x1 | 0x4 | 0x100, ctypes.byref(bitmap))
        if result != 0 or not bitmap:
            return False
        try:
            return _save_hbitmap(bitmap, output_path)
        finally:
            ctypes.windll.gdi32.DeleteObject(bitmap)
    except Exception:
        return False
    finally:
        if interface:
            try:
                release(interface)
            except Exception:
                pass


class _BITMAP(ctypes.Structure):
    _fields_ = [
        ("bmType", wintypes.LONG), ("bmWidth", wintypes.LONG), ("bmHeight", wintypes.LONG),
        ("bmWidthBytes", wintypes.LONG), ("bmPlanes", wintypes.WORD), ("bmBitsPixel", wintypes.WORD),
        ("bmBits", ctypes.c_void_p),
    ]


class _BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG),
        ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG), ("biYPelsPerMeter", wintypes.LONG),
        ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD),
    ]


class _BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", _BITMAPINFOHEADER), ("bmiColors", wintypes.DWORD * 3)]


def _save_hbitmap(bitmap_handle, output_path: str) -> bool:
    try:
        from PIL import Image

        bitmap = _BITMAP()
        if not ctypes.windll.gdi32.GetObjectW(bitmap_handle, ctypes.sizeof(bitmap), ctypes.byref(bitmap)):
            return False
        width, height = int(bitmap.bmWidth), abs(int(bitmap.bmHeight))
        if width <= 0 or height <= 0:
            return False
        info = _BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(_BITMAPINFOHEADER)
        info.bmiHeader.biWidth = width
        info.bmiHeader.biHeight = -height
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        info.bmiHeader.biCompression = 0
        buffer = ctypes.create_string_buffer(width * height * 4)
        dc = ctypes.windll.user32.GetDC(None)
        try:
            rows = ctypes.windll.gdi32.GetDIBits(
                dc, bitmap_handle, 0, height, buffer, ctypes.byref(info), 0
            )
        finally:
            ctypes.windll.user32.ReleaseDC(None, dc)
        if rows != height:
            return False
        image = Image.frombuffer("RGBA", (width, height), buffer, "raw", "BGRA", 0, 1)
        rgb_extrema = image.convert("RGB").getextrema()
        if image.getchannel("A").getbbox() and max(channel[1] for channel in rgb_extrema) <= 32:
            # A few packaged apps expose only a black monochrome glyph. Keep it
            # readable in COMBO-X's dark skins by placing it on a neutral tile.
            tile = Image.new("RGBA", image.size, (245, 245, 245, 255))
            tile.alpha_composite(image)
            image = tile
        image.save(output_path, "PNG")
        return True
    except Exception:
        return False


def _cache_icon(
    identity: str,
    candidates: list[tuple[str, int]],
    parsing_name: str = "",
    force: bool = False,
) -> str:
    output = os.path.join(icon_cache_dir(), _safe_cache_name(identity))
    if not force and os.path.isfile(output) and os.path.getsize(output) > 0:
        return output
    for source, index in candidates:
        if _extract_resource_icon(source, index, output):
            return output
    if parsing_name and _save_shell_item_image(parsing_name, output):
        return output
    try:
        if os.path.exists(output):
            os.remove(output)
    except OSError:
        pass
    return ""


def _known_shortcut_roots() -> list[tuple[str, bool]]:
    appdata = os.environ.get("APPDATA", "")
    programdata = os.environ.get("PROGRAMDATA", "")
    userprofile = os.environ.get("USERPROFILE", "")
    public = os.environ.get("PUBLIC", "")
    candidates = [
        (os.path.join(appdata, r"Microsoft\Windows\Start Menu\Programs"), True),
        (os.path.join(programdata, r"Microsoft\Windows\Start Menu\Programs"), True),
        (os.path.join(userprofile, "Desktop"), False),
        (os.path.join(public, "Desktop"), False),
    ]
    return [(path, recursive) for path, recursive in candidates if path and os.path.isdir(path)]


def _collect_shortcuts() -> list[dict]:
    import win32com.client

    wsh = win32com.client.Dispatch("WScript.Shell")
    apps = []
    allowed = {".exe", ".com", ".bat", ".cmd", ".msc"}
    for root, recursive in _known_shortcut_roots():
        iterator = os.walk(root) if recursive else [(root, [], os.listdir(root))]
        for directory, _subdirs, files in iterator:
            for filename in files:
                path = os.path.join(directory, filename)
                extension = os.path.splitext(filename)[1].lower()
                if extension not in {".lnk", ".exe"}:
                    continue
                target = path
                arguments = ""
                icon_location = ""
                if extension == ".lnk":
                    try:
                        shortcut = wsh.CreateShortcut(path)
                        target = os.path.expandvars(str(shortcut.TargetPath or "").strip())
                        arguments = str(shortcut.Arguments or "").strip()
                        icon_location = str(shortcut.IconLocation or "").strip()
                    except Exception:
                        continue
                    if not target or os.path.splitext(target)[1].lower() not in allowed:
                        continue
                if not os.path.isfile(target):
                    continue
                name = os.path.splitext(filename)[0]
                icon_file, icon_index = _split_icon_location(icon_location)
                candidates = []
                if icon_file:
                    candidates.append((icon_file, icon_index))
                candidates.append((target, 0))
                identity = "shortcut|" + os.path.normcase(os.path.abspath(path))
                apps.append({
                    "Name": name,
                    "AppID": path,
                    "IconSource": icon_file or target,
                    "IconPath": "",
                    "_IconIdentity": identity,
                    "_IconCandidates": candidates,
                    "_ParsingName": "",
                    "TargetPath": target,
                    "Arguments": arguments,
                    "SourceKind": "shortcut",
                })
    return apps


def _collect_apps_folder() -> list[dict]:
    import win32com.client

    namespace = win32com.client.Dispatch("Shell.Application").Namespace("shell:AppsFolder")
    if namespace is None:
        return []
    items = namespace.Items()
    apps = []
    for index in range(int(items.Count)):
        try:
            item = items.Item(index)
            name = str(item.Name or "").strip()
            app_id = str(item.ExtendedProperty("System.AppUserModel.ID") or item.Path or "").strip()
            item_path = os.path.expandvars(str(item.Path or "").strip())
            if not name or not app_id:
                continue
            parsing_name = "shell:AppsFolder\\" + app_id
            candidates = [(item_path, 0)] if os.path.isfile(item_path) else []
            identity = "appsfolder|" + app_id.casefold()
            apps.append({
                "Name": name,
                "AppID": app_id,
                "IconSource": item_path or parsing_name,
                "IconPath": "",
                "_IconIdentity": identity,
                "_IconCandidates": candidates,
                "_ParsingName": parsing_name,
                "TargetPath": item_path if os.path.isfile(item_path) else "",
                "Arguments": "",
                "SourceKind": "appsfolder",
            })
        except Exception:
            continue
    return apps


def _deduplicate(apps: list[dict]) -> list[dict]:
    selected: dict[str, dict] = {}
    for app in apps:
        target = str(app.get("TargetPath") or "").strip()
        app_id = str(app.get("AppID") or "").strip()
        name = " ".join(str(app.get("Name") or "").split())
        if not name or not app_id:
            continue
        arguments = " ".join(str(app.get("Arguments") or "").split())
        source_kind = str(app.get("SourceKind") or "")
        if target and source_kind == "shortcut" and arguments:
            # Browser-installed web apps intentionally share one proxy EXE.
            # Their --app-id/profile arguments are the actual application
            # identity. This also correctly preserves any other shortcuts that
            # launch the same executable with different modes or documents.
            identity = (
                "shortcut-target|"
                + os.path.normcase(os.path.normpath(target))
                + "|args|"
                + arguments.casefold()
            )
        elif target:
            identity = "target|" + os.path.normcase(os.path.normpath(target))
        else:
            identity = "appid|" + app_id.casefold()
        previous = selected.get(identity)
        if previous is None:
            selected[identity] = app
            continue
        # Prefer a Start-menu shortcut: it preserves arguments and the launch
        # path users expect. Prefer an existing icon over an empty result.
        old_score = (bool(previous.get("IconPath")), previous.get("SourceKind") == "shortcut")
        new_score = (bool(app.get("IconPath")), app.get("SourceKind") == "shortcut")
        if new_score > old_score:
            selected[identity] = app

    # Remove remaining aliases with identical display names, retaining the
    # candidate with artwork. This keeps the picker compact.
    by_name: dict[str, dict] = {}
    for app in selected.values():
        key = str(app.get("Name") or "").casefold()
        previous = by_name.get(key)
        if previous is None or (not previous.get("IconPath") and app.get("IconPath")):
            by_name[key] = app
    return sorted(by_name.values(), key=lambda item: str(item.get("Name") or "").casefold())


def collect_catalogue(force_icons: bool = False) -> list[dict]:
    if not IS_WINDOWS:
        return load_catalogue()
    import pythoncom

    started = time.perf_counter()
    pythoncom.CoInitialize()
    try:
        # Deduplicate metadata before rendering. AppsFolder and Start-menu
        # shortcuts overlap heavily; rendering first wastes most first-run time.
        apps = _deduplicate(_collect_shortcuts() + _collect_apps_folder())
        for app in apps:
            app["IconPath"] = _cache_icon(
                str(app.pop("_IconIdentity", "")),
                list(app.pop("_IconCandidates", [])),
                str(app.pop("_ParsingName", "")),
                force=force_icons,
            )
        payload = {
            "version": CATALOG_VERSION,
            "generated_at": time.time(),
            "duration_seconds": round(time.perf_counter() - started, 3),
            "apps": apps,
        }
        _atomic_write_json(catalogue_path(), payload)
        return apps
    finally:
        pythoncom.CoUninitialize()


if __name__ == "__main__":
    apps = collect_catalogue()
    print(json.dumps({"count": len(apps), "catalog": catalogue_path()}, ensure_ascii=False))
