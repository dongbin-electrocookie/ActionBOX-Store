import asyncio
import os
import sys

# pycaw 및 comtypes 모듈 임포트
try:
    import comtypes
    from pycaw.pycaw import AudioUtilities, ISimpleAudioVolume
except ImportError:
    print("[Error] pycaw 라이브러리가 설치되지 않았습니다. 'pip install pycaw comtypes'를 실행하세요.")
    AudioUtilities = None

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.STEP = 0.10  # 10% 씩 조절

    def _get_audio_apps(self):
        """현재 오디오 세션이 있는 프로그램(exe) 목록을 반환합니다."""
        if not AudioUtilities: 
            return["에러: pycaw 라이브러리 인식 실패"]
        
        comtypes.CoInitialize()
        try:
            apps = set()
            sessions = AudioUtilities.GetAllSessions()
            for session in sessions:
                if session.Process:
                    apps.add(session.Process.name())
                    
            if len(apps) == 0:
                return ["현재 소리를 내고 있는 앱이 없습니다"]
                
            return sorted(list(apps), key=str.lower)
            
        except Exception as e:
            return[f"에러 발생: {str(e)}"]
        finally:
            comtypes.CoUninitialize()

    def _change_app_volume(self, app_name, action):
        """지정된 앱의 볼륨을 조절하고, 변경된 볼륨 텍스트를 반환합니다."""
        if not AudioUtilities or not app_name: return None

        comtypes.CoInitialize()
        try:
            sessions = AudioUtilities.GetAllSessions()
            for session in sessions:
                if session.Process and session.Process.name().lower() == app_name.lower():
                    volume = session._ctl.QueryInterface(ISimpleAudioVolume)
                    
                    # 확장자(.exe) 떼어내서 이름 예쁘게 만들기 (예: chrome.exe -> Chrome)
                    display_name = app_name.replace(".exe", "").capitalize()
                    
                    if action == "vol_mute":
                        current_mute = volume.GetMute()
                        new_mute = 0 if current_mute else 1
                        volume.SetMute(new_mute, None)
                        
                        # 뮤트 상태 텍스트 반환
                        if new_mute:
                            return f"{display_name}\n[MUTE]"
                        else:
                            current_vol = int(volume.GetMasterVolume() * 100)
                            return f"{display_name}\n{current_vol}%"
                    
                    elif action == "vol_up":
                        current_vol = volume.GetMasterVolume()
                        new_vol = min(1.0, current_vol + self.STEP)
                        volume.SetMasterVolume(new_vol, None)
                        volume.SetMute(0, None) # 볼륨 올리면 뮤트 자동 해제
                        return f"{display_name}\n{int(new_vol * 100)}%"
                        
                    elif action == "vol_down":
                        current_vol = volume.GetMasterVolume()
                        new_vol = max(0.0, current_vol - self.STEP)
                        volume.SetMasterVolume(new_vol, None)
                        volume.SetMute(0, None) # 볼륨 내리면 뮤트 자동 해제
                        return f"{display_name}\n{int(new_vol * 100)}%"
                        
        except Exception as e:
            print(f"[{self.uuid}] 볼륨 조절 실패: {e}")
        finally:
            comtypes.CoUninitialize()
            
        return None

    async def handle_message(self, data):
        event = data.get("event")
        command = data.get("command") or data.get("payload", {}).get("command")

        # 1. UI에서 앱 목록을 요청했을 때
        if command == "get_audio_apps":
            context = data.get("context") or data.get("payload", {}).get("context")
            apps = await asyncio.to_thread(self._get_audio_apps)
            
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {"command": "audio_app_list", "apps": apps}
            })

        # 2. 버튼을 누르거나 다이얼을 돌렸을 때
        elif event == "keyDown":
            settings = data.get("payload", {}).get("settings", {})
            context = data.get("context")
            app_name = settings.get("app_name")
            action_type = settings.get("action_type") 
            
            if app_name and action_type:
                # 볼륨 조절 함수 비동기 실행 후, 결과 텍스트(예: Chrome 50%) 받아오기
                new_title_text = await asyncio.to_thread(self._change_app_volume, app_name, action_type)
                
                # ★[핵심 피드백] 변경된 볼륨 텍스트를 기기 화면과 PC 버튼에 즉시 덮어씌움!
                if new_title_text:
                    await self.runner.send_message({
                        "event": "setTitle",
                        "context": context,
                        "payload": {"title": new_title_text}
                    })