import asyncio
import json

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.toggle_states = {} # 상태 1, 2 토글 관리

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")

        if event == "keyDidAppear":
            self.toggle_states[context] = 1
        elif event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        settings = data.get("payload", {}).get("settings", {})
        
        # 현재 상태(1 또는 2)에 맞는 리스트 가져오기
        current_state = self.toggle_states.get(context, 1)
        action_list_key = f"actions_{current_state}"
        action_list = settings.get(action_list_key, [])
        
        # 🚀 리스트에 있는 액션들을 순서대로 지휘
        for action_to_run in action_list:
            action_id = action_to_run.get("action_id")
            delay_ms = int(action_to_run.get("delay_ms", 0))
            custom_data = action_to_run.get("custom_data", "")

            # 1. 지정된 시간(ms)만큼 대기
            if delay_ms > 0:
                await asyncio.sleep(delay_ms / 1000.0)
            
            if not action_id: continue

            # 2. 🚀 데이터 포장 (직렬화)
            # 외부 플러그인의 데이터는 딕셔너리(객체)일 수 있으므로 문자열로 변환
            if isinstance(custom_data, dict):
                # 딕셔너리가 비어있지 않을 때만 JSON 문자열로 변환
                payload_str = json.dumps(custom_data) if custom_data else ""
            else:
                payload_str = str(custom_data)

            # 3. 타겟 ID 조립 (기존 플러그인 엔진의 규칙 '#')
            final_target_id = action_id
            if payload_str and "#" not in action_id:
                final_target_id = f"{action_id}#{payload_str}"

            # 4. ActionBox 메인 엔진에게 대리 실행(Fake Click) 요청
            await self.runner.send_message({
                "event": "requestFakeClick",
                "payload": {
                    "origin_key": context,
                    "target_action_id": final_target_id
                }
            })
        
        # 모든 액션이 끝나면 상태 토글 (1 -> 2 -> 1)
        self.toggle_states[context] = 2 if current_state == 1 else 1