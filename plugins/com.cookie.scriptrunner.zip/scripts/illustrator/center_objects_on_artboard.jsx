#target illustrator

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else if (app.activeDocument.selection.length === 0) {
    alert("선택된 오브젝트가 없습니다.");
} else {
    var doc = app.activeDocument;
    var bounds = doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect;
    var centerX = (bounds[0] + bounds[2]) / 2;
    var centerY = (bounds[1] + bounds[3]) / 2;
    var moved = 0;
    var skipped = 0;

    for (var i = 0; i < doc.selection.length; i++) {
        var item = doc.selection[i];
        try {
            if (item.locked || item.hidden) throw new Error();
            var itemBounds = item.visibleBounds;
            item.translate(
                centerX - (itemBounds[0] + itemBounds[2]) / 2,
                centerY - (itemBounds[1] + itemBounds[3]) / 2
            );
            moved++;
        } catch (e) {
            skipped++;
        }
    }
    if (skipped > 0) alert(moved + "개 중앙 이동 완료, " + skipped + "개 건너뜀.");
}
