#target photoshop

var prefix = "Layer_"; // 원하는 접두어
var startNum = 1;

function getSelectedLayerIndices() {
    var selectedLayers = [];
    var ref = new ActionReference();
    ref.putProperty(stringIDToTypeID("property"), stringIDToTypeID("targetLayers"));
    ref.putEnumerated(stringIDToTypeID("document"), stringIDToTypeID("ordinal"), stringIDToTypeID("targetEnum"));
    try {
        var desc = executeActionGet(ref);
        if (desc.hasKey(stringIDToTypeID("targetLayers"))) {
            var selLayers = desc.getList(stringIDToTypeID("targetLayers"));
            for (var i = 0; i < selLayers.count; i++) {
                var idx = selLayers.getReference(i).getIndex();
                selectedLayers.push(idx);
            }
        }
    } catch (e) {
        alert("선택된 레이어가 없습니다.");
    }
    return selectedLayers;
}

function setLayerNameByIndex(idx, name) {
    try {
        var ref = new ActionReference();
        ref.putIndex(charIDToTypeID("Lyr "), idx);
        var desc = new ActionDescriptor();
        var nameDesc = new ActionDescriptor();
        nameDesc.putString(charIDToTypeID("Nm  "), name);
        desc.putReference(charIDToTypeID("null"), ref);
        desc.putObject(charIDToTypeID("T   "), charIDToTypeID("Lyr "), nameDesc);
        executeAction(charIDToTypeID("setd"), desc, DialogModes.NO);
        return true;
    } catch (e) {
        return false;
    }
}

function renameSelectedLayers() {
    if (app.documents.length === 0) {
        alert("열린 문서가 없습니다.");
        return;
    }

    var indices = getSelectedLayerIndices();
    if (!indices || indices.length === 0) {
        try {
            indices = [app.activeDocument.activeLayer.itemIndex];
        } catch (e) {
            alert("선택된 레이어가 없습니다.");
            return;
        }
    }

    // Photoshop의 레이어 인덱스는 위쪽이 숫자가 큼 → 내림차순 정렬해야 위에서 아래로 순서가 맞음
    indices.sort(function(a, b) { return b - a });

    var renamed = 0;
    for (var i = 0; i < indices.length; i++) {
        if (setLayerNameByIndex(indices[i], prefix + (startNum + renamed))) {
            renamed++;
        }
    }

    var skipped = indices.length - renamed;
    alert(renamed + "개 레이어 이름 변경 완료" + (skipped ? ", " + skipped + "개 건너뜀." : "."));
}

renameSelectedLayers();
