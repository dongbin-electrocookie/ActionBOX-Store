import asyncio
import platform

try:
    import keyboard
    keyboard_available = True
except ImportError:
    print("[Meet Plugin] 'keyboard' 라이브러리가 없습니다.")
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # Google Meet 웹 브라우저 단축키 풀세트 매핑
        self.action_map = {
            "toggle_mic": "ctrl+d",
            "toggle_cam": "ctrl+e",
            "toggle_hand": "ctrl+alt+h",
            "toggle_chat": "ctrl+alt+c",
            "toggle_participants": "ctrl+alt+p",
            "toggle_cc": "c",
            "toggle_fullscreen": "f",
            "leave_meeting": "ctrl+w"  # 탭 닫기 신공!
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("meet_action")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)