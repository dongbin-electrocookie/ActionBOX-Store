#target illustrator

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else if (app.activeDocument.selection.length === 0) {
    alert("선택된 오브젝트가 없습니다.");
} else {
    var selection = app.activeDocument.selection;
    var rotated = 0;
    var skipped = 0;
    for (var i = 0; i < selection.length; i++) {
        try {
            if (selection[i].locked || selection[i].hidden) throw new Error();
            selection[i].rotate(-45);
            rotated++;
        } catch (e) {
            skipped++;
        }
    }
    if (skipped > 0) alert(rotated + "개 회전 완료, " + skipped + "개 건너뜀.");
}
