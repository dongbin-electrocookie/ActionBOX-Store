import asyncio
import base64
import hashlib
import json
import os
import sys
import time
import traceback
from typing import Any, Dict, Optional, Tuple

import websockets


class PRISMPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.prism"
        self.cd_uri = "ws://localhost:8765"
        self.cd_ws = None
        self.obs_ws = None
        self.obs_connected = False

        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_file = os.path.join(self.plugin_dir, "prism_config.json")
        self.desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")

        self.last_valid_settings: Dict[str, Dict[str, Any]] = {}
        self.pending_requests: Dict[str, asyncio.Future] = {}
        self.config = {"ip": "localhost", "port": 4455, "password": ""}
        self.load_config()

    def log(self, message: str):
        line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}"
        try:
            print(line, flush=True)
        except Exception:
            pass

    def load_config(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    self.config.update(json.load(f))
            except Exception as e:
                self.log(f"[PRISM] Config load error: {e}")

    def save_config(self):
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            self.log(f"[PRISM] Save config error: {e}")

    def is_obs_connected(self) -> bool:
        return self.obs_ws is not None and self.obs_connected

    # ★ 1. PRISM이 켜졌을 때 열려있는 UI 창에 목록을 자동으로 쏴주는 방송(Broadcast) 함수 추가
    async def broadcast_lists_to_ui(self):
        try:
            res_scenes = await self.send_to_obs("GetSceneList", allow_failure=True)
            scenes = self._response_data(res_scenes).get("scenes", [])
            
            res_inputs = await self.send_to_obs("GetInputList", allow_failure=True)
            inputs = self._response_data(res_inputs).get("inputs", [])
            
            res_transitions = await self.send_to_obs("GetSceneTransitionList", allow_failure=True)
            transitions = self._response_data(res_transitions).get("transitions", [])

            for ctx in list(self.last_valid_settings.keys()):
                await self.send_to_pi(ctx, {"command": "sceneList", "scenes": scenes})
                await self.send_to_pi(ctx, {"command": "inputList", "inputs": inputs})
                await self.send_to_pi(ctx, {"command": "transitionList", "transitions": transitions})
                
            self.log("[PRISM] Auto-Refreshed UI Lists for all open instances.")
        except Exception as e:
            self.log(f"[PRISM] Broadcast error: {e}")

    async def connect_to_obs(self):
        while True:
            try:
                if self.obs_ws is not None:
                    try:
                        await self.obs_ws.close()
                    except Exception:
                        pass
                self.obs_ws = None
                self.obs_connected = False

                obs_uri = f"ws://{self.config.get('ip', 'localhost')}:{self.config.get('port', 4455)}"
                self.log(f"[PRISM] Connecting to {obs_uri}...")

                async with websockets.connect(obs_uri) as ws:
                    self.obs_ws = ws

                    hello_msg = json.loads(await ws.recv())
                    if hello_msg.get("op") != 0:
                        raise RuntimeError(f"Unexpected hello packet: {hello_msg}")

                    auth_data = hello_msg.get("d", {}).get("authentication")
                    identify_payload = {
                        "op": 1,
                        "d": {
                            "rpcVersion": 1,
                            "eventSubscriptions": 0,
                        },
                    }

                    if auth_data:
                        password = self.config.get("password", "")
                        if not password:
                            raise RuntimeError("PRISM requires a password but prism_config.json password is empty")

                        secret = base64.b64encode(
                            hashlib.sha256((password + auth_data["salt"]).encode("utf-8")).digest()
                        ).decode("utf-8")
                        auth_response = base64.b64encode(
                            hashlib.sha256((secret + auth_data["challenge"]).encode("utf-8")).digest()
                        ).decode("utf-8")
                        identify_payload["d"]["authentication"] = auth_response

                    await ws.send(json.dumps(identify_payload))
                    identified_msg = json.loads(await ws.recv())
                    if identified_msg.get("op") != 2:
                        raise RuntimeError(f"PRISM identify/auth failed: {identified_msg}")

                    self.obs_connected = True
                    self.log("[PRISM] Connected and authenticated")

                    # ★ 2. PRISM 연결 성공 직후, UI 자동 새로고침 실행!
                    asyncio.create_task(self.broadcast_lists_to_ui())

                    async for raw in ws:
                        try:
                            msg = json.loads(raw)
                        except Exception:
                            continue

                        if msg.get("op") == 7:
                            req_id = msg.get("d", {}).get("requestId")
                            fut = self.pending_requests.get(req_id)
                            if fut and not fut.done():
                                fut.set_result(msg)

            except Exception as e:
                self.log(f"[PRISM] Connection error: {e}")

            finally:
                self.obs_connected = False
                self.obs_ws = None
                for _, fut in list(self.pending_requests.items()):
                    if not fut.done():
                        fut.cancel()
                self.pending_requests.clear()

            await asyncio.sleep(5)

    async def send_to_obs(
        self,
        request_type: str,
        request_data: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
        *,
        allow_failure: bool = False,
    ) -> Optional[Dict[str, Any]]:
        if not self.is_obs_connected():
            self.log(f"[PRISM] Not connected. Cannot send {request_type}")
            return None

        if request_data is None:
            request_data = {}
        if request_id is None:
            request_id = f"{request_type}-{time.time()}"

        payload = {
            "op": 6,
            "d": {
                "requestType": request_type,
                "requestId": request_id,
                "requestData": request_data,
            },
        }

        future = asyncio.get_running_loop().create_future()
        self.pending_requests[request_id] = future

        try:
            await self.obs_ws.send(json.dumps(payload))
            response = await asyncio.wait_for(future, timeout=4.0)

            status = response.get("d", {}).get("requestStatus", {})
            result = status.get("result", False)
            comment = status.get("comment", "")
            code = status.get("code")

            if not result and not allow_failure:
                self.log(f"[PRISM] Request failed: {request_type} code={code} comment={comment!r} data={request_data}")

            return response

        except asyncio.TimeoutError:
            self.log(f"[PRISM] Request timeout: {request_type}")
            return None

        except asyncio.CancelledError:
            self.log(f"[PRISM] Request cancelled: {request_type}")
            return None

        except Exception as e:
            self.log(f"[PRISM] Send error for {request_type}: {e}")
            self.obs_connected = False
            return None

        finally:
            self.pending_requests.pop(request_id, None)

    def _response_ok(self, response: Optional[Dict[str, Any]]) -> bool:
        return bool(response and response.get("d", {}).get("requestStatus", {}).get("result", False))

    def _response_data(self, response: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        if not response:
            return {}
        return response.get("d", {}).get("responseData", {}) or {}

    async def connect_to_cookiedeck(self):
        while True:
            try:
                self.log(f"[PRISM Plugin] Connecting to CookieDeck at {self.cd_uri}...")
                async with websockets.connect(self.cd_uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    self.log("[PRISM Plugin] Registered to CookieDeck")

                    async for raw in ws:
                        data = json.loads(raw)
                        await self.handle_message(data)

            except Exception as e:
                self.log(f"[PRISM Plugin] Disconnected from CookieDeck: {e}")

            finally:
                self.cd_ws = None

            await asyncio.sleep(3)

    async def send_to_pi(self, context: str, payload: Dict[str, Any]):
        if not self.cd_ws or not context:
            return
        try:
            await self.cd_ws.send(json.dumps({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": payload,
            }))
        except Exception as e:
            self.log(f"[PRISM Plugin] Failed to sendToPropertyInspector: {e}")

    async def handle_message(self, data: Dict[str, Any]):
        try:
            event = data.get("event")
            context = data.get("context")
            payload = data.get("payload", {}) or {}

            if event == "keyDidAppear":
                settings = payload.get("settings", {}) or {}
                if context and settings:
                    self.last_valid_settings[context] = settings
                    self.log(f"[PRISM] Settings primed for {context}")
                return

            if event == "didReceiveSettings":
                settings = payload.get("settings", payload) or {}
                if context and settings:
                    self.last_valid_settings.setdefault(context, {}).update(settings)
                    self.log(f"[PRISM] Settings cached for {context}: {settings}")
                return

            if event == "keyDown":
                await self.on_key_down(data)
                return

            if event == "sendToPlugin":
                command = payload.get("command")
                if not command and isinstance(payload.get("payload"), dict):
                    payload = payload["payload"]
                    command = payload.get("command")

                if command == "getPrismSettings":
                    await self.send_to_pi(context, {"command": "prismSettings", "settings": self.config})

                elif command == "setPrismSettings":
                    new_settings = payload.get("settings", {}) or {}
                    self.config.update(new_settings)
                    self.save_config()
                    self.log("[PRISM] Config updated. PRISM will reconnect automatically.")

                    try:
                        if self.obs_ws is not None:
                            await self.obs_ws.close()
                    except Exception:
                        pass

                    if self.cd_ws and context:
                        await self.cd_ws.send(json.dumps({"event": "closeSettings", "key": context}))

                elif command == "getSceneList":
                    res = await self.send_to_obs("GetSceneList", allow_failure=True)
                    await self.send_to_pi(context, {
                        "command": "sceneList",
                        "scenes": self._response_data(res).get("scenes", [])
                    })

                elif command == "getInputList":
                    res = await self.send_to_obs("GetInputList", allow_failure=True)
                    await self.send_to_pi(context, {
                        "command": "inputList",
                        "inputs": self._response_data(res).get("inputs", [])
                    })

                elif command == "getTransitionList":
                    res = await self.send_to_obs("GetSceneTransitionList", allow_failure=True)
                    await self.send_to_pi(context, {
                        "command": "transitionList",
                        "transitions": self._response_data(res).get("transitions", [])
                    })

                return

        except Exception as e:
            self.log(f"[PRISM Plugin] Message handling error: {e}")
            self.log(traceback.format_exc())

    async def ensure_settings(self, context: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        incoming_settings = payload.get("settings", {}) if isinstance(payload, dict) else {}
        if incoming_settings:
            self.last_valid_settings[context] = incoming_settings

        settings = self.last_valid_settings.get(context, {})
        if settings:
            return settings

        if self.cd_ws and context:
            self.log(f"[PRISM] Missing settings for {context}. Requesting from engine...")
            await self.cd_ws.send(json.dumps({"event": "getSettings", "context": context}))
            for _ in range(15):
                await asyncio.sleep(0.1)
                settings = self.last_valid_settings.get(context, {})
                if settings:
                    break

        return settings

    async def toggle_studio_mode(self) -> bool:
        state_res = await self.send_to_obs("GetStudioModeEnabled")
        if not self._response_ok(state_res):
            return False

        enabled = bool(self._response_data(state_res).get("studioModeEnabled", False))
        set_res = await self.send_to_obs("SetStudioModeEnabled", {"studioModeEnabled": not enabled})
        return self._response_ok(set_res)

    async def toggle_scene_item(self, scene_name: str, source_name: str) -> bool:
        item_res = await self.send_to_obs("GetSceneItemId", {
            "sceneName": scene_name,
            "sourceName": source_name
        })
        if not self._response_ok(item_res):
            return False

        scene_item_id = self._response_data(item_res).get("sceneItemId")
        if scene_item_id is None:
            self.log(f"[PRISM] Scene item not found: scene={scene_name!r}, source={source_name!r}")
            return False

        enabled_res = await self.send_to_obs("GetSceneItemEnabled", {
            "sceneName": scene_name,
            "sceneItemId": scene_item_id
        })
        if not self._response_ok(enabled_res):
            return False

        current = bool(self._response_data(enabled_res).get("sceneItemEnabled", False))
        set_res = await self.send_to_obs("SetSceneItemEnabled", {
            "sceneName": scene_name,
            "sceneItemId": scene_item_id,
            "sceneItemEnabled": not current,
        })
        return self._response_ok(set_res)

    async def media_play_pause(self, input_name: str) -> bool:
        status_res = await self.send_to_obs("GetMediaInputStatus", {"inputName": input_name})
        if not self._response_ok(status_res):
            return False

        media_state = self._response_data(status_res).get("mediaState")
        if media_state in (
            "OBS_MEDIA_STATE_PLAYING",
            "OBS_MEDIA_STATE_OPENING",
            "OBS_MEDIA_STATE_BUFFERING",
        ):
            action = "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_PAUSE"
        else:
            action = "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_PLAY"

        act_res = await self.send_to_obs("TriggerMediaInputAction", {
            "inputName": input_name,
            "mediaAction": action
        })
        return self._response_ok(act_res)

    async def screenshot_source(self, source_name: str) -> bool:
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"PRISM_{source_name}_{timestamp}.png".replace(" ", "_")
        save_path = os.path.join(self.desktop_path, filename).replace("\\", "/")

        res = await self.send_to_obs("SaveSourceScreenshot", {
            "sourceName": source_name,
            "imageFormat": "png",
            "imageFilePath": save_path,
        })

        if self._response_ok(res):
            self.log(f"[PRISM] Screenshot saved: {save_path}")
            return True
        return False

    async def execute_action(self, obs_action: str, settings: Dict[str, Any], context: str) -> Tuple[bool, str]:
        req_type = None
        req_data: Dict[str, Any] = {}

        if obs_action == "stream_toggle":
            req_type = "ToggleStream"

        elif obs_action == "record_toggle":
            req_type = "ToggleRecord"

        elif obs_action == "virtual_cam_toggle":
            req_type = "ToggleVirtualCam"

        elif obs_action == "replay_buffer_toggle":
            req_type = "ToggleReplayBuffer"

        elif obs_action == "replay_buffer_save":
            req_type = "SaveReplayBuffer"

        elif obs_action == "record_chapter":
            req_type = "CreateRecordChapter"
            req_data = {"chapterName": "CookieDeck Marker"}

        elif obs_action == "stream_marker":
            return False, "stream_marker is not supported in this plugin build"

        elif obs_action == "studio_mode_toggle":
            ok = await self.toggle_studio_mode()
            return ok, "Toggle studio mode"

        elif obs_action == "trigger_transition":
            req_type = "TriggerStudioModeTransition"

        elif obs_action == "set_transition":
            target_transition = settings.get("target_transition")
            if not target_transition:
                return False, "No target transition selected"
            req_type = "SetCurrentSceneTransition"
            req_data = {"transitionName": target_transition}

        elif obs_action == "change_scene":
            target_scene = settings.get("target_scene")
            if not target_scene:
                return False, "No target scene selected"
            req_type = "SetCurrentProgramScene"
            req_data = {"sceneName": target_scene}

        elif obs_action == "toggle_source":
            target = (settings.get("target_name") or "").strip()
            parts = [p.strip() for p in target.split(";", 1)]
            if len(parts) != 2 or not parts[0] or not parts[1]:
                return False, "toggle_source requires 'SceneName;SourceName'"
            ok = await self.toggle_scene_item(parts[0], parts[1])
            return ok, f"Toggle source {parts[1]} in {parts[0]}"

        elif obs_action == "filter_control":
            src = settings.get("target_input")
            flt = settings.get("filter_name")
            state = settings.get("enable_state", "true") == "true"
            if not src or not flt:
                return False, "Filter control requires source and filter name"
            req_type = "SetSourceFilterEnabled"
            req_data = {
                "sourceName": src,
                "filterName": flt,
                "filterEnabled": state
            }

        elif obs_action == "media_play_pause":
            inp = settings.get("target_input")
            if not inp:
                return False, "No media input selected"
            ok = await self.media_play_pause(inp)
            return ok, f"Play/Pause media {inp}"

        elif obs_action == "media_restart":
            inp = settings.get("target_input")
            if not inp:
                return False, "No media input selected"
            req_type = "TriggerMediaInputAction"
            req_data = {
                "inputName": inp,
                "mediaAction": "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_RESTART"
            }

        elif obs_action == "toggle_mute":
            inp = settings.get("target_input")
            if not inp:
                return False, "No input selected"
            req_type = "ToggleInputMute"
            req_data = {"inputName": inp}

        elif obs_action == "screenshot_source":
            src = settings.get("target_input")
            if not src:
                return False, "No source selected"
            ok = await self.screenshot_source(src)
            return ok, f"Screenshot {src}"

        else:
            return False, f"Unsupported action: {obs_action}"

        self.log(f"[PRISM Action] Executing {obs_action} => {req_type} data={req_data}")
        res = await self.send_to_obs(req_type, req_data, request_id=f"{obs_action}-{context}")
        return self._response_ok(res), f"{obs_action} => {req_type}"

    async def on_key_down(self, data: Dict[str, Any]):
        context = data.get("context") or data.get("action")
        if not context:
            self.log("[PRISM] keyDown without context/action")
            return

        settings = await self.ensure_settings(context, data.get("payload", {}) or {})
        obs_action = settings.get("command") or settings.get("prism_action") or settings.get("obs_action")
        if not obs_action:
            self.log(f"[PRISM] No action found for {context}. Ignored.")
            return

        ok, detail = await self.execute_action(obs_action, settings, context)
        if ok:
            self.log(f"[PRISM] Success: {detail}")
        else:
            self.log(f"[PRISM] Failed: {detail}")

    async def start(self):
        asyncio.create_task(self.connect_to_obs())
        await self.connect_to_cookiedeck()


if __name__ == "__main__":
    plugin = PRISMPlugin()
    try:
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(plugin.start())
    except KeyboardInterrupt:
        plugin.log("[PRISM Plugin] Shutting down...")