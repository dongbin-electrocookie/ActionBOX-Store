import asyncio
import winsound # 윈도우 기본 알림음 재생용

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get('UUID', 'com.cookie.pomodoro')
        
        # 버튼별 타이머 상태를 저장하는 딕셔너리
        # 구조: { context: {"task": asyncio_task, "time_left": 1500, "is_running": False, "mode": "work"} }
        self.timers = {}

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")
        payload = data.get("payload", {})
        
        settings = payload.get("settings", {})
        command = payload.get("command")

        # 1. 초기화 (버튼이 화면에 보일 때)
        if event == "keyDidAppear":
            if context not in self.timers:
                self._init_timer_state(context, settings)
            await self._update_display(context)

        # 2. 버튼 클릭 -> 시작 / 일시정지 토글
        elif event == "keyDown":
            state = self.timers.get(context)
            if not state: return
            
            # 토글 로직
            state["is_running"] = not state["is_running"]
            
            if state["is_running"]:
                # 타이머 루프 시작
                if state["task"] is None or state["task"].done():
                    state["task"] = asyncio.create_task(self._timer_loop(context))
            
            await self._update_display(context)

        # 3. 설정 변경 시 타이머 리셋
        elif event == "sendToPlugin" and command == "reset_timer":
            self._init_timer_state(context, settings)
            await self._update_display(context)

    def _init_timer_state(self, context, settings):
        """타이머 상태를 초기화합니다."""
        work_time = int(settings.get("work_time", 25)) * 60
        
        # 기존에 돌던 루프가 있으면 취소
        if context in self.timers and self.timers[context].get("task"):
            self.timers[context]["task"].cancel()
            
        self.timers[context] = {
            "task": None,
            "time_left": work_time,
            "is_running": False,
            "mode": "work", # "work" 또는 "rest"
            "settings": settings
        }

    async def _timer_loop(self, context):
        """1초마다 시간을 깎는 독립된 백그라운드 루프"""
        try:
            while self.timers[context]["is_running"]:
                await asyncio.sleep(1) # 정확히 1초 대기
                
                state = self.timers[context]
                state["time_left"] -= 1

                # 시간이 다 되었을 때
                if state["time_left"] <= 0:
                    await self._handle_time_up(context, state)
                
                # 화면 업데이트
                await self._update_display(context)
                
        except asyncio.CancelledError:
            pass # 루프 강제 취소 시 안전하게 종료

    async def _handle_time_up(self, context, state):
        """시간 종료 시 모드 전환 및 알림"""
        # 띠링~ 소리 재생 (비동기로 실행하여 타이머 안 멈추게 함)
        await asyncio.to_thread(winsound.MessageBeep, winsound.MB_ICONASTERISK, 500)
        
        settings = state["settings"]
        
        # 작업 <-> 휴식 모드 전환
        if state["mode"] == "work":
            state["mode"] = "rest"
            state["time_left"] = int(settings.get("rest_time", 5)) * 60
        else:
            state["mode"] = "work"
            state["time_left"] = int(settings.get("work_time", 25)) * 60
            
        state["is_running"] = False # 시간이 끝나면 일단 일시정지

    async def _update_display(self, context):
        """기기 버튼 화면에 남은 시간을 예쁘게 텍스트로 보냅니다."""
        state = self.timers.get(context)
        if not state: return

        # 분:초 포맷팅
        mins, secs = divmod(state["time_left"], 60)
        time_str = f"{mins:02d}:{secs:02d}"
        
        # 상태에 따른 텍스트 변경 (이모지 완전 제거!)
        mode_text = "WORK" if state["mode"] == "work" else "REST"
        status_text = "Running" if state["is_running"] else "Paused"
        
        # 예: "WORK\n 24:59\n Running"
        display_text = f"[{mode_text}]\n{time_str}\n{status_text}"

        await self.runner.send_message({
            "event": "setTitle",
            "context": context,
            "payload": {"title": display_text}
        })