#include <CoreAudio/CoreAudio.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct {
    _Atomic(float) gain;
    _Atomic(unsigned long long) callbacks;
    _Atomic(float) inputPeak;
    _Atomic(float) outputPeak;
} GainState;

void *mixer_gain_create(void) {
    GainState *state = calloc(1, sizeof(GainState));
    if (state) {
        atomic_init(&state->gain, 1.0f);
        atomic_init(&state->callbacks, 0);
        atomic_init(&state->inputPeak, 0);
        atomic_init(&state->outputPeak, 0);
    }
    return state;
}
void mixer_gain_destroy(void *state) { free(state); }
void mixer_gain_set(void *state, float gain) {
    atomic_store_explicit(&((GainState *)state)->gain, gain, memory_order_relaxed);
}
unsigned long long mixer_callback_count(void *state) {
    return atomic_load_explicit(&((GainState *)state)->callbacks, memory_order_relaxed);
}
float mixer_input_peak(void *state) { return atomic_load_explicit(&((GainState *)state)->inputPeak, memory_order_relaxed); }
float mixer_output_peak(void *state) { return atomic_load_explicit(&((GainState *)state)->outputPeak, memory_order_relaxed); }

/* No allocation, logging, locks, or IPC on the real-time audio thread.
 * The tap follows any hardware input channels in this private aggregate.
 * Only its trailing channels are read; microphone buffers are never read.
 */
void mixer_process(void *opaque, const AudioBufferList *input,
                   AudioBufferList *output, unsigned int tapChannels) {
    GainState *state = opaque;
    float gain = atomic_load_explicit(&state->gain, memory_order_relaxed);
    atomic_fetch_add_explicit(&state->callbacks, 1, memory_order_relaxed);
    unsigned int inputChannels = 0;
    for (unsigned int i = 0; i < input->mNumberBuffers; ++i)
        inputChannels += input->mBuffers[i].mNumberChannels;
    unsigned int outChannel = 0;
    float inputPeak = 0, outputPeak = 0;
    for (unsigned int o = 0; o < output->mNumberBuffers; ++o) {
        AudioBuffer *out = &output->mBuffers[o];
        if (!out->mData || !out->mNumberChannels) continue;
        memset(out->mData, 0, out->mDataByteSize);
        unsigned int outFrames = out->mDataByteSize / (sizeof(float) * out->mNumberChannels);
        for (unsigned int c = 0; c < out->mNumberChannels; ++c, ++outChannel) {
            if (inputChannels < tapChannels || outChannel >= tapChannels) continue;
            unsigned int wanted = inputChannels - tapChannels + outChannel;
            for (unsigned int i = 0; i < input->mNumberBuffers; ++i) {
                const AudioBuffer *in = &input->mBuffers[i];
                if (wanted >= in->mNumberChannels) { wanted -= in->mNumberChannels; continue; }
                if (!in->mData || !in->mNumberChannels) break;
                unsigned int frames = in->mDataByteSize / (sizeof(float) * in->mNumberChannels);
                if (frames > outFrames) frames = outFrames;
                const float *src = in->mData;
                float *dst = out->mData;
                for (unsigned int f = 0; f < frames; ++f) {
                    float sample = src[f * in->mNumberChannels + wanted];
                    float scaled = sample * gain;
                    dst[f * out->mNumberChannels + c] = scaled;
                    inputPeak = fmaxf(inputPeak, fabsf(sample));
                    outputPeak = fmaxf(outputPeak, fabsf(scaled));
                }
                break;
            }
        }
    }
    atomic_store_explicit(&state->inputPeak, inputPeak, memory_order_relaxed);
    atomic_store_explicit(&state->outputPeak, outputPeak, memory_order_relaxed);
}

/* Explicit --self-test only: planar taps, disabled hardware inputs, mono,
 * mute, and silent extra output channels. Never opens a device. */
int mixer_dsp_self_test(void) {
    GainState *state = mixer_gain_create();
    if (!state) return 0;
    mixer_gain_set(state, 0.5f);
    float physical[] = {0.99f, 0.99f}, left[] = {0.2f, -0.4f}, right[] = {0.8f, -1.0f};
    float output[] = {9, 9, 9, 9};
    struct { UInt32 count; AudioBuffer buffers[3]; } planar = {3, {
        {1, sizeof(physical), physical}, {1, sizeof(left), left}, {1, sizeof(right), right}}};
    AudioBufferList out = {1, {2, sizeof(output), output}};
    mixer_process(state, (AudioBufferList *)&planar, &out, 2);
    int ok = fabsf(output[0] - 0.1f) < 0.0001f && fabsf(output[1] - 0.4f) < 0.0001f
        && fabsf(output[2] + 0.2f) < 0.0001f && fabsf(output[3] + 0.5f) < 0.0001f;
    mixer_gain_set(state, 0);
    mixer_process(state, (AudioBufferList *)&planar, &out, 2);
    for (int i = 0; i < 4; ++i) ok = ok && output[i] == 0;
    float monoOutput[] = {9, 9}, extraOutput[] = {9, 9};
    AudioBufferList mono = {1, {1, sizeof(left), left}};
    struct { UInt32 count; AudioBuffer buffers[2]; } separated = {2, {
        {1, sizeof(monoOutput), monoOutput}, {1, sizeof(extraOutput), extraOutput}}};
    mixer_gain_set(state, 1);
    mixer_process(state, &mono, (AudioBufferList *)&separated, 1);
    ok = ok && monoOutput[0] == left[0] && monoOutput[1] == left[1]
        && extraOutput[0] == 0 && extraOutput[1] == 0;
    mixer_gain_destroy(state);
    return ok;
}

/* Disable hardware input streams on this IOProc. Only the final tap input
 * stream is needed. This mixer does not request or process microphone audio.
 */
OSStatus mixer_enable_tap_input(AudioDeviceID device, AudioDeviceIOProcID proc) {
    AudioObjectPropertyAddress address = {
        kAudioDevicePropertyIOProcStreamUsage, kAudioObjectPropertyScopeInput, 0};
    UInt32 size = 0;
    OSStatus status = AudioObjectGetPropertyDataSize(device, &address, 0, NULL, &size);
    if (status != noErr || size < sizeof(AudioHardwareIOProcStreamUsage)) return status ?: -50;
    AudioHardwareIOProcStreamUsage *usage = calloc(1, size);
    if (!usage) return -108;
    usage->mIOProc = proc;
    status = AudioObjectGetPropertyData(device, &address, 0, NULL, &size, usage);
    if (status == noErr && usage->mNumberStreams) {
        for (UInt32 i = 0; i < usage->mNumberStreams; ++i)
            usage->mStreamIsOn[i] = (i + 1 == usage->mNumberStreams);
        usage->mIOProc = proc;
        status = AudioObjectSetPropertyData(device, &address, 0, NULL, size, usage);
    }
    free(usage);
    return status;
}
