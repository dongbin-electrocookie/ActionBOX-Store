import asyncio
import websockets
import json
import platform

class XSplitPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.xsplit"
        self.cd_uri = "ws://localhost:8765"
        self.cd_ws = None
        
        self.xs_ws = None
        self.is_connected = False
        self.xs_ports = [55511, 55512, 55513]
        
        self.req_id = 0
        self.pending_requests = {}
        self.xsplit_task = None

        # 🚀 [대통합 표준] 버튼별(context) 설정을 기억하기 위한 저장소
        # 멀티액션 시 누락되는 장면/소스/출력 ID를 여기서 복구합니다.
        self.last_valid_settings = {}

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.cd_uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    print(f"[{self.PLUGIN_UUID}] CookieDeck 등록 완료.")
                    
                    if not self.xsplit_task:
                        self.xsplit_task = asyncio.create_task(self.xsplit_reconnect_loop())
                        
                    await self.listen_cookiedeck()
            except Exception:
                await asyncio.sleep(3)

    async def listen_cookiedeck(self):
        async for message in self.cd_ws:
            try:
                data = json.loads(message)
                event = data.get("event")
                context = data.get("context")
                payload = data.get("payload", {})

                # 🚀 버튼이 나타나거나 설정이 바뀌면 메모리 업데이트
                if event in ["keyDidAppear", "didReceiveSettings"]:
                    settings = payload.get("settings", {}) if event == "keyDidAppear" else payload
                    if settings:
                        if context not in self.last_valid_settings:
                            self.last_valid_settings[context] = {}
                        # 값이 있는 설정만 필터링하여 캐시
                        self.last_valid_settings[context].update({k: v for k, v in settings.items() if v})

                elif event == "keyDown":
                    await self.on_key_down(data)
                elif event == "sendToPlugin":
                    await self.on_pi_request(data.get("payload", {}), context)
            except Exception:
                pass

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {})
        
        # 🚀 1. 메모리와 현재 데이터를 합칩니다 (멀티액션 대응 핵심)
        saved = self.last_valid_settings.get(context, {})
        final_settings = {**saved, **incoming_settings}
        
        # 🚀 2. [표준화] 'command'를 우선 확인하고, 없으면 기존 'xs_action'을 사용합니다.
        action = final_settings.get("command") or final_settings.get("xs_action", "toggle_mic")
        
        # --- XSplit API 실행 매핑 ---
        if action == "set_scene" and final_settings.get("target_scene"):
            await self.send_to_xsplit("setActiveScene", {"id": final_settings.get("target_scene")})
            
        elif action == "toggle_source" and final_settings.get("target_scene") and final_settings.get("target_source"):
            await self.send_to_xsplit("toggleSourceState", {
                "sceneId": final_settings.get("target_scene"), 
                "sourceId": final_settings.get("target_source")
            })
            
        elif action == "set_preset" and final_settings.get("target_scene") and final_settings.get("target_preset"):
            await self.send_to_xsplit("setActivePreset", {
                "sceneId": final_settings.get("target_scene"), 
                "presetId": final_settings.get("target_preset")
            })
            
        elif action in ["toggle_output", "toggle_record"] and final_settings.get("target_output"):
            await self.send_to_xsplit("toggleOutputState", {"id": final_settings.get("target_output")})
            
        elif action == "toggle_mic":
            await self.send_to_xsplit("toggleMicrophoneState")
            
        elif action == "toggle_speaker":
            await self.send_to_xsplit("toggleSpeakerState")
            
        elif action == "screenshot":
            await self.send_to_xsplit("doScreenshot")
            
        elif action == "push_to_live":
            await self.send_to_xsplit("doPushToLive")

    # ... (on_pi_request 및 XSplit 통신 로직은 기존과 동일) ...
    async def on_pi_request(self, payload, context):
        command = payload.get("command")
        if command == "getSceneList":
            res = await self.send_to_xsplit("getAllScenes")
            if res:
                scenes = res.get("payload", {}).get("scenes", [])
                await self.cd_ws.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": {"command": "sceneList", "scenes": scenes}}))
        elif command == "getSourceList":
            scene_id = payload.get("sceneId")
            res = await self.send_to_xsplit("getSceneSources", {"sceneId": scene_id})
            if res:
                sources = res.get("payload", {}).get("sources", [])
                await self.cd_ws.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": {"command": "sourceList", "sources": sources}}))
        elif command == "getPresetList":
            scene_id = payload.get("sceneId")
            res = await self.send_to_xsplit("getScenePresets", {"sceneId": scene_id})
            if res:
                presets = res.get("payload", {}).get("presets", [])
                await self.cd_ws.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": {"command": "presetList", "presets": presets}}))
        elif command == "getOutputList":
            res = await self.send_to_xsplit("getAllOutputs")
            if res:
                outputs = res.get("payload", {}).get("outputs", [])
                await self.cd_ws.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": {"command": "outputList", "outputs": outputs}}))

    async def xsplit_reconnect_loop(self):
        while True:
            for port in self.xs_ports:
                if self.is_connected: break
                try:
                    url = f"ws://127.0.0.1:{port}"
                    async with websockets.connect(url, open_timeout=1) as ws:
                        print(f"[{self.PLUGIN_UUID}] ✅ XSplit 연결됨 ({url})")
                        self.xs_ws = ws
                        self.is_connected = True
                        await self.listen_xsplit(ws)
                except Exception: pass
            self.is_connected = False
            await asyncio.sleep(2)

    async def listen_xsplit(self, ws):
        try:
            async for message in ws:
                data = json.loads(message)
                async_id = data.get("asyncId")
                if async_id in self.pending_requests:
                    self.pending_requests[async_id].set_result(data)
        except websockets.ConnectionClosed:
            print(f"[{self.PLUGIN_UUID}] ❌ XSplit 연결 끊김.")

    async def send_to_xsplit(self, event, payload=None):
        if not self.is_connected or not self.xs_ws: return None
        self.req_id += 1
        req_id = self.req_id
        msg = {"asyncId": req_id, "event": event}
        if payload: msg["payload"] = payload
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        self.pending_requests[req_id] = future
        try:
            await self.xs_ws.send(json.dumps(msg))
            return await asyncio.wait_for(future, timeout=2.0)
        except Exception: return None
        finally:
            if req_id in self.pending_requests: del self.pending_requests[req_id]

async def main():
    plugin = XSplitPlugin()
    await plugin.connect()

if __name__ == "__main__":
    asyncio.run(main())