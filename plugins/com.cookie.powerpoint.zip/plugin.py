import asyncio
import platform

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 파워포인트 발표 및 편집용 핵심 단축키 맵
        self.action_map = {
            # 1. 슬라이드 쇼 제어 (프리젠터 모드)
            "show_start": "f5",
            "show_current": "shift+f5",
            "show_next": "space",       # 다음 장으로 (엔터나 스페이스, 오른쪽 화살표)
            "show_prev": "left",        # 이전 장으로 (백스페이스나 왼쪽 화살표)
            "show_end": "esc",          # 쇼 종료
            "show_black": "b",          # 화면 임시로 까맣게 (Black)
            "show_white": "w",          # 화면 임시로 하얗게 (White)
            "show_laser": "ctrl+l",     # 레이저 포인터 (최신 PPT 지원)
            "show_pen": "ctrl+p",       # 화면에 그리는 펜 도구
            "show_eraser": "ctrl+e",    # 지우개 도구
            "show_arrow": "ctrl+a",     # 다시 기본 마우스 커서로

            # 2. 슬라이드 편집 노가다 방지
            "edit_new_slide": "ctrl+m",
            "edit_duplicate": "ctrl+d", # 복사는 Ctrl+C보다 D가 훨씬 편합니다
            "edit_undo": "ctrl+z",
            "edit_redo": "ctrl+y",

            # 3. 객체 및 서식
            "format_copy": "ctrl+shift+c",
            "format_paste": "ctrl+shift+v",
            "format_group": "ctrl+g",
            "format_ungroup": "ctrl+shift+g",
            "font_bold": "ctrl+b",
            "font_italic": "ctrl+i",

            # 4. 파일
            "file_save": "ctrl+s",
            "file_save_as": "f12"
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("ppt_action", "show_next")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)