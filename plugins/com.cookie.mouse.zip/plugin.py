import asyncio
import threading
from pynput.mouse import Button, Controller

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.mouse = Controller()
        
        # [상태 관리] 드래그 중인지 여부 저장
        self.is_dragging = False
        
        # [설정] 이동 속도
        self.NORMAL_STEP = 10
        self.SLOW_STEP = 1
        self.SCROLL_STEP = 2

        # 액션 매핑
        self.action_map = {
            # 클릭
            "click_left": lambda: self.mouse.click(Button.left, 1),
            "click_right": lambda: self.mouse.click(Button.right, 1),
            "click_middle": lambda: self.mouse.click(Button.middle, 1),
            "click_back": lambda: self.mouse.click(Button.x1, 1),
            "click_forward": lambda: self.mouse.click(Button.x2, 1),
            "double_click": lambda: self.mouse.click(Button.left, 2),
            
            # [신규] 드래그 토글 (별도 함수 연결)
            "toggle_drag": self.handle_drag_toggle,

            # 세로 스크롤 (dx=0, dy)
            "scroll_up": lambda: self.mouse.scroll(0, self.SCROLL_STEP),
            "scroll_down": lambda: self.mouse.scroll(0, -self.SCROLL_STEP),
            
            # [신규] 가로 스크롤 (dx, dy=0)
            "scroll_left": lambda: self.mouse.scroll(-self.SCROLL_STEP, 0),
            "scroll_right": lambda: self.mouse.scroll(self.SCROLL_STEP, 0),
            
            # 커서 이동 (10px)
            "move_up": lambda: self.mouse.move(0, -self.NORMAL_STEP),
            "move_down": lambda: self.mouse.move(0, self.NORMAL_STEP),
            "move_left": lambda: self.mouse.move(-self.NORMAL_STEP, 0),
            "move_right": lambda: self.mouse.move(self.NORMAL_STEP, 0),

            # 커서 이동 (1px)
            "move_up_slow": lambda: self.mouse.move(0, -self.SLOW_STEP),
            "move_down_slow": lambda: self.mouse.move(0, self.SLOW_STEP),
            "move_left_slow": lambda: self.mouse.move(-self.SLOW_STEP, 0),
            "move_right_slow": lambda: self.mouse.move(self.SLOW_STEP, 0),
        }

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("mouse_action")

        if selected_action:
            action_func = self.action_map.get(selected_action)
            if action_func:
                await asyncio.to_thread(action_func)

    # [신규 로직] 드래그 토글 함수
    def handle_drag_toggle(self):
        if self.is_dragging:
            # 이미 잡고 있으면 -> 놓는다 (Release)
            self.mouse.release(Button.left)
            self.is_dragging = False
            print(f"[{self.uuid}] Drag Released")
        else:
            # 안 잡고 있으면 -> 잡는다 (Press)
            self.mouse.press(Button.left)
            self.is_dragging = True
            print(f"[{self.uuid}] Drag Started")