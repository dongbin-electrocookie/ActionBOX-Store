import asyncio
import websockets
import json
import subprocess
import os
import keyboard
import time

class DevToolsPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.devtools"
        self.uri = "ws://localhost:8765"
        self.websocket = None

    async def connect(self):
        while True:
            try:
                # CookieDeck 웹소켓에 접속
                async with websockets.connect(self.uri) as websocket:
                    self.websocket = websocket
                    await self.register()
                    await self.listen()
            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] Connection failed: {e}. Retrying in 5s...")
                await asyncio.sleep(5)

    async def register(self):
        # 나 여기 왔어요! 하고 등록
        await self.websocket.send(json.dumps({
            "event": "register", 
            "uuid": self.PLUGIN_UUID
        }))
        print(f"[{self.PLUGIN_UUID}] Registered.")

    async def listen(self):
        async for message in self.websocket:
            try:
                data = json.loads(message)
                event = data.get("event")
                
                # 버튼을 눌렀을 때
                if event == "keyDown":
                    await self.on_key_down(data)
                
                # 설정창(PI)에서 데이터 요청이 왔을 때 (폴더 선택 등)
                elif event == "sendToPlugin":
                    await self.on_pi_request(data)

            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] Error: {e}")

    async def on_key_down(self, data):
        action_id = data.get("action")
        settings = data.get("payload", {}).get("settings", {})

        # 1. 단축키 액션
        if action_id == "com.cookie.devtools.hotkey":
            keys = settings.get("keys")
            if keys:
                print(f"[Hotkey] {keys}")
                await asyncio.sleep(0.05) # 씹힘 방지
                keyboard.send(keys)

        # 2. Git 액션
        elif action_id == "com.cookie.devtools.git":
            command = settings.get("git_command")
            project_path = settings.get("project_path")
            
            if command and project_path:
                if os.path.exists(project_path):
                    # 블로킹 방지를 위해 스레드로 실행
                    await asyncio.to_thread(self.run_git, command, project_path)
                else:
                    print(f"[Git Error] Path not found: {project_path}")

    async def on_pi_request(self, data):
        # 설정창에서 폴더/파일 선택 요청 등 처리할 게 있다면 여기서
        pass

    def run_git(self, command, cwd):
        try:
            print(f"[Git] Running '{command}' in '{cwd}'")
            startupinfo = None
            if os.name == 'nt':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

            full_cmd = ["git"] + command.split()
            result = subprocess.run(
                full_cmd, cwd=cwd, capture_output=True, text=True,
                startupinfo=startupinfo
            )
            
            if result.returncode == 0:
                print(f"[Git Success] {result.stdout.strip()}")
            else:
                print(f"[Git Error] {result.stderr.strip()}")
        except Exception as e:
            print(f"[Git Exception] {e}")

# 독립 실행을 위한 메인 루프
if __name__ == "__main__":
    plugin = DevToolsPlugin()
    try:
        asyncio.run(plugin.connect())
    except KeyboardInterrupt:
        pass