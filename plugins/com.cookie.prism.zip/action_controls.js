// Shared OBS-compatible inspector behaviour. Keep the PRISM copy identical so
// either plugin remains independently installable without the other plugin.
(() => {
    const baseUpdate = updateUI, baseSave = saveSettings, baseConnect = connectCookieDeckSocket;
    let inputs = [], audio = [], sceneItems = [], itemScene = '', filters = [];
    let capabilities = null, result = null;
    const el = id => document.getElementById(id);
    const action = () => el('obs-action').value;
    const text = key => langData[key] || key;
    const send = (command, payload = {}) => {
        if (websocket?.readyState === WebSocket.OPEN) websocket.send(JSON.stringify({
            event: 'sendToPlugin', context: key, payload: {command, ...payload}
        }));
    };
    const required = {
        stream_toggle: ['ToggleStream'], record_toggle: ['ToggleRecord'],
        virtual_cam_toggle: ['ToggleVirtualCam'], replay_buffer_toggle: ['ToggleReplayBuffer'],
        replay_buffer_save: ['SaveReplayBuffer'], record_chapter: ['GetRecordStatus', 'CreateRecordChapter'],
        studio_mode_toggle: ['GetStudioModeEnabled', 'SetStudioModeEnabled'],
        trigger_transition: ['GetStudioModeEnabled', 'TriggerStudioModeTransition'],
        set_transition: ['GetSceneTransitionList', 'SetCurrentSceneTransition'],
        change_scene: ['SetCurrentProgramScene'],
        toggle_source: ['GetSceneItemList', 'GetSceneItemEnabled', 'SetSceneItemEnabled'],
        filter_control: ['GetSourceFilterList', 'SetSourceFilterEnabled'],
        media_play_pause: ['GetMediaInputStatus', 'TriggerMediaInputAction'],
        media_restart: ['TriggerMediaInputAction'], toggle_mute: ['GetInputMute', 'ToggleInputMute'],
        screenshot_source: ['GetSourceScreenshot']
    };

    // Loading/empty lists must have a real empty value; never save "No items"
    // as an OBS source, or silently replace a saved source with the first item.
    window.populateSelect = function(id, items, selected, property) {
        const select = el(id);
        select.innerHTML = '';
        const placeholder = document.createElement('option');
        placeholder.value = '';
        placeholder.text = text(items?.length ? 'SELECT_TARGET' : 'LIST_EMPTY');
        placeholder.disabled = true;
        select.add(placeholder);
        for (const item of items || []) {
            const name = typeof item === 'string' ? item : item[property];
            if (typeof name !== 'string' || !name) continue;
            const option = document.createElement('option');
            option.value = name;
            option.text = name;
            if (item.containerName != null) {
                option.dataset.container = item.containerName;
                option.dataset.itemId = String(item.sceneItemId);
                option.text = `${item.containerName} / ${name} [${item.sceneItemId}]`;
            }
            select.add(option);
        }
        if (selected && !Array.from(select.options).some(option => option.value === selected)) {
            const missing = document.createElement('option');
            missing.value = selected;
            missing.text = selected;
            missing.disabled = true;
            select.add(missing);
        }
        select.value = selected || '';
    };

    function showResult() {
        let message = result && result.action === action() ? text(result.code) : '';
        if (action() === 'stream_marker') message = text('ACTION_MARKER_UNSUPPORTED');
        else if (capabilities && !(required[action()] || []).every(name => capabilities.has(name))) {
            message = text('ACTION_UNSUPPORTED');
        }
        if (!message) return;
        el('desc-group').classList.remove('hidden');
        el('desc-text').innerText = message + (result?.action === action() && result.detail ? `\n${result.detail}` : '');
    }

    function renderInputs() {
        let items = inputs;
        if (action() === 'toggle_mute') items = audio;
        if (action() === 'toggle_source') items = itemScene === el('scene-select').value ? sceneItems : [];
        populateSelect('input-select', items, settings.target_input, action() === 'toggle_source' ? 'sourceName' : 'inputName');
        if (action() === 'toggle_source' && settings.target_scene_item_id != null) {
            const index = Array.from(el('input-select').options).findIndex(option =>
                option.value === settings.target_input &&
                option.dataset.itemId === String(settings.target_scene_item_id) &&
                option.dataset.container === settings.target_container);
            if (index >= 0) el('input-select').selectedIndex = index;
            else {
                // A deleted/recreated scene item must not retarget a saved
                // button to the first instance with the same source name.
                const missing = document.createElement('option');
                missing.value = settings.target_input || '';
                missing.dataset.itemId = String(settings.target_scene_item_id);
                missing.dataset.container = settings.target_container || '';
                missing.text = `${missing.dataset.container} / ${missing.value} [${missing.dataset.itemId}]`;
                missing.disabled = true;
                el('input-select').add(missing);
                el('input-select').selectedIndex = el('input-select').options.length - 1;
            }
        }
    }

    function requestTargets() {
        if (action() === 'toggle_mute') send('getAudioList');
        if (action() === 'filter_control' && el('input-select').value) {
            send('getFilterList', {sourceName: el('input-select').value});
        }
        if (action() === 'toggle_source' && el('scene-select').value) {
            send('getSceneItems', {sceneName: el('scene-select').value});
        }
    }

    window.updateUI = function() {
        baseUpdate();
        if (action() === 'toggle_source') {
            el('text-group').classList.add('hidden');
            el('scene-group').classList.remove('hidden');
            el('input-group').classList.remove('hidden');
            el('desc-group').classList.add('hidden');
        }
        renderInputs();
        showResult();
        requestTargets();
    };

    window.saveSettings = function(...args) {
        if (action() === 'toggle_source') {
            const selected = el('input-select').selectedOptions[0];
            settings.target_scene_item_id = selected?.dataset.itemId != null ? Number(selected.dataset.itemId) : null;
            settings.target_container = selected?.dataset.container || '';
            el('text-input').value = `${el('scene-select').value};${el('input-select').value}`;
        } else {
            delete settings.target_scene_item_id;
            delete settings.target_container;
        }
        result = null;
        baseSave(...args);
    };

    window.connectCookieDeckSocket = function() {
        baseConnect();
        const receive = websocket.onmessage;
        websocket.onmessage = async evt => {
            const data = JSON.parse(evt.data);
            if (data.event === 'didReceiveSettings') {
                const value = data.payload || {};
                if (value.enable_state === false || value.enable_state === true) value.enable_state = String(value.enable_state);
                // Migrate legacy "Scene;Source" without saving on restore.
                if ((value.command || value.obs_action) === 'toggle_source' && value.target_scene_item_id == null) {
                    const split = String(value.target_name || '').indexOf(';');
                    if (split >= 0) {
                        value.target_scene = value.target_name.slice(0, split).trim();
                        value.target_input = value.target_name.slice(split + 1).trim();
                    }
                }
                await receive({data: JSON.stringify({...data, payload: value})});
                populateSelect('scene-select', [], settings.target_scene, 'sceneName');
                populateSelect('transition-select', [], settings.target_transition, 'transitionName');
                populateSelect('filter-name', filters, settings.filter_name, 'filterName');
                renderInputs();
                send('getActionCapabilities');
                requestTargets();
                return;
            }
            if (data.event === 'sendToPropertyInspector') {
                const payload = data.payload || {};
                if (payload.command === 'inputList') inputs = payload.inputs || [];
                else if (payload.command === 'audioList') audio = payload.inputs || [];
                else if (payload.command === 'sceneItems' && payload.sceneName === el('scene-select').value) {
                    sceneItems = payload.items || [];
                    itemScene = payload.sceneName;
                } else if (payload.command === 'filterList' && payload.sourceName === el('input-select').value) {
                    filters = payload.filters || [];
                    populateSelect('filter-name', filters, settings.filter_name, 'filterName');
                } else if (payload.command === 'actionCapabilities') {
                    capabilities = Array.isArray(payload.requests) ? new Set(payload.requests) : null;
                    for (const option of el('obs-action').options) {
                        option.disabled = option.value === 'stream_marker' || !!(capabilities &&
                            !(required[option.value] || []).every(name => capabilities.has(name)));
                    }
                    showResult();
                    requestTargets();
                } else if (payload.command === 'actionResult') {
                    result = {action: action(), code: payload.code, detail: payload.detail || ''};
                    showResult();
                }
                await receive(evt);
                if (['inputList', 'audioList', 'sceneItems'].includes(payload.command)) renderInputs();
                if (payload.command === 'sceneList') requestTargets();
                return;
            }
            await receive(evt);
            if (data.event === 'didReceiveGlobalSettings' || data.event === 'applicationDidLaunch') updateUI();
        };
        el('scene-select').onchange = () => {
            if (action() === 'toggle_source') {
                sceneItems = [];
                itemScene = '';
                settings.target_input = '';
                settings.target_scene_item_id = null;
                settings.target_container = '';
                renderInputs();
            }
            saveSettings(false);
            requestTargets();
        };
        el('input-select').onchange = () => {
            if (action() === 'filter_control') {
                filters = [];
                settings.filter_name = '';
                populateSelect('filter-name', [], '', 'filterName');
            }
            saveSettings(false);
            requestTargets();
        };
    };
})();
