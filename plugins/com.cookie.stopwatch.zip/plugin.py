import asyncio
import time

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get('UUID', 'com.cookie.stopwatch')
        
        # 스톱워치 상태 저장소 (last_press 추가)
        self.watches = {}
        
        # 0.1초마다 화면을 갱신하는 루프 시작
        asyncio.create_task(self.update_loop())

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")

        # 1. 화면에 버튼이 보일 때 초기화
        if event == "keyDidAppear":
            if context not in self.watches:
                self.watches[context] = {
                    "is_running": False,
                    "elapsed": 0.0,
                    "last_tick": 0.0,
                    "last_press": 0.0 # ★ 더블 클릭 감지용 시간
                }
            await self._update_display(context)

        # 2. 버튼을 누르는 순간 (`keyDown`만 사용!)
        elif event == "keyDown":
            if context in self.watches:
                watch = self.watches[context]
                now = time.time()
                
                # ★ [더블 클릭 감지] 0.4초 이내에 다시 눌렀다면? -> 초기화 (Reset)
                if now - watch["last_press"] < 0.4:
                    watch["is_running"] = False
                    watch["elapsed"] = 0.0
                    watch["last_press"] = 0.0 # 3번 연타 방지용 리셋
                
                # ★ [일반 클릭] -> 시작 / 일시정지 (Toggle)
                else:
                    watch["is_running"] = not watch["is_running"]
                    if watch["is_running"]:
                        # 시작하는 순간의 시간을 기록
                        watch["last_tick"] = now
                    watch["last_press"] = now # 방금 누른 시간 기록

                await self._update_display(context)

    async def update_loop(self):
        """0.1초마다 돌아가며 실행 중인 스톱워치의 시간을 올립니다."""
        while True:
            for context, watch in list(self.watches.items()):
                if watch["is_running"]:
                    now = time.time()
                    watch["elapsed"] += (now - watch["last_tick"])
                    watch["last_tick"] = now
                    
                    await self._update_display(context)
            
            await asyncio.sleep(0.1)

    async def _update_display(self, context):
        """시간을 MM:SS.d 형태로 포맷팅하여 화면에 전송합니다."""
        watch = self.watches.get(context)
        if not watch: return

        total_seconds = watch["elapsed"]
        
        mins = int(total_seconds // 60)
        secs = int(total_seconds % 60)
        dec = int((total_seconds * 10) % 10)

        time_str = f"{mins:02d}:{secs:02d}.{dec}"
        
        status_text = "[RUN]" if watch["is_running"] else "[STOP]"
        if watch["elapsed"] == 0.0:
            status_text = "[READY]"

        display_text = f"{status_text}\n{time_str}"

        await self.runner.send_message({
            "event": "setTitle",
            "context": context,
            "payload": {"title": display_text}
        })