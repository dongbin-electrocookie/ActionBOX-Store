#target photoshop

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else {
    try {
        var layer = app.activeDocument.activeLayer;
        if (layer.isBackgroundLayer || layer.allLocked) {
            alert("배경 또는 잠긴 레이어는 회전할 수 없습니다.");
        } else {
            layer.rotate(-90, AnchorPosition.MIDDLECENTER);
        }
    } catch (e) {
        alert("회전 오류: " + e.message);
    }
}
