import asyncio
import os
import sys
import time

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False


IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        self.windows_action_map = {
            "togglebold": ["ctrl+b"],
            "applyborder": ["ctrl+shift+7"],
            "formatheader": ["ctrl+b", "ctrl+e", "ctrl+shift+7"],
            "formatnumber": ["ctrl+shift+1"],
            "autofitcolumns": ["alt+h", "o", "i"],
            "pastevalues": ["ctrl+shift+v"],
            "togglefilter": ["ctrl+shift+l"],
            "freezepanes": ["alt+w", "f", "f"],
            "unfreezepanes": ["alt+w", "f", "f"],
            "addsheet": ["shift+f11"],
            "saveaspdf": ["ctrl+p"],
            "reportformat": ["ctrl+b", "ctrl+e", "ctrl+shift+7"],
        }
        self.macos_action_map = {
            "togglebold": ["command+b"],
            "applyborder": ["command+option+0"],
            "formatheader": ["command+b", "command+e", "command+option+0"],
            "formatnumber": ["ctrl+shift+1"],
            "autofitcolumns": ["control+option+h", "o", "i"],
            "pastevalues": ["command+shift+v"],
            "togglefilter": ["ctrl+shift+l"],
            "freezepanes": ["control+option+w", "f", "f"],
            "unfreezepanes": ["control+option+w", "f", "f"],
            "addsheet": ["shift+f11"],
            "saveaspdf": ["command+p"],
            "reportformat": ["command+b", "command+e", "command+option+0"],
        }
        self.action_map = self.macos_action_map if IS_MACOS else self.windows_action_map

        self.icon_map = {
            "togglebold": "STATE_TOGGLEBOLD", "applyborder": "STATE_APPLYBORDER",
            "formatheader": "STATE_FORMATHEADER", "formatnumber": "STATE_FORMATNUMBER",
            "autofitcolumns": "STATE_AUTOFITCOLUMNS", "pastevalues": "STATE_PASTEVALUES",
            "togglefilter": "STATE_TOGGLEFILTER", "freezepanes": "STATE_FREEZEPANES",
            "unfreezepanes": "STATE_UNFREEZEPANES", "addsheet": "STATE_ADDSHEET",
            "saveaspdf": "STATE_SAVEASPDF", "reportformat": "STATE_REPORTFORMAT",
        }

    def _default_settings(self):
        return {
            "excel_action": "togglebold", "command": "togglebold", "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map["togglebold"],
            "default_visuals_initialized": True,
        }

    def _merge_settings(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        return merged

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "togglebold", "STATE_TOGGLEBOLD")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if context and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon", "context": context,
                "payload": {"icon_path": icon_path},
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return
        meaningful = any((settings or {}).get(k) not in ("", None, False) for k in [
            "command", "excel_action", "builtin_icon_name",
            "default_visuals_initialized", "sync_title_on_action_change", "title",
        ])
        if meaningful:
            self.context_settings[context] = self._merge_settings(settings)
            return
        defaults = self._default_settings()
        self.context_settings[context] = defaults.copy()
        await self.runner.send_message({
            "event": "setSettings", "context": context, "payload": defaults,
        })
        await self._send_builtin_icon(context, defaults["command"])

    def _normalize_key(self, key_name):
        key = str(key_name).strip().lower()
        aliases = {
            "control": "ctrl", "option": "option" if IS_MACOS else "alt",
            "command": "command" if IS_MACOS else "win", "return": "enter",
            "escape": "esc",
        }
        return aliases.get(key, key)

    def _send_hotkey_sequence(self, sequence):
        for chord in sequence:
            if IS_WINDOWS and keyboard_available:
                keyboard.send(chord)
            elif pyautogui_available:
                parts = [self._normalize_key(part) for part in chord.split("+") if part.strip()]
                if len(parts) == 1:
                    pyautogui.press(parts[0])
                elif parts:
                    pyautogui.hotkey(*parts)
            else:
                print(f"[{self.uuid}] No keyboard injection library is available.")
                return
            time.sleep(0.06)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}
        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ("willAppear", "keyDidAppear"):
            await self._initialize_default_visuals_if_new(context, settings)
            return
        if event == "didReceiveSettings" and context:
            cached = self.context_settings.get(context, {})
            self.context_settings[context] = self._merge_settings({**cached, **settings})
            return
        if event in ("keyDidDisappear", "willDisappear"):
            self.context_settings.pop(context, None)
            return
        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            action = action_command or settings.get("command") or settings.get("excel_action") or cached.get("command") or "togglebold"
            await self._send_builtin_icon(context, action)
            return
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = self._merge_settings({**cached, **incoming})
        if context:
            self.context_settings[context] = settings
        selected_action = settings.get("command") or settings.get("excel_action") or "togglebold"
        sequence = self.action_map.get(selected_action)
        if sequence:
            await asyncio.to_thread(self._send_hotkey_sequence, sequence)
        else:
            print(f"[{self.uuid}] Unknown action: {selected_action}")
