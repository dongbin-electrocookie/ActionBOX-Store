import asyncio
try:
    import keyboard
except ImportError:
    keyboard = None

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # Fender Studio Pro (Studio One) Windows 기본 단축키 맵
        self.hotkey_map = {
            # Transport
            "play_stop": "space",
            "record": "*",           # Numpad *
            "return_zero": ".",      # Numpad .
            "loop_toggle": "/",      # Numpad /
            "metronome": "c",
            
            # Tools
            "tool_arrow": "1",
            "tool_range": "2",
            "tool_split": "3",
            "tool_eraser": "4",
            "tool_paint": "5",
            "tool_mute": "6",
            "tool_listen": "7",
            
            # Windows / Views
            "view_editor": "f2",
            "view_console": "f3",
            "view_inspector": "f4",
            "view_browser": "f5",
            "view_video": "f6",
            
            # Editing
            "undo": "ctrl+z",
            "redo": "ctrl+y",
            "duplicate": "d",
            "duplicate_shared": "shift+d",
            "split_cursor": "alt+x",
            "merge_events": "g",
            "quantize": "q",
            "quantize_50": "alt+q",
            "mute_events": "m",
            
            # Zoom
            "zoom_in": "e",
            "zoom_out": "w",
            "zoom_in_v": "shift+e",
            "zoom_out_v": "shift+w",
            "zoom_full": "shift+e", # 스튜디오원 특성상 여러번 누르면 전체화면 맞춤
            
            # Track / Marker
            "add_track": "t",
            "add_marker": "y",
            "next_marker": "shift+n",
            "prev_marker": "shift+b"
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard: return

        settings = data.get("payload", {}).get("settings", {})
        action = settings.get("s1_hotkey")

        if action and action in self.hotkey_map:
            hotkey = self.hotkey_map[action]
            
            # 스레드로 키 전송 (버튼 연타 시 UI 멈춤 방지)
            await asyncio.to_thread(keyboard.send, hotkey)
            print(f"[{self.uuid}] S1 Hotkey Sent: {hotkey}")