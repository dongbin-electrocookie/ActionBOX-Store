import asyncio
import websockets
import json
import requests
import os
import webbrowser
import shutil
from datetime import datetime, timedelta
from PIL import Image, ImageDraw, ImageFont
import io
import base64

class GitHubPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.github"
        self.uri = "ws://localhost:8765"
        self.websocket = None
        self.active_buttons = {}
        self.last_states = {}
        self.last_valid_settings = {}

        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_file = os.path.join(self.plugin_dir, 'github_config.json')
        self.cache_dir = os.path.join(self.plugin_dir, "github_cache")

        if os.path.exists(self.cache_dir):
            shutil.rmtree(self.cache_dir)
        os.makedirs(self.cache_dir, exist_ok=True)

        self.token = self.load_token()
        self.username = None

        self.action_icon_map = {
            "com.cookie.github.notifications": "ACTION_NOTIFICATIONS",
            "com.cookie.github.reviews": "ACTION_REVIEWS",
            "com.cookie.github.contributions": "ACTION_CONTRIBUTIONS",
            "com.cookie.github.repo": "ACTION_REPO",
            "com.cookie.github.workflow": "ACTION_WORKFLOW"
        }

        self.i18n = {
            "en": {
                "IMG_NO_TOKEN": "No\nToken",
                "IMG_REVIEWS": "Reviews",
                "IMG_NO_USER": "No\nUser",
                "IMG_COMMITTED": "Done",
                "IMG_DO_IT": "Do It!",
                "IMG_BUILD": "Build",
                "IMG_NO_RUN": "No\nRun",
                "IMG_ERR": "Err"
            },
            "ko": {
                "IMG_NO_TOKEN": "토큰\n없음",
                "IMG_REVIEWS": "리뷰",
                "IMG_NO_USER": "계정\n없음",
                "IMG_COMMITTED": "완료",
                "IMG_DO_IT": "하자!",
                "IMG_BUILD": "빌드",
                "IMG_NO_RUN": "실행\n없음",
                "IMG_ERR": "오류"
            },
            "ja": {
                "IMG_NO_TOKEN": "トークン\nなし",
                "IMG_REVIEWS": "レビュー",
                "IMG_NO_USER": "ユー\nザー",
                "IMG_COMMITTED": "完了",
                "IMG_DO_IT": "やる!",
                "IMG_BUILD": "ビルド",
                "IMG_NO_RUN": "実行\nなし",
                "IMG_ERR": "エラー"
            },
            "de": {
                "IMG_NO_TOKEN": "Kein\nToken",
                "IMG_REVIEWS": "Reviews",
                "IMG_NO_USER": "Kein\nUser",
                "IMG_COMMITTED": "Fertig",
                "IMG_DO_IT": "Los!",
                "IMG_BUILD": "Build",
                "IMG_NO_RUN": "Kein\nRun",
                "IMG_ERR": "Fehler"
            },
            "es": {
                "IMG_NO_TOKEN": "Sin\nToken",
                "IMG_REVIEWS": "Reviews",
                "IMG_NO_USER": "Sin\nUsuario",
                "IMG_COMMITTED": "Hecho",
                "IMG_DO_IT": "¡Hazlo!",
                "IMG_BUILD": "Build",
                "IMG_NO_RUN": "Sin\nRun",
                "IMG_ERR": "Err"
            },
            "fr": {
                "IMG_NO_TOKEN": "Pas de\nToken",
                "IMG_REVIEWS": "Reviews",
                "IMG_NO_USER": "Pas\nd’utilisateur",
                "IMG_COMMITTED": "Fait",
                "IMG_DO_IT": "Vas-y !",
                "IMG_BUILD": "Build",
                "IMG_NO_RUN": "Pas de\nRun",
                "IMG_ERR": "Err"
            },
            "ru": {
                "IMG_NO_TOKEN": "Нет\nтокена",
                "IMG_REVIEWS": "Ревью",
                "IMG_NO_USER": "Нет\nюзера",
                "IMG_COMMITTED": "Готово",
                "IMG_DO_IT": "Сделай!",
                "IMG_BUILD": "Сборка",
                "IMG_NO_RUN": "Нет\nrun",
                "IMG_ERR": "Ошибка"
            },
            "it": {
                "IMG_NO_TOKEN": "Nessun\nToken",
                "IMG_REVIEWS": "Reviews",
                "IMG_NO_USER": "Nessun\nUtente",
                "IMG_COMMITTED": "Fatto",
                "IMG_DO_IT": "Fallo!",
                "IMG_BUILD": "Build",
                "IMG_NO_RUN": "Nessun\nRun",
                "IMG_ERR": "Err"
            },
            "pt-PT": {
                "IMG_NO_TOKEN": "Sem\nToken",
                "IMG_REVIEWS": "Reviews",
                "IMG_NO_USER": "Sem\nUtilizador",
                "IMG_COMMITTED": "Feito",
                "IMG_DO_IT": "Vai!",
                "IMG_BUILD": "Build",
                "IMG_NO_RUN": "Sem\nRun",
                "IMG_ERR": "Erro"
            }
        }

    def _lang(self, settings_or_code):
        if isinstance(settings_or_code, dict):
            code = (settings_or_code.get("_lang") or "en").lower()
        else:
            code = (settings_or_code or "en").lower()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        code = alias.get(code, code)
        return code if code in self.i18n else "en"

    def _t(self, settings_or_code, key):
        lang = self._lang(settings_or_code)
        return self.i18n.get(lang, self.i18n["en"]).get(key, key)

    def _get_builtin_icon_path(self, action_id):
        icon_name = self.action_icon_map.get(action_id, "ACTION_NOTIFICATIONS")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id, page=None):
        if not self.websocket or not context:
            return
        icon_path = self._get_builtin_icon_path(action_id)
        if os.path.exists(icon_path):
            await self.websocket.send(json.dumps({
                "event": "setImage",
                "context": context,
                "payload": {"image": None, "page": page}
            }))
            await self.websocket.send(json.dumps({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            }))

    def _default_settings_for_action(self, action_id):
        return {
            "repo": "",
            "command": "",
            "_lang": "en",
            "sync_title_on_target_change": False,
            "builtin_icon_name": self.action_icon_map.get(action_id, "ACTION_NOTIFICATIONS"),
            "default_visuals_initialized": True
        }

    def _has_meaningful_settings(self, settings):
        settings = settings or {}
        return any([
            bool(settings.get("repo")),
            bool(settings.get("command")),
            bool(settings.get("title")),
            bool(settings.get("builtin_icon_name")),
            bool(settings.get("default_visuals_initialized")),
            settings.get("sync_title_on_target_change", False)
        ])

    def _action_requires_repo(self, action_id):
        return action_id in ["com.cookie.github.repo", "com.cookie.github.workflow"]

    def load_token(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    return json.load(f).get("token", "")
            except Exception:
                pass
        return ""

    def save_token(self, token):
        self.token = token
        self.username = None
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump({"token": token}, f, indent=4)
            asyncio.create_task(self.force_update_all())
        except Exception as e:
            print(f"[GitHub] Save Error: {e}")

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.uri) as websocket:
                    self.websocket = websocket
                    await self.register()
                    await asyncio.to_thread(self.fetch_username)
                    update_task = asyncio.create_task(self.update_loop())
                    await self.listen()
                    update_task.cancel()
            except Exception as e:
                print(f"[GitHub] Connection Retry: {e}")
                await asyncio.sleep(5)

    async def register(self):
        await self.websocket.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))

    async def _initialize_default_visuals_if_new(self, context, action_id, payload):
        settings = (payload or {}).get("settings", {}) if isinstance(payload, dict) else {}
        page = payload.get("page") if isinstance(payload, dict) else None

        if not self._has_meaningful_settings(settings):
            defaults = self._default_settings_for_action(action_id)
            self.last_valid_settings[context] = defaults.copy()
            if self.websocket:
                await self.websocket.send(json.dumps({
                    "event": "setSettings",
                    "context": context,
                    "payload": defaults
                }))
            await self._send_builtin_icon(context, action_id, page)
            return False

        merged = {**self._default_settings_for_action(action_id), **settings}
        self.last_valid_settings[context] = merged
        return True

    async def listen(self):
        async for message in self.websocket:
            try:
                data = json.loads(message)
                event = data.get("event")
                context = data.get("context")
                payload = data.get("payload", {}) or {}

                if event is None and "command" in data:
                    event = "sendToPlugin"
                    payload = data

                if event == "keyDidAppear":
                    data["_target_page"] = payload.get("page")
                    self.active_buttons[context] = data
                    self.last_states.pop(context, None)
                    has_existing_settings = await self._initialize_default_visuals_if_new(context, data.get("action"), payload)
                    if has_existing_settings:
                        await self.update_button(context)

                elif event in ("willDisappear", "keyDidDisappear"):
                    self.active_buttons.pop(context, None)
                    self.last_valid_settings.pop(context, None)
                    self.last_states.pop(context, None)

                elif event == "didReceiveSettings":
                    incoming_settings = payload or {}
                    action_id = self.active_buttons.get(context, {}).get("action", "")
                    base = self._default_settings_for_action(action_id) if action_id else {}
                    if context not in self.last_valid_settings:
                        self.last_valid_settings[context] = {}
                    self.last_valid_settings[context].update(base)
                    self.last_valid_settings[context].update(incoming_settings)

                    if context in self.active_buttons:
                        self.active_buttons[context]["payload"]["settings"] = incoming_settings
                        self.last_states.pop(context, None)
                        await self.update_button(context)

                elif event == "keyDown":
                    await self.handle_click(context, payload.get("settings", {}))

                elif event == "sendToPlugin":
                    command = payload.get("command")
                    if command == "checkTokenStatus":
                        await self.send_pi_message(context, {"command": "tokenStatus", "hasToken": bool(self.token)})
                    elif command == "getGlobalToken":
                        await self.send_pi_message(context, {"command": "globalToken", "token": self.token})
                    elif command == "saveGlobalToken":
                        self.save_token(payload.get("token", ""))
                        await self.send_pi_message(context, {"command": "tokenStatus", "hasToken": True})
                    elif command == "forceUpdate":
                        self.last_states.pop(context, None)
                        await self.update_button(context)
            except Exception as e:
                print(f"[GitHub] Listen Error: {e}")

    async def send_pi_message(self, context, payload):
        if self.websocket:
            await self.websocket.send(json.dumps({"event": "sendToPropertyInspector", "context": context, "payload": payload}))

    def fetch_username(self):
        if not self.token:
            return
        try:
            headers = {"Authorization": f"token {self.token}"}
            resp = requests.get("https://api.github.com/user", headers=headers, timeout=5)
            if resp.status_code == 200:
                self.username = resp.json().get("login")
                print(f"[GitHub] Logged in as: {self.username}")
        except Exception as e:
            print(f"[GitHub] User Fetch Error: {e}")

    async def update_loop(self):
        while True:
            await asyncio.sleep(60)
            await self.force_update_all()

    async def force_update_all(self):
        if not self.username and self.token:
            await asyncio.to_thread(self.fetch_username)
        for ctx in list(self.active_buttons.keys()):
            await self.update_button(ctx)
            await asyncio.sleep(0.3)

    async def update_button(self, context):
        if context not in self.active_buttons:
            return

        btn_data = self.active_buttons[context]
        incoming = btn_data.get("payload", {}).get("settings", {}) or {}
        action_id = btn_data.get("action")
        saved = self.last_valid_settings.get(context, {})
        final_settings = {**self._default_settings_for_action(action_id), **saved, **incoming}
        target_page = btn_data.get("_target_page")
        repo = final_settings.get("command") or final_settings.get("repo")

        if not self.token:
            await self._send_builtin_icon(context, action_id, target_page)
            return

        if self._action_requires_repo(action_id) and not repo:
            await self._send_builtin_icon(context, action_id, target_page)
            return

        headers = {"Authorization": f"token {self.token}", "Accept": "application/vnd.github.v3+json"}
        text_display = "?"
        bg_color = (30, 30, 30)
        is_grass_mode = False
        grass_data = []

        try:
            if action_id == "com.cookie.github.notifications":
                resp = await asyncio.to_thread(requests.get, "https://api.github.com/notifications", headers=headers, timeout=5)
                if resp.status_code == 200:
                    count = len(resp.json())
                    text_display = str(count)
                    bg_color = (200, 50, 50) if count > 0 else (50, 50, 50)

            elif action_id == "com.cookie.github.reviews":
                resp = await asyncio.to_thread(requests.get, "https://api.github.com/search/issues?q=is:pr+is:open+review-requested:@me", headers=headers, timeout=5)
                if resp.status_code == 200:
                    count = resp.json().get("total_count", 0)
                    text_display = f"{self._t(final_settings, 'IMG_REVIEWS')}\n{count}"
                    if count >= 3:
                        bg_color = (200, 50, 50)
                    elif count > 0:
                        bg_color = (200, 100, 0)
                    else:
                        bg_color = (50, 100, 50)

            elif action_id == "com.cookie.github.contributions":
                is_grass_mode = True
                if not self.username:
                    text_display = self._t(final_settings, "IMG_NO_USER")
                else:
                    resp = await asyncio.to_thread(requests.get, f"https://api.github.com/users/{self.username}/events", headers=headers, timeout=5)
                    if resp.status_code == 200:
                        events = resp.json()
                        today = datetime.utcnow().date()
                        last_5_days = [(today - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(4, -1, -1)]
                        commit_status = {day: False for day in last_5_days}
                        for evt in events:
                            if evt.get("created_at", "")[:10] in commit_status and evt.get("type") == "PushEvent":
                                commit_status[evt.get("created_at", "")[:10]] = True
                        grass_data = [commit_status[day] for day in last_5_days]
                        is_today_committed = grass_data[-1]
                        text_display = self._t(final_settings, "IMG_COMMITTED") if is_today_committed else self._t(final_settings, "IMG_DO_IT")
                        bg_color = (40, 100, 40) if is_today_committed else (80, 80, 80)
                    else:
                        text_display = self._t(final_settings, "IMG_ERR")

            elif action_id == "com.cookie.github.repo":
                resp = await asyncio.to_thread(requests.get, f"https://api.github.com/repos/{repo}", headers=headers, timeout=5)
                if resp.status_code == 200:
                    stars = resp.json().get("stargazers_count", 0)
                    stars_str = f"{stars/1000:.1f}k" if stars >= 1000 else str(stars)
                    text_display = f"★\n{stars_str}"
                    bg_color = (40, 40, 180)

            elif action_id == "com.cookie.github.workflow":
                resp = await asyncio.to_thread(requests.get, f"https://api.github.com/repos/{repo}/actions/runs?per_page=1", headers=headers, timeout=5)
                if resp.status_code == 200:
                    runs = resp.json().get("workflow_runs", [])
                    if runs:
                        status = runs[0].get("conclusion")
                        run_status = runs[0].get("status")
                        text_display = self._t(final_settings, "IMG_BUILD")
                        if run_status in ["in_progress", "queued"]:
                            bg_color = (200, 200, 50)
                        elif status == "success":
                            bg_color = (40, 150, 40)
                        elif status == "failure":
                            bg_color = (180, 40, 40)
                    else:
                        text_display = self._t(final_settings, "IMG_NO_RUN")

            grass_tuple = tuple(grass_data) if is_grass_mode else None
            current_state = (text_display, bg_color, grass_tuple)

            if self.last_states.get(context) == current_state:
                return

            self.last_states[context] = current_state

            if is_grass_mode:
                b64_image = await asyncio.to_thread(self.create_grass_image_base64, text_display, bg_color, grass_data)
            else:
                b64_image = await asyncio.to_thread(self.create_image_base64, text_display, bg_color)

            if self.websocket and b64_image:
                await self.websocket.send(json.dumps({
                    "event": "setImage",
                    "context": context,
                    "payload": {"image": b64_image, "page": target_page}
                }))

        except Exception as e:
            print(f"[GitHub API Error] {e}")
            b64_image = await asyncio.to_thread(self.create_image_base64, self._t(final_settings, "IMG_ERR"), (0, 0, 0))
            if self.websocket and b64_image:
                await self.websocket.send(json.dumps({
                    "event": "setImage",
                    "context": context,
                    "payload": {"image": b64_image, "page": target_page}
                }))

    def _font_paths(self, names):
        paths = []
        for name in names:
            paths.append(os.path.join(self.plugin_dir, name))
            paths.append(os.path.join(r"C:\Windows\Fonts", name))
            paths.append(name)
        return paths

    def _load_font(self, names, size):
        for path in self._font_paths(names):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
        return ImageFont.load_default()

    def _multiline_center(self, draw, img, text, font, fill, y):
        try:
            bbox = draw.multiline_textbbox((0, 0), text, font=font, spacing=2, align="center")
            w = bbox[2] - bbox[0]
            draw.multiline_text(((img.width - w) / 2, y), text, font=font, fill=fill, spacing=2, align="center")
        except Exception:
            draw.multiline_text((8, y), text, font=font, fill=fill, spacing=2, align="center")

    def create_image_base64(self, text, color_rgb):
        img = Image.new('RGB', (128, 128), color_rgb)
        draw = ImageDraw.Draw(img)

        font_names = ["malgunbd.ttf", "YuGothB.ttc", "Yu Gothic Bold.ttf", "meiryob.ttc", "msgothic.ttc", "arial.ttf"]
        font = self._load_font(font_names, 28 if len(text) <= 8 else 24)

        self._multiline_center(draw, img, text, font, "white", 42)

        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        return base64.b64encode(buffered.getvalue()).decode('utf-8')

    def create_grass_image_base64(self, text, bg_color, grass_data):
        img = Image.new('RGB', (128, 128), bg_color)
        draw = ImageDraw.Draw(img)

        font_names = ["malgunbd.ttf", "YuGothB.ttc", "Yu Gothic Bold.ttf", "meiryob.ttc", "msgothic.ttc", "arial.ttf"]
        font = self._load_font(font_names, 24 if len(text) <= 6 else 20)

        self._multiline_center(draw, img, text, font, "white", 38)

        box_size = 16
        gap = 6
        start_x = (128 - (5 * box_size + 4 * gap)) / 2
        start_y = 90

        for i, committed in enumerate(grass_data):
            x = start_x + i * (box_size + gap)
            y = start_y
            fill_color = (57, 211, 83) if committed else (22, 27, 34)
            if i == 4 and not committed:
                fill_color = (14, 68, 41)
            outline_color = (200, 200, 200) if i == 4 else (100, 100, 100)
            draw.rectangle([x, y, x + box_size, y + box_size], fill=fill_color, outline=outline_color, width=1)

        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        return base64.b64encode(buffered.getvalue()).decode('utf-8')

    async def handle_click(self, context, incoming_settings):
        data = self.active_buttons.get(context)
        if not data:
            return

        action_id = data.get("action")
        saved = self.last_valid_settings.get(context, {})
        final_settings = {**saved, **incoming_settings}
        repo = final_settings.get("command") or final_settings.get("repo")
        url = "https://github.com/"

        if action_id == "com.cookie.github.notifications":
            url += "notifications"
        elif action_id == "com.cookie.github.reviews":
            url += "pulls/review-requested"
        elif action_id == "com.cookie.github.contributions":
            if self.username:
                url += self.username
        elif repo:
            url += repo
            if action_id == "com.cookie.github.workflow":
                url += "/actions"

        await asyncio.to_thread(webbrowser.open, url)

if __name__ == "__main__":
    plugin = GitHubPlugin()
    try:
        asyncio.run(plugin.connect())
    except KeyboardInterrupt:
        pass
