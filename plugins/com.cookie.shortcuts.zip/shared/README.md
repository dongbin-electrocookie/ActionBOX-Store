# Shared Shortcuts API v1

The mandatory `com.cookie.shortcuts` plugin owns the physical keyboard engine,
key labels, compact editor CSS, and localized custom-shortcut editor. Consumers
reference these files; do not copy them into individual app plugins.

## Integration

- `utility/shortcut_shared.py` loads the core from the real application data
  root (including `~/COMBO-X` on macOS), not the executable directory or cwd.
- `utility/python_runner.py` attaches the common dispatcher to actions with a
  `SharedShortcut` manifest entry. Their original handlers still receive API,
  MIDI, OSC, lifecycle, and unrelated events.
- Each opted-in inspector includes `shared/keys.js` and `shared/editor.js` from
  this plugin and declares its action UUID with `data-shortcut-action`.
- The editor is appended inside the existing `.sdpi-wrapper`, after the app's
  original controls. The wrapper is the single form scroll owner; the shared
  editor has no nested scrolling or permanent Default/Custom status label.
- Clip Studio's old text-only custom-key editor is removed. Existing saved
  `custom_hotkey` values still load in the shared editor for compatibility;
  recording a replacement or resetting uses the shared settings format.
- Blender, Unity, and PowerPoint have existing main-process input routes;
  `cookiedeck.py` also resolves their custom overrides before those routes.
- Original action UUIDs, selected functions, titles, and icons are not replaced
  with keyboard settings. Discord/Slack retain their existing focus behavior.

The 26 consumers are: Photoshop, After Effects, Premiere, DaVinci Resolve,
Clip Studio, Figma, Illustrator, Unreal, Unity, Teams, Meet, Zoom, Cubase,
FL Studio, Ableton, Studio One, Pro Tools, Blender, Excel, Word, PowerPoint,
HWP, Notion shortcuts, Slack shortcuts, Discord shortcuts, and VS Code shortcuts.
API actions and hold-to-talk actions are not automatically opted in.

## Defaults and saved overrides

App manifests contain explicit `windows` and `darwin` default tables. `null`
means no keyboard-only default has been verified for this feature/platform:
a user can still record a custom chord. It does not mean the app is unsupported.
The 2026-10-19 source audit and platform corrections are recorded in
`docs/shortcut-defaults-audit-20261019.json`, with official sources and context/
version limitations for all 26 consumers. `DefaultReview` in each manifest
records the date and sources. This is not live verification of every installed
application/version/keymap. Do not replace explicit nulls with a Ctrl-to-Command
guess or a browser-close/ribbon-navigation chord from another platform.

The Unity trusted-host resolver reads the same reviewed defaults; its old
encoded Values remain stable for saved buttons/icons. Blender intentionally
keeps valid Control bindings on macOS (Blender's keymap preserves them alongside
some Command alternatives). PowerPoint's existing four capability profiles
remain synchronized with the common defaults.

Custom settings use this versioned, platform-specific schema:

```json
{
  "shared_shortcut": {
    "version": 1,
    "scope": "[\"file_save\",\"hotkey\",\"desktop\"]",
    "platforms": {
      "windows": {"enabled": true, "steps": [["ctrl", "num1"]]},
      "darwin": {"enabled": true, "steps": [["command", "s"], ["enter"]]}
    }
  }
}
```

Each inner array is a simultaneous chord; outer arrays are ordered steps.
`num1` differs from `1`, `numenter` from `enter`, `multiply` from literal `*`.
Custom Control is never silently changed to Command. Scope includes the
selected function, control mode, and desktop/web profile. A function change
clears the old override rather than applying it to a different function.
Reset disables the current platform override and uses its app default.
Sequence length is limited to 32. Recording requests are scoped and identified
so delayed results cannot overwrite a newly selected function.

## Packaging and validation

Ship the updated main application/runner, complete Shortcuts plugin including
this directory, and updated consumer manifests/inspectors together. Updating
only a store ZIP or only the main executable is insufficient. This source
change does not publish remote store ZIPs or build/sign a new installer.

Shortcuts is protected as a default plugin, and package validation rejects
Shortcuts updates missing this core. The engine is cached per process: restart
the main application/runner after replacing it. No keyboard listener is
installed on import; recording is explicit and macOS uses the trusted host's
permission-gated native recorder.

Automated tests mock OS input and app focus. They cover the 26 bindings,
platform defaults, scoped overrides, key identities, failure cleanup,
dispatch, Qt editor interaction, and package validation. Before release,
verify real Windows/macOS application shortcuts, macOS permissions, and the
installed build; those cannot be proven by mock-input tests.

Run from the project root:

```sh
python3 -m unittest tests.test_shortcut_default_audit tests.test_shared_shortcuts tests.test_shared_shortcut_editor tests.test_hotkey_macos_presets tests.test_hotkey_modifier_sides tests.test_hotkey_shift_scan tests.test_protools_shortcuts tests.test_plugin_package -q
```
