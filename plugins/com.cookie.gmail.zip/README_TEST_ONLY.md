# com.cookie.gmail 테스트용 플러그인

이 플러그인은 배포용이 아니라 Gmail API 연동 테스트용입니다.

## 필요한 준비

1. Google Cloud Console에서 OAuth Client ID를 만듭니다.
   - Application type: Desktop app
   - API: Gmail API 활성화
2. OAuth Client 파일을 다운로드하고 이름을 `credentials.json`으로 변경합니다.
3. `credentials.json`을 이 플러그인 폴더의 `plugin.py`와 같은 위치에 넣습니다.
4. CookieDeck/ActionBOX에서 Gmail 플러그인을 버튼에 등록합니다.
5. 설정창에서 [Google 계정 연결]을 누릅니다.
6. 브라우저에서 Google 로그인/권한 허용을 진행합니다.

## Python 의존성

플러그인 실행 환경에 아래 패키지가 필요합니다.

```bash
pip install -r requirements.txt
```

필요 패키지:
- google-api-python-client
- google-auth
- google-auth-oauthlib
- Pillow

## 기능

- Gmail 검색 조건의 결과 개수를 버튼 제목/이미지에 표시
- 기본 검색 조건: `is:unread`
- 버튼 클릭 시 Gmail 검색 화면 열기
- Gmail 작성창 열기 모드

## 토큰 저장 위치

Windows 기준:

```text
%APPDATA%\ActionBOX\plugins\com.cookie.gmail\token.json
```

연결 해제를 누르면 이 토큰 파일을 삭제합니다.

## 주의

- 이 테스트 플러그인은 `gmail.readonly` 권한을 사용합니다.
- 메일 본문을 읽거나 저장하지 않고, `messages.list`의 `resultSizeEstimate`를 이용해 개수만 표시합니다.
- 로그에 토큰이나 메일 본문을 저장하지 않습니다.
