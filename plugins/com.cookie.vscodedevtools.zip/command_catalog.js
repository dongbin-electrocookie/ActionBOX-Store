// The manifest is the single source of built-in commands for both inspectors.
class CommandCatalog {
    constructor(actionId, selectId) {
        this.actionId = actionId;
        this.selectId = selectId;
        this.states = [];
        this.loaded = false;
        this.lastResult = null;
    }

    commandValue(settings) {
        const field = this.actionId.endsWith('.hotkey') ? 'keys' : 'git_command';
        const value = Object.prototype.hasOwnProperty.call(settings, field) ? settings[field] : settings.command;
        return typeof value === 'string' ? value.trim() : '';
    }

    mergeSettings(previous, incoming) {
        incoming = incoming || {};
        const field = this.actionId.endsWith('.hotkey') ? 'keys' : 'git_command';
        const merged = {...previous, ...incoming};
        if (Object.prototype.hasOwnProperty.call(incoming, field) ||
            Object.prototype.hasOwnProperty.call(incoming, 'command')) {
            merged[field] = merged.command = this.commandValue(incoming);
        }
        return merged;
    }

    renderResult(languageData, fallback) {
        const note = document.getElementById('execution-result');
        note.hidden = !this.lastResult;
        if (!this.lastResult) { note.textContent = ''; return; }
        const code = this.lastResult.code;
        const message = languageData[code] || CommandCatalog.resultFallbacks[code] || CommandCatalog.resultFallbacks.RESULT_FAILED;
        // Git output can contain arbitrary file names/server text, never HTML.
        note.textContent = message + (this.lastResult.output ? '\n' + String(this.lastResult.output).slice(0, 4096) : '');
    }

    getState(value) {
        return this.states.find(state => state.Value === value);
    }

    async load() {
        const response = await fetch('./manifest.json');
        if (!response.ok) throw new Error('Manifest load failed: ' + response.status);
        const manifest = await response.json();
        const action = (manifest.Actions || []).find(entry => entry.UUID === this.actionId);
        this.states = (action?.States || []).filter(state => state.Value && !state.Hidden);
        if (!this.states.length) throw new Error('No commands declared for ' + this.actionId);

        const select = document.getElementById(this.selectId);
        const placeholder = Array.from(select.options).find(option => option.value === '');
        select.replaceChildren();
        if (placeholder) select.appendChild(placeholder);
        const groups = new Map();
        for (const state of this.states) {
            let parent = select;
            if (state.GroupKey || state.Group) {
                const groupId = state.GroupKey || state.Group;
                if (!groups.has(groupId)) {
                    const group = document.createElement('optgroup');
                    group.label = state.Group || groupId;
                    group.setAttribute('data-label-i18n', state.GroupKey || '');
                    group.setAttribute('data-fallback', group.label);
                    groups.set(groupId, group);
                    select.appendChild(group);
                }
                parent = groups.get(groupId);
            }
            const option = document.createElement('option');
            option.value = state.Value;
            option.innerText = state.InspectorName || state.Name;
            option.setAttribute('data-i18n', state.InspectorNameKey || state.NameKey || '');
            option.setAttribute('data-fallback', option.innerText);
            option.setAttribute('data-title-key', state.TitleKey || '');
            parent.appendChild(option);
        }
        this.loaded = true;
        select.disabled = false;
    }

    translate(languageData) {
        const select = document.getElementById(this.selectId);
        select.querySelectorAll('[data-i18n], [data-label-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n') || element.getAttribute('data-label-i18n');
            const text = languageData[key] || element.getAttribute('data-fallback');
            if (!text) return;
            if (element.tagName === 'OPTGROUP') element.label = text;
            else element.innerText = text;
        });
    }
}

CommandCatalog.resultFallbacks = {
    RESULT_SUCCESS: 'Completed.', RESULT_RUNNING: 'Running…', RESULT_FAILED: 'The operation failed.',
    HOTKEY_SENT: 'Shortcut sent. VS Code must have focus.',
    HOTKEY_EMPTY: 'Select or enter a shortcut.',
    HOTKEY_FAILED: 'Could not send the shortcut. Check input permissions.',
    GIT_NO_COMMAND: 'Select a Git command.', GIT_NO_PROJECT: 'Choose a local Git project folder.',
    GIT_PATH_INVALID: 'The project folder does not exist.',
    GIT_NOT_INSTALLED: 'Git was not found. Install Git and restart COMBO-X.',
    GIT_NOT_REPOSITORY: 'The selected folder is not a Git working tree.',
    GIT_AUTH_REQUIRED: 'Git authentication failed. Authenticate this repository with Git, then retry.',
    GIT_REMOTE_REQUIRED: 'Check the Git remote and upstream branch.',
    GIT_TIMEOUT: 'Git timed out. Check the repository before retrying; the operation may have partially completed.',
};
