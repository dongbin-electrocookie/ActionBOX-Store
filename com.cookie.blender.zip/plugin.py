import asyncio
import os
import sys

try:
    import pyautogui
    PYAUTOGUI_OK = True
except ImportError:
    pyautogui = None
    PYAUTOGUI_OK = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.default_full_cmd = 'single|e|TITLE_EXTRUDE'
        self.context_settings = {}

        # Blender's default keymap is mostly cross-platform. Unlike Photoshop/AE,
        # Blender usually keeps Ctrl/Alt as Blender modifiers on macOS instead of
        # replacing everything with Command. We still keep a platform map here so
        # future macOS-only corrections can be added safely without touching pi.html.
        self.windows_key_map = {
            'ctrl+b': 'ctrl+b',
            'ctrl+r': 'ctrl+r',
            'ctrl+x': 'ctrl+x',
            'ctrl+a': 'ctrl+a',
            'ctrl+p': 'ctrl+p',
            'ctrl+tab': 'ctrl+tab',
            'alt+s': 'alt+s',
            'alt+a': 'alt+a',
            'alt+h': 'alt+h',
            'alt+p': 'alt+p',
            'shift+v': 'shift+v',
            'shift+n': 'shift+n',
            'shift+a': 'shift+a',
            'shift+d': 'shift+d',
            'shift+h': 'shift+h',
            'ctrl+l': 'ctrl+l',
            'ctrl+i': 'ctrl+i',
            'shift+g': 'shift+g',
            'ctrl+add': 'ctrl+add',
            'ctrl+num1': 'ctrl+num1',
            'ctrl+num3': 'ctrl+num3',
            'ctrl+num7': 'ctrl+num7',
            'shift+r': 'shift+r',
            'alt+d': 'alt+d',
            'ctrl+space': 'ctrl+space',
            'shift+tab': 'shift+tab',
            'alt+g': 'alt+g',
            'alt+z': 'alt+z',
            'ctrl+alt+q': 'ctrl+alt+q',
        }
        self.macos_key_map = {
            # Keep Ctrl for Blender keymap. Option is the macOS physical Alt key.
            'ctrl+b': 'ctrl+b',
            'ctrl+r': 'ctrl+r',
            'ctrl+x': 'ctrl+x',
            'ctrl+a': 'ctrl+a',
            'ctrl+p': 'ctrl+p',
            'ctrl+tab': 'ctrl+tab',
            'alt+s': 'option+s',
            'alt+a': 'option+a',
            'alt+h': 'option+h',
            'alt+p': 'option+p',
            'shift+v': 'shift+v',
            'shift+n': 'shift+n',
            'shift+a': 'shift+a',
            'shift+d': 'shift+d',
            'shift+h': 'shift+h',
            'ctrl+l': 'ctrl+l',
            'ctrl+i': 'ctrl+i',
            'shift+g': 'shift+g',
            'ctrl+add': 'ctrl+add',
            'ctrl+num1': 'ctrl+num1',
            'ctrl+num3': 'ctrl+num3',
            'ctrl+num7': 'ctrl+num7',
            'shift+r': 'shift+r',
            'alt+d': 'option+d',
            'ctrl+space': 'ctrl+space',
            'shift+tab': 'shift+tab',
            'alt+g': 'option+g',
            'alt+z': 'option+z',
            'ctrl+alt+q': 'ctrl+option+q',
        }

    def _parse_full_cmd(self, full_cmd):
        parts = (full_cmd or '').split('|')
        if len(parts) < 3:
            return None, None, None
        return parts[0], parts[1], parts[2]

    def _default_settings(self):
        cmd_type, key_val, title_key = self._parse_full_cmd(self.default_full_cmd)
        return {
            "full_cmd": self.default_full_cmd,
            "cmd_type": cmd_type,
            "key_val": key_val,
            "builtin_icon_name": title_key,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})

        full_cmd = merged.get("full_cmd") or self.default_full_cmd
        full_cmd = full_cmd.replace('combo|ctrl+num8|TITLE_GROW_SELECTION', 'combo|ctrl+add|TITLE_GROW_SELECTION')
        cmd_type, key_val, title_key = self._parse_full_cmd(full_cmd)
        if not cmd_type or not key_val or not title_key:
            full_cmd = self.default_full_cmd
            cmd_type, key_val, title_key = self._parse_full_cmd(full_cmd)

        merged["full_cmd"] = full_cmd
        merged["cmd_type"] = cmd_type
        merged["key_val"] = key_val
        merged["builtin_icon_name"] = title_key
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("full_cmd"),
            s.get("cmd_type"),
            s.get("key_val"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_builtin_icon_path(self, title_key):
        icon_path = os.path.join(self.plugin_dir, 'icon', f'{title_key}.png')
        if os.path.exists(icon_path):
            return icon_path
        return os.path.join(self.plugin_dir, 'icon', 'DEFAULT.png')

    async def _send_builtin_icon(self, context, title_key):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        if not context or not title_key:
            return
        icon_path = self._get_builtin_icon_path(title_key)
        if not os.path.exists(icon_path):
            return
        await self.runner.send_message({
            'event': 'setIcon',
            'context': context,
            'payload': {'icon_path': icon_path}
        })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                'event': 'setSettings',
                'context': context,
                'payload': defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["builtin_icon_name"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get('event')
        payload = data.get('payload', {}) or {}
        context = data.get('context') or payload.get('context')
        payload_settings = payload.get('settings')
        settings = payload_settings if isinstance(payload_settings, dict) else data.get('settings', {}) or {}
        control_command = data.get('command') or payload.get('command')

        if event in ['willAppear', 'keyDidAppear']:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == 'didReceiveSettings':
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ['keyDidDisappear', 'willDisappear']:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == 'apply_builtin_icon':
            cached = self.context_settings.get(context, {})
            full_cmd = data.get('full_cmd') or payload.get('full_cmd') or settings.get('full_cmd') or cached.get('full_cmd') or self.default_full_cmd
            _cmd_type, _key_val, title_key = self._parse_full_cmd(full_cmd)
            if context and title_key:
                await self._send_builtin_icon(context, title_key)
            return

        if event == 'keyDown':
            await self.on_key_down(context, settings)

    def _platform_key_value(self, key_val):
        key_val = (key_val or '').strip().lower()
        if IS_MACOS:
            return self.macos_key_map.get(key_val, key_val)
        return self.windows_key_map.get(key_val, key_val)

    def _normalize_key_token(self, token):
        key = (token or '').strip().lower()
        if not key:
            return key

        # Common aliases used by PI values or older keymaps.
        aliases = {
            'cmd': 'command',
            'win': 'command' if IS_MACOS else 'win',
            'windows': 'command' if IS_MACOS else 'win',
            'control': 'ctrl',
            'option': 'option' if IS_MACOS else 'alt',
            'alt': 'option' if IS_MACOS else 'alt',
            'grave': '`',
            'page up': 'pageup',
            'page down': 'pagedown',
            'num+': 'add',
            'numpad+': 'add',
            'numpadplus': 'add',
            'num-': 'subtract',
            'numpad-': 'subtract',
            'numpadminus': 'subtract',
            'numpad.': 'decimal',
            'numpaddecimal': 'decimal',
        }
        key = aliases.get(key, key)
        return key

    async def _press_single(self, key_val):
        key = self._normalize_key_token(self._platform_key_value(key_val))
        if not key:
            return
        await asyncio.to_thread(pyautogui.press, key)

    async def _press_combo(self, key_val):
        combo = self._platform_key_value(key_val)
        keys = [self._normalize_key_token(k) for k in combo.split('+')]
        keys = [k for k in keys if k]
        if not keys:
            return
        await asyncio.to_thread(pyautogui.hotkey, *keys)

    async def _press_sequence(self, key_val):
        steps = [step.strip() for step in str(key_val or '').split(',') if step.strip()]
        for step in steps:
            if '+' in step:
                await self._press_combo(step)
            else:
                await self._press_single(step)
            await asyncio.sleep(0.04)

    async def on_key_down(self, context, incoming_settings):
        if not PYAUTOGUI_OK:
            print('[Blender Error] pyautogui is not installed.')
            return

        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **(incoming_settings or {})})
        if context:
            self.context_settings[context] = settings

        full_cmd = settings.get('full_cmd') or self.default_full_cmd
        cmd_type, key_val, _title_key = self._parse_full_cmd(full_cmd)
        if not key_val:
            return

        try:
            if cmd_type == 'single':
                await self._press_single(key_val)
            elif cmd_type == 'combo':
                await self._press_combo(key_val)
            elif cmd_type == 'sequence':
                await self._press_sequence(key_val)
        except Exception as e:
            print(f'[Blender Error] platform={sys.platform}, cmd_type={cmd_type}, key_val={key_val}, error={e}')
