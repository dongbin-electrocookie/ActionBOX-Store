import AppKit
import CoreAudio
import Foundation
import AVFoundation

@_silgen_name("mixer_gain_create") func gainCreate() -> UnsafeMutableRawPointer?
@_silgen_name("mixer_gain_destroy") func gainDestroy(_ state: UnsafeMutableRawPointer)
@_silgen_name("mixer_gain_set") func gainSet(_ state: UnsafeMutableRawPointer, _ gain: Float)
@_silgen_name("mixer_callback_count") func callbackCount(_ state: UnsafeMutableRawPointer) -> UInt64
@_silgen_name("mixer_input_peak") func inputPeak(_ state: UnsafeMutableRawPointer) -> Float
@_silgen_name("mixer_output_peak") func outputPeak(_ state: UnsafeMutableRawPointer) -> Float
@_silgen_name("mixer_process") func processAudio(_ state: UnsafeMutableRawPointer,
    _ input: UnsafePointer<AudioBufferList>, _ output: UnsafeMutablePointer<AudioBufferList>, _ channels: UInt32)
@_silgen_name("mixer_enable_tap_input") func enableTapInput(_ device: AudioDeviceID, _ proc: AudioDeviceIOProcID) -> OSStatus
@_silgen_name("mixer_dsp_self_test") func dspSelfTest() -> Int32

struct MixerError: Error {
    let code: String
    let status: OSStatus
    init(_ code: String, _ status: OSStatus = 0) { self.code = code; self.status = status }
}
func check(_ status: OSStatus, _ code: String = "audio_error") throws {
    if status != noErr { throw MixerError(code, status) }
}
func address(_ selector: AudioObjectPropertySelector,
             _ scope: AudioObjectPropertyScope = kAudioObjectPropertyScopeGlobal) -> AudioObjectPropertyAddress {
    AudioObjectPropertyAddress(mSelector: selector, mScope: scope, mElement: kAudioObjectPropertyElementMain)
}
func scalar<T>(_ object: AudioObjectID, _ selector: AudioObjectPropertySelector,
               _ initial: T, _ scope: AudioObjectPropertyScope = kAudioObjectPropertyScopeGlobal) throws -> T {
    var value = initial, size = UInt32(MemoryLayout<T>.size), addr = address(selector, scope)
    let status = withUnsafeMutableBytes(of: &value) { data in
        AudioObjectGetPropertyData(object, &addr, 0, nil, &size, data.baseAddress!)
    }
    try check(status)
    return value
}
func ids(_ object: AudioObjectID, _ selector: AudioObjectPropertySelector,
         _ scope: AudioObjectPropertyScope = kAudioObjectPropertyScopeGlobal) throws -> [AudioObjectID] {
    var addr = address(selector, scope), size: UInt32 = 0
    try check(AudioObjectGetPropertyDataSize(object, &addr, 0, nil, &size))
    guard size <= 1024 * 1024, size % 4 == 0 else { throw MixerError("audio_error") }
    if size == 0 { return [] }
    var result = [AudioObjectID](repeating: 0, count: Int(size) / 4)
    let status = result.withUnsafeMutableBytes { data in
        AudioObjectGetPropertyData(object, &addr, 0, nil, &size, data.baseAddress!)
    }
    try check(status)
    return Array(result.prefix(Int(size) / 4))
}
func text(_ object: AudioObjectID, _ selector: AudioObjectPropertySelector) throws -> String {
    var value: Unmanaged<CFString>?, size = UInt32(MemoryLayout<Unmanaged<CFString>?>.size)
    var addr = address(selector)
    try check(AudioObjectGetPropertyData(object, &addr, 0, nil, &size, &value))
    return value?.takeRetainedValue() as String? ?? ""
}

@available(macOS 14.2, *)
struct AudioApp {
    let id: String
    let name: String
    var processes: [AudioObjectID]
}

@available(macOS 14.2, *)
func audioApps() throws -> [String: AudioApp] {
    var result: [String: AudioApp] = [:]
    for object in try ids(AudioObjectID(kAudioObjectSystemObject), kAudioHardwarePropertyProcessObjectList) {
        guard let pid: pid_t = try? scalar(object, kAudioProcessPropertyPID, pid_t(0)),
              pid != getpid(),
              (try? scalar(object, kAudioProcessPropertyIsRunningOutput, UInt32(0))) == 1 else { continue }
        let running = NSRunningApplication(processIdentifier: pid)
        var bundle = running?.bundleURL
        // Browser audio often belongs to a nested Helper.app. Group it under
        // the outer application, rather than saving an ephemeral renderer PID.
        if let parts = bundle?.pathComponents, let outer = parts.firstIndex(where: { $0.hasSuffix(".app") }) {
            bundle = URL(fileURLWithPath: NSString.path(withComponents: Array(parts.prefix(outer + 1))))
        }
        let appBundle = bundle.flatMap { Bundle(url: $0) }
        let bundleID = appBundle?.bundleIdentifier ?? running?.bundleIdentifier
            ?? (try? text(object, kAudioProcessPropertyBundleID)) ?? ""
        let key = bundleID.isEmpty ? "pid:\(pid)" : "bundle:\(bundleID)"
        let name = (appBundle?.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String)
            ?? (appBundle?.object(forInfoDictionaryKey: "CFBundleName") as? String)
            ?? running?.localizedName ?? bundleID
        if result[key] == nil { result[key] = AudioApp(id: key, name: name.isEmpty ? "PID \(pid)" : name, processes: []) }
        result[key]!.processes.append(object)
    }
    return result
}

@available(macOS 14.2, *)
final class Route {
    var tap: AudioObjectID = 0
    var aggregate: AudioObjectID = 0
    var proc: AudioDeviceIOProcID?
    let state: UnsafeMutableRawPointer
    let processes: [AudioObjectID]
    let output: AudioDeviceID

    init(app: AudioApp, output: AudioDeviceID, gain: Float) throws {
        guard let state = gainCreate() else { throw MixerError("audio_error") }
        self.state = state; self.processes = app.processes.sorted(); self.output = output
        do {
            let uid = try text(output, kAudioDevicePropertyDeviceUID)
            let description = CATapDescription(processes: app.processes, deviceUID: uid, stream: 0)
            description.name = "COMBO-X: \(app.name)"
            description.isPrivate = true
            description.muteBehavior = .mutedWhenTapped
            try check(AudioHardwareCreateProcessTap(description, &tap), "capture_unavailable")
            let format = try scalar(tap, kAudioTapPropertyFormat, AudioStreamBasicDescription())
            guard format.mFormatID == kAudioFormatLinearPCM,
                  format.mFormatFlags & kAudioFormatFlagIsFloat != 0,
                  format.mFormatFlags & kAudioFormatFlagIsBigEndian == 0,
                  format.mBitsPerChannel == 32, format.mChannelsPerFrame > 0 else {
                throw MixerError("unsupported_format")
            }
            let tapUID = try text(tap, kAudioTapPropertyUID)
            let config: [String: Any] = [
                kAudioAggregateDeviceNameKey: "COMBO-X App Volume",
                kAudioAggregateDeviceUIDKey: UUID().uuidString,
                kAudioAggregateDeviceIsPrivateKey: true,
                kAudioAggregateDeviceIsStackedKey: false,
                kAudioAggregateDeviceMainSubDeviceKey: uid,
                kAudioAggregateDeviceSubDeviceListKey: [[kAudioSubDeviceUIDKey: uid]],
                kAudioAggregateDeviceTapListKey: [[kAudioSubTapUIDKey: tapUID,
                                                   kAudioSubTapDriftCompensationKey: true]],
                kAudioAggregateDeviceTapAutoStartKey: true,
            ]
            try check(AudioHardwareCreateAggregateDevice(config as CFDictionary, &aggregate))
            let outputs = try ids(aggregate, kAudioDevicePropertyStreams, kAudioObjectPropertyScopeOutput)
            var channels: UInt32 = 0
            for stream in outputs {
                let out = try scalar(stream, kAudioStreamPropertyVirtualFormat, AudioStreamBasicDescription())
                guard out.mFormatID == kAudioFormatLinearPCM,
                      out.mFormatFlags & kAudioFormatFlagIsFloat != 0,
                      out.mFormatFlags & kAudioFormatFlagIsBigEndian == 0,
                      out.mBitsPerChannel == 32, out.mSampleRate == format.mSampleRate else {
                    throw MixerError("unsupported_format")
                }
                channels += out.mChannelsPerFrame
            }
            guard channels == format.mChannelsPerFrame else { throw MixerError("unsupported_format") }
            gainSet(state, gain)
            let tapChannels = format.mChannelsPerFrame
            try check(AudioDeviceCreateIOProcIDWithBlock(&proc, aggregate, nil) { _, input, _, output, _ in
                processAudio(state, input, output, tapChannels)
            })
            guard let proc else { throw MixerError("audio_error") }
            try check(enableTapInput(aggregate, proc))
            try check(AudioDeviceStart(aggregate, proc), "capture_unavailable")
            for _ in 0..<200 {
                if callbackCount(state) != 0 { break }
                Thread.sleep(forTimeInterval: 0.01)
            }
            guard callbackCount(state) != 0 else { throw MixerError("capture_unavailable") }
        } catch {
            close()
            throw error
        }
    }

    func close() {
        if let proc {
            AudioDeviceStop(aggregate, proc)
            AudioDeviceDestroyIOProcID(aggregate, proc)
            self.proc = nil
        }
        if aggregate != 0 { AudioHardwareDestroyAggregateDevice(aggregate); aggregate = 0 }
        // mutedWhenTapped automatically restores original output when the tap
        // stops being read, including helper crashes or parent termination.
        if tap != 0 { AudioHardwareDestroyProcessTap(tap); tap = 0 }
    }
    deinit { close(); gainDestroy(state) }
}

@available(macOS 14.2, *)
final class Control {
    var volume: Float = 1
    var muted = false
    var route: Route?
    var lastError: String?
    var started = Date()
    var gain: Float { muted ? 0 : volume }
}

@available(macOS 14.2, *)
final class Mixer {
    var controls: [String: Control] = [:]
    let parent = getppid()
    func stop() { controls.removeAll() }

    func refresh() {
        guard getppid() == parent, parent > 1 else { stop(); exit(0) }
        guard let apps = try? audioApps(),
              let output = try? scalar(AudioObjectID(kAudioObjectSystemObject),
                                        kAudioHardwarePropertyDefaultOutputDevice, AudioDeviceID(0)) else {
            for control in controls.values { control.route = nil }
            return
        }
        for (id, control) in controls {
            guard let app = apps[id] else { control.route = nil; continue }
            if let route = control.route,
               route.output != output || route.processes != app.processes.sorted() { control.route = nil }
            if let route = control.route, Date().timeIntervalSince(control.started) > 3,
               callbackCount(route.state) == 0 {
                control.route = nil; control.lastError = "capture_unavailable"
            }
            // Failed routes stay released until an explicit user action; no
            // infinite permission prompts or repeated audio interruptions.
            if control.route == nil && control.lastError == nil {
                do {
                    control.route = try Route(app: app, output: output, gain: control.gain)
                    control.started = Date()
                } catch let error as MixerError { control.lastError = error.code }
                catch { control.lastError = "audio_error" }
            }
        }
    }

    func request(_ value: [String: Any]) throws -> [String: Any] {
        let command = value["command"] as? String ?? ""
        if command == "shutdown" { stop(); return ["shutdown": true] }
        if command == "status", let id = value["app"] as? String,
           let control = controls[id], let route = control.route {
            return ["callbacks": callbackCount(route.state), "input_peak": inputPeak(route.state),
                    "output_peak": outputPeak(route.state), "volume": Int((control.volume * 100).rounded()),
                    "muted": control.muted]
        }
        let apps = try audioApps()
        if command == "list" {
            return ["apps": apps.values.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
                .map { ["id": $0.id, "name": $0.name] }]
        }
        guard command == "change", let id = value["app"] as? String,
              let action = value["action"] as? String,
              ["vol_up", "vol_down", "vol_mute"].contains(action) else { throw MixerError("invalid_request") }
        guard let app = apps[id] else { throw MixerError("not_running") }
        let control = controls[id] ?? Control()
        let oldVolume = control.volume, oldMute = control.muted
        switch action {
        case "vol_up": control.volume = min(1, control.volume + 0.1); control.muted = false
        case "vol_down": control.volume = max(0, control.volume - 0.1); control.muted = false
        default: control.muted.toggle()
        }
        do {
            let output = try scalar(AudioObjectID(kAudioObjectSystemObject),
                                    kAudioHardwarePropertyDefaultOutputDevice, AudioDeviceID(0))
            if let route = control.route,
               route.output != output || route.processes != app.processes.sorted() { control.route = nil }
            if control.route == nil {
                control.route = try Route(app: app, output: output, gain: control.gain)
                control.started = Date()
            } else if let route = control.route { gainSet(route.state, control.gain) }
            control.lastError = nil
            controls[id] = control
            return ["name": app.name, "volume": Int((control.volume * 100).rounded()), "muted": control.muted]
        } catch {
            control.volume = oldVolume; control.muted = oldMute
            control.route = nil
            throw error
        }
    }
}

func reply(_ value: [String: Any]) {
    if let data = try? JSONSerialization.data(withJSONObject: value, options: [.sortedKeys]) {
        FileHandle.standardOutput.write(data + Data([10]))
    }
}

if CommandLine.arguments.contains("--test-source") {
    // Explicit manual verification only: a quiet local tone, never auto-run
    // by the plugin. Stops on stdin EOF or after 60 seconds.
    NSApplication.shared.setActivationPolicy(.accessory)
    let engine = AVAudioEngine(), player = AVAudioPlayerNode()
    let format = AVAudioFormat(standardFormatWithSampleRate: 48000, channels: 2)!
    let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: 48000)!
    buffer.frameLength = 48000
    for channel in 0..<2 {
        for frame in 0..<48000 {
            buffer.floatChannelData![channel][frame] = Float(sin(Double(frame) * 440 * 2 * .pi / 48000) * 0.004)
        }
    }
    engine.attach(player)
    engine.connect(player, to: engine.mainMixerNode, format: format)
    do {
        try engine.start()
        player.scheduleBuffer(buffer, at: nil, options: .loops)
        player.play()
        reply(["ok": true, "pid": getpid(), "test_source": true])
        DispatchQueue.global().async { _ = FileHandle.standardInput.readDataToEndOfFile(); exit(0) }
        Timer.scheduledTimer(withTimeInterval: 60, repeats: false) { _ in exit(0) }
        RunLoop.main.run()
        withExtendedLifetime([engine, player, buffer]) {}
    } catch { reply(["ok": false, "error": "test_source_failed"]); exit(1) }
}

if CommandLine.arguments.contains("--self-test") {
    // DSP tests do not open devices, create taps, or request audio permission.
    if let state = gainCreate() {
        gainSet(state, 0.5)
        var input: [Float] = [0.2, -0.4, 0.8, -1]
        var output: [Float] = [9, 9, 9, 9]
        input.withUnsafeMutableBytes { src in
            output.withUnsafeMutableBytes { dst in
                var inList = AudioBufferList(mNumberBuffers: 1, mBuffers:
                    AudioBuffer(mNumberChannels: 2, mDataByteSize: 16, mData: src.baseAddress))
                var outList = AudioBufferList(mNumberBuffers: 1, mBuffers:
                    AudioBuffer(mNumberChannels: 2, mDataByteSize: 16, mData: dst.baseAddress))
                processAudio(state, &inList, &outList, 2)
            }
        }
        let ok = zip(output, [Float(0.1), -0.2, 0.4, -0.5]).allSatisfy { abs($0 - $1) < 0.0001 }
            && dspSelfTest() == 1
        gainDestroy(state)
        reply(["ok": ok, "dsp": output]); exit(ok ? 0 : 1)
    }
    exit(1)
}

if #available(macOS 14.2, *) {
    let mixer = Mixer()
    if CommandLine.arguments.contains("--list") {
        do { reply(try mixer.request(["command": "list"]).merging(["ok": true]) { a, _ in a }) }
        catch { reply(["ok": false, "error": "audio_error"]) }
        exit(0)
    }
    NSApplication.shared.setActivationPolicy(.accessory)
    let timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in mixer.refresh() }
    signal(SIGTERM, SIG_IGN); signal(SIGINT, SIG_IGN)
    let term = DispatchSource.makeSignalSource(signal: SIGTERM, queue: .main)
    let interrupt = DispatchSource.makeSignalSource(signal: SIGINT, queue: .main)
    for source in [term, interrupt] { source.setEventHandler { mixer.stop(); exit(0) }; source.resume() }
    DispatchQueue.global().async {
        while let line = readLine() {
            guard line.utf8.count < 16384, let data = line.data(using: .utf8),
                  let value = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { continue }
            DispatchQueue.main.async {
                let id = value["id"] as? Int ?? 0
                do {
                    var result = try mixer.request(value)
                    result["id"] = id; result["ok"] = true; reply(result)
                    if result["shutdown"] as? Bool == true { exit(0) }
                } catch let error as MixerError {
                    reply(["id": id, "ok": false, "error": error.code, "status": error.status])
                } catch { reply(["id": id, "ok": false, "error": "audio_error"]) }
            }
        }
        DispatchQueue.main.async { mixer.stop(); exit(0) }
    }
    RunLoop.main.run()
    withExtendedLifetime([timer, term, interrupt]) {}
} else {
    reply(["ok": false, "error": "unsupported_macos"])
    exit(1)
}
