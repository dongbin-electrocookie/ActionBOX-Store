#target illustrator

// Illustrator 아이소메트릭 격자 생성 스크립트
var rows = parseInt(prompt("몇 줄을 생성할까요? (세로)", "10"));
var cols = parseInt(prompt("몇 칸을 생성할까요? (가로)", "10"));
var size = parseFloat(prompt("한 셀의 한 변 길이 (px)", "20"));

if (isNaN(rows) || isNaN(cols) || isNaN(size)) {
  alert("숫자 입력이 잘못되었습니다.");
} else {
  var doc = app.activeDocument;
  var layer = doc.activeLayer;

  var dx = size * Math.sqrt(3); // x 방향 거리
  var dy = size * 1.5; // y 방향 거리 (기본 육각형 배치 기준)

  for (var r = 0; r < rows; r++) {
    for (var c = 0; c < cols; c++) {
      var x = c * dx + (r % 2) * (dx / 2);
      var y = r * dy;

      var hex = layer.pathItems.polygon(x, y, size, 6);
      hex.stroked = true;
      hex.filled = false;
      hex.strokeColor = makeGray(60); // 회색 선
      hex.rotate(30); // 아이소메트릭 스타일
    }
  }

  function makeGray(v) {
    var color = new GrayColor();
    color.gray = v;
    return color;
  }

  alert("아이소메트릭 격자 생성 완료!");
}