import asyncio
import websockets
import json
import os
import sys
import traceback

class VTubeStudioPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.vtubestudio"
        self.cd_uri = "ws://localhost:8765"
        self.cd_ws = None
        
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_file = os.path.join(self.plugin_dir, 'vts_config.json')
        
        self.vts_ws = None
        self.vts_connected = False
        self.last_context = None  
        self.context_settings = {}
        
        # 👉 현재 아바타 투명도(0~255)를 기억하는 변수
        self.opacity_state = {} 
        
        self.load_config()

    def load_config(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
            except:
                self.config = {"ip": "localhost", "port": 8001, "token": ""}
        else:
            self.config = {"ip": "localhost", "port": 8001, "token": ""}

    def save_config(self):
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, indent=4)

    # ========================================================
    # VTube Studio 통신 로직
    # ========================================================
    async def vts_connect_loop(self):
        while True:
            vts_uri = f"ws://{self.config.get('ip', 'localhost')}:{self.config.get('port', 8001)}"
            try:
                async with websockets.connect(vts_uri) as ws:
                    self.vts_ws = ws
                    self.vts_connected = True
                    print("[VTS] 🟢 Connected to VTube Studio!")
                    await self.vts_authenticate()
                    
                    async for message in ws:
                        await self.handle_vts_message(json.loads(message))
            except Exception as e:
                self.vts_connected = False
                self.vts_ws = None
            await asyncio.sleep(3)

    async def vts_authenticate(self):
        token = self.config.get("token", "")
        if not token:
            req = {
                "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "TokenReq",
                "messageType": "AuthenticationTokenRequest",
                "data": {"pluginName": "CookieDeck", "pluginDeveloper": "ElectroCookie"}
            }
        else:
            req = {
                "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "AuthReq",
                "messageType": "AuthenticationRequest",
                "data": {"pluginName": "CookieDeck", "pluginDeveloper": "ElectroCookie", "authenticationToken": token}
            }
        await self.vts_ws.send(json.dumps(req))

    async def handle_vts_message(self, data):
        msg_type = data.get("messageType")
        
        if msg_type == "AuthenticationTokenResponse":
            token = data.get("data", {}).get("authenticationToken")
            if token:
                self.config["token"] = token
                self.save_config()
                await self.vts_authenticate()
                
        elif msg_type == "HotkeyTriggerResponse":
            pass 
        elif msg_type == "APIError":
            print(f"❌ [VTS Error] 명령 거부: {data.get('data', {}).get('message')}")
            
        elif msg_type in ["HotkeysInCurrentModelResponse", "ItemListResponse", "AvailableModelsResponse"]:
            cmd = "hotkeyList" if msg_type.startswith("Hotkey") else "itemList" if msg_type.startswith("Item") else "modelList"
            list_key = "availableHotkeys" if msg_type.startswith("Hotkey") else "availableItems" if msg_type.startswith("Item") else "availableModels"
            
            if self.cd_ws and self.last_context:
                await self.cd_ws.send(json.dumps({
                    "event": "sendToPropertyInspector", "context": self.last_context, 
                    "payload": {"command": cmd, "data": data.get("data", {}).get(list_key,[])}
                }))

    # ========================================================
    # CookieDeck 통신 로직
    # ========================================================
    async def cookiedeck_connect_loop(self):
        while True:
            try:
                async with websockets.connect(self.cd_uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    print("[CookieDeck] 🟢 Connected to main app!")
                    
                    async for message in ws:
                        await self.handle_cookiedeck_message(json.loads(message))
            except Exception as e:
                self.cd_ws = None
            await asyncio.sleep(2)

    async def handle_cookiedeck_message(self, data):
        try:
            event = data.get("event")
            context = data.get("context")
            
            if event == "keyDown":
                incoming_settings = data.get("payload", {}).get("settings", {})
                
                if incoming_settings:
                    if context not in self.context_settings:
                        self.context_settings[context] = {}
                    self.context_settings[context].update(incoming_settings)

                settings = self.context_settings.get(context, incoming_settings)
                action_type = settings.get("action_type", "hotkey")
                
                if not (self.vts_connected and self.vts_ws):
                    return

                req = None

                # ==================================================
                # 1. 줌(확대/축소), 회전, 투명도 로직 (다이얼용)
                # ==================================================
                if action_type in ["zoom_in", "zoom_out"]:
                    sense = float(settings.get("zoom_sense", 20))
                    base_zoom = (sense / 100.0) * 0.15
                    zoom_amount = base_zoom if action_type == "zoom_in" else -base_zoom
                    
                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecZoom",
                        "messageType": "MoveModelRequest",
                        "data": {
                            "timeInSeconds": 0,
                            "valuesAreRelativeToModel": True, 
                            "size": zoom_amount
                        }
                    }

                elif action_type in ["rotate_cw", "rotate_ccw"]:
                    sense = float(settings.get("zoom_sense", 20))
                    base_rot = (sense / 100.0) * 15.0 
                    rot_amount = base_rot if action_type == "rotate_cw" else -base_rot
                    
                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecRotRel",
                        "messageType": "MoveModelRequest",
                        "data": {
                            "timeInSeconds": 0,
                            "valuesAreRelativeToModel": True,
                            "rotation": rot_amount
                        }
                    }

                # 👉 신규 추가: 투명도 제어 (Opacity)
                elif action_type in ["opacity_cw", "opacity_ccw"]:
                    # 초기 투명도 설정 (기본값 255: 완전 선명함)
                    if context not in self.opacity_state:
                        self.opacity_state[context] = 255
                        
                    sense = float(settings.get("zoom_sense", 20))
                    step = int((sense / 100.0) * 25) # 다이얼 한 틱당 1~25 사이로 투명도 변화
                    
                    # 선명하게(+) 또는 투명하게(-)
                    if action_type == "opacity_cw":
                        self.opacity_state[context] = min(255, self.opacity_state[context] + step)
                    else:
                        self.opacity_state[context] = max(0, self.opacity_state[context] - step)
                        
                    # ColorTintRequest의 colorA (Alpha 값)을 사용해 투명도 제어!
                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecOpacity",
                        "messageType": "ColorTintRequest",
                        "data": {
                            "colorTint": {
                                "colorR": 255, "colorG": 255, "colorB": 255, 
                                "colorA": self.opacity_state[context]
                            },
                            "artMeshMatcher": {
                                "tintAll": True
                            }
                        }
                    }

                # ==================================================
                # 2. 이동 로직 (버튼/조이스틱용)
                # ==================================================
                elif action_type == "move_absolute":
                    time_sec = float(settings.get("abs_time", 0.5))
                    pos_x = float(settings.get("abs_x", 0.0))    
                    pos_y = float(settings.get("abs_y", 0.0))    
                    size_val = float(settings.get("abs_size", 0.0))
                    rot_val = float(settings.get("abs_rot", 0.0)) 
                    
                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecMoveAbs",
                        "messageType": "MoveModelRequest",
                        "data": {
                            "timeInSeconds": time_sec,
                            "valuesAreRelativeToModel": False, 
                            "positionX": pos_x,
                            "positionY": pos_y,
                            "size": size_val,
                            "rotation": rot_val
                        }
                    }

                elif action_type in ["move_up", "move_down", "move_left", "move_right"]:
                    sense = float(settings.get("move_sense", 30))
                    base_move = (sense / 100.0) * 0.1 
                    dx, dy = 0.0, 0.0
                    
                    if action_type == "move_up": dy = base_move
                    elif action_type == "move_down": dy = -base_move
                    elif action_type == "move_right": dx = base_move
                    elif action_type == "move_left": dx = -base_move
                    
                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecMoveRel",
                        "messageType": "MoveModelRequest",
                        "data": {
                            "timeInSeconds": 0,
                            "valuesAreRelativeToModel": True, 
                            "positionX": dx,
                            "positionY": dy
                        }
                    }

                # ==================================================
                # 3. 일반 동작 로직 (핫키, 아이템, 색상, 모델)
                # ==================================================
                elif action_type == "hotkey" and settings.get("hotkeyID"):
                    req = {"apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecHotkey", "messageType": "HotkeyTriggerRequest", "data": {"hotkeyID": settings.get("hotkeyID")}}
                elif action_type == "item" and settings.get("itemName"):
                    req = {"apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecItem", "messageType": "ItemLoadRequest", "data": {"fileName": settings.get("itemName"), "positionX": 0, "positionY": 0, "size": 0.3}}
                elif action_type == "color" and settings.get("colorHex"):
                    hex_color = settings.get("colorHex").lstrip('#')
                    if len(hex_color) == 6:
                        r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
                        req = {"apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecColor", "messageType": "ColorTintRequest", "data": {"colorTint": {"colorR": r, "colorG": g, "colorB": b, "colorA": 255}, "artMeshMatcher": {"tintAll": True}}}
                elif action_type == "model" and settings.get("modelID"):
                    req = {"apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecModel", "messageType": "ModelLoadRequest", "data": {"modelID": settings.get("modelID")}}

                if req:
                    await self.vts_ws.send(json.dumps(req))

            else:
                command = data.get("command") or data.get("payload", {}).get("command")
                if command in ["getHotkeys", "getItems", "getModels"]:
                    self.last_context = context 
                    if self.vts_connected and self.vts_ws:
                        req_type = "HotkeysInCurrentModelRequest" if command == "getHotkeys" else "ItemListRequest" if command == "getItems" else "AvailableModelsRequest"
                        req = {"apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": command, "messageType": req_type}
                        await self.vts_ws.send(json.dumps(req))
                
                elif command == "setVtsSettings":
                    settings = data.get("settings") or data.get("payload", {}).get("settings", {})
                    self.config["ip"] = settings.get("ip", "localhost")
                    self.config["port"] = int(settings.get("port", 8001))
                    self.save_config()
                    if self.vts_ws: await self.vts_ws.close()
                
                elif command == "getVtsSettings":
                    if self.cd_ws and context:
                        await self.cd_ws.send(json.dumps({
                            "event": "sendToPropertyInspector", "context": context,
                            "payload": {"command": "vtsSettings", "settings": self.config}
                        }))
                        
        except Exception as e:
            traceback.print_exc()

    async def run(self):
        await asyncio.gather(self.vts_connect_loop(), self.cookiedeck_connect_loop())

if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(VTubeStudioPlugin().run())