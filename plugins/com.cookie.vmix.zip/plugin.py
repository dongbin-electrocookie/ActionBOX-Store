import asyncio
import websockets
import json
import urllib.request
import urllib.parse

class VMixPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.vmix"
        self.cd_uri = "ws://localhost:8765"
        self.cd_ws = None
        
        # vMix의 기본 로컬 API 주소 (vMix 설정에서 웹 컨트롤이 켜져 있어야 함)
        self.vmix_url = "http://127.0.0.1:8088/api/"

    async def connect(self):
        while True:
            try:
                async with websockets.connect(self.cd_uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    print(f"[{self.PLUGIN_UUID}] CookieDeck 등록 완료.")
                    await self.listen_cookiedeck()
            except Exception as e:
                print(f"[{self.PLUGIN_UUID}] CookieDeck 연결 실패. 재시도 중... {e}")
                await asyncio.sleep(3)

    async def listen_cookiedeck(self):
        async for message in self.cd_ws:
            try:
                data = json.loads(message)
                if data.get("event") == "keyDown":
                    await self.on_key_down(data)
            except Exception:
                pass

    # =================================================================
    # 🚀 vMix로 HTTP GET 요청을 발사하는 함수
    # =================================================================
    def send_vmix_request(self, params):
        try:
            # 딕셔너리를 URL 파라미터로 변환 (예: Function=Cut&Input=1)
            query_string = urllib.parse.urlencode(params)
            req_url = f"{self.vmix_url}?{query_string}"
            
            # vMix 서버로 호출 (timeout=1초로 짧게 주어 메인 스레드 보호)
            with urllib.request.urlopen(req_url, timeout=1) as response:
                if response.status == 200:
                    print(f"[{self.PLUGIN_UUID}] ✅ vMix 전송 성공: {req_url}")
                else:
                    print(f"[{self.PLUGIN_UUID}] ⚠️ vMix 응답 코드: {response.status}")
        except Exception as e:
            print(f"[{self.PLUGIN_UUID}] ❌ vMix 연결 실패 (vMix가 켜져있나요?): {e}")

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        action = settings.get("vmix_action", "Cut")
        target_input = settings.get("target_input", "").strip()

        # vMix API에 보낼 명령어 조립
        params = {"Function": action}
        
        # 특정 입력(Input) 지정이 필요한 기능이라면 파라미터에 추가
        if target_input:
            params["Input"] = target_input

        # 메인 프로그램이 멈추지 않도록 백그라운드 스레드에서 전송
        await asyncio.to_thread(self.send_vmix_request, params)

async def main():
    plugin = VMixPlugin()
    await plugin.connect()

if __name__ == "__main__":
    asyncio.run(main())