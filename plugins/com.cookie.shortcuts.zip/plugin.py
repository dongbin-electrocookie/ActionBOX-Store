import asyncio
import glob
import json
import os
import subprocess
import sys
import time

try:
    import keyboard
    keyboard_available = True
except Exception:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except Exception:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

if IS_WINDOWS:
    try:
        import ctypes
    except Exception:
        ctypes = None
else:
    ctypes = None

VK_MAP = {
    0x11: 'ctrl', 0x10: 'shift', 0x12: 'alt', 0x5B: 'windows', 0x5C: 'windows',
    0x25: 'left', 0x26: 'up', 0x27: 'right', 0x28: 'down',
    0x0D: 'enter', 0x20: 'space', 0x1B: 'esc', 0x08: 'backspace', 0x09: 'tab',
    0x2E: 'delete', 0x2D: 'insert', 0x24: 'home', 0x23: 'end', 0x21: 'page up', 0x22: 'page down',
    0xBA: ';', 0xBB: '=', 0xBC: ',', 0xBD: '-', 0xBE: '.', 0xBF: '/', 0xC0: '`',
    0xDB: '[', 0xDC: '\\', 0xDD: ']', 0xDE: "'"
}
for i in range(65, 91):
    VK_MAP[i] = chr(i).lower()
for i in range(48, 58):
    VK_MAP[i] = chr(i)
for i in range(112, 124):
    VK_MAP[i] = f"f{i-111}"


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.is_recording = False
        self.app_list_cache = None
        self.context_settings = {}
        self.log_file = os.path.join(self.plugin_dir, "shortcuts_debug_log.txt")

        self.texts = {
            "en": {"timeout": "Scan timed out", "error": "Error while loading app list"},
            "ko": {"timeout": "스캔 시간 초과", "error": "목록을 불러오는 중 오류 발생"},
            "ja": {"timeout": "スキャン時間切れ", "error": "一覧読み込み中にエラーが発生しました"},
            "de": {"timeout": "Scan-Zeitüberschreitung", "error": "Fehler beim Laden der App-Liste"},
            "es": {"timeout": "Tiempo de escaneo agotado", "error": "Error al cargar la lista de apps"},
            "fr": {"timeout": "Délai d’analyse dépassé", "error": "Erreur lors du chargement de la liste des applications"},
            "ru": {"timeout": "Время сканирования истекло", "error": "Ошибка при загрузке списка приложений"},
            "it": {"timeout": "Timeout scansione", "error": "Errore durante il caricamento dell'elenco app"},
            "pt-PT": {"timeout": "Tempo de análise esgotado", "error": "Erro ao carregar a lista de apps"}
        }
        self.action_icon_map = {
            "open": "ACTION_OPEN",
            "hotkey": "ACTION_HOTKEY",
            "typetext": "ACTION_TYPETEXT",
            "runapp": "ACTION_RUNAPP"
        }

    def _log(self, msg):
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(msg + "\n")
        except Exception:
            pass

    def _lang(self, code):
        code = (code or "en").lower()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        code = alias.get(code, code)
        return code if code in self.texts else "en"

    def _get_action_key(self, action_id):
        action_id = (action_id or "").lower()
        if action_id.endswith(".open"):
            return "open"
        if action_id.endswith(".hotkey"):
            return "hotkey"
        if action_id.endswith(".typetext"):
            return "typetext"
        if action_id.endswith(".runapp"):
            return "runapp"
        return "open"

    def _get_icon_path(self, action_id):
        action_key = self._get_action_key(action_id)
        icon_name = self.action_icon_map.get(action_key, "ACTION_OPEN")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id):
        icon_path = self._get_icon_path(action_id)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return

        settings = dict(settings or {})
        action_key = self._get_action_key(action_id)

        if action_key == "open":
            meaningful_keys = ["path", "command", "builtin_icon_name", "default_visuals_initialized", "sync_title_on_path_change", "title"]
            default_settings = {
                "path": "",
                "command": "",
                "_lang": "en",
                "sync_title_on_path_change": False,
                "builtin_icon_name": self.action_icon_map["open"],
                "default_visuals_initialized": True
            }
        elif action_key == "hotkey":
            meaningful_keys = ["hotkey", "hotkey_custom", "command", "builtin_icon_name", "default_visuals_initialized", "sync_title_on_hotkey_change", "title"]
            default_settings = {
                "hotkey": "custom",
                "hotkey_custom": "",
                "command": "",
                "_lang": "en",
                "sync_title_on_hotkey_change": False,
                "builtin_icon_name": self.action_icon_map["hotkey"],
                "default_visuals_initialized": True
            }
        elif action_key == "typetext":
            meaningful_keys = ["text_to_type", "command", "builtin_icon_name", "default_visuals_initialized", "sync_title_on_text_change", "title"]
            default_settings = {
                "text_to_type": "",
                "command": "",
                "_lang": "en",
                "sync_title_on_text_change": False,
                "builtin_icon_name": self.action_icon_map["typetext"],
                "default_visuals_initialized": True
            }
        else:
            meaningful_keys = ["appid", "appname", "command", "builtin_icon_name", "default_visuals_initialized", "sync_title_on_app_change", "title"]
            default_settings = {
                "appid": "",
                "appname": "",
                "command": "",
                "_lang": "en",
                "sync_title_on_app_change": False,
                "builtin_icon_name": self.action_icon_map["runapp"],
                "default_visuals_initialized": True
            }

        meaningful = any(settings.get(k) not in ("", None, False) for k in meaningful_keys)
        if meaningful:
            self.context_settings[context] = settings.copy()
            return

        self.context_settings[context] = default_settings.copy()
        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": default_settings
        })
        await self._send_builtin_icon(context, action_id)

    def _get_installed_apps_windows(self, lang):
        try:
            ps_script = (
                "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
                "$apps = Get-StartApps | Select-Object Name, AppID; "
                "if ($apps) { ConvertTo-Json $apps -Compress } else { '[]' }"
            )
            cmd = ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps_script]
            creation_flags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0
            result = subprocess.run(cmd, capture_output=True, text=True, creationflags=creation_flags,
                                    encoding='utf-8', errors='ignore', timeout=15)
            output = result.stdout.strip()
            if not output:
                return []
            apps = json.loads(output)
            if isinstance(apps, dict):
                apps = [apps]
            if isinstance(apps, list):
                return sorted(apps, key=lambda x: x.get('Name', '').lower())
            return []
        except subprocess.TimeoutExpired:
            return [{"Name": self.texts[lang]["timeout"], "AppID": ""}]
        except Exception as e:
            self._log(f"[apps/windows] failed: {e}")
            return [{"Name": self.texts[lang]["error"], "AppID": ""}]

    def _get_installed_apps_macos(self, lang):
        apps = []
        seen = set()
        patterns = [
            "/Applications/*.app",
            "/Applications/*/*.app",
            os.path.expanduser("~/Applications/*.app"),
            os.path.expanduser("~/Applications/*/*.app"),
        ]
        for pattern in patterns:
            for path in glob.glob(pattern):
                if not os.path.isdir(path):
                    continue
                real = os.path.realpath(path)
                if real in seen:
                    continue
                seen.add(real)
                name = os.path.splitext(os.path.basename(path))[0]
                apps.append({"Name": name, "AppID": path})
        return sorted(apps, key=lambda x: x.get("Name", "").lower())

    def _get_installed_apps_linux(self, lang):
        apps = []
        seen = set()
        desktop_dirs = ["/usr/share/applications", "/usr/local/share/applications", os.path.expanduser("~/.local/share/applications")]
        for directory in desktop_dirs:
            for path in glob.glob(os.path.join(directory, "*.desktop")):
                if path in seen:
                    continue
                seen.add(path)
                name = os.path.splitext(os.path.basename(path))[0]
                try:
                    with open(path, "r", encoding="utf-8", errors="ignore") as f:
                        for line in f:
                            if line.startswith("Name="):
                                name = line.split("=", 1)[1].strip()
                                break
                except Exception:
                    pass
                apps.append({"Name": name, "AppID": path})
        return sorted(apps, key=lambda x: x.get("Name", "").lower())

    def _get_installed_apps(self, lang_code="en"):
        lang = self._lang(lang_code)
        if self.app_list_cache is not None:
            return self.app_list_cache
        if IS_WINDOWS:
            apps = self._get_installed_apps_windows(lang)
        elif IS_MACOS:
            apps = self._get_installed_apps_macos(lang)
        else:
            apps = self._get_installed_apps_linux(lang)
        self.app_list_cache = apps
        return apps

    def _normalize_hotkey(self, hotkey):
        s = (hotkey or "").strip().lower()
        if not s:
            return ""
        parts = [p.strip() for p in s.split("+") if p.strip()]
        alias = {
            "cmd": "command" if IS_MACOS else "windows",
            "command": "command" if IS_MACOS else "windows",
            "win": "command" if IS_MACOS else "windows",
            "windows": "command" if IS_MACOS else "windows",
            "control": "ctrl",
            "option": "option" if IS_MACOS else "alt",
            "escape": "esc",
            "return": "enter",
            "pgup": "pageup",
            "page up": "pageup",
            "pgdn": "pagedown",
            "page down": "pagedown",
            "del": "delete",
            "ins": "insert"
        }
        return "+".join(alias.get(p, p) for p in parts)

    def _translate_hotkey_for_platform(self, hotkey):
        hk = self._normalize_hotkey(hotkey)
        if not hk or not IS_MACOS:
            return hk

        mac_specific = {
            "windows+r": "command+space",
            "command+r": "command+space",
            "windows+e": "command+option+space",
            "command+e": "command+option+space",
            "windows+l": "ctrl+command+q",
            "command+l": "ctrl+command+q",
            "windows+d": "command+f3",
            "command+d": "command+f3",
            "windows+shift+s": "command+shift+5",
            "command+shift+s": "command+shift+5",
            "windows+v": "command+v",
            "command+v": "command+v",
            "ctrl+shift+esc": "command+option+esc",
            "ctrl+shift+escape": "command+option+esc",
            "alt+f4": "command+w",
            "option+f4": "command+w",
            "alt+tab": "command+tab",
            "option+tab": "command+tab",
        }
        if hk in mac_specific:
            return mac_specific[hk]

        parts = hk.split("+")
        converted = []
        for p in parts:
            if p == "ctrl":
                converted.append("command")
            elif p == "alt":
                converted.append("option")
            elif p in ("windows", "win"):
                converted.append("command")
            else:
                converted.append(p)
        return "+".join(converted)

    def _send_hotkey_blocking(self, hotkey):
        hk = self._translate_hotkey_for_platform(hotkey)
        if not hk:
            self._log("[hotkey] empty")
            return
        self._log(f"[hotkey] send -> {hk}")

        if IS_WINDOWS and keyboard_available:
            try:
                keyboard.press_and_release(hk)
                return
            except Exception as e:
                self._log(f"[hotkey] press_and_release failed: {e}")
            try:
                keyboard.send(hk)
                return
            except Exception as e:
                self._log(f"[hotkey] send failed: {e}")

        if not pyautogui_available:
            self._log("[hotkey] pyautogui unavailable")
            return
        try:
            parts = [p.strip() for p in hk.split("+") if p.strip()]
            if len(parts) == 1:
                pyautogui.press(parts[0])
            else:
                pyautogui.hotkey(*parts)
        except Exception as e:
            self._log(f"[hotkey] pyautogui failed: {e}")

    def _type_text_blocking(self, text):
        if not text:
            return
        if IS_WINDOWS and keyboard_available:
            try:
                keyboard.write(text, delay=0.01)
                return
            except TypeError:
                keyboard.write(text, 0.01)
                return
            except Exception as e:
                self._log(f"[type] keyboard failed: {e}")
        if pyautogui_available:
            try:
                pyautogui.write(text, interval=0.01)
            except Exception as e:
                self._log(f"[type] pyautogui failed: {e}")

    async def handle_message(self, data):
        event = data.get("event")
        action_id = data.get("action", "")
        command = data.get("command") or data.get("payload", {}).get("command")
        context = data.get("context") or data.get("payload", {}).get("context")
        payload = data.get("payload", {}) or {}
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                merged = dict(cached)
                merged.update(settings or {})
                self.context_settings[context] = merged
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_id)
            return

        if event == "keyDown":
            await self.on_key_down(data)
        elif command == "get_app_list":
            lang_code = data.get("payload", {}).get("lang", "en")
            apps = await asyncio.to_thread(self._get_installed_apps, lang_code)
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {"command": "app_list_result", "apps": apps}
            })
        elif command == "start_recording":
            if not self.is_recording:
                self.is_recording = True

                async def _record_task():
                    try:
                        hotkey = await asyncio.to_thread(self._poll_hardware_keys)
                        await self.runner.send_message({
                            "event": "sendToPropertyInspector",
                            "context": context,
                            "payload": {"command": "recording_finished", "hotkey": hotkey}
                        })
                    finally:
                        self.is_recording = False
                asyncio.create_task(_record_task())

    def _poll_hardware_keys_windows(self):
        if not ctypes:
            return ""
        start_time = time.time()
        modifiers_set = {'ctrl', 'shift', 'alt', 'windows'}
        modifier_order = ['ctrl', 'shift', 'alt', 'windows']
        captured_mods = []
        captured_keys = []
        capture_started = False
        all_released_at = None

        while time.time() - start_time < 10.0:
            pressed_keys = []
            for vk, name in VK_MAP.items():
                if ctypes.windll.user32.GetAsyncKeyState(vk) & 0x8000:
                    if name not in pressed_keys:
                        pressed_keys.append(name)

            for mod in modifier_order:
                if mod in pressed_keys and mod not in captured_mods:
                    captured_mods.append(mod)

            non_mods = [k for k in pressed_keys if k not in modifiers_set]
            if non_mods:
                capture_started = True
                all_released_at = None
                for key in non_mods:
                    if key not in captured_keys:
                        captured_keys.append(key)
            elif capture_started and not pressed_keys:
                if all_released_at is None:
                    all_released_at = time.time()
                elif time.time() - all_released_at >= 0.12:
                    return "+".join(captured_mods + captured_keys)
            else:
                all_released_at = None

            time.sleep(0.01)
        return "+".join(captured_mods + captured_keys) if captured_keys else ""

    def _poll_hardware_keys_pynput(self):
        try:
            from pynput import keyboard as pynput_keyboard
        except Exception as e:
            self._log(f"[record] pynput unavailable: {e}")
            return ""

        captured = {"value": "", "released_at": None, "started": False}
        active_keys = set()
        modifiers = set()
        captured_mods = []
        captured_keys = []
        start_time = time.time()

        def key_to_name(key):
            if key in (pynput_keyboard.Key.ctrl, pynput_keyboard.Key.ctrl_l, pynput_keyboard.Key.ctrl_r):
                return "ctrl"
            if key in (pynput_keyboard.Key.shift, pynput_keyboard.Key.shift_l, pynput_keyboard.Key.shift_r):
                return "shift"
            if key in (pynput_keyboard.Key.alt, pynput_keyboard.Key.alt_l, pynput_keyboard.Key.alt_r):
                return "option" if IS_MACOS else "alt"
            if key in (pynput_keyboard.Key.cmd, pynput_keyboard.Key.cmd_l, pynput_keyboard.Key.cmd_r):
                return "command" if IS_MACOS else "windows"
            special = {
                pynput_keyboard.Key.enter: "enter",
                pynput_keyboard.Key.esc: "esc",
                pynput_keyboard.Key.backspace: "backspace",
                pynput_keyboard.Key.tab: "tab",
                pynput_keyboard.Key.space: "space",
                pynput_keyboard.Key.delete: "delete",
                pynput_keyboard.Key.home: "home",
                pynput_keyboard.Key.end: "end",
                pynput_keyboard.Key.page_up: "pageup",
                pynput_keyboard.Key.page_down: "pagedown",
                pynput_keyboard.Key.left: "left",
                pynput_keyboard.Key.right: "right",
                pynput_keyboard.Key.up: "up",
                pynput_keyboard.Key.down: "down",
            }
            if key in special:
                return special[key]
            name = getattr(key, "char", None)
            if name:
                return name.lower()
            text = str(key).replace("Key.", "").lower()
            return text

        def on_press(key):
            name = key_to_name(key)
            active_keys.add(name)
            if name in {"ctrl", "shift", "alt", "option", "windows", "command"}:
                modifiers.add(name)
                if name not in captured_mods:
                    captured_mods.append(name)
                return True

            captured["started"] = True
            captured["released_at"] = None
            if name not in captured_keys:
                captured_keys.append(name)
            return True

        def on_release(key):
            name = key_to_name(key)
            active_keys.discard(name)
            modifiers.discard(name)
            return True

        try:
            with pynput_keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
                while listener.running and time.time() - start_time < 10.0:
                    if captured["started"] and not active_keys:
                        if captured["released_at"] is None:
                            captured["released_at"] = time.time()
                        elif time.time() - captured["released_at"] >= 0.12:
                            order = ["ctrl", "shift", "alt", "option", "windows", "command"]
                            mods = [m for m in order if m in captured_mods]
                            captured["value"] = "+".join(mods + captured_keys)
                            break
                    elif active_keys:
                        captured["released_at"] = None
                    time.sleep(0.02)
                listener.stop()
        except Exception as e:
            self._log(f"[record] listener failed: {e}")
            return ""
        if captured["value"]:
            return captured["value"]
        order = ["ctrl", "shift", "alt", "option", "windows", "command"]
        mods = [m for m in order if m in captured_mods]
        return "+".join(mods + captured_keys) if captured_keys else ""

    def _poll_hardware_keys(self):
        if IS_WINDOWS:
            return self._poll_hardware_keys_windows()
        return self._poll_hardware_keys_pynput()

    async def on_key_down(self, data):
        action_id = data.get("action")
        context = data.get("context")
        payload_settings = data.get("payload", {}).get("settings")
        incoming_settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = dict(cached)
        settings.update(incoming_settings or {})
        if context:
            self.context_settings[context] = settings

        command = settings.get("command")
        self._log(f"[keyDown] action={action_id} context={context} command={command} settings={settings}")

        if action_id == "com.cookie.shortcuts.open":
            path = command or settings.get("path")
            if path:
                await asyncio.to_thread(self.open_path, path)

        elif action_id == "com.cookie.shortcuts.hotkey":
            hotkey_preset = settings.get("hotkey")
            hotkey_to_send = command or (settings.get("hotkey_custom") if hotkey_preset == 'custom' else hotkey_preset)
            if hotkey_to_send:
                await asyncio.to_thread(self._send_hotkey_blocking, hotkey_to_send)
            else:
                self._log("[hotkey] missing hotkey_to_send")

        elif action_id == "com.cookie.shortcuts.typetext":
            text = command or settings.get("text_to_type")
            if text:
                await asyncio.to_thread(self._type_text_blocking, text)

        elif action_id == "com.cookie.shortcuts.runapp":
            app_id = command or settings.get("appid")
            if app_id:
                await asyncio.to_thread(self.run_application, app_id)

    def run_application(self, app_id):
        try:
            if IS_WINDOWS:
                if "\\" in app_id or ":" in app_id or os.path.exists(app_id):
                    self.open_path(app_id)
                else:
                    os.startfile(f"shell:AppsFolder\\{app_id}")
            elif IS_MACOS:
                if app_id.endswith(".app") or os.path.exists(app_id):
                    subprocess.Popen(["open", app_id], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    subprocess.Popen(["open", "-a", app_id], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                self.open_path(app_id)
        except Exception as e:
            self._log(f"[runapp] failed: {e}")

    def open_path(self, path):
        try:
            path = os.path.expandvars(os.path.expanduser(str(path).strip()))
            if not path:
                return
            if IS_WINDOWS:
                os.startfile(path)
            elif IS_MACOS:
                subprocess.Popen(['open', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen(['xdg-open', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            self._log(f"[open] failed: {e}")
