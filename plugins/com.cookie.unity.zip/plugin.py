import asyncio
import pyautogui

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        cmd_type = settings.get("cmd_type")
        key_val = settings.get("key_val", "")

        if not key_val: return

        try:
            if cmd_type == "single":
                pyautogui.press(key_val)
            elif cmd_type == "combo":
                # ctrl+shift+f 같은 조합키 처리
                keys = key_val.split('+')
                pyautogui.hotkey(*keys)
        except Exception as e:
            print(f"[Unity Plugin] Input Error: {e}")

        # 하드웨어 LCD 타이틀 실시간 동기화 (0xDD 명령으로 자동 변환됨)
        title = settings.get("title", "Unity")
        await self.runner.send_message({
            "event": "setTitle",
            "context": data.get("context"),
            "payload": {"title": title}
        })