import asyncio
import os
import sys

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    print("[Zoom Plugin] 'keyboard' library is missing. pyautogui fallback will be used when available.")
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    print("[Zoom Plugin] 'pyautogui' library is missing.")
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.windows_action_map = {
            "toggle_mic": "alt+a",
            "toggle_cam": "alt+v",
            "toggle_share": "alt+s",
            "toggle_hand": "alt+y",
            "leave_meeting": "alt+q",
            "toggle_chat": "alt+h",
            "toggle_participants": "alt+u",
            "toggle_record": "alt+r",
            "mute_all": "alt+m"
        }

        self.macos_action_map = {
            "toggle_mic": "command+shift+a",
            "toggle_cam": "command+shift+v",
            "toggle_share": "command+shift+s",
            "toggle_hand": "option+y",
            "leave_meeting": "command+w",
            "toggle_chat": "command+shift+h",
            "toggle_participants": "command+u",
            "toggle_record": "command+shift+r",
            "mute_all": "command+control+m"
        }

        self.action_map = self.macos_action_map if IS_MACOS else self.windows_action_map

        self.icon_map = {
            "toggle_mic": "STATE_TOGGLE_MIC",
            "toggle_cam": "STATE_TOGGLE_CAM",
            "toggle_share": "STATE_TOGGLE_SHARE",
            "toggle_hand": "STATE_TOGGLE_HAND",
            "leave_meeting": "STATE_LEAVE_MEETING",
            "toggle_chat": "STATE_TOGGLE_CHAT",
            "toggle_participants": "STATE_TOGGLE_PARTICIPANTS",
            "toggle_record": "STATE_TOGGLE_RECORD",
            "mute_all": "STATE_MUTE_ALL"
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "toggle_mic", "STATE_TOGGLE_MIC")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if context and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "command", "zoom_action", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "toggle_mic"
        new_settings = {
            "zoom_action": default_action,
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })
        await self._send_builtin_icon(context, default_action)

    def _normalize_pyautogui_key(self, key_name):
        key = str(key_name).strip().lower()
        aliases = {
            "ctrl": "ctrl",
            "control": "ctrl",
            "cmd": "command" if IS_MACOS else "win",
            "command": "command" if IS_MACOS else "win",
            "win": "command" if IS_MACOS else "win",
            "windows": "command" if IS_MACOS else "win",
            "alt": "option" if IS_MACOS else "alt",
            "option": "option" if IS_MACOS else "alt",
            "return": "enter",
            "plus": "+",
        }
        return aliases.get(key, key)

    def _send_hotkey_sync(self, hotkey):
        if not hotkey:
            return

        if IS_WINDOWS and keyboard_available:
            keyboard.send(hotkey)
            return

        if not pyautogui_available:
            print(f"[Zoom Plugin] Cannot send hotkey because pyautogui is unavailable: {hotkey}")
            return

        parts = [self._normalize_pyautogui_key(part) for part in hotkey.split('+') if part.strip()]
        if not parts:
            return

        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or settings.get("zoom_action") or "toggle_mic")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("command") or settings.get("zoom_action")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(self._send_hotkey_sync, hotkey)
