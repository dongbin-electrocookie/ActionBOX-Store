/* Shared editor. Only shared_shortcut is owned here; action/title/icon/API
 * settings are never repurposed as keyboard fields. */
(() => {
    'use strict';
    const script=document.currentScript, actionID=script?.dataset.shortcutAction;
    if(!actionID || window.ComboXShortcutEditor) return;
    const rootURL=new URL('.',script.src || document.baseURI);
    let config,state={},socket,context,currentScope,owned,pending,recording=false,lastError;
    let platform=/Mac/.test(navigator.platform || '')?'darwin':'windows';
    let lang='en',texts={},section,display,note,record,append,reset,sides;
    const fallback={label:'Shortcut',record:'Record shortcut',append:'Record next step',reset:'Restore default',
        waiting:'Press and release the keys…',
        unavailable:'No default shortcut is available. You can register your own.',
        error:'Recording failed or timed out. Check input permissions and try again.',
        backend_missing:'The Windows recording component is missing. Reinstall or update COMBO-X.',
        busy:'Another shortcut recording is in progress. Finish it and try again.',
        timeout:'No complete shortcut was recorded. Press and release the keys, then try again.',
        listener_stopped:'The keyboard recorder stopped unexpectedly. Check the error below and try again.',
        too_many_steps:'A shortcut can contain at most 32 steps.',
        sides:'Distinguish left/right modifier keys',numpad:'Numeric keypad'};
    const t=key=>texts[key] || fallback[key] || key;
    const active=()=>!config?.HotkeyModeOnly || (state.control_mode || 'hotkey')==='hotkey';
    function selected(settings=state) {
        let value=config?.Default || '';
        for(const key of config?.SelectionKeys || ['command']) {
            if(settings[key]!==undefined && settings[key]!==null && settings[key]!==''){value=String(settings[key]);break;}
        }
        return config?.Aliases?.[value] || value;
    }
    function scope(settings=state){return JSON.stringify([selected(settings),settings.control_mode || 'hotkey',settings.execution_environment || 'desktop']);}
    function defaultSteps(){
        let defaults=config.Defaults?.[platform] || {};
        if(config.EnvironmentProfiles) defaults=defaults[state.execution_environment || 'desktop'] || {};
        let result=defaults[selected()];
        if(!Object.prototype.hasOwnProperty.call(defaults,selected()) && config.LiteralSelection) result=[selected().split('+')];
        if(config.EditLastSequence && selected()==='edit_last') result=state.edit_last_mode==='up'?[['up']]:[['up'],['e']];
        return result;
    }
    function override(){return owned?.scope===scope()?owned.platforms?.[platform]:null;}
    function keyLabel(key){
        return window.ComboXShortcutKeys?.label(key,platform,texts) || key;
    }
    function render(){
        if(!section) return;
        section.hidden=!active();
        const custom=override();
        let steps=custom?.enabled?custom.steps:defaultSteps();
        if(!custom && config.LegacyCustomField && state[config.LegacyCustomField]) steps=[state[config.LegacyCustomField].split('+')];
        display.textContent=recording?t('waiting'):steps?.map(step=>step.map(keyLabel).join(' + ')).join(' → ') || t('unavailable');
        // Reserve this line for errors, not a permanent Default/Custom badge.
        note.textContent=lastError ? t(lastError.key)+(lastError.detail?'\n'+lastError.detail:'') : '';
        record.textContent=t('record');append.textContent=t('append');reset.textContent=t('reset');
        sides.parentElement.querySelector('span').textContent=t('sides');
        record.disabled=recording;append.disabled=recording || !steps?.length;
        section.querySelector('label').textContent=t('label');
    }
    async function language(value){
        lang=value || 'en';
        try{texts=await(await fetch(new URL('locales/'+lang+'.json',rootURL))).json();}catch(_){texts={};}
        render();
    }
    function adopt(settings){
        if(!config){state={...settings};return;}
        const nextScope=scope(settings);
        if(currentScope!==undefined && nextScope!==currentScope){
            owned=undefined;pending=undefined;recording=false;lastError=undefined;
            if(config.LegacyCustomField) settings[config.LegacyCustomField]='';
        }else if(settings.shared_shortcut?.version===1 && settings.shared_shortcut.scope===nextScope){
            owned=structuredClone(settings.shared_shortcut);
        }
        currentScope=nextScope;state={...settings};render();
    }
    function persist(){
        const payload={...state};
        if(owned) payload.shared_shortcut=owned;
        if(config.LegacyCustomField) payload[config.LegacyCustomField]='';
        if(new URLSearchParams(location.search).get('popup')==='true'){
            adopt(payload);window.parent.postMessage({event:'saveSettingsToParent',payload},'*');
        }else socket.send(JSON.stringify({event:'setSettings',context,key:context,payload}));
    }
    function start(adding=false){
        if(!socket || recording || !active()) return;
        lastError=undefined;
        pending={id:crypto.randomUUID(),scope:scope(),adding};recording=true;render();
        socket.send(JSON.stringify({event:'startSharedHotkeyRecording',context,request_id:pending.id,distinguish_modifier_sides:sides.checked}));
        const id=pending.id;
        setTimeout(()=>{if(pending?.id===id) fail('timeout');},11500);
    }
    function fail(reason,detail){
        const errorKeys={'recording-backend-missing':'backend_missing','recorder-busy':'busy',
            'timeout':'timeout','recorder-stopped':'listener_stopped','too-many-steps':'too_many_steps'};
        const key=errorKeys[reason] || 'error';
        // Plain text only. Keep the failure until retry/reset or a different
        // action is selected; localization/settings refresh must not erase it.
        lastError={key,detail:String(detail || (!errorKeys[reason] ? reason || '' : '')).slice(0,512)};
        pending=undefined;recording=false;render();
    }
    function message(event){
        let data;try{data=JSON.parse(event.data);}catch(_){return;}
        if(data.event==='didReceiveGlobalSettings' || data.event==='applicationDidLaunch'){
            if(data.payload?.platform) platform=data.payload.platform.startsWith('win')?'windows':data.payload.platform;
            language(data.payload?.language);render();
        }
        if(data.event==='didReceiveSettings') adopt({...data.payload});
        if(data.event==='sendToPropertyInspector' && data.payload?.command==='native_recording_unavailable' && pending){
            if(data.payload.request_id && data.payload.request_id!==pending.id) return;
            fail(data.payload.reason,data.payload.detail);
        }
        if(data.event==='sendToPropertyInspector' && data.payload?.command==='shared_recording_finished'){
            const result=data.payload;
            if(!pending || result.request_id!==pending.id || pending.scope!==scope()) return;
            const adding=pending.adding;pending=undefined;recording=false;
            const keys=result.keys || (result.hotkey || '').split('+').filter(Boolean);
            if(!keys.length){fail(result.reason,result.detail);return;}
            const previous=override()?.steps || defaultSteps() || [];
            const steps=adding?[...previous,keys]:[keys];
            if(steps.length>32){fail('too-many-steps');return;}
            lastError=undefined;
            owned={version:1,scope:scope(),platforms:{...(owned?.platforms || {}),[platform]:{enabled:true,steps}}};
            persist();render();
        }
    }
    function observe(ws){
        socket=ws;
        if(ws.__sharedShortcutObserved) return;
        ws.__sharedShortcutObserved=true;
        if(ws.addEventListener) ws.addEventListener('message',message);
        else{const old=ws.onmessage;ws.onmessage=e=>{message(e);old?.call(ws,e);};}
    }
    const originalSend=WebSocket.prototype.send;
    WebSocket.prototype.send=function(raw){
        let data;try{data=JSON.parse(raw);}catch(_){return originalSend.call(this,raw);}
        if(data.event==='registerPropertyInspector'){context=data.context || data.key;observe(this);}
        if(data.event==='setSettings' && config && this===socket){
            const incoming={...(data.payload || {})};
            if(currentScope!==undefined && scope(incoming)!==currentScope){
                owned=undefined;pending=undefined;recording=false;lastError=undefined;delete incoming.shared_shortcut;
                if(config.LegacyCustomField) incoming[config.LegacyCustomField]='';
            }else if(owned) incoming.shared_shortcut=owned;
            adopt(incoming);data.payload=incoming;raw=JSON.stringify(data);
        }
        return originalSend.call(this,raw);
    };
    function mount(){
        section=document.createElement('div');section.className='shared-shortcut-editor';
        section.innerHTML='<div class="sdpi-item"><label></label><div class="sdpi-item-value shared-hotkey" tabindex="0" role="button"></div></div>'+
            '<div class="shared-shortcut-buttons"><button type="button"></button><button type="button"></button><button type="button"></button></div>'+
            '<label class="shared-shortcut-sides"><input type="checkbox"><span></span></label><div class="mini-note shared-shortcut-note" role="status" aria-live="polite"></div>';
        display=section.querySelector('.shared-hotkey');[record,append,reset]=section.querySelectorAll('button');
        sides=section.querySelector('input');note=section.querySelector('.shared-shortcut-note');
        // Keep one scroll owner: the existing app form. Its native controls
        // stay first; this shared keyboard editor is the last form section.
        let form=document.querySelector('body > .sdpi-wrapper') || document.querySelector('.sdpi-wrapper');
        if(!form){
            form=document.createElement('div');form.className='sdpi-wrapper';
            const title=document.querySelector('iframe[src*="title_pi"]');
            if(title) title.after(form);else document.body.prepend(form);
        }
        form.append(section);
        record.onclick=()=>start();append.onclick=()=>start(true);display.onclick=()=>start();
        display.onkeydown=e=>{if(e.key==='Enter' || e.key===' '){e.preventDefault();start();}};
        reset.onclick=()=>{pending=undefined;recording=false;lastError=undefined;
            owned={version:1,scope:scope(),platforms:{...(owned?.platforms || {}),[platform]:{enabled:false}}};persist();render();};
        if(config.LegacyCustomField) document.getElementById('custom-hotkey')?.closest('.sdpi-item')?.setAttribute('hidden','');
        const css=document.createElement('link');css.rel='stylesheet';css.href=new URL('editor.css',rootURL);document.head.append(css);
        render();
    }
    function prepareSettings(settings){
        if(!config) return settings;
        const incoming={...settings};
        if(currentScope!==undefined && scope(incoming)!==currentScope){
            owned=undefined;pending=undefined;recording=false;lastError=undefined;delete incoming.shared_shortcut;
            if(config.LegacyCustomField) incoming[config.LegacyCustomField]='';
        }else if(owned) incoming.shared_shortcut=owned;
        adopt(incoming);return incoming;
    }
    window.addEventListener('message',event=>{
        if(event.data?.event==='loadSettingsFromParent'){
            adopt({...event.data.payload});if(event.data.language) language(event.data.language);
        }
    });
    window.ComboXShortcutEditor={message,adopt,scope,render,start,keyLabel,prepareSettings};
    const ready=document.readyState==='loading'?new Promise(r=>document.addEventListener('DOMContentLoaded',r,{once:true})):Promise.resolve();
    Promise.all([fetch('./manifest.json').then(r=>r.json()),ready]).then(([manifest])=>{
        config=manifest.Actions?.find(a=>a.UUID===actionID)?.SharedShortcut;
        if(config?.Version!==1) throw Error('Unsupported shared shortcut editor version');
        mount();if(Object.keys(state).length) adopt(state);language(lang);
        if(socket) socket.send(JSON.stringify({event:'getSettings',context,key:context}));
    }).catch(error=>console.error('[Shared Shortcuts]',error));
})();
