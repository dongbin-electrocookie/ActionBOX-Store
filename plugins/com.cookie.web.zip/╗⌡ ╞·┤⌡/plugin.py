import asyncio
import json
import webbrowser
import os
import subprocess
import sys
import io

# --- 라이브러리 임포트 및 예외 처리 ---
libraries_ok = False
requests = None
BeautifulSoup = None
urljoin = None
urlparse = None
winreg = None
Image = None

try:
    import requests
    from bs4 import BeautifulSoup
    from urllib.parse import urljoin, urlparse
    if sys.platform == "win32":
        import winreg
    from PIL import Image
    libraries_ok = True
except ImportError as e:
    print(f"[Web Plugin Error] Missing libraries: {e}")
    # sys.exit(1) <--- 절대 금지 (러너 전체가 죽음)

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.available_browsers = self.find_installed_browsers() if libraries_ok else {}
        # print(f"[{self.uuid}] Found browsers: {self.available_browsers}")

    async def handle_message(self, data):
        if not libraries_ok:
            return

        event = data.get("event")
        
        if event == "keyDown":
            await self.on_key_down(data)
        elif event == "fetchIcon":
            await self.on_fetch_icon(data)
        elif event == "getAvailableBrowsers":
            await self.on_get_browsers(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        url = settings.get("url")
        browser_path = settings.get("browser", "default")
        
        if url:
            if not url.startswith(('http://', 'https://')): 
                url = 'https://' + url
            
            # 브라우저 실행 (Blocking 될 수 있으므로 스레드로 분리 권장)
            # webbrowser.open은 보통 non-blocking이지만, subprocess는 blocking일 수 있음
            await asyncio.to_thread(self._open_url, url, browser_path)

    def _open_url(self, url, browser_path):
        if browser_path == "default":
            webbrowser.open(url)
        else:
            try: 
                subprocess.Popen([browser_path, url])
            except Exception: 
                webbrowser.open(url)

    async def on_fetch_icon(self, data):
        context = data.get("context")
        url = data.get("payload", {}).get("url")
        
        if context and url:
            # 아이콘 다운로드 및 가공은 무거운 작업이므로 스레드로 분리 (기존 로직 유지)
            icon_path = await asyncio.to_thread(self.fetch_and_save_favicon, url)
            
            if icon_path:
                # 러너를 통해 메인 프로그램으로 아이콘 설정 요청 전송
                await self.runner.send_message({
                    "event": "setIcon", 
                    "context": context, 
                    "payload": {"icon_path": icon_path}
                })

    async def on_get_browsers(self, data):
        context = data.get("context")
        if context:
            # PI(설정창)로 브라우저 목록 전송
            await self.runner.send_message({
                "event": "sendToPropertyInspector", 
                "context": context,
                "payload": { 
                    "event": "didReceiveAvailableBrowsers", 
                    "browsers": self.available_browsers 
                }
            })

    # --- [헬퍼] 브라우저 스캔 기능 (기존 코드 유지) ---
    def find_installed_browsers(self):
        if sys.platform != "win32" or not winreg: return {}
        
        browser_exes = {
            "chrome.exe": "Google Chrome",
            "msedge.exe": "Microsoft Edge",
            "firefox.exe": "Mozilla Firefox",
            "opera.exe": "Opera",
            "vivaldi.exe": "Vivaldi",
            "brave.exe": "Brave",
            "whale.exe": "Naver Whale",
            "Arc.exe": "Arc Browser",
            "DuckDuckGo.exe": "DuckDuckGo Browser",
            "comet.exe": "Comet Browser" 
        }
        
        installed_browsers = {}
        app_paths_key = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"
        
        for exe, name in browser_exes.items():
            try:
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, os.path.join(app_paths_key, exe))
                path, _ = winreg.QueryValueEx(key, None)
                installed_browsers[name] = path
                winreg.CloseKey(key)
            except FileNotFoundError:
                try:
                    key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, os.path.join(app_paths_key, exe))
                    path, _ = winreg.QueryValueEx(key, None)
                    installed_browsers[name] = path
                    winreg.CloseKey(key)
                except FileNotFoundError: pass
        return installed_browsers

    # --- [헬퍼] 아이콘 다운로드 및 가공 기능 (기존 코드 유지) ---

    def fetch_and_save_favicon(self, url):
        base_path = os.path.dirname(os.path.abspath(__file__))
        default_icon_path = os.path.join(base_path, "default.jpg")

        try:
            if not url.startswith(('http://', 'https://')): 
                url = 'https://' + url
            headers = {'User-Agent': 'Mozilla/5.0'}
            
            response = requests.get(url, headers=headers, timeout=5)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            icon_link = soup.find("link", rel=lambda r: r and 'icon' in r.lower())
            icon_url = None
            
            if icon_link and icon_link.get('href'):
                icon_url = urljoin(url, icon_link['href'])
            else:
                fallback_url = urljoin(url, '/favicon.ico')
                try:
                    if requests.head(fallback_url, headers=headers, timeout=2).ok:
                        icon_url = fallback_url
                except requests.exceptions.RequestException:
                    pass

            if not icon_url:
                print(f"[{self.uuid}] Favicon not found for {url}. Using default icon.")
                return default_icon_path if os.path.exists(default_icon_path) else None

            icon_response = requests.get(icon_url, headers=headers, timeout=5)
            icon_response.raise_for_status()

            # --- ▼▼▼▼▼ 이미지 처리 부분 핵심 수정 ▼▼▼▼▼ ---

            icon_data = io.BytesIO(icon_response.content)
            img = Image.open(icon_data)
            
            # 1. 원본 이미지를 RGBA 모드로 변환 (투명도 채널 확보)
            img = img.convert("RGBA")
            
            # 2. 96x96으로 리사이즈 (기존과 동일)
            img = img.resize((96, 96), Image.Resampling.LANCZOS)

            # 3. 배경색(R,G,B = 60,60,60)으로 채워진 새 배경 이미지 생성
            #    크기는 최종 목표인 128x128
            background_color = (60, 60, 60)
            background = Image.new('RGB', (128, 128), background_color)

            # 4. 배경 위에 리사이즈된 아이콘을 중앙에 붙여넣기
            #    img.split()[-1]은 RGBA의 A(알파) 채널을 마스크로 사용하여
            #    투명한 부분은 배경색이 보이도록 합니다.
            bg_w, bg_h = background.size
            img_w, img_h = img.size
            offset = ((bg_w - img_w) // 2, (bg_h - img_h) // 2)
            background.paste(img, offset, img.split()[-1])
            
            # --- ▲▲▲▲▲ 이미지 처리 부분 핵심 수정 ▲▲▲▲▲ ---

            # 파일 저장 (저장할 때는 PNG가 아닌 JPG로 저장해야 용량이 작아집니다)
            cache_dir = "favicon_cache"
            os.makedirs(cache_dir, exist_ok=True)
            
            domain = urlparse(url).netloc
            safe_filename = "".join(c for c in domain if c.isalnum() or c in ('-', '_')).rstrip()
            
            # ▼▼▼ [수정] 저장 형식을 JPG로 변경 (투명도가 없으므로) ▼▼▼
            save_path = os.path.join(cache_dir, f"{safe_filename}.jpg") 
            background.save(save_path, 'JPEG', quality=90) # JPEG으로 저장
            
            return os.path.abspath(save_path)
            
        except Exception as e:
            print(f"[{self.uuid}] Icon fetch error: {e}. Using default icon.")
            return default_icon_path if os.path.exists(default_icon_path) else None