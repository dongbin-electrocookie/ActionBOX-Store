# Discord Pro / Discord API

This plugin sets an explicit mute or deafen state through the official desktop
Discord RPC interface. It does not invite a bot, install a Discord client mod,
use a normal user's account token, or fall back to toggle hotkeys.

## Local setup

1. Start the Discord desktop app and sign into the account being tested.
2. In ComboX, open a Discord API button and enter your application's **Application
   ID** from the Discord Developer Portal.
3. Enter that application's **OAuth2 Client Secret** into the password field.
   This is not a bot token. Do not share it in chat or include it in a distribution.
4. Leave Redirect URI blank for the local RPC flow. If your application requires
   one for token exchange, use the exact registered URI (including trailing slash).
5. Click **Connect / Authorize Discord** and approve the access request in Discord.
   A prompt is only expected when Discord accepts the authorization request;
   previously granted access may not need another prompt.
6. Wait for **Discord authenticated**, then test the mute/unmute and
   deafen/undeafen buttons. Each command waits for Discord's response and checks
   the returned state before reporting success.

**Creating an application does not grant unrestricted RPC access.** Discord's
approval / tester restrictions still apply. `rpc` and `rpc.voice.write` access
can be rejected before a consent prompt appears. The status area reports safe
error categories and numeric Discord/HTTP codes; it never displays raw responses
that might contain credentials. There is no permission-bypass mechanism.

## Credentials and lifetime

- The password field is cleared after connecting. Client Secret, authorization
  code, access token and refresh token are **not written to button settings,
  plugin files, logs, or messages sent back to the inspector**.
- The secret and OAuth tokens are held only in the plugin process's memory.
  They are sent only to the local ComboX runner / Discord IPC and the fixed HTTPS
  Discord token endpoint as required by OAuth. HTTP redirects are refused.
- A connected session is shared by buttons using the same Application ID and
  Redirect URI. Tokens can refresh while ComboX remains open. Discord restarts
  trigger a fresh IPC handshake/authentication on the next action, not an
  automatic replay of an uncertain command.
- **After restarting ComboX, enter the secret and authorize again.** Persistent
  credential storage is intentionally not implemented in this version.
- **Disconnect / Forget** closes the local session and clears its in-memory
  credentials; it does not revoke authorization in the Discord account. Revoke
  that separately in Discord's Authorized Apps settings if required.
- Discord documents that closing an RPC controller can restore the voice settings
  that existed before it took control. Switching to a different app ID, disconnecting
  or quitting ComboX may therefore restore earlier mute/deafen states.
- Desktop IPC probes slots 0–9. Windows uses bounded nonblocking named-pipe I/O;
  macOS/Linux use the documented Unix-domain socket locations. Browser/mobile
  Discord is not an RPC transport.

## References

- https://discord.com/developers/docs/topics/rpc#authenticating
- https://discord.com/developers/docs/topics/rpc#authorize
- https://discord.com/developers/docs/topics/rpc#setvoicesettings
- https://discord.com/developers/docs/topics/oauth2
- https://discord.com/developers/docs/topics/opcodes-and-status-codes#rpc

Automated tests mock Discord/OAuth. No test approves a real account, reads actual
credentials, or changes the running Discord client's audio state.

## Verification (2026-10-26)

- 31 authorization/transport/inspector tests passed on system Python and the
  Windows embedded runtime. Three tests use a uniquely named, owned Windows pipe
  with a fake Discord server, not the running Discord client's pipes.
- Four-skin inspector layout checks plus runner import and package-name regressions
  passed (44 selected tests total on the application Python runtime).
- A separate pre-existing store-name test cannot run because
  `internal_plugins/store/locales/en.json` is absent in this checkout. The same
  failure was reproduced using the pre-change Discord Pro backup; store files
  were not created or modified as part of this work.
- Real Discord OAuth approval / permission eligibility still needs to be tested
  locally by the application owner. No real Client Secret was accessed in testing.
- `cookiedeck.py`, the ordinary Discord plugin, and existing artwork are unchanged.
