import asyncio
import platform

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 영상 편집 실무자를 위한 프리미어 단축키 맵
        self.action_map = {
            # 1. 파일 및 기본 편집
            "file_save": "ctrl+s",
            "file_export": "ctrl+m",
            "edit_undo": "ctrl+z",
            "edit_redo": "ctrl+shift+z",
            "edit_copy": "ctrl+c",
            "edit_paste": "ctrl+v",
            "edit_ripple_delete": "shift+delete", # 잔물결 삭제 (최애 기능)

            # 2. 툴바 (Tools)
            "tool_selection": "v",
            "tool_track_select": "a",
            "tool_ripple_edit": "b",
            "tool_razor": "c",
            "tool_slip": "y",
            "tool_pen": "p",
            "tool_hand": "h",
            "tool_zoom": "z",
            "tool_type": "t",

            # 3. 타임라인 컷편집 (Timeline)
            "timeline_add_edit": "ctrl+k", # 현재 트랙 자르기
            "timeline_add_edit_all": "ctrl+shift+k", # 모든 트랙 자르기
            "timeline_trim_in": "q", # 플레이헤드 기준 왼쪽 다 자르고 땡기기
            "timeline_trim_out": "w", # 플레이헤드 기준 오른쪽 다 자르고 땡기기

            # 4. 재생 및 탐색 (Playback)
            "play_toggle": "space",
            "play_reverse": "j",
            "play_stop": "k",
            "play_forward": "l",
            "play_prev_frame": "left",
            "play_next_frame": "right",

            # 5. 마커 및 인/아웃 (Markers & In/Out)
            "mark_in": "i",
            "mark_out": "o",
            "mark_clear": "ctrl+shift+x",
            "marker_add": "m",
            "marker_next": "shift+m",
            "marker_prev": "ctrl+shift+m",

            # 6. 화면/타임라인 뷰 (View)
            "view_zoom_in": "=",
            "view_zoom_out": "-",
            "view_fit": "\\" # 역슬래시 (타임라인 한눈에 보기)
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("pr_action", "tool_selection")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)