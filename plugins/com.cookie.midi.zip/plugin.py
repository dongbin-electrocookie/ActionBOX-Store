import asyncio
import os

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.current_octave_shift = 0
        self.context_settings = {}

        self.icon_map = {
            "note": "TYPE_NOTE",
            "cc": "TYPE_CC",
            "pc": "TYPE_PC",
            "octave_up": "OCTAVE_UP",
            "octave_down": "OCTAVE_DOWN",
            "transport_play": "TRANSPORT_PLAY",
            "transport_stop": "TRANSPORT_STOP",
            "transport_record": "TRANSPORT_RECORD",
            "transport_rewind": "TRANSPORT_REWIND",
            "transport_fastforward": "TRANSPORT_FASTFORWARD",
            "transport_cycle": "TRANSPORT_CYCLE",
            "track_prev": "TRACK_PREV",
            "track_next": "TRACK_NEXT",
        }

    def _default_settings(self):
        visual_key = "note"
        return {
            "midi_type": "note",
            "channel": "1",
            "d1": "60",
            "d2": "100",
            "octave_dir": "up",
            "transport_action": "play",
            "track_dir": "next",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[visual_key],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        merged["builtin_icon_name"] = self.icon_map.get(self._get_visual_key(merged), "TYPE_NOTE")
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("midi_type"),
            s.get("channel"),
            s.get("d1"),
            s.get("d2"),
            s.get("octave_dir"),
            s.get("transport_action"),
            s.get("track_dir"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_visual_key(self, settings):
        midi_type = (settings or {}).get("midi_type", "note")
        if midi_type == "note":
            return "note"
        if midi_type == "cc":
            return "cc"
        if midi_type == "pc":
            return "pc"
        if midi_type == "octave":
            return "octave_down" if (settings or {}).get("octave_dir", "up") == "down" else "octave_up"
        if midi_type == "transport":
            return f"transport_{(settings or {}).get('transport_action', 'play')}"
        if midi_type == "track":
            return f"track_{(settings or {}).get('track_dir', 'next')}"
        return "note"

    def _get_icon_path(self, visual_key):
        icon_name = self.icon_map.get(visual_key or "note", "TYPE_NOTE")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, visual_key):
        icon_path = self._get_icon_path(visual_key)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, self._get_visual_key(defaults))
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        visual_key = data.get("visual_key") or payload.get("visual_key")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            await self._send_builtin_icon(context, visual_key or self._get_visual_key({**cached, **settings}))
            return

        if event == "keyDown":
            await self.process_midi(data, is_pressed=True)
        elif event == "keyUp":
            await self.process_midi(data, is_pressed=False)

    async def process_midi(self, data, is_pressed):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = settings

        midi_type = settings.get("midi_type", "note")
        channel = int(settings.get("channel", 1)) - 1

        status = 0
        d1 = 0
        d2 = 0

        if midi_type == "note":
            d1 = int(settings.get("d1", 60))
            d1 = max(0, min(127, d1 + self.current_octave_shift))
            if is_pressed:
                status = 0x90 | channel
                d2 = int(settings.get("d2", 100))
            else:
                status = 0x80 | channel
                d2 = 0

        elif midi_type == "cc":
            if not is_pressed:
                return
            status = 0xB0 | channel
            d1 = int(settings.get("d1", 60))
            d2 = int(settings.get("d2", 127))

        elif midi_type == "pc":
            if not is_pressed:
                return
            status = 0xC0 | channel
            d1 = int(settings.get("d1", 0))
            d2 = 0

        elif midi_type == "octave":
            if not is_pressed:
                return
            direction = settings.get("octave_dir", "up")
            if direction == "up":
                self.current_octave_shift = min(48, self.current_octave_shift + 12)
            else:
                self.current_octave_shift = max(-48, self.current_octave_shift - 12)

            # Preserve original feedback behavior
            oct_text = f"Octave\n{'+' if self.current_octave_shift > 0 else ''}{self.current_octave_shift // 12}"
            if self.current_octave_shift == 0:
                oct_text = "Octave\n0"
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": oct_text}
            })
            return

        elif midi_type == "transport":
            t_action = settings.get("transport_action", "play")
            t_map = {"rewind": 91, "fastforward": 92, "stop": 93, "play": 94, "record": 95, "cycle": 86}
            d1 = t_map.get(t_action, 94)
            d2 = 127 if is_pressed else 0
            status = 0x90 | channel

        elif midi_type == "track":
            track_dir = settings.get("track_dir", "next")
            d1 = 48 if track_dir == "prev" else 49
            d2 = 127 if is_pressed else 0
            status = 0x90 | channel

        else:
            return

        payload = {
            "event": "sendToPlugin",
            "context": context,
            "payload": {
                "command": "direct_serial",
                "serial_cmd": 0x70,
                "serial_data": [status, d1, d2]
            }
        }
        await self.runner.send_message(payload)
