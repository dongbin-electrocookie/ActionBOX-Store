import asyncio
import websockets
import json
import os
import hashlib
import base64
import platform
import time

class OBSPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.obs"
        self.uri = "ws://localhost:8765"
        self.websocket = None
        
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_file = os.path.join(self.plugin_dir, 'obs_config.json')
        
        self.obs_request_queue = asyncio.Queue()
        self.obs_connection_task = None
        self.is_obs_connected = False
        
        self.desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
        
        # 🚀 [대통합] 멀티액션 시 누락되는 타겟 정보(장면, 소스 등)를 기억합니다.
        self.last_valid_settings = {}

    # ... (connect, register, listen 로직은 기존과 동일) ...

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {})
        
        # 🚀 1. 유효한 설정이 들어오면 기억해둡니다 (캐시 업데이트)
        if incoming_settings:
            # 설정값이 있는 항목만 업데이트
            self.last_valid_settings.update({k: v for k, v in incoming_settings.items() if v})

        # 🚀 2. 메모리와 현재 데이터를 합칩니다 (멀티액션 대응)
        final_settings = {**self.last_valid_settings, **incoming_settings}
        
        # 🚀 3. [표준화] 'command'를 우선 확인하고, 없으면 기존 'obs_action'을 사용합니다.
        obs_action = final_settings.get("command") or final_settings.get("obs_action", "stream_toggle")
        
        req_type = None
        req_data = {}

        # 1. 방송/녹화/가상카메라
        if obs_action == "stream_toggle": req_type = "ToggleStream"
        elif obs_action == "record_toggle": req_type = "ToggleRecord"
        elif obs_action == "virtual_cam_toggle": req_type = "ToggleVirtualCam"
        
        # 2. 리플레이 버퍼
        elif obs_action == "replay_buffer_toggle": req_type = "ToggleReplayBuffer"
        elif obs_action == "replay_buffer_save": req_type = "SaveReplayBuffer"
        
        # 3. 마커 추가
        elif obs_action == "stream_marker": req_type = "CreateStreamMarker"
        elif obs_action == "record_chapter": 
            req_type = "CreateRecordChapter"
            req_data = {"chapterName": "CookieDeck Marker"}

        # 4. 스튜디오 모드 & 트랜지션
        elif obs_action == "studio_mode_toggle": req_type = "ToggleStudioMode"
        elif obs_action == "trigger_transition": req_type = "TriggerStudioModeTransition"
        elif obs_action == "set_transition":
            target_trans = final_settings.get("target_transition")
            if target_trans:
                req_type = "SetCurrentSceneTransition"
                req_data = {"transitionName": target_trans}

        # 5. 장면/소스 제어
        elif obs_action == "change_scene":
            target_sc = final_settings.get("target_scene")
            if target_sc: 
                req_type = "SetCurrentProgramScene"
                req_data = {"sceneName": target_sc}

        elif obs_action == "toggle_source":
            target_nm = final_settings.get("target_name", "")
            parts = target_nm.split(';')
            if len(parts) == 2:
                req_type = "ToggleSceneItemEnabled"
                req_data = {"sceneName": parts[0].strip(), "sceneItemName": parts[1].strip()}

        elif obs_action == "filter_control":
            src = final_settings.get("target_input")
            flt = final_settings.get("filter_name")
            state = final_settings.get("enable_state", "true") == "true"
            if src and flt:
                req_type = "SetSourceFilterEnabled"
                req_data = {"sourceName": src, "filterName": flt, "filterEnabled": state}

        # 6. 미디어/오디오/스크린샷
        elif obs_action == "media_play_pause":
            inp = final_settings.get("target_input")
            if inp: 
                req_type = "TriggerMediaInputAction"
                req_data = {"inputName": inp, "mediaAction": "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_PLAY_PAUSE"}
        
        elif obs_action == "media_restart":
            inp = final_settings.get("target_input")
            if inp: 
                req_type = "TriggerMediaInputAction"
                req_data = {"inputName": inp, "mediaAction": "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_RESTART"}

        elif obs_action == "toggle_mute":
            inp = final_settings.get("target_input")
            if inp: 
                req_type = "ToggleInputMute"
                req_data = {"inputName": inp}

        elif obs_action == "screenshot_source":
            src = final_settings.get("target_input")
            if src:
                req_type = "SaveSourceScreenshot"
                timestamp = time.strftime("%Y%m%d_%H%M%S")
                filename = f"OBS_{src}_{timestamp}.png".replace(" ", "_")
                save_path = os.path.join(self.desktop_path, filename).replace("\\", "/")
                req_data = {"sourceName": src, "imageFormat": "png", "imageFilePath": save_path}

        if req_type:
            await self.send_to_obs(req_type, req_data, f"{obs_action}-{context}")

    # ... (나머지 클래스 메서드는 기존과 동일) ...