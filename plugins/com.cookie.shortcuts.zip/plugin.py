import asyncio
import os
import shutil
import subprocess
import sys
import time

try:
    import keyboard
    keyboard_available = True
except Exception:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except Exception:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

if IS_WINDOWS:
    try:
        import ctypes
    except Exception:
        ctypes = None
else:
    ctypes = None

VK_MAP = {
    0x11: 'ctrl', 0x10: 'shift', 0x12: 'alt', 0x5B: 'windows', 0x5C: 'windows',
    0x25: 'left', 0x26: 'up', 0x27: 'right', 0x28: 'down',
    0x0D: 'enter', 0x20: 'space', 0x1B: 'esc', 0x08: 'backspace', 0x09: 'tab',
    0x2E: 'delete', 0x2D: 'insert', 0x24: 'home', 0x23: 'end', 0x21: 'page up', 0x22: 'page down',
    0xBA: ';', 0xBB: '=', 0xBC: ',', 0xBD: '-', 0xBE: '.', 0xBF: '/', 0xC0: '`',
    0xDB: '[', 0xDC: '\\', 0xDD: ']', 0xDE: "'"
}
for i in range(65, 91):
    VK_MAP[i] = chr(i).lower()
for i in range(48, 58):
    VK_MAP[i] = chr(i)
for i in range(112, 124):
    VK_MAP[i] = f"f{i-111}"


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.is_recording = False
        self.context_settings = {}
        base_path = os.environ.get("ACTIONBOX_BASE_PATH") or os.path.dirname(os.path.dirname(os.path.dirname(self.plugin_dir)))
        self.log_file = os.path.join(base_path, "logs", "shortcuts_debug.log")

        self.action_icon_map = {
            "hotkey": "ACTION_HOTKEY",
            "typetext": "ACTION_TYPETEXT"
        }

    def _log(self, msg):
        if os.environ.get("COMBOX_FILE_LOGS", "0").strip().lower() not in {"1", "true", "yes", "on"}:
            return
        try:
            os.makedirs(os.path.dirname(self.log_file), exist_ok=True)
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(msg + "\n")
        except Exception:
            pass

    def _get_action_key(self, action_id):
        action_id = (action_id or "").lower()
        if action_id.endswith(".hotkey"):
            return "hotkey"
        if action_id.endswith(".typetext"):
            return "typetext"
        return None

    def _get_icon_path(self, action_id, icon_name=None):
        if not icon_name:
            action_key = self._get_action_key(action_id)
            if not action_key:
                return None
            icon_name = self.action_icon_map.get(action_key)

        if not icon_name:
            return None

        icon_name = os.path.basename(str(icon_name)).replace(".png", "")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id, icon_name=None):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        if not icon_name and context:
            cached_settings = self.context_settings.get(context, {}) or {}
            icon_name = cached_settings.get("builtin_icon_name")

        icon_path = self._get_icon_path(action_id, icon_name)
        if icon_path and os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return

        settings = dict(settings or {})
        action_key = self._get_action_key(action_id)
        if not action_key:
            return

        if action_key == "hotkey":
            meaningful_keys = ["hotkey", "hotkey_custom", "command", "builtin_icon_name", "default_visuals_initialized", "sync_title_on_hotkey_change", "title"]
            default_settings = {
                "hotkey": "custom",
                "hotkey_custom": "",
                "command": "",
                "_lang": "en",
                "sync_title_on_hotkey_change": False,
                "distinguish_modifier_sides": False,
                "builtin_icon_name": self.action_icon_map["hotkey"],
                "default_visuals_initialized": True
            }
        elif action_key == "typetext":
            meaningful_keys = ["text_to_type", "command", "builtin_icon_name", "default_visuals_initialized", "sync_title_on_text_change", "title"]
            default_settings = {
                "text_to_type": "",
                "command": "",
                "_lang": "en",
                "sync_title_on_text_change": False,
                "builtin_icon_name": self.action_icon_map["typetext"],
                "default_visuals_initialized": True
            }
        meaningful = any(settings.get(k) not in ("", None, False) for k in meaningful_keys)
        if meaningful:
            self.context_settings[context] = settings.copy()
            return

        self.context_settings[context] = default_settings.copy()
        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": default_settings
        })
        await self._send_builtin_icon(context, action_id)

    def _normalize_hotkey(self, hotkey):
        s = (hotkey or "").strip().lower()
        if not s:
            return ""
        parts = [p.strip() for p in s.split("+") if p.strip()]
        alias = {
            "cmd": "command" if IS_MACOS else "windows",
            "command": "command" if IS_MACOS else "windows",
            "win": "command" if IS_MACOS else "windows",
            "windows": "command" if IS_MACOS else "windows",
            "control": "ctrl",
            "option": "option" if IS_MACOS else "alt",
            "alt": "option" if IS_MACOS else "alt",
            "escape": "esc",
            "return": "enter",
            "pgup": "pageup",
            "page up": "pageup",
            "pgdn": "pagedown",
            "page down": "pagedown",
            "del": "delete",
            "ins": "insert"
        }
        normalized = []
        for part in parts:
            side, separator, base = part.partition(' ')
            if separator and side in ('left', 'right'):
                normalized.append(side + ' ' + alias.get(base, base))
            else:
                normalized.append(alias.get(part, part))
        return "+".join(normalized)

    def _translate_hotkey_for_platform(self, hotkey):
        # OS-specific presets now store the actual chord. Only normalize key
        # names, just like the host's local-input path. Semantic remapping here
        # used to turn Command+L into Lock Screen and Control into Command.
        return self._normalize_hotkey(hotkey)

    def _translate_hotkey_for_keyboard_lib(self, hotkey):
        hk = self._normalize_hotkey(hotkey)
        if not hk:
            return ""
        # The Windows `keyboard` module uses spaced names for paging keys,
        # while pyautogui uses pageup/pagedown. Keep both backends happy.
        keyboard_alias = {
            "pageup": "page up",
            "pagedown": "page down",
            "esc": "esc",
        }
        return "+".join(keyboard_alias.get(p, p) for p in hk.split("+"))

    def _send_windows_virtual_hotkey(self, hotkey):
        if not IS_WINDOWS or ctypes is None: return False
        try:
            from utility.shortcut_shared import load_shared
        except ModuleNotFoundError:
            from shortcut_shared import load_shared
        return load_shared().windows_keys(self._normalize_hotkey(hotkey).split('+'), backend=ctypes, sleep=time.sleep)

    def _send_hotkey_blocking(self, hotkey):
        hk = self._translate_hotkey_for_platform(hotkey)
        if not hk:
            self._log("[hotkey] empty")
            return
        self._log(f"[hotkey] send -> {hk}")

        if self._send_windows_virtual_hotkey(hk):
            return

        if IS_MACOS and self._send_macos_native_hotkey(hk):
            return

        if IS_WINDOWS and keyboard_available:
            keyboard_hk = self._translate_hotkey_for_keyboard_lib(hk)
            try:
                keyboard.press_and_release(keyboard_hk)
                return
            except Exception as e:
                self._log(f"[hotkey] press_and_release failed: {e}")
            try:
                keyboard.send(keyboard_hk)
                return
            except Exception as e:
                self._log(f"[hotkey] send failed: {e}")

        if not pyautogui_available:
            self._log("[hotkey] pyautogui unavailable")
            return
        try:
            parts = [p.strip() for p in hk.split("+") if p.strip()]
            if len(parts) == 1:
                pyautogui.press(parts[0])
            else:
                pyautogui.hotkey(*parts)
        except Exception as e:
            self._log(f"[hotkey] pyautogui failed: {e}")

    def _send_macos_native_hotkey(self, hotkey):
        if not IS_MACOS: return False
        parts = self._normalize_hotkey(hotkey).split('+')
        if len(parts)==2 and parts[0] in ('ctrl','control'):
            if parts[1] in ('left','right'): return self._switch_macos_space(1 if parts[1]=='right' else -1)
            if parts[1]=='up':
                return subprocess.run(['open','-a','Mission Control'], stdout=subprocess.DEVNULL,
                                      stderr=subprocess.DEVNULL, timeout=3).returncode==0
        try:
            from utility.shortcut_shared import load_shared
        except ModuleNotFoundError:
            from shortcut_shared import load_shared
        return load_shared().mac_keys(parts, sleep=time.sleep)

    def _switch_macos_space(self, direction):
        """Switch adjacent macOS Spaces through the WindowServer API."""
        if not IS_MACOS or direction not in (-1, 1):
            return False
        try:
            import ctypes as mac_ctypes
            import objc

            sky = mac_ctypes.CDLL(
                "/System/Library/PrivateFrameworks/SkyLight.framework/SkyLight"
            )
            sky.CGSMainConnectionID.argtypes = []
            sky.CGSMainConnectionID.restype = mac_ctypes.c_uint32
            sky.CGSCopyManagedDisplaySpaces.argtypes = [mac_ctypes.c_uint32]
            sky.CGSCopyManagedDisplaySpaces.restype = mac_ctypes.c_void_p
            sky.CGSGetActiveSpace.argtypes = [mac_ctypes.c_uint32]
            sky.CGSGetActiveSpace.restype = mac_ctypes.c_uint64
            setter = sky.CGSManagedDisplaySetCurrentSpace
            setter.argtypes = [
                mac_ctypes.c_uint32,
                mac_ctypes.c_void_p,
                mac_ctypes.c_uint64,
            ]
            setter.restype = mac_ctypes.c_int32

            connection = sky.CGSMainConnectionID()
            rows_pointer = sky.CGSCopyManagedDisplaySpaces(connection)
            if not rows_pointer:
                return False
            displays = objc.objc_object(c_void_p=rows_pointer)
            active = int(sky.CGSGetActiveSpace(connection))
            display = next(
                (
                    row for row in displays
                    if int((row.get("Current Space") or {}).get("ManagedSpaceID", 0))
                    == active
                ),
                displays[0] if displays else None,
            )
            if display is None:
                return False
            spaces = [
                int(space.get("ManagedSpaceID", 0))
                for space in (display.get("Spaces") or [])
                if int(space.get("ManagedSpaceID", 0)) > 0
            ]
            if active not in spaces:
                return False
            target_index = spaces.index(active) + int(direction)
            if not 0 <= target_index < len(spaces):
                return True
            identifier = display.get("Display Identifier")
            objc_identifier = getattr(identifier, "__pyobjc_object__", None)
            if objc_identifier is None:
                import Foundation
                identifier = Foundation.NSString.stringWithString_(str(identifier))
                objc_identifier = getattr(identifier, "__pyobjc_object__", None)
            if objc_identifier is None:
                return False
            return int(setter(
                connection,
                objc.pyobjc_id(objc_identifier),
                spaces[target_index],
            )) == 0
        except Exception as exc:
            self._log(f"[hotkey] direct Space switch failed: {exc}")
            return False

    def _set_windows_clipboard_text(self, text):
        if ctypes is None:
            return False

        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        user32.OpenClipboard.argtypes = [ctypes.c_void_p]
        user32.OpenClipboard.restype = ctypes.c_int
        user32.EmptyClipboard.restype = ctypes.c_int
        user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
        user32.SetClipboardData.restype = ctypes.c_void_p
        kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
        kernel32.GlobalAlloc.restype = ctypes.c_void_p
        kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
        kernel32.GlobalLock.restype = ctypes.c_void_p
        kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
        kernel32.GlobalFree.argtypes = [ctypes.c_void_p]

        opened = False
        memory_handle = None
        try:
            for _ in range(10):
                if user32.OpenClipboard(None):
                    opened = True
                    break
                time.sleep(0.02)
            if not opened or not user32.EmptyClipboard():
                return False

            encoded = (str(text) + "\0").encode("utf-16-le")
            memory_handle = kernel32.GlobalAlloc(0x0002, len(encoded))
            if not memory_handle:
                return False
            memory_pointer = kernel32.GlobalLock(memory_handle)
            if not memory_pointer:
                return False
            try:
                ctypes.memmove(memory_pointer, encoded, len(encoded))
            finally:
                kernel32.GlobalUnlock(memory_handle)

            if not user32.SetClipboardData(13, memory_handle):  # CF_UNICODETEXT
                return False
            memory_handle = None  # Clipboard now owns the allocated memory.
            return True
        finally:
            if memory_handle:
                kernel32.GlobalFree(memory_handle)
            if opened:
                user32.CloseClipboard()

    def _set_clipboard_text_blocking(self, text):
        try:
            if IS_WINDOWS:
                return self._set_windows_clipboard_text(text)
            if IS_MACOS:
                subprocess.run(
                    ["pbcopy"], input=str(text), text=True, encoding="utf-8", check=True
                )
                return True

            clipboard_commands = (
                (["wl-copy"], "wl-copy"),
                (["xclip", "-selection", "clipboard"], "xclip"),
                (["xsel", "--clipboard", "--input"], "xsel"),
            )
            for command, executable in clipboard_commands:
                if shutil.which(executable):
                    subprocess.run(
                        command, input=str(text), text=True, encoding="utf-8", check=True
                    )
                    return True
        except Exception as e:
            self._log(f"[type] clipboard set failed: {e}")
        return False

    def _type_text_blocking(self, text):
        if not text:
            return
        if self._set_clipboard_text_blocking(text):
            time.sleep(0.03)
            self._send_hotkey_blocking("cmd+v" if IS_MACOS else "ctrl+v")
            return
        self._log("[type] clipboard unavailable; falling back to simulated typing")
        if IS_WINDOWS and keyboard_available:
            try:
                keyboard.write(text, delay=0.01)
                return
            except TypeError:
                keyboard.write(text, 0.01)
                return
            except Exception as e:
                self._log(f"[type] keyboard failed: {e}")
        if pyautogui_available:
            try:
                pyautogui.write(text, interval=0.01)
            except Exception as e:
                self._log(f"[type] pyautogui failed: {e}")

    async def handle_message(self, data):
        event = data.get("event")
        action_id = data.get("action", "")
        command = data.get("command") or data.get("payload", {}).get("command")
        context = data.get("context") or data.get("payload", {}).get("context")
        payload = data.get("payload", {}) or {}
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                merged = dict(cached)
                merged.update(settings or {})
                self.context_settings[context] = merged
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_id, payload.get("builtin_icon_name"))
            return

        if event == "keyDown":
            await self.on_key_down(data)
        elif command == "start_recording":
            if not self.is_recording:
                self.is_recording = True

                async def _record_task():
                    try:
                        distinguish_sides = payload.get('distinguish_modifier_sides') is True
                        hotkey = await asyncio.to_thread(self._poll_hardware_keys, distinguish_sides)
                        await self.runner.send_message({
                            "event": "sendToPropertyInspector",
                            "context": context,
                            "payload": {"command": "recording_finished", "hotkey": hotkey}
                        })
                    finally:
                        self.is_recording = False
                asyncio.create_task(_record_task())

    def _poll_hardware_keys_windows(self, distinguish_sides=False):
        try:
            from utility.shortcut_shared import load_shared
        except ModuleNotFoundError:
            from shortcut_shared import load_shared
        return '+'.join(load_shared().record_windows(distinguish_sides, clock=time))

    def _poll_hardware_keys_pynput(self, distinguish_sides=False):
        try:
            from pynput import keyboard as pynput_keyboard
        except Exception as e:
            self._log(f"[record] pynput unavailable: {e}")
            return ""

        captured = {"value": "", "released_at": None, "started": False}
        active_keys = set()
        modifiers = set()
        captured_mods = []
        captured_keys = []
        start_time = time.time()

        def key_to_name(key):
            if distinguish_sides:
                sided_keys = {
                    pynput_keyboard.Key.ctrl_l: 'left ctrl', pynput_keyboard.Key.ctrl_r: 'right ctrl',
                    pynput_keyboard.Key.shift_l: 'left shift', pynput_keyboard.Key.shift_r: 'right shift',
                    pynput_keyboard.Key.alt_l: 'left option' if IS_MACOS else 'left alt',
                    pynput_keyboard.Key.alt_r: 'right option' if IS_MACOS else 'right alt',
                    pynput_keyboard.Key.cmd_l: 'left command' if IS_MACOS else 'left windows',
                    pynput_keyboard.Key.cmd_r: 'right command' if IS_MACOS else 'right windows',
                }
                if key in sided_keys:
                    return sided_keys[key]
                vk = getattr(key, 'vk', None)
                if IS_WINDOWS and vk is not None and (65 <= vk <= 90 or 48 <= vk <= 57):
                    return chr(vk).lower()
                if IS_WINDOWS and vk in VK_MAP and vk >= 0xBA:
                    return VK_MAP[vk]
                if IS_WINDOWS and vk is not None and 0x60 <= vk <= 0x69:
                    return f'num{vk - 0x60}'
                if IS_WINDOWS and vk in (0x6A, 0x6B, 0x6D, 0x6E, 0x6F):
                    return {0x6A:'multiply', 0x6B:'add', 0x6D:'subtract', 0x6E:'decimal', 0x6F:'divide'}[vk]
            if key in (pynput_keyboard.Key.ctrl, pynput_keyboard.Key.ctrl_l, pynput_keyboard.Key.ctrl_r):
                return "ctrl"
            if key in (pynput_keyboard.Key.shift, pynput_keyboard.Key.shift_l, pynput_keyboard.Key.shift_r):
                return "shift"
            if key in (pynput_keyboard.Key.alt, pynput_keyboard.Key.alt_l, pynput_keyboard.Key.alt_r):
                return "option" if IS_MACOS else "alt"
            if key in (pynput_keyboard.Key.cmd, pynput_keyboard.Key.cmd_l, pynput_keyboard.Key.cmd_r):
                return "command" if IS_MACOS else "windows"
            special = {
                pynput_keyboard.Key.enter: "enter",
                pynput_keyboard.Key.esc: "esc",
                pynput_keyboard.Key.backspace: "backspace",
                pynput_keyboard.Key.tab: "tab",
                pynput_keyboard.Key.space: "space",
                pynput_keyboard.Key.delete: "delete",
                pynput_keyboard.Key.home: "home",
                pynput_keyboard.Key.end: "end",
                pynput_keyboard.Key.page_up: "pageup",
                pynput_keyboard.Key.page_down: "pagedown",
                pynput_keyboard.Key.left: "left",
                pynput_keyboard.Key.right: "right",
                pynput_keyboard.Key.up: "up",
                pynput_keyboard.Key.down: "down",
            }
            if key in special:
                return special[key]
            name = getattr(key, "char", None)
            if name:
                return name.lower()
            text = str(key).replace("Key.", "").lower()
            return text

        def on_press(key):
            name = key_to_name(key)
            vk = getattr(key, 'vk', None)
            identity = ('vk', vk) if distinguish_sides and vk is not None else key
            active_keys.add(identity)
            # Any key, including a modifier by itself, starts recording.
            captured["started"] = True
            captured["released_at"] = None

            if name.removeprefix('left ').removeprefix('right ') in {"ctrl", "shift", "alt", "option", "windows", "command"}:
                modifiers.add(name)
                if name not in captured_mods:
                    captured_mods.append(name)
                return True

            if name not in captured_keys:
                captured_keys.append(name)
            return True

        def on_release(key):
            name = key_to_name(key)
            vk = getattr(key, 'vk', None)
            identity = ('vk', vk) if distinguish_sides and vk is not None else key
            active_keys.discard(identity)
            modifiers.discard(name)
            return True

        def win32_event_filter(msg, data):
            # AltGr can generate a synthetic Ctrl event. Ignore that event,
            # never a genuine physical Ctrl press. Known extended AltGr Ctrl
            # packets carry scan 0x21D or the right-Alt make code with E0.
            if data.vkCode in (0x11, 0xA2) and (
                data.flags & 0x10 or data.scanCode == 0x21D
                or (data.scanCode == 0x38 and data.flags & 0x01)
            ):
                return False
            return True

        listener_options = {'on_press': on_press, 'on_release': on_release}
        if IS_WINDOWS and distinguish_sides:
            listener_options['win32_event_filter'] = win32_event_filter
        modifier_order = [base for name in ('ctrl', 'shift', 'alt', 'option', 'windows', 'command')
                          for base in (name, 'left ' + name, 'right ' + name)]
        try:
            with pynput_keyboard.Listener(**listener_options) as listener:
                while listener.running and time.time() - start_time < 10.0:
                    if captured["started"] and not active_keys:
                        if captured["released_at"] is None:
                            captured["released_at"] = time.time()
                        elif time.time() - captured["released_at"] >= 0.12:
                            order = modifier_order
                            mods = [m for m in order if m in captured_mods]
                            captured["value"] = "+".join(mods + captured_keys)
                            break
                    elif active_keys:
                        captured["released_at"] = None
                    time.sleep(0.02)
                listener.stop()
        except Exception as e:
            self._log(f"[record] listener failed: {e}")
            return ""
        if captured["value"]:
            return captured["value"]
        order = modifier_order
        mods = [m for m in order if m in captured_mods]
        return "+".join(mods + captured_keys) if (mods or captured_keys) else ""

    def _poll_hardware_keys(self, distinguish_sides=False):
        if IS_WINDOWS:
            return self._poll_hardware_keys_windows(distinguish_sides)
        return self._poll_hardware_keys_pynput(distinguish_sides)

    async def on_key_down(self, data):
        action_id = data.get("action")
        context = data.get("context")
        payload_settings = data.get("payload", {}).get("settings")
        incoming_settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = dict(cached)
        settings.update(incoming_settings or {})
        if context:
            self.context_settings[context] = settings

        command = settings.get("command")
        if action_id == "com.cookie.shortcuts.typetext":
            self._log(
                f"[keyDown] action={action_id} context={context} "
                f"chars={len(str(command or settings.get('text_to_type') or ''))}"
            )
        else:
            self._log(f"[keyDown] action={action_id} context={context} command={command} settings={settings}")

        if action_id == "com.cookie.shortcuts.hotkey":
            hotkey_preset = settings.get("hotkey")
            hotkey_custom = settings.get("hotkey_custom")

            # The selected preset/custom value is authoritative. `command` is
            # only a backward-compatibility mirror and may be stale in older
            # saved mappings.
            if hotkey_preset == "custom":
                hotkey_to_send = hotkey_custom or command
            else:
                hotkey_to_send = hotkey_preset or command
            if hotkey_to_send:
                await asyncio.to_thread(self._send_hotkey_blocking, hotkey_to_send)
            else:
                self._log("[hotkey] missing hotkey_to_send")

        elif action_id == "com.cookie.shortcuts.typetext":
            text = command or settings.get("text_to_type")
            if text:
                await asyncio.to_thread(self._type_text_blocking, text)
