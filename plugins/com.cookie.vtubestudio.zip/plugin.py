import asyncio
import json
import websockets

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.vts_uri = "ws://localhost:8001" # VTS 기본 포트
        self.auth_token = None
        self.plugin_name = "CookieDeck"
        self.plugin_developer = "ElectroCookie"
        self.vts_ws = None

    async def _connect_vts(self):
        """VTube Studio에 웹소켓으로 연결하고 인증합니다."""
        if self.vts_ws and not self.vts_ws.closed:
            return True

        try:
            self.vts_ws = await websockets.connect(self.vts_uri, ping_interval=None)
            
            # 1. 인증 요청
            auth_req = {
                "apiName": "VTubeStudioPublicAPI",
                "apiVersion": "1.0",
                "requestID": "CookieDeckAuth",
                "messageType": "AuthenticationTokenRequest",
                "data": {
                    "pluginName": self.plugin_name,
                    "pluginDeveloper": self.plugin_developer
                }
            }
            await self.vts_ws.send(json.dumps(auth_req))
            resp = json.loads(await self.vts_ws.recv())
            
            if resp.get("messageType") == "AuthenticationTokenResponse":
                self.auth_token = resp["data"]["authenticationToken"]
                
                # 2. 토큰으로 로그인
                login_req = {
                    "apiName": "VTubeStudioPublicAPI",
                    "apiVersion": "1.0",
                    "requestID": "CookieDeckLogin",
                    "messageType": "AuthenticationRequest",
                    "data": {
                        "pluginName": self.plugin_name,
                        "pluginDeveloper": self.plugin_developer,
                        "authenticationToken": self.auth_token
                    }
                }
                await self.vts_ws.send(json.dumps(login_req))
                login_resp = json.loads(await self.vts_ws.recv())
                
                if login_resp.get("data", {}).get("authenticated"):
                    print(f"[{self.uuid}] VTube Studio 연결 및 인증 성공!")
                    return True
            return False
        except Exception as e:
            print(f"[{self.uuid}] VTS 연결 실패: {e}")
            self.vts_ws = None
            return False

    async def _get_hotkeys(self):
        """VTS에서 현재 모델의 핫키 목록을 가져옵니다."""
        if not await self._connect_vts(): return[]
        
        req = {
            "apiName": "VTubeStudioPublicAPI",
            "apiVersion": "1.0",
            "requestID": "GetHotkeys",
            "messageType": "HotkeysInCurrentModelRequest"
        }
        await self.vts_ws.send(json.dumps(req))
        resp = json.loads(await self.vts_ws.recv())
        
        if resp.get("messageType") == "HotkeysInCurrentModelResponse":
            # {"name": "화남", "hotkeyID": "12345..."} 형태의 리스트 반환
            return resp.get("data", {}).get("availableHotkeys", [])
        return[]

    async def _trigger_hotkey(self, hotkey_id):
        """선택한 핫키를 실행합니다."""
        if not await self._connect_vts(): return
        
        req = {
            "apiName": "VTubeStudioPublicAPI",
            "apiVersion": "1.0",
            "requestID": "TriggerHotkey",
            "messageType": "HotkeyTriggerRequest",
            "data": {
                "hotkeyID": hotkey_id
            }
        }
        await self.vts_ws.send(json.dumps(req))

    async def handle_message(self, data):
        event = data.get("event")
        command = data.get("payload", {}).get("command")
        context = data.get("context")

        # 1. 버튼 눌렀을 때 (핫키 실행)
        if event == "keyDown":
            settings = data.get("payload", {}).get("settings", {})
            hotkey_id = settings.get("vts_hotkey")
            if hotkey_id:
                await self._trigger_hotkey(hotkey_id)

        # 2. 설정창(PI)에서 핫키 목록 요청 시
        elif command == "get_hotkeys":
            hotkeys = await self._get_hotkeys()
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": {
                    "command": "vts_hotkey_list",
                    "hotkeys": hotkeys
                }
            })