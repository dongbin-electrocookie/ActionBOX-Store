import sys
import os
import asyncio
import threading
import subprocess
import time

try:
    import keyboard
    KEYBOARD_OK = True
except ImportError:
    keyboard = None
    KEYBOARD_OK = False

try:
    import pyperclip
    PYPERCLIP_OK = True
except ImportError:
    pyperclip = None
    PYPERCLIP_OK = False


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']

        self.MAX_HISTORY_SIZE = 20
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.history_file = os.path.join(self.plugin_dir, "clipboard_history.txt")
        self.snippets_file = os.path.join(self.plugin_dir, "my_snippets.txt")
        self.history_lock = threading.Lock()
        self.context_settings = {}

        self.icon_map = {
            "view_history": "VIEW_CLIPBOARD_HISTORY",
            "edit_snippets": "EDIT_SNIPPETS",
        }

        self._setup_files()
        self._start_monitor_thread()

    def _command_from_action(self, action_id, settings=None):
        settings = settings or {}
        cmd = settings.get("command")
        if cmd:
            return cmd
        action_id = action_id or ""
        if "view_history" in action_id:
            return "view_history"
        if "edit_snippets" in action_id:
            return "edit_snippets"
        return "view_history"

    def _icon_key_from_command(self, command):
        return self.icon_map.get(command or "view_history", "VIEW_CLIPBOARD_HISTORY")

    def _default_settings(self, action_id=""):
        command = self._command_from_action(action_id, {})
        return {
            "command": command,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self._icon_key_from_command(command),
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings, action_id=""):
        merged = self._default_settings(action_id)
        merged.update(settings or {})
        command = self._command_from_action(action_id, merged)
        merged["command"] = command
        merged["builtin_icon_name"] = self._icon_key_from_command(command)
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_builtin_icon_path(self, command):
        icon_name = self._icon_key_from_command(command)
        icon_path = os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")
        if os.path.exists(icon_path):
            return icon_path
        fallback = os.path.join(self.plugin_dir, "icon", "pluginIcon.png")
        return fallback if os.path.exists(fallback) else None

    async def _send_builtin_icon(self, context, command):
        icon_path = self._get_builtin_icon_path(command)
        if context and icon_path:
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        incoming = dict(settings or {})
        if self._has_meaningful_settings(incoming):
            merged = self._merge_with_defaults(incoming, action_id)
            self.context_settings[context] = merged
            return merged

        defaults = self._default_settings(action_id)
        self.context_settings[context] = defaults.copy()

        if context:
            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })
            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["command"])

        return defaults

    async def handle_message(self, data):
        event = data.get("event")

        if event == "keyDown":
            await self.on_key_down(data)
            return

        if event in ["keyDidAppear", "willAppear"]:
            context = data.get("context")
            action_id = data.get("action", "")
            settings = data.get("payload", {}).get("settings", {}) or {}
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if event == "didReceiveSettings":
            context = data.get("context")
            action_id = data.get("action", "")
            settings = data.get("payload", {}).get("settings")
            if not isinstance(settings, dict):
                settings = data.get("payload", {}) if isinstance(data.get("payload", {}), dict) else {}
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings}, action_id)
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            context = data.get("context")
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

    async def on_key_down(self, data):
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        if isinstance(incoming_settings, str) and incoming_settings.startswith("{"):
            try:
                incoming_settings = json.loads(incoming_settings)
            except Exception:
                incoming_settings = {}

        if not isinstance(incoming_settings, dict):
            incoming_settings = {}

        context = data.get("context")
        action_id = data.get("action", "")
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings}, action_id)
        if context:
            self.context_settings[context] = settings

        command = self._command_from_action(action_id, settings)

        file_to_open = None
        if command == "view_history":
            file_to_open = self.history_file
        elif command == "edit_snippets":
            file_to_open = self.snippets_file

        if file_to_open:
            await asyncio.to_thread(self._open_file, file_to_open)

    def _setup_files(self):
        if not os.path.exists(self.history_file):
            with open(self.history_file, 'w', encoding='utf-8') as f:
                f.write("--- Clipboard History ---\n")
        if not os.path.exists(self.snippets_file):
            with open(self.snippets_file, 'w', encoding='utf-8') as f:
                f.write("--- My Snippets ---\n")

    def _start_monitor_thread(self):
        if not KEYBOARD_OK or not PYPERCLIP_OK:
            return
        monitor_thread = threading.Thread(target=self._clipboard_monitor, daemon=True)
        monitor_thread.start()

    def _clipboard_monitor(self):
        try:
            keyboard.add_hotkey('ctrl+c', self._on_copy, suppress=False)
            keyboard.wait()
        except Exception as e:
            print(f"[{self.uuid} ERROR] Monitor thread crashed: {e}")

    def _on_copy(self):
        try:
            time.sleep(0.1)
            copied_text = pyperclip.paste().strip()
            if not copied_text:
                return

            with self.history_lock:
                lines = []
                if os.path.exists(self.history_file):
                    with open(self.history_file, 'r', encoding='utf-8') as f:
                        lines = f.readlines()

                header = lines[0] if lines else "--- Clipboard History ---\n"
                content_lines = [line.strip() for line in lines if line.strip() and line.strip() != header.strip()]

                if content_lines and content_lines[0] == copied_text:
                    return

                new_content = [copied_text] + content_lines
                final_content = new_content[:self.MAX_HISTORY_SIZE]

                with open(self.history_file, 'w', encoding='utf-8') as f:
                    f.write(header)
                    f.write('\n\n'.join(final_content))

        except Exception as e:
            print(f"[{self.uuid} ERROR] on_copy failed: {e}")

    def _open_file(self, file_path):
        try:
            if sys.platform == "win32":
                os.startfile(file_path)
            elif sys.platform == "darwin":
                subprocess.run(["open", file_path])
            else:
                subprocess.run(["xdg-open", file_path])
        except Exception as e:
            print(f"[{self.uuid} ERROR] Failed to open file: {e}")
