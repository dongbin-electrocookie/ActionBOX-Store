import asyncio

try:
    import keyboard
except ImportError:
    keyboard = None

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # FL Studio 핵심 단축키 맵
        self.hotkey_map = {
            # Transport & Modes
            "play_pause": "space",
            "record": "r",
            "pat_song_toggle": "l",
            "metronome": "m",
            "wait_for_input": "ctrl+i",
            
            # Windows
            "win_playlist": "f5",
            "win_channel_rack": "f6",
            "win_piano_roll": "f7",
            "win_plugin_picker": "f8",
            "win_mixer": "f9",
            "close_all": "f12",
            
            # Tools (피아노롤, 플레이리스트에서 작동)
            "tool_draw": "p",
            "tool_paint": "b",
            "tool_slice": "c",
            "tool_delete": "d",
            "tool_mute": "t",
            "tool_select": "e",
            
            # Edit
            "undo": "ctrl+alt+z", # FL의 히스토리 뒤로가기
            "quantize": "ctrl+q",
            "clone": "ctrl+b",
            "save": "ctrl+s"
        }

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        mode = settings.get("control_mode", "hotkey")
        context = data.get("context")

        # 1. 단축키 모드 (Hotkey)
        if mode == "hotkey":
            if not keyboard: return
            action = settings.get("fl_hotkey")
            if action in self.hotkey_map:
                hotkey = self.hotkey_map[action]
                await asyncio.to_thread(keyboard.send, hotkey)

        # 2. 하드웨어 네이티브 MIDI 모드 (CC 전송)
        elif mode == "midi":
            try:
                channel = int(settings.get("midi_channel", 1)) - 1
                cc_num = int(settings.get("midi_cc", 10))
                cc_val = int(settings.get("midi_val", 127))
                
                status = 0xB0 | channel # 0xB0 = Control Change
                
                # CookieDeck의 하드웨어 USB MIDI(0x70)로 직접 발사!
                payload = {
                    "event": "sendToPlugin",
                    "context": context,
                    "payload": {
                        "command": "direct_serial",
                        "serial_cmd": 0x70,
                        "serial_data": [status, cc_num, cc_val]
                    }
                }
                await self.runner.send_message(payload)
                print(f"[{self.uuid}] FL Studio MIDI Sent: CC {cc_num}, Val {cc_val}")
                
            except Exception as e:
                print(f"[{self.uuid}] MIDI 전송 에러: {e}")