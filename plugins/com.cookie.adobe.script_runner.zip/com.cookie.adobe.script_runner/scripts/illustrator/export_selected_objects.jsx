#target illustrator

// Illustrator has a built-in global copy() command. Isolate script variables
// from application globals, including when run through DoJavaScriptFile.
(function () {

function safeFileName(name, fallback) {
    var value = String(name || "").replace(/[\\\/:*?"<>|]/g, "_").replace(/^\s+|\s+$/g, "");
    return value || fallback;
}

function uniqueBasePath(folder, name) {
    var basePath = folder.fsName + "/" + name;
    var index = 2;
    while (new File(basePath + ".ai").exists || new File(basePath + ".svg").exists || new File(basePath + ".png").exists) {
        basePath = folder.fsName + "/" + name + "_" + index;
        index++;
    }
    return basePath;
}

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else if (app.activeDocument.selection.length === 0) {
    alert("선택된 객체가 없습니다.");
} else {
    var doc = app.activeDocument;
    var selection = [];
    for (var selectedIndex = 0; selectedIndex < doc.selection.length; selectedIndex++) {
        selection.push(doc.selection[selectedIndex]);
    }
    var exportFolder = Folder.selectDialog("저장할 폴더를 선택하세요");

    if (exportFolder) {
        var exported = 0;
        var skipped = 0;
        var errors = [];
        for (var i = 0; i < selection.length; i++) {
            var tempDoc = null;
            var stage = "객체 확인";
            try {
                var item = selection[i];
                if (item.locked || item.hidden) throw new Error("잠기거나 숨겨진 객체");

                var bounds = item.visibleBounds;
                var width = Math.max(1, bounds[2] - bounds[0]);
                var height = Math.max(1, bounds[1] - bounds[3]);
                stage = "임시 문서 생성";
                tempDoc = app.documents.add(DocumentColorSpace.RGB, width, height);
                stage = "객체 복제";
                var duplicatedItem = item.duplicate(tempDoc, ElementPlacement.PLACEATBEGINNING);
                stage = "아트보드 설정";
                var copiedBounds = duplicatedItem.visibleBounds;
                tempDoc.artboards[0].artboardRect = [copiedBounds[0], copiedBounds[1], copiedBounds[2], copiedBounds[3]];

                var objectName = safeFileName(item.name, "export_" + (i + 1));
                var basePath = uniqueBasePath(exportFolder, objectName);

                stage = "AI 저장";
                tempDoc.saveAs(new File(basePath + ".ai"), new IllustratorSaveOptions());

                var svgOptions = new ExportOptionsSVG();
                svgOptions.embedRasterImages = true;
                stage = "SVG 저장";
                tempDoc.exportFile(new File(basePath + ".svg"), ExportType.SVG, svgOptions);

                var pngOptions = new ExportOptionsPNG24();
                pngOptions.transparency = true;
                pngOptions.artBoardClipping = true;
                pngOptions.horizontalScale = 100;
                pngOptions.verticalScale = 100;
                stage = "PNG 저장";
                tempDoc.exportFile(new File(basePath + ".png"), ExportType.PNG24, pngOptions);
                exported++;
            } catch (e) {
                skipped++;
                if (errors.length < 5) {
                    errors.push((i + 1) + "번 객체 — " + stage + ": " + String(e.message || e) +
                        (e.number ? " (" + e.number + ")" : ""));
                }
            } finally {
                if (tempDoc) {
                    try { tempDoc.close(SaveOptions.DONOTSAVECHANGES); } catch (closeError) {}
                }
            }
        }
        try { doc.activate(); } catch (activateError) {}
        var message = exported + "개 객체 저장 완료" + (skipped ? ", " + skipped + "개 저장 실패." : ".");
        if (errors.length) message += "\n\n" + errors.join("\n");
        alert(message);
    }
}

})();
