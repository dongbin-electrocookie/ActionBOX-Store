# COMBO-X App Volume — macOS helper

Requires macOS 14.2 or later. This is a local Core Audio process-tap mixer,
not a wrapper around an OS per-app volume slider. Windows continues using
pycaw and Windows audio sessions unchanged.

## Build / distribute

Run `python3 macos/build_helper.py` from the plugin directory on a Mac with
Xcode command-line tools. The result is a universal arm64/x86_64 accessory
application under `macos/COMBO-X App Volume.app`. Include the **whole bundle**
when preparing the plugin ZIP. End users do not need Xcode or Swift installed.

Local builds use an ad-hoc signature. For a separately distributed store ZIP,
sign the helper with your Developer ID Application identity using
`--sign-identity`, notarize its distribution, and staple the notarization
ticket to the helper app before packaging it. The main PKG builder rebuilds
the helper when this plugin is present; the existing resource-seed signing
and PKG notarization pipeline signs the nested helper as well.

`COMBO-X-App-Volume --self-test` tests DSP without opening audio devices.
`COMBO-X-App-Volume --list` reads running audio process metadata only.

## Permission / behavior

The first volume change requests **System Audio Recording** permission for
COMBO-X App Volume (or its responsible parent app, as identified by macOS).
No audio is written to a file, transmitted over the network, or passed through
Python. The helper has no Dock icon. It processes only the selected app's
audio on the current default output device, using a private aggregate device.
Physical microphone streams are disabled for its IOProc.

Tap and output formats must be native-endian Float32 PCM, have matching sample
rates and channel counts. Unsupported hardware formats fail before starting
the tap and never silently substitute whole-system volume control.

Volume state is held while the helper runs; it is not a persistent Windows
mixer setting. Original output is restored when COMBO-X/the plugin exits,
the helper crashes, the parent disappears, or an audio route cannot be rebuilt.
The tap uses `mutedWhenTapped`, not permanent process mute. Changing the default
output or the selected app's process IDs releases and rebuilds the route.
Failed routes remain released until another explicit user action.

## Verification still required before publishing

Local verification measured an isolated quiet test tone through the real Core
Audio callback: output/input peak ratios were 0.9, 0 (mute), 0.9 (unmute), and
1.0 (restore). Both test processes were closed afterward. This verifies the
signal path, not a listening test or a signed installation on another Mac.
Automated DSP/protocol/Windows regression tests do not request capture permission.
Before publishing, verify fresh permission grant/denial, audible changes,
app relaunch, Chrome renderer processes, USB/Bluetooth output changes,
sleep/wake, parent exit/crash, and the signed PKG on another Mac. Do not publish
the ad-hoc test bundle as a notarized production plugin.
