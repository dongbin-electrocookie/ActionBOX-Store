#target aftereffects
(function () {
    var comp = app.project && app.project.activeItem;
    if (!(comp instanceof CompItem) || comp.selectedLayers.length === 0) {
        alert("Open a composition and select at least one layer.");
        return;
    }
    app.beginUndoGroup("Center Selected Layers");
    for (var i = 0; i < comp.selectedLayers.length; i++) {
        var layer = comp.selectedLayers[i];
        var position = layer.property("ADBE Transform Group").property("ADBE Position");
        if (position && !position.expressionEnabled) {
            position.setValue(layer.threeDLayer
                ? [comp.width / 2, comp.height / 2, position.value[2]]
                : [comp.width / 2, comp.height / 2]);
        }
    }
    app.endUndoGroup();
}());
