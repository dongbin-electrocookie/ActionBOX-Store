import asyncio
import platform

try:
    import keyboard
    keyboard_available = True
except ImportError:
    print("[Teams Plugin] 'keyboard' 라이브러리가 없습니다.")
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # Microsoft Teams 윈도우 단축키 매핑
        self.action_map = {
            "toggle_mic": "ctrl+shift+m",
            "toggle_cam": "ctrl+shift+o",
            "toggle_share": "ctrl+shift+e",
            "toggle_hand": "ctrl+shift+k",
            "toggle_blur": "ctrl+shift+p",
            "leave_meeting": "ctrl+shift+h"
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("teams_action")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)