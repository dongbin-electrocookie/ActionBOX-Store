import asyncio
import urllib.request
import json
import os

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.polling_tasks = {}
        self.active_contexts = {}
        self.context_settings = {}
        self.status_i18n = {
            "en": {"CONFIG_NEEDED": "Config\nNeeded","API_ERR": "❌\nAPI Err","NO_RUN": "⚠️\nNo Run","SENDING": "🚀\nSending","SENT": "✅\nSent","FAIL": "❌\nFail","READY": "✅\nReady","ERROR": "❌\nError","BUILDING": "🔄\nBuilding","RUNNING": "🔄\nRunning","SUCCESS": "✅\nSuccess","FAILED": "❌\nFailed","CF_READY": "☁️\nCF Ready","RW_READY": "🚂\nRW Ready"},
            "ko": {"CONFIG_NEEDED": "설정\n필요","API_ERR": "❌\nAPI 오류","NO_RUN": "⚠️\n실행 없음","SENDING": "🚀\n전송 중","SENT": "✅\n전송 완료","FAIL": "❌\n실패","READY": "✅\n정상","ERROR": "❌\n오류","BUILDING": "🔄\n빌드 중","RUNNING": "🔄\n실행 중","SUCCESS": "✅\n성공","FAILED": "❌\n실패","CF_READY": "☁️\nCF 준비","RW_READY": "🚂\nRW 준비"},
            "ja": {"CONFIG_NEEDED": "設定\n必要","API_ERR": "❌\nAPIエラー","NO_RUN": "⚠️\n実行なし","SENDING": "🚀\n送信中","SENT": "✅\n送信完了","FAIL": "❌\n失敗","READY": "✅\nReady","ERROR": "❌\nError","BUILDING": "🔄\nBuilding","RUNNING": "🔄\nRunning","SUCCESS": "✅\nSuccess","FAILED": "❌\nFailed","CF_READY": "☁️\nCF Ready","RW_READY": "🚂\nRW Ready"},
            "de": {"CONFIG_NEEDED": "Config\nNötig","API_ERR": "❌\nAPI-Fehler","NO_RUN": "⚠️\nKein Lauf","SENDING": "🚀\nSenden","SENT": "✅\nGesendet","FAIL": "❌\nFehler","READY": "✅\nBereit","ERROR": "❌\nFehler","BUILDING": "🔄\nBuild","RUNNING": "🔄\nLäuft","SUCCESS": "✅\nErfolg","FAILED": "❌\nFehlg.","CF_READY": "☁️\nCF bereit","RW_READY": "🚂\nRW bereit"},
            "es": {"CONFIG_NEEDED": "Config\nNeces.","API_ERR": "❌\nError API","NO_RUN": "⚠️\nSin run","SENDING": "🚀\nEnvío","SENT": "✅\nEnviado","FAIL": "❌\nFallo","READY": "✅\nListo","ERROR": "❌\nError","BUILDING": "🔄\nBuild","RUNNING": "🔄\nActivo","SUCCESS": "✅\nÉxito","FAILED": "❌\nFalló","CF_READY": "☁️\nCF listo","RW_READY": "🚂\nRW listo"},
            "fr": {"CONFIG_NEEDED": "Config\nRequise","API_ERR": "❌\nErreur API","NO_RUN": "⚠️\nAucun","SENDING": "🚀\nEnvoi","SENT": "✅\nEnvoyé","FAIL": "❌\nÉchec","READY": "✅\nPrêt","ERROR": "❌\nErreur","BUILDING": "🔄\nBuild","RUNNING": "🔄\nActif","SUCCESS": "✅\nSuccès","FAILED": "❌\nÉchec","CF_READY": "☁️\nCF prêt","RW_READY": "🚂\nRW prêt"},
            "ru": {"CONFIG_NEEDED": "Нужна\nнастр.","API_ERR": "❌\nAPI err","NO_RUN": "⚠️\nНет run","SENDING": "🚀\nОтправ.","SENT": "✅\nОтпр.","FAIL": "❌\nСбой","READY": "✅\nГотово","ERROR": "❌\nОшибка","BUILDING": "🔄\nСборка","RUNNING": "🔄\nЗапуск","SUCCESS": "✅\nУспех","FAILED": "❌\nПровал","CF_READY": "☁️\nCF готов","RW_READY": "🚂\nRW готов"},
            "it": {"CONFIG_NEEDED": "Config\nRich.","API_ERR": "❌\nErrore API","NO_RUN": "⚠️\nNo run","SENDING": "🚀\nInvio","SENT": "✅\nInviato","FAIL": "❌\nErrore","READY": "✅\nPronto","ERROR": "❌\nErrore","BUILDING": "🔄\nBuild","RUNNING": "🔄\nAttivo","SUCCESS": "✅\nSuccesso","FAILED": "❌\nFallito","CF_READY": "☁️\nCF pronto","RW_READY": "🚂\nRW pronto"},
            "pt-PT": {"CONFIG_NEEDED": "Config\nNecess.","API_ERR": "❌\nErro API","NO_RUN": "⚠️\nSem run","SENDING": "🚀\nEnviar","SENT": "✅\nEnviado","FAIL": "❌\nFalha","READY": "✅\nPronto","ERROR": "❌\nErro","BUILDING": "🔄\nBuild","RUNNING": "🔄\nAtivo","SUCCESS": "✅\nSucesso","FAILED": "❌\nFalhou","CF_READY": "☁️\nCF pronto","RW_READY": "🚂\nRW pronto"},
        }
        self.icon_map = {
            ("vercel", "monitor"): "VERCEL_MONITOR", ("vercel", "redeploy"): "VERCEL_REDEPLOY",
            ("netlify", "monitor"): "NETLIFY_MONITOR", ("netlify", "redeploy"): "NETLIFY_REDEPLOY",
            ("cloudflare", "monitor"): "CLOUDFLARE_MONITOR", ("cloudflare", "redeploy"): "CLOUDFLARE_REDEPLOY",
            ("railway", "monitor"): "RAILWAY_MONITOR", ("railway", "redeploy"): "RAILWAY_REDEPLOY",
            ("github", "monitor"): "GITHUB_MONITOR", ("github", "redeploy"): "GITHUB_REDEPLOY",
        }

    def tr(self, settings, key):
        lang = (settings or {}).get("_lang", "en")
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        lang = alias.get(lang, lang)
        lang_data = self.status_i18n.get(lang, self.status_i18n["en"])
        return lang_data.get(key, self.status_i18n["en"].get(key, key))

    def _provider_from_action(self, action_id):
        action_id = (action_id or "").lower()
        for provider in ["vercel", "netlify", "cloudflare", "railway", "github"]:
            if provider in action_id:
                return provider
        return "vercel"

    def _default_settings_for_action(self, action_id):
        provider = self._provider_from_action(action_id)
        return {
            "action_type": "monitor",
            "api_key": "",
            "project_id": "",
            "webhook_url": "",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[(provider, "monitor")],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, action_id, settings):
        merged = self._default_settings_for_action(action_id)
        merged.update(settings or {})
        provider = self._provider_from_action(action_id)
        action_type = merged.get("action_type") or "monitor"
        merged["action_type"] = action_type
        merged["builtin_icon_name"] = self.icon_map.get((provider, action_type), self.icon_map[(provider, "monitor")])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any(s.get(k) not in ("", None, False) for k in [
            "action_type", "api_key", "project_id", "webhook_url", "title",
            "builtin_icon_name", "default_visuals_initialized", "sync_title_on_action_change"
        ])

    def _icon_path_for(self, action_id, action_type):
        provider = self._provider_from_action(action_id)
        icon_name = self.icon_map.get((provider, action_type or "monitor"), "VERCEL_MONITOR")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id, action_type):
        icon_path = self._icon_path_for(action_id, action_type)
        if os.path.exists(icon_path):
            await self.runner.send_message({"event": "setIcon", "context": context, "payload": {"icon_path": icon_path}})

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return {}
        if not self._has_meaningful_settings(settings):
            new_settings = self._default_settings_for_action(action_id)
            self.context_settings[context] = self._merge_with_defaults(action_id, new_settings)
            await self.runner.send_message({"event": "setSettings", "context": context, "payload": new_settings})
            await self._send_builtin_icon(context, action_id, "monitor")
            return new_settings
        merged = self._merge_with_defaults(action_id, settings)
        self.context_settings[context] = merged
        return merged

    async def handle_message(self, data):
        event = data.get("event", "")
        context = data.get("context")
        payload = data.get("payload") or {}
        action_id = data.get("action") or self.active_contexts.get(context, {}).get("action")
        if not context:
            return

        if "disappear" in event.lower() or "delete" in event.lower() or "remove" in event.lower() or "clear" in event.lower():
            if context in self.polling_tasks:
                self.polling_tasks[context].cancel()
                del self.polling_tasks[context]
            self.active_contexts.pop(context, None)
            self.context_settings.pop(context, None)
            return

        settings = payload.get("settings") if isinstance(payload, dict) and "settings" in payload else payload
        if not isinstance(settings, dict):
            settings = {}

        control_command = data.get("command") or payload.get("command")
        action_type_override = data.get("action_type") or payload.get("action_type")

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            await self._send_builtin_icon(context, action_id, action_type_override or settings.get("action_type") or cached.get("action_type") or "monitor")
            return

        if event in ["willAppear", "keyDidAppear"]:
            settings = await self._initialize_default_visuals_if_new(context, action_id, settings)
            target_page = payload.get("page") or self.active_contexts.get(context, {}).get("page")
            self.active_contexts[context] = {"action": action_id, "page": target_page}
            self.context_settings[context] = self._merge_with_defaults(action_id, settings)
            if context in self.polling_tasks:
                self.polling_tasks[context].cancel()
            self.polling_tasks[context] = asyncio.create_task(self.start_polling(context, action_id, self.context_settings[context], target_page))
            return

        if event == "didReceiveSettings":
            cached = self.context_settings.get(context, {})
            merged = self._merge_with_defaults(action_id, {**cached, **settings})
            self.context_settings[context] = merged
            target_page = payload.get("page") or self.active_contexts.get(context, {}).get("page")
            self.active_contexts[context] = {"action": action_id, "page": target_page}
            if context in self.polling_tasks:
                self.polling_tasks[context].cancel()
            self.polling_tasks[context] = asyncio.create_task(self.start_polling(context, action_id, merged, target_page))
            return

        if event == "keyDown":
            cached = self.context_settings.get(context, {})
            merged = self._merge_with_defaults(action_id, {**cached, **settings})
            self.context_settings[context] = merged
            target_page = payload.get("page", self.active_contexts.get(context, {}).get("page"))
            await self.on_key_down(context, action_id, merged, target_page)
            return

    async def start_polling(self, context, action_id, settings, target_page):
        while True:
            try:
                current_settings = self.context_settings.get(context, settings)
                action_type = current_settings.get("action_type", "monitor")
                if action_type == "monitor" and action_id:
                    if "vercel" in action_id:
                        await self.check_vercel_status(context, current_settings, target_page)
                    elif "netlify" in action_id:
                        await self.check_netlify_status(context, current_settings, target_page)
                    elif "cloudflare" in action_id:
                        await self.check_cloudflare_status(context, current_settings, target_page)
                    elif "railway" in action_id:
                        await self.check_railway_status(context, current_settings, target_page)
                    elif "github" in action_id:
                        await self.check_github_status(context, current_settings, target_page)
            except asyncio.CancelledError:
                return
            except Exception as e:
                print(f"Polling error: {e}")
            await asyncio.sleep(60)

    async def _fetch_api(self, req):
        def fetch():
            try:
                with urllib.request.urlopen(req) as response:
                    return json.loads(response.read().decode())
            except Exception as e:
                print(f"API call failed: {e}")
                return None
        return await asyncio.to_thread(fetch)

    async def check_vercel_status(self, context, settings, target_page):
        api_key, project_id = settings.get("api_key"), settings.get("project_id")
        if not api_key or not project_id:
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": self.tr(settings, "CONFIG_NEEDED"), "page": target_page}})
            return
        req = urllib.request.Request(f"https://api.vercel.com/v6/deployments?projectId={project_id}&limit=1", headers={"Authorization": f"Bearer {api_key}"})
        res = await self._fetch_api(req)
        if res and "deployments" in res and res["deployments"]:
            state = res["deployments"][0].get("state", "UNKNOWN")
            title = {"READY": self.tr(settings, "READY"), "ERROR": self.tr(settings, "ERROR"), "BUILDING": self.tr(settings, "BUILDING")}.get(state, f"⚠️\n{state}")
        else:
            title = self.tr(settings, "API_ERR")
        await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": title, "page": target_page}})

    async def check_netlify_status(self, context, settings, target_page):
        api_key, site_id = settings.get("api_key"), settings.get("project_id")
        if not api_key or not site_id:
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": self.tr(settings, "CONFIG_NEEDED"), "page": target_page}})
            return
        req = urllib.request.Request(f"https://api.netlify.com/api/v1/sites/{site_id}/deploys?per_page=1", headers={"Authorization": f"Bearer {api_key}"})
        res = await self._fetch_api(req)
        if res and len(res) > 0:
            state = res[0].get("state", "unknown")
            title = {"ready": self.tr(settings, "READY"), "error": self.tr(settings, "ERROR"), "building": self.tr(settings, "BUILDING")}.get(state, f"⚠️\n{state}")
        else:
            title = self.tr(settings, "API_ERR")
        await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": title, "page": target_page}})

    async def check_github_status(self, context, settings, target_page):
        api_key, repo = settings.get("api_key"), settings.get("project_id")
        if not api_key or not repo:
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": self.tr(settings, "CONFIG_NEEDED"), "page": target_page}})
            return
        req = urllib.request.Request(f"https://api.github.com/repos/{repo}/actions/runs?per_page=1", headers={"Authorization": f"token {api_key}","Accept": "application/vnd.github.v3+json","User-Agent": "CookieDeck-App"})
        res = await self._fetch_api(req)
        if res and "workflow_runs" in res:
            if res["workflow_runs"]:
                status = res["workflow_runs"][0].get("status")
                conclusion = res["workflow_runs"][0].get("conclusion")
                title = self.tr(settings, "RUNNING") if status in ["in_progress", "queued"] else (self.tr(settings, "SUCCESS") if conclusion == "success" else self.tr(settings, "FAILED"))
            else:
                title = self.tr(settings, "NO_RUN")
        else:
            title = self.tr(settings, "API_ERR")
        await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": title, "page": target_page}})

    async def check_cloudflare_status(self, context, settings, target_page):
        await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": self.tr(settings, "CF_READY"), "page": target_page}})

    async def check_railway_status(self, context, settings, target_page):
        await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": self.tr(settings, "RW_READY"), "page": target_page}})

    async def on_key_down(self, context, action_id, settings, target_page):
        action_type = settings.get("action_type", "monitor")
        if action_type == "redeploy":
            webhook_url = settings.get("webhook_url")
            if not webhook_url:
                return
            await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": self.tr(settings, "SENDING"), "page": target_page}})
            try:
                req = urllib.request.Request(webhook_url, method="POST")
                if action_id and "github" in action_id:
                    req.add_header("Authorization", f"token {settings.get('api_key')}")
                    req.add_header("Accept", "application/vnd.github.v3+json")
                    req.add_header("User-Agent", "CookieDeck-App")
                await asyncio.to_thread(lambda: urllib.request.urlopen(req))
                await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": self.tr(settings, "SENT"), "page": target_page}})
            except Exception as e:
                print(f"Webhook send failed: {e}")
                await self.runner.send_message({"event": "setTitle", "context": context, "payload": {"title": self.tr(settings, "FAIL"), "page": target_page}})
