#target photoshop

var outputs = [
    { name: "Instagram_Post", width: 1080, height: 1080 },
    { name: "Instagram_Story", width: 1080, height: 1920 },
    { name: "YouTube_Thumbnail", width: 1280, height: 720 },
    { name: "Twitter_Image", width: 1200, height: 675 },
    { name: "Blog_1200w", width: 1200, height: null }
];

function uniqueFile(folder, baseName) {
    var file = new File(folder.fsName + "/" + baseName + ".png");
    var index = 2;
    while (file.exists) {
        file = new File(folder.fsName + "/" + baseName + "_" + index + ".png");
        index++;
    }
    return file;
}

function resizeCoverAndCrop(doc, width, height) {
    var sourceWidth = doc.width.as("px");
    var sourceHeight = doc.height.as("px");
    var scale = Math.max(width / sourceWidth, height / sourceHeight);
    doc.resizeImage(UnitValue(Math.round(sourceWidth * scale), "px"), UnitValue(Math.round(sourceHeight * scale), "px"), null, ResampleMethod.BICUBIC);

    var centerX = doc.width.as("px") / 2;
    var centerY = doc.height.as("px") / 2;
    doc.crop([centerX - width / 2, centerY - height / 2, centerX + width / 2, centerY + height / 2]);
}

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else {
    var doc = app.activeDocument;
    var folder = new Folder(Folder.desktop + "/SNS_Exports");
    if (!folder.exists && !folder.create()) {
        alert("내보내기 폴더를 만들 수 없습니다.");
    } else {
        var tempDoc = null;
        try {
            for (var i = 0; i < outputs.length; i++) {
                var item = outputs[i];
                tempDoc = doc.duplicate();
                if (item.height === null) {
                    tempDoc.resizeImage(UnitValue(item.width, "px"), null, null, ResampleMethod.BICUBIC);
                } else {
                    resizeCoverAndCrop(tempDoc, item.width, item.height);
                }

                var opts = new PNGSaveOptions();
                opts.compression = 9;
                tempDoc.saveAs(uniqueFile(folder, item.name), opts, true, Extension.LOWERCASE);
                tempDoc.close(SaveOptions.DONOTSAVECHANGES);
                tempDoc = null;
            }
            alert("SNS용 다중 해상도 저장 완료:\n" + folder.fsName);
        } catch (e) {
            alert("다중 해상도 저장 오류: " + e.message);
        } finally {
            if (tempDoc) {
                try { tempDoc.close(SaveOptions.DONOTSAVECHANGES); } catch (ignore) {}
            }
            app.activeDocument = doc;
        }
    }
}
