import asyncio
import os
import winsound

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get('UUID', 'com.cookie.pomodoro')
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.timers = {}
        self.default_icon_name = "TIMER"

        self.i18n = {
            "en": {"MODE_WORK": "WORK", "MODE_REST": "REST", "STATUS_RUNNING": "Running", "STATUS_PAUSED": "Paused"},
            "ko": {"MODE_WORK": "작업", "MODE_REST": "휴식", "STATUS_RUNNING": "실행중", "STATUS_PAUSED": "일시정지"},
            "ja": {"MODE_WORK": "作業", "MODE_REST": "休憩", "STATUS_RUNNING": "実行中", "STATUS_PAUSED": "一時停止"},
            "de": {"MODE_WORK": "ARBEIT", "MODE_REST": "PAUSE", "STATUS_RUNNING": "Läuft", "STATUS_PAUSED": "Pausiert"},
            "es": {"MODE_WORK": "TRABAJO", "MODE_REST": "DESCANSO", "STATUS_RUNNING": "En marcha", "STATUS_PAUSED": "Pausado"},
            "fr": {"MODE_WORK": "TRAVAIL", "MODE_REST": "PAUSE", "STATUS_RUNNING": "En cours", "STATUS_PAUSED": "En pause"},
            "ru": {"MODE_WORK": "РАБОТА", "MODE_REST": "ОТДЫХ", "STATUS_RUNNING": "Работает", "STATUS_PAUSED": "Пауза"},
            "it": {"MODE_WORK": "LAVORO", "MODE_REST": "PAUSA", "STATUS_RUNNING": "In esecuzione", "STATUS_PAUSED": "In pausa"},
            "pt-PT": {"MODE_WORK": "TRABALHO", "MODE_REST": "PAUSA", "STATUS_RUNNING": "Em execução", "STATUS_PAUSED": "Em pausa"}
        }

    def _lang(self, settings):
        lang = (settings.get("_lang") or "en").lower()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        lang = alias.get(lang, lang)
        return lang if lang in self.i18n else "en"

    def _t(self, settings, key):
        lang = self._lang(settings)
        return self.i18n.get(lang, self.i18n["en"]).get(key, key)

    def _get_icon_path(self):
        return os.path.join(self.plugin_dir, "icon", f"{self.default_icon_name}.png")

    async def _send_builtin_icon(self, context):
        icon_path = self._get_icon_path()
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "work_time", "rest_time", "show_timer_on_title",
            "builtin_icon_name", "default_visuals_initialized", "title"
        ])
        if meaningful:
            return

        new_settings = {
            "work_time": 25,
            "rest_time": 5,
            "_lang": "en",
            "show_timer_on_title": False,
            "builtin_icon_name": self.default_icon_name,
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })
        await self._send_builtin_icon(context)

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        settings = payload.get("settings", {}) or {}
        command = payload.get("command")

        if event in ["willAppear", "keyDidAppear"]:
            if context not in self.timers:
                self._init_timer_state(context, settings)
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "keyDown":
            state = self.timers.get(context)
            if not state:
                self._init_timer_state(context, settings)
                state = self.timers.get(context)

            incoming_settings = payload.get("settings", {}) or {}
            if incoming_settings:
                state["settings"].update(incoming_settings)

            state["is_running"] = not state["is_running"]
            if state["is_running"]:
                if state["task"] is None or state["task"].done():
                    state["task"] = asyncio.create_task(self._timer_loop(context))

            if state["settings"].get("show_timer_on_title"):
                await self._update_display(context)

        elif event == "sendToPlugin" and command == "reset_timer":
            self._init_timer_state(context, settings)
            # do not auto-set title here unless UI explicitly asked for it

    def _init_timer_state(self, context, settings):
        work_time = int(settings.get("work_time", 25)) * 60
        if context in self.timers and self.timers[context].get("task"):
            self.timers[context]["task"].cancel()
        self.timers[context] = {
            "task": None,
            "time_left": work_time,
            "is_running": False,
            "mode": "work",
            "settings": settings.copy() if isinstance(settings, dict) else {}
        }

    async def _timer_loop(self, context):
        try:
            while self.timers[context]["is_running"]:
                await asyncio.sleep(1)
                state = self.timers[context]
                state["time_left"] -= 1
                if state["time_left"] <= 0:
                    await self._handle_time_up(context, state)
                if state["settings"].get("show_timer_on_title"):
                    await self._update_display(context)
        except asyncio.CancelledError:
            pass

    async def _handle_time_up(self, context, state):
        await asyncio.to_thread(winsound.MessageBeep, winsound.MB_ICONASTERISK)
        settings = state["settings"]
        if state["mode"] == "work":
            state["mode"] = "rest"
            state["time_left"] = int(settings.get("rest_time", 5)) * 60
        else:
            state["mode"] = "work"
            state["time_left"] = int(settings.get("work_time", 25)) * 60
        state["is_running"] = False

    def _build_display_text(self, state):
        mins, secs = divmod(state["time_left"], 60)
        time_str = f"{mins:02d}:{secs:02d}"
        settings = state.get("settings", {})
        mode_text = self._t(settings, "MODE_WORK") if state["mode"] == "work" else self._t(settings, "MODE_REST")
        status_text = self._t(settings, "STATUS_RUNNING") if state["is_running"] else self._t(settings, "STATUS_PAUSED")
        return f"[{mode_text}]\n{time_str}\n{status_text}"

    async def _update_display(self, context):
        state = self.timers.get(context)
        if not state:
            return
        display_text = self._build_display_text(state)
        await self.runner.send_message({
            "event": "setTitle",
            "context": context,
            "payload": {"title": display_text}
        })
