import asyncio
import sys

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 🚀 [업그레이드] 실무에서 가장 많이 쓰는 윈도우 창 관리 단축키 총망라
        self.hotkey_map = {
            # 1. 기본 분할 및 크기
            "left": "win+left",
            "right": "win+right",
            "maximize": "win+up",
            "minimize": "win+down",
            
            # 2. 다중 모니터 이동 (듀얼 모니터 필수품!)
            "monitor_prev": "win+shift+left",
            "monitor_next": "win+shift+right",
            
            # 3. 특수 제어
            "focus_mode": "win+home",  # 현재 창 빼고 다 숨기기 (집중 모드)
            "snap_layout": "win+z",    # 윈도우 11 화면 분할 레이아웃 호출
            "show_desktop": "win+d"    # 바탕화면 보기 (토글)
        }

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return
        
        # OS 체크: Windows가 아니면 무시
        if sys.platform != "win32":
            print(f"[{self.uuid}] Ignored: Window Mover works only on Windows.")
            return

        settings = data.get("payload", {}).get("settings", {})
        
        # 설정된 동작 가져오기 (기본값: left)
        selected_action = settings.get("win_action", "left")
        hotkey_to_send = self.hotkey_map.get(selected_action)
        
        if hotkey_to_send:
            # 키 씹힘 방지 및 공유 런타임 보호를 위해 백그라운드 스레드에서 실행
            await asyncio.to_thread(keyboard.send, hotkey_to_send)