#target illustrator

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else if (app.activeDocument.selection.length < 2) {
    alert("두 개 이상의 오브젝트를 선택해주세요.");
} else {
    var gapInput = prompt("간격(px)을 입력하세요:", "50");
    if (gapInput !== null) {
        var gap = parseFloat(gapInput);
        if (isNaN(gap)) {
            alert("숫자를 입력해주세요.");
        } else {
            var items = [];
            var selection = app.activeDocument.selection;
            for (var i = 0; i < selection.length; i++) {
                if (!selection[i].locked && !selection[i].hidden) items.push(selection[i]);
            }

            if (items.length < 2) {
                alert("정렬 가능한 오브젝트가 두 개 이상 필요합니다.");
            } else {
                items.sort(function(a, b) { return a.left - b.left; });
                var currentX = items[0].left;
                for (var j = 1; j < items.length; j++) {
                    currentX += items[j - 1].width + gap;
                    items[j].left = currentX;
                }
            }
        }
    }
}
