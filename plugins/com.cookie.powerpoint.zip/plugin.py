import asyncio
import os

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.action_map = {
            "show_start": "f5",
            "show_current": "shift+f5",
            "show_next": "space",
            "show_prev": "left",
            "show_end": "esc",
            "show_black": "b",
            "show_white": "w",
            "show_laser": "ctrl+l",
            "show_pen": "ctrl+p",
            "show_eraser": "ctrl+e",
            "show_arrow": "ctrl+a",
            "edit_new_slide": "ctrl+m",
            "edit_duplicate": "ctrl+d",
            "edit_undo": "ctrl+z",
            "edit_redo": "ctrl+y",
            "format_copy": "ctrl+shift+c",
            "format_paste": "ctrl+shift+v",
            "format_group": "ctrl+g",
            "format_ungroup": "ctrl+shift+g",
            "font_bold": "ctrl+b",
            "font_italic": "ctrl+i",
            "file_save": "ctrl+s",
            "file_save_as": "f12"
        }

        self.icon_map = {
            "show_start": "STATE_SHOW_START",
            "show_current": "STATE_SHOW_CURRENT",
            "show_next": "STATE_SHOW_NEXT",
            "show_prev": "STATE_SHOW_PREV",
            "show_end": "STATE_SHOW_END",
            "show_black": "STATE_SHOW_BLACK",
            "show_white": "STATE_SHOW_WHITE",
            "show_laser": "STATE_SHOW_LASER",
            "show_pen": "STATE_SHOW_PEN",
            "show_eraser": "STATE_SHOW_ERASER",
            "show_arrow": "STATE_SHOW_ARROW",
            "edit_new_slide": "STATE_EDIT_NEW_SLIDE",
            "edit_duplicate": "STATE_EDIT_DUPLICATE",
            "edit_undo": "STATE_EDIT_UNDO",
            "edit_redo": "STATE_EDIT_REDO",
            "format_copy": "STATE_FORMAT_COPY",
            "format_paste": "STATE_FORMAT_PASTE",
            "format_group": "STATE_FORMAT_GROUP",
            "format_ungroup": "STATE_FORMAT_UNGROUP",
            "font_bold": "STATE_FONT_BOLD",
            "font_italic": "STATE_FONT_ITALIC",
            "file_save": "STATE_FILE_SAVE",
            "file_save_as": "STATE_FILE_SAVE_AS"
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "show_next", "STATE_SHOW_NEXT")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "command", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "show_next"
        new_settings = {
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        # Initial placement: icon only, never overwrite title
        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or "show_next")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available:
            return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("command", "show_next")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)
