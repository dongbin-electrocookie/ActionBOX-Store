#target illustrator

// Illustrator 아이소메트릭 큐브 격자 생성 스크립트
var cols = parseInt(prompt("가로 셀 수?", "5"));
var rows = parseInt(prompt("세로 셀 수?", "5"));
var size = parseFloat(prompt("한 큐브의 크기(px)?", "30"));

if (isNaN(rows) || isNaN(cols) || isNaN(size)) {
  alert("숫자 입력이 잘못되었습니다.");
} else {
  var doc = app.activeDocument;
  var layer = doc.activeLayer;

  var dx = size * Math.cos(Math.PI / 6); // cos(30°) ≈ 0.866
  var dy = size * Math.sin(Math.PI / 6); // sin(30°) = 0.5
  var h = size; // 큐브 높이

  for (var row = 0; row < rows; row++) {
    for (var col = 0; col < cols; col++) {
      var cx = (col - row) * dx;
      var cy = (col + row) * dy;

      // 위면 (Top)
      var top = layer.pathItems.add();
      top.setEntirePath([
        [cx, cy],
        [cx + dx, cy - dy],
        [cx, cy - 2 * dy],
        [cx - dx, cy - dy]
      ]);
      top.closed = true;
      top.filled = true;
      top.fillColor = makeRGB(200, 200, 200); // 밝은 회색
      top.stroked = true;
      top.strokeColor = makeGray(50);

      // 왼쪽면 (Left)
      var left = layer.pathItems.add();
      left.setEntirePath([
        [cx - dx, cy - dy],
        [cx, cy - 2 * dy],
        [cx, cy - 2 * dy - h],
        [cx - dx, cy - dy - h]
      ]);
      left.closed = true;
      left.filled = true;
      left.fillColor = makeRGB(160, 160, 160); // 중간 회색
      left.stroked = true;
      left.strokeColor = makeGray(50);

      // 오른쪽면 (Right)
      var right = layer.pathItems.add();
      right.setEntirePath([
        [cx + dx, cy - dy],
        [cx, cy - 2 * dy],
        [cx, cy - 2 * dy - h],
        [cx + dx, cy - dy - h]
      ]);
      right.closed = true;
      right.filled = true;
      right.fillColor = makeRGB(120, 120, 120); // 어두운 회색
      right.stroked = true;
      right.strokeColor = makeGray(50);
    }
  }

  alert("아이소 큐브 격자 생성 완료!");

  // Helper functions
  function makeGray(v) {
    var color = new GrayColor();
    color.gray = v;
    return color;
  }

  function makeRGB(r, g, b) {
    var color = new RGBColor();
    color.red = r;
    color.green = g;
    color.blue = b;
    return color;
  }
}
