# HP AI Studio for COMBO-X

Official-store plugin baseline for Windows. It controls observable local workflows and configurable published-service endpoints without assuming an unpublished HP management API.

- Opens or focuses HP AI Studio
- Shows installed/running state
- Opens user-selected project folders
- Runs AI-focused WSL presets for Python, packages, PyTorch/CUDA, Docker, Jupyter, Git, project/model files, GPU, and system resources
- Runs user-entered WSL commands with distribution, working-directory, result destination, and timeout controls
- Opens local Swagger or published-service pages
- Monitors a GET-safe health endpoint
- Sends clipboard or fixed text through a configurable JSON inference request
- Extracts results with an optional dot path and writes them to COMBO-X, clipboard, or a user-data file
- Displays AMD, Intel, and NVIDIA GPU usage plus dedicated/shared graphics-memory usage through Windows GPU counters

API keys remain in COMBO-X settings and are never written into the plugin installation directory or result files.

WSL commands run once per physical key press. Concurrent commands on the same key are rejected, output is capped before it is sent to the Property Inspector, and the timeout can be configured from 1 to 600 seconds. Long-running training jobs should be launched in a terminal or a persistent session manager rather than captured by the button Action.

GPU adapters are matched to Windows performance-counter instances by DXGI LUID, so hybrid and integrated AMD/Intel/NVIDIA systems do not depend on vendor utilities. Dedicated and shared memory totals come from DXGI, including large unified-memory configurations. If `nvidia-smi` is present, its temperature and NVIDIA sensor values are appended.
