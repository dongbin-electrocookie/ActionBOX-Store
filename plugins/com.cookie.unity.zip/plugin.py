import asyncio
import os

try:
    import pyautogui
    PYAUTOGUI_AVAILABLE = True
except ImportError:
    pyautogui = None
    PYAUTOGUI_AVAILABLE = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.icon_map = {
            "play_stop": "STATE_PLAY_STOP",
            "pause": "STATE_PAUSE",
            "step": "STATE_STEP",
            "console": "STATE_CONSOLE",
            "move": "STATE_MOVE",
            "rotate": "STATE_ROTATE",
            "scale": "STATE_SCALE",
            "rect": "STATE_RECT",
            "center": "STATE_CENTER",
            "local": "STATE_LOCAL",
            "pivot": "STATE_PIVOT",
            "new_empty": "STATE_NEW_EMPTY",
            "new_child": "STATE_NEW_CHILD",
            "duplicate": "STATE_DUPLICATE",
            "rename": "STATE_RENAME",
            "add_comp": "STATE_ADD_COMP",
            "focus": "STATE_FOCUS",
            "lock_view": "STATE_LOCK_VIEW",
            "align": "STATE_ALIGN",
            "move_view": "STATE_MOVE_VIEW",
            "inspector": "STATE_INSPECTOR",
            "game": "STATE_GAME",
            "scene": "STATE_SCENE",
            "hierarchy": "STATE_HIERARCHY",
            "project": "STATE_PROJECT",
            "assetstore": "STATE_ASSETSTORE",
            "maximize": "STATE_MAXIMIZE",
            "save": "STATE_SAVE",
            "save_all": "STATE_SAVE_ALL",
            "refresh": "STATE_REFRESH",
        }

    def _get_icon_path(self, action_key):
        icon_name = self.icon_map.get(action_key or "play_stop", "STATE_PLAY_STOP")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_key):
        icon_path = self._get_icon_path(action_key)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "full_cmd", "cmd_type", "key_val", "action_key",
            "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_full_cmd = "combo|ctrl+p|Play"
        default_action = "play_stop"
        new_settings = {
            "full_cmd": default_full_cmd,
            "cmd_type": "combo",
            "key_val": "ctrl+p",
            "action_key": default_action,
            "command": default_full_cmd,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })
        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("action_key") or "play_stop")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not PYAUTOGUI_AVAILABLE:
            return

        settings = data.get("payload", {}).get("settings", {})
        cmd_type = settings.get("cmd_type")
        key_val = settings.get("key_val", "")

        if not key_val:
            return

        try:
            if cmd_type == "single":
                await asyncio.to_thread(pyautogui.press, key_val)
            elif cmd_type == "combo":
                keys = key_val.split('+')
                await asyncio.to_thread(pyautogui.hotkey, *keys)
        except Exception as e:
            print(f"[Unity Plugin] Input Error: {e}")
