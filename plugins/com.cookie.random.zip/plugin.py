import asyncio
import random
import base64
import io
from PIL import Image, ImageDraw, ImageFont
import os
import sys

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get('UUID', 'com.cookie.random')
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.icon_map = {
            "d6": "MODE_D6",
            "d20": "MODE_D20",
            "coin": "MODE_COIN",
            "magic_conch": "MODE_MAGIC_CONCH",
            "custom_roulette": "MODE_CUSTOM_ROULETTE",
            "russian_roulette": "MODE_RUSSIAN_ROULETTE",
            "gacha": "MODE_GACHA",
            "rps": "MODE_RPS"
        }

        self.lang = {
            "en": {
                "RESULT_HEADS": "Heads",
                "RESULT_TAILS": "Tails",
                "CONCH": ["No.", "Ask again.", "Stay put.", "Also no.", "Of course!", "Someday..."],
                "RESULT_NO_ITEMS": "No items",
                "RESULT_BANG": "BANG!!!",
                "RESULT_CLICK": "Click!",
                "RESULT_LEGENDARY": "LEGENDARY",
                "RESULT_EPIC": "EPIC",
                "RESULT_RARE": "RARE",
                "RESULT_NORMAL": "NORMAL",
                "RPS": {"Scissors": "✌️", "Rock": "✊", "Paper": "✋"}
            },
            "ko": {
                "RESULT_HEADS": "앞면",
                "RESULT_TAILS": "뒷면",
                "CONCH": ["안 돼.", "다시 한번.", "가만히 있어.", "그것도 안 돼.", "물론!", "언젠가는..."],
                "RESULT_NO_ITEMS": "항목 없음",
                "RESULT_BANG": "탕!!!",
                "RESULT_CLICK": "찰칵!",
                "RESULT_LEGENDARY": "LEGENDARY",
                "RESULT_EPIC": "EPIC",
                "RESULT_RARE": "RARE",
                "RESULT_NORMAL": "NORMAL",
                "RPS": {"가위": "✌️", "바위": "✊", "보": "✋"}
            },
            "ja": {
                "RESULT_HEADS": "表",
                "RESULT_TAILS": "裏",
                "CONCH": ["ダメ。", "もう一度。", "そのままで。", "それもダメ。", "もちろん！", "いつかは..."],
                "RESULT_NO_ITEMS": "項目なし",
                "RESULT_BANG": "バーン!!!",
                "RESULT_CLICK": "カチッ!",
                "RESULT_LEGENDARY": "LEGENDARY",
                "RESULT_EPIC": "EPIC",
                "RESULT_RARE": "RARE",
                "RESULT_NORMAL": "NORMAL",
                "RPS": {"チョキ": "✌️", "グー": "✊", "パー": "✋"}
            },
            "de": {
                "RESULT_HEADS": "Kopf",
                "RESULT_TAILS": "Zahl",
                "CONCH": ["Nein.", "Frag noch mal.", "Bleib lieber.", "Auch nein.", "Natürlich!", "Irgendwann..."],
                "RESULT_NO_ITEMS": "Keine Einträge",
                "RESULT_BANG": "BANG!!!",
                "RESULT_CLICK": "Klick!",
                "RESULT_LEGENDARY": "LEGENDARY",
                "RESULT_EPIC": "EPIC",
                "RESULT_RARE": "RARE",
                "RESULT_NORMAL": "NORMAL",
                "RPS": {"Schere": "✌️", "Stein": "✊", "Papier": "✋"}
            },
            "es": {
                "RESULT_HEADS": "Cara",
                "RESULT_TAILS": "Cruz",
                "CONCH": ["No.", "Pregunta otra vez.", "Quédate quieto.", "Tampoco.", "¡Claro!", "Algún día..."],
                "RESULT_NO_ITEMS": "Sin elementos",
                "RESULT_BANG": "¡BANG!!!",
                "RESULT_CLICK": "¡Click!",
                "RESULT_LEGENDARY": "LEGENDARY",
                "RESULT_EPIC": "EPIC",
                "RESULT_RARE": "RARE",
                "RESULT_NORMAL": "NORMAL",
                "RPS": {"Tijeras": "✌️", "Piedra": "✊", "Papel": "✋"}
            },
            "fr": {
                "RESULT_HEADS": "Pile",
                "RESULT_TAILS": "Face",
                "CONCH": ["Non.", "Redemande.", "Reste sur place.", "Toujours non.", "Bien sûr !", "Un jour..."],
                "RESULT_NO_ITEMS": "Aucun élément",
                "RESULT_BANG": "BANG !!!",
                "RESULT_CLICK": "Click !",
                "RESULT_LEGENDARY": "LEGENDARY",
                "RESULT_EPIC": "EPIC",
                "RESULT_RARE": "RARE",
                "RESULT_NORMAL": "NORMAL",
                "RPS": {"Ciseaux": "✌️", "Pierre": "✊", "Feuille": "✋"}
            },
            "ru": {
                "RESULT_HEADS": "Орёл",
                "RESULT_TAILS": "Решка",
                "CONCH": ["Нет.", "Спроси ещё раз.", "Оставайся на месте.", "Тоже нет.", "Конечно!", "Когда-нибудь..."],
                "RESULT_NO_ITEMS": "Нет элементов",
                "RESULT_BANG": "БАХ!!!",
                "RESULT_CLICK": "Щёлк!",
                "RESULT_LEGENDARY": "LEGENDARY",
                "RESULT_EPIC": "EPIC",
                "RESULT_RARE": "RARE",
                "RESULT_NORMAL": "NORMAL",
                "RPS": {"Ножницы": "✌️", "Камень": "✊", "Бумага": "✋"}
            },
            "it": {
                "RESULT_HEADS": "Testa",
                "RESULT_TAILS": "Croce",
                "CONCH": ["No.", "Chiedi di nuovo.", "Resta fermo.", "Neanche questo.", "Certo!", "Un giorno..."],
                "RESULT_NO_ITEMS": "Nessun elemento",
                "RESULT_BANG": "BANG!!!",
                "RESULT_CLICK": "Click!",
                "RESULT_LEGENDARY": "LEGENDARY",
                "RESULT_EPIC": "EPIC",
                "RESULT_RARE": "RARE",
                "RESULT_NORMAL": "NORMAL",
                "RPS": {"Forbici": "✌️", "Sasso": "✊", "Carta": "✋"}
            },
            "pt-PT": {
                "RESULT_HEADS": "Cara",
                "RESULT_TAILS": "Coroa",
                "CONCH": ["Não.", "Pergunta outra vez.", "Fica quieto.", "Também não.", "Claro!", "Um dia..."],
                "RESULT_NO_ITEMS": "Sem itens",
                "RESULT_BANG": "BANG!!!",
                "RESULT_CLICK": "Click!",
                "RESULT_LEGENDARY": "LEGENDARY",
                "RESULT_EPIC": "EPIC",
                "RESULT_RARE": "RARE",
                "RESULT_NORMAL": "NORMAL",
                "RPS": {"Tesoura": "✌️", "Pedra": "✊", "Papel": "✋"}
            }
        }

    def _lang(self, settings):
        code = (settings.get("_lang") or "en").lower()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        code = alias.get(code, code)
        return code if code in self.lang else "en"

    def _get_icon_path(self, mode):
        icon_name = self.icon_map.get(mode or "d6", "MODE_D6")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, mode):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(mode)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "game_mode", "roulette_items", "builtin_icon_name",
            "default_visuals_initialized", "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_mode = "d6"
        new_settings = {
            "game_mode": default_mode,
            "roulette_items": "",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_mode],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        # Initial placement: icon only, never overwrite title
        await self._send_builtin_icon(context, default_mode)

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")
        payload = data.get("payload", {}) or {}
        settings = payload.get("settings", {}) or {}
        command = payload.get("command")
        mode = payload.get("game_mode") or payload.get("mode")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "sendToPlugin" and command == "apply_builtin_icon":
            await self._send_builtin_icon(context, mode or settings.get("game_mode") or "d6")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        settings = data.get("payload", {}).get("settings", {})
        b64_image = await asyncio.to_thread(self.run_random_game, settings)

        if b64_image:
            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": {"image": b64_image}
            })

    def run_random_game(self, settings):
        mode = settings.get("game_mode", "d6")
        lang = self.lang[self._lang(settings)]

        if mode == "d6":
            result_text = str(random.randint(1, 6))
            return self.create_dice_image(result_text, (231, 76, 60))
        elif mode == "d20":
            result_text = str(random.randint(1, 20))
            return self.create_dice_image(result_text, (41, 128, 185))
        elif mode == "coin":
            result_text = random.choice([lang["RESULT_HEADS"], lang["RESULT_TAILS"]])
            return self.create_text_image(result_text, "🪙", (241, 196, 15))
        elif mode == "magic_conch":
            result_text = random.choice(lang["CONCH"])
            return self.create_text_image(result_text, "🐚", (142, 68, 173))
        elif mode == "custom_roulette":
            items_str = settings.get("roulette_items", lang["RESULT_NO_ITEMS"])
            items = [item.strip() for item in items_str.split(',') if item.strip()]
            result_text = random.choice(items) if items else lang["RESULT_NO_ITEMS"]
            return self.create_text_image(result_text, "🎯", (26, 188, 156))
        elif mode == "russian_roulette":
            if random.randint(1, 6) == 1:
                return self.create_text_image(lang["RESULT_BANG"], "💥", (192, 57, 43), large_font=True)
            else:
                return self.create_text_image(lang["RESULT_CLICK"], "😌", (46, 204, 113))
        elif mode == "gacha":
            rand_val = random.random()
            if rand_val < 0.05:
                result, color = lang["RESULT_LEGENDARY"], (255, 215, 0)
            elif rand_val < 0.20:
                result, color = lang["RESULT_EPIC"], (155, 89, 182)
            elif rand_val < 0.50:
                result, color = lang["RESULT_RARE"], (52, 152, 219)
            else:
                result, color = lang["RESULT_NORMAL"], (149, 165, 166)
            return self.create_text_image(result, "✨", color, large_font=True)
        elif mode == "rps":
            result = random.choice(list(lang["RPS"].keys()))
            return self.create_text_image(result, lang["RPS"][result], (230, 126, 34))

        return None

    def _font_candidates(self, font_name):
        name = (font_name or "").lower()
        plugin_fonts = [
            os.path.join(self.plugin_dir, "fonts", font_name),
            os.path.join(self.plugin_dir, font_name),
        ]

        if "emoji" in name or "seguiemj" in name:
            system_fonts = [
                # Windows
                r"C:\\Windows\\Fonts\\seguiemj.ttf",
                # macOS
                "/System/Library/Fonts/Apple Color Emoji.ttc",
                # Linux common
                "/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf",
            ]
        else:
            system_fonts = [
                # Windows
                r"C:\\Windows\\Fonts\\malgunbd.ttf",
                r"C:\\Windows\\Fonts\\malgun.ttf",
                # macOS Korean / Latin fallbacks
                "/System/Library/Fonts/AppleSDGothicNeo.ttc",
                "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
                "/Library/Fonts/Arial Unicode.ttf",
                # Linux common
                "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc",
                "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            ]

        return plugin_fonts + system_fonts

    def get_font(self, font_name, size):
        for candidate in self._font_candidates(font_name):
            try:
                if candidate and os.path.exists(candidate):
                    return ImageFont.truetype(candidate, size)
            except Exception:
                pass
        try:
            return ImageFont.truetype(font_name, size)
        except Exception:
            return ImageFont.load_default()

    def create_dice_image(self, text, bg_color):
        img = Image.new('RGB', (128, 128), color=bg_color)
        draw = ImageDraw.Draw(img)
        font_size = 80
        font = self.get_font("malgunbd.ttf", font_size)
        max_width = 116

        try:
            w = draw.textlength(text, font=font)
            while w > max_width and font_size > 15:
                font_size -= 5
                font = self.get_font("malgunbd.ttf", font_size)
                w = draw.textlength(text, font=font)
        except:
            w = len(text) * (font_size / 2)

        y_pos = 64 - (font_size / 2) - 10
        draw.text(((128 - w) / 2, y_pos), text, font=font, fill=(255,255,255))
        return self._image_to_base64(img)

    def create_text_image(self, text, icon, bg_color, large_font=False):
        img = Image.new('RGB', (128, 128), color=bg_color)
        draw = ImageDraw.Draw(img)

        font_icon = self.get_font("seguiemj.ttf", 40)
        base_size = 28 if large_font else 22
        font_text = self.get_font("malgunbd.ttf", base_size)

        try:
            w_icon = draw.textlength(icon, font=font_icon)
        except:
            w_icon = 40
        draw.text(((128 - w_icon) / 2, 15), icon, font=font_icon, fill=(255,255,255))

        max_width = 116
        try:
            w_text = draw.textlength(text, font=font_text)
            while w_text > max_width and base_size > 10:
                base_size -= 2
                font_text = self.get_font("malgunbd.ttf", base_size)
                w_text = draw.textlength(text, font=font_text)
        except:
            w_text = len(text) * (base_size / 2)

        y_pos = 75 - ((28 - base_size) / 4)
        draw.text(((128 - w_text) / 2, y_pos), text, font=font_text, fill=(255,255,255), align="center")
        return self._image_to_base64(img)

    def _image_to_base64(self, img):
        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        return f"data:image/png;base64,{base64.b64encode(buffered.getvalue()).decode('utf-8')}"
