on zoneList(layoutName)
	if layoutName is "thirds" then return {{0, 0, 0.3333, 1}, {0.3333, 0, 0.3334, 1}, {0.6667, 0, 0.3333, 1}}
	if layoutName is "wide-center" then return {{0, 0, 0.25, 1}, {0.25, 0, 0.5, 1}, {0.75, 0, 0.25, 1}}
	if layoutName is "rows" then return {{0, 0, 1, 0.5}, {0, 0.5, 1, 0.5}}
	if layoutName is "quarters" then return {{0, 0, 0.5, 0.5}, {0.5, 0, 0.5, 0.5}, {0, 0.5, 0.5, 0.5}, {0.5, 0.5, 0.5, 0.5}}
	if layoutName is "left-main" then return {{0, 0, 0.65, 1}, {0.65, 0, 0.35, 0.5}, {0.65, 0.5, 0.35, 0.5}}
	if layoutName is "right-main" then return {{0, 0, 0.35, 0.5}, {0, 0.5, 0.35, 0.5}, {0.35, 0, 0.65, 1}}
	if layoutName is "six" then return {{0, 0, 0.3333, 0.5}, {0.3333, 0, 0.3334, 0.5}, {0.6667, 0, 0.3333, 0.5}, {0, 0.5, 0.3333, 0.5}, {0.3333, 0.5, 0.3334, 0.5}, {0.6667, 0.5, 0.3333, 0.5}}
	if layoutName is "nine" then return {{0, 0, 0.3333, 0.3333}, {0.3333, 0, 0.3334, 0.3333}, {0.6667, 0, 0.3333, 0.3333}, {0, 0.3333, 0.3333, 0.3334}, {0.3333, 0.3333, 0.3334, 0.3334}, {0.6667, 0.3333, 0.3333, 0.3334}, {0, 0.6667, 0.3333, 0.3333}, {0.3333, 0.6667, 0.3334, 0.3333}, {0.6667, 0.6667, 0.3333, 0.3333}}
	if layoutName is "focus" then return {{0, 0, 0.2, 1}, {0.2, 0, 0.6, 1}, {0.8, 0, 0.2, 1}}
	return {{0, 0, 0.5, 1}, {0.5, 0, 0.5, 1}}
end zoneList

on run argv
	set layoutName to item 1 of argv
	set zones to zoneList(layoutName)
	set zoneIndex to 1
	set zoneData to item zoneIndex of zones

	tell application "Finder"
		set desktopBounds to bounds of window of desktop
	end tell
	set screenWidth to item 3 of desktopBounds
	set screenHeight to item 4 of desktopBounds
	set menuBarHeight to 25
	set leftEdge to (item 1 of zoneData) * screenWidth
	set topEdge to menuBarHeight + (item 2 of zoneData) * (screenHeight - menuBarHeight)
	set rightEdge to leftEdge + (item 3 of zoneData) * screenWidth
	set bottomEdge to topEdge + (item 4 of zoneData) * (screenHeight - menuBarHeight)

	tell application "System Events"
		set frontProcess to first application process whose frontmost is true
		if exists window 1 of frontProcess then
			set position of window 1 of frontProcess to {leftEdge as integer, topEdge as integer}
			set size of window 1 of frontProcess to {(rightEdge - leftEdge) as integer, (bottomEdge - topEdge) as integer}
		end if
	end tell

end run
