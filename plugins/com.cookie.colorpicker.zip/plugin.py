import asyncio
import base64
import io
import ctypes
import os

try:
    from PIL import Image
    import pyautogui
    PIL_OK = True
except ImportError:
    Image = None
    pyautogui = None
    PIL_OK = False

user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.default_icon_path = os.path.join(self.plugin_dir, "icon", "PICK_COLOR.png")
        self.context_settings = {}

    def _default_settings(self):
        return {
            "sync_led": False,
            "_lang": "en",
            "sync_title_on_pick": False,
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("sync_led", False),
            s.get("_lang"),
            s.get("title"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_pick", False)
        ])

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self.on_key_did_appear(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if event == "keyDown":
            await self.on_key_down(context, settings)

    async def on_key_did_appear(self, context, incoming_settings):
        if not context:
            return

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            if os.path.exists(self.default_icon_path):
                await self.runner.send_message({
                    "event": "setIcon",
                    "context": context,
                    "payload": {"icon_path": self.default_icon_path}
                })
            return

        self.context_settings[context] = self._merge_with_defaults(incoming_settings)

    def get_pixel_color(self, x, y):
        hdc = user32.GetDC(0)
        pixel = gdi32.GetPixel(hdc, x, y)
        user32.ReleaseDC(0, hdc)

        r = pixel & 0xFF
        g = (pixel >> 8) & 0xFF
        b = (pixel >> 16) & 0xFF
        return r, g, b

    async def on_key_down(self, context, incoming_settings):
        if not context or not PIL_OK:
            return

        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **(incoming_settings or {})})
        self.context_settings[context] = settings

        x, y = pyautogui.position()

        try:
            r, g, b = self.get_pixel_color(x, y)
            hex_val = f"#{r:02x}{g:02x}{b:02x}".upper()

            color_img = Image.new("RGB", (128, 128), (r, g, b))
            buffer = io.BytesIO()
            color_img.save(buffer, format="PNG")
            b64_str = base64.b64encode(buffer.getvalue()).decode()

            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": {"image": f"data:image/png;base64,{b64_str}"}
            })

            if settings.get("sync_title_on_pick", False):
                settings["title"] = hex_val
                self.context_settings[context] = settings

                await self.runner.send_message({
                    "event": "setSettings",
                    "context": context,
                    "payload": settings
                })

                await self.runner.send_message({
                    "event": "setTitle",
                    "context": context,
                    "payload": {"title": hex_val}
                })

            if settings.get("sync_led", False):
                await self.runner.send_message({
                    "event": "sendToPlugin",
                    "context": context,
                    "payload": {
                        "command": "direct_serial",
                        "serial_cmd": 0xC0,
                        "serial_data": [255, r, g, b]
                    }
                })

            print(f"[ColorPicker] Picked: {hex_val} at ({x}, {y})")

        except Exception as e:
            print(f"[ColorPicker Error] {e}")
