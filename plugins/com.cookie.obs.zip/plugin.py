import asyncio
import base64
import hashlib
import json
import os
import sys
import time
import traceback

import websockets


class OBSPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.obs"
        self.uri = "ws://localhost:8765"
        self.cd_ws = None
        self.obs_ws = None
        self.obs_connected = False

        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_file = os.path.join(self.plugin_dir, "obs_config.json")
        self.desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")

        self.last_valid_settings = {}
        self.pending_requests = {}
        self.config = {"ip": "localhost", "port": 4455, "password": ""}
        self.load_config()

        # Property Inspector가 한 번이라도 요청했던 context 추적
        self.scene_list_contexts = set()
        self.input_list_contexts = set()
        self.transition_list_contexts = set()

        # 마지막으로 받아온 목록 캐시
        self.cached_scenes = []
        self.cached_inputs = []
        self.cached_transitions = []

        # 연결 직후 너무 빨리 목록 요청이 나가지 않도록 후처리 태스크 분리
        self.post_connect_refresh_task = None

    def log(self, message: str):
        try:
            print(message, flush=True)
        except Exception:
            pass

    def load_config(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    self.config.update(json.load(f))
            except Exception as e:
                self.log(f"[OBS] Config load error: {e}")

    def save_config(self):
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            self.log(f"[OBS] Save config error: {e}")

    def is_obs_connected(self) -> bool:
        return self.obs_ws is not None and self.obs_connected

    async def send_to_pi(self, context, payload):
        if not self.cd_ws or not context:
            return
        try:
            await self.cd_ws.send(json.dumps({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": payload,
            }))
        except Exception as e:
            self.log(f"[OBS] sendToPI error: {e}")

    async def fetch_scene_list(self):
        if not self.is_obs_connected():
            return self.cached_scenes
        res = await self.send_to_obs("GetSceneList")
        if self._response_ok(res):
            self.cached_scenes = self._response_data(res).get("scenes", [])
        return self.cached_scenes

    async def fetch_input_list(self):
        if not self.is_obs_connected():
            return self.cached_inputs
        res = await self.send_to_obs("GetInputList")
        if self._response_ok(res):
            self.cached_inputs = self._response_data(res).get("inputs", [])
        return self.cached_inputs

    async def fetch_transition_list(self):
        if not self.is_obs_connected():
            return self.cached_transitions
        res = await self.send_to_obs("GetSceneTransitionList")
        if self._response_ok(res):
            self.cached_transitions = self._response_data(res).get("transitions", [])
        return self.cached_transitions

    async def broadcast_scene_list(self):
        for context in list(self.scene_list_contexts):
            await self.send_to_pi(context, {
                "command": "sceneList",
                "scenes": self.cached_scenes,
            })

    async def broadcast_input_list(self):
        for context in list(self.input_list_contexts):
            await self.send_to_pi(context, {
                "command": "inputList",
                "inputs": self.cached_inputs,
            })

    async def broadcast_transition_list(self):
        for context in list(self.transition_list_contexts):
            await self.send_to_pi(context, {
                "command": "transitionList",
                "transitions": self.cached_transitions,
            })

    async def refresh_all_lists_and_broadcast(self):
        if not self.is_obs_connected():
            return
        await self.fetch_scene_list()
        await self.fetch_input_list()
        await self.fetch_transition_list()
        await self.broadcast_scene_list()
        await self.broadcast_input_list()
        await self.broadcast_transition_list()
        self.log("[OBS] Property Inspector lists refreshed after connect/reconnect")

    async def delayed_refresh_after_connect(self):
        # OBS identify 직후 바로 요청하면 응답 수신 루프가 아직 안정적으로 돌기 전일 수 있어
        # 약간 지연 후 여러 번 재시도해서 PI의 "로딩 중" 상태를 자동 해제한다.
        delays = (0.8, 1.5, 3.0)
        for idx, delay in enumerate(delays, start=1):
            await asyncio.sleep(delay)
            if not self.is_obs_connected():
                return
            try:
                await self.refresh_all_lists_and_broadcast()
                self.log(f"[OBS] Delayed auto-refresh pass {idx} completed")
            except Exception as e:
                self.log(f"[OBS] Delayed auto-refresh pass {idx} failed: {e}")

    async def connect_to_obs(self):
        while True:
            try:
                if self.obs_ws is not None:
                    try:
                        await self.obs_ws.close()
                    except Exception:
                        pass

                self.obs_ws = None
                self.obs_connected = False

                obs_uri = f"ws://{self.config['ip']}:{self.config['port']}"
                self.log(f"[OBS] Connecting to OBS Studio at {obs_uri}...")

                async with websockets.connect(obs_uri) as ws:
                    self.obs_ws = ws

                    hello_msg = json.loads(await ws.recv())
                    if hello_msg.get("op") != 0:
                        raise RuntimeError(f"Unexpected hello packet: {hello_msg}")

                    auth_data = hello_msg.get("d", {}).get("authentication")
                    identify_payload = {
                        "op": 1,
                        "d": {
                            "rpcVersion": 1,
                            "eventSubscriptions": 0,
                        },
                    }

                    if auth_data:
                        password = self.config.get("password", "")
                        if not password:
                            raise RuntimeError("OBS password is empty in obs_config.json")

                        secret = base64.b64encode(
                            hashlib.sha256((password + auth_data["salt"]).encode("utf-8")).digest()
                        ).decode("utf-8")
                        auth_response = base64.b64encode(
                            hashlib.sha256((secret + auth_data["challenge"]).encode("utf-8")).digest()
                        ).decode("utf-8")
                        identify_payload["d"]["authentication"] = auth_response

                    await ws.send(json.dumps(identify_payload))
                    identified_msg = json.loads(await ws.recv())
                    if identified_msg.get("op") != 2:
                        raise RuntimeError(f"OBS identify/auth failed: {identified_msg}")

                    self.obs_connected = True
                    self.log("[OBS] Successfully Connected & Authenticated!")

                    # 기존 후처리 태스크가 남아 있으면 정리
                    if self.post_connect_refresh_task and not self.post_connect_refresh_task.done():
                        self.post_connect_refresh_task.cancel()

                    # 리더 루프가 먼저 안정적으로 돈 뒤에 목록 재동기화가 수행되도록 지연 태스크 사용
                    self.post_connect_refresh_task = asyncio.create_task(
                        self.delayed_refresh_after_connect()
                    )

                    async for message in ws:
                        try:
                            msg_data = json.loads(message)
                        except Exception:
                            continue

                        if msg_data.get("op") == 7:
                            req_id = msg_data.get("d", {}).get("requestId")
                            future = self.pending_requests.get(req_id)
                            if future and not future.done():
                                future.set_result(msg_data)

            except Exception as e:
                self.log(f"[OBS] Connection Error: {e}")

            finally:
                self.obs_connected = False
                self.obs_ws = None
                if self.post_connect_refresh_task and not self.post_connect_refresh_task.done():
                    self.post_connect_refresh_task.cancel()
                self.post_connect_refresh_task = None
                for _, fut in list(self.pending_requests.items()):
                    if not fut.done():
                        fut.cancel()
                self.pending_requests.clear()

            await asyncio.sleep(5)

    async def send_to_obs(self, request_type, request_data=None, request_id=None):
        if not self.is_obs_connected():
            self.log(f"[OBS] Not connected. Cannot send {request_type}")
            return None

        if request_data is None:
            request_data = {}
        if request_id is None:
            request_id = f"{request_type}-{time.time()}"

        payload = {
            "op": 6,
            "d": {
                "requestType": request_type,
                "requestId": request_id,
                "requestData": request_data,
            },
        }

        loop = asyncio.get_running_loop()
        future = loop.create_future()
        self.pending_requests[request_id] = future

        try:
            await self.obs_ws.send(json.dumps(payload))
            response = await asyncio.wait_for(future, timeout=4.0)
            status = response.get("d", {}).get("requestStatus", {})
            if not status.get("result", False):
                self.log(
                    f"[OBS] Request failed: {request_type} code={status.get('code')} comment={status.get('comment')}"
                )
            return response

        except asyncio.TimeoutError:
            self.log(f"[OBS] Request Timeout: {request_type}")
            return None

        except asyncio.CancelledError:
            self.log(f"[OBS] Request Cancelled: {request_type}")
            return None

        except Exception as e:
            self.log(f"[OBS] Send Error: {request_type} -> {e}")
            self.obs_connected = False
            return None

        finally:
            self.pending_requests.pop(request_id, None)

    def _response_ok(self, response):
        return bool(response and response.get("d", {}).get("requestStatus", {}).get("result", False))

    def _response_data(self, response):
        if not response:
            return {}
        return response.get("d", {}).get("responseData", {}) or {}

    async def connect_to_cookiedeck(self):
        while True:
            try:
                self.log(f"[OBS Plugin] Connecting to CookieDeck at {self.uri}...")
                async with websockets.connect(self.uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    self.log("[OBS Plugin] Registered to CookieDeck!")

                    async for message in ws:
                        data = json.loads(message)
                        await self.handle_message(data)

            except Exception as e:
                self.log(f"[OBS Plugin] Disconnected. Retrying... ({e})")

            finally:
                self.cd_ws = None

            await asyncio.sleep(3)

    async def handle_message(self, data):
        try:
            event = data.get("event")
            context = data.get("context")
            payload = data.get("payload", {}) or {}

            if event == "keyDidAppear":
                settings = payload.get("settings", {}) or {}
                if context and settings:
                    self.last_valid_settings[context] = settings
                    self.log(f"[OBS] Settings Primed for {context}")
                return

            if event == "didReceiveSettings":
                settings = payload.get("settings", payload) or {}
                if context and settings:
                    if context not in self.last_valid_settings:
                        self.last_valid_settings[context] = {}
                    self.last_valid_settings[context].update(settings)
                    self.log(f"[OBS] Settings Cached for {context}")
                return

            if event == "keyDown":
                await self.on_key_down(data)
                return

            if event == "sendToPlugin":
                command = payload.get("command")
                if not command:
                    payload = payload.get("payload", {}) or {}
                    command = payload.get("command")

                if command == "getObsSettings":
                    await self.send_to_pi(context, {
                        "command": "obsSettings",
                        "settings": self.config,
                    })

                elif command == "setObsSettings":
                    new_settings = payload.get("settings", {}) or {}
                    self.config.update(new_settings)
                    self.save_config()
                    self.log("[OBS] Config updated. Reconnecting to OBS...")
                    try:
                        if self.obs_ws is not None:
                            await self.obs_ws.close()
                    except Exception:
                        pass
                    if self.cd_ws and context:
                        await self.cd_ws.send(json.dumps({"event": "closeSettings", "key": context}))

                elif command == "getSceneList":
                    if context:
                        self.scene_list_contexts.add(context)
                    if self.cached_scenes:
                        await self.send_to_pi(context, {"command": "sceneList", "scenes": self.cached_scenes})
                    if self.is_obs_connected():
                        await self.fetch_scene_list()
                        await self.send_to_pi(context, {"command": "sceneList", "scenes": self.cached_scenes})

                elif command == "getInputList":
                    if context:
                        self.input_list_contexts.add(context)
                    if self.cached_inputs:
                        await self.send_to_pi(context, {"command": "inputList", "inputs": self.cached_inputs})
                    if self.is_obs_connected():
                        await self.fetch_input_list()
                        await self.send_to_pi(context, {"command": "inputList", "inputs": self.cached_inputs})

                elif command == "getTransitionList":
                    if context:
                        self.transition_list_contexts.add(context)
                    if self.cached_transitions:
                        await self.send_to_pi(context, {"command": "transitionList", "transitions": self.cached_transitions})
                    if self.is_obs_connected():
                        await self.fetch_transition_list()
                        await self.send_to_pi(context, {"command": "transitionList", "transitions": self.cached_transitions})
                return

        except Exception as e:
            self.log(f"[OBS Plugin] Message Handling Error: {e}")
            self.log(traceback.format_exc())

    async def ensure_settings(self, context, payload):
        incoming_settings = payload.get("settings", {}) if isinstance(payload, dict) else {}
        if incoming_settings:
            self.last_valid_settings[context] = incoming_settings

        final_settings = self.last_valid_settings.get(context, {})
        if final_settings:
            return final_settings

        if self.cd_ws and context:
            self.log(f"[OBS] Missing settings for {context}. Requesting from engine...")
            await self.cd_ws.send(json.dumps({
                "event": "getSettings",
                "context": context,
            }))
            for _ in range(15):
                await asyncio.sleep(0.1)
                if self.last_valid_settings.get(context):
                    final_settings = self.last_valid_settings[context]
                    break
        return final_settings

    async def toggle_studio_mode(self):
        state_res = await self.send_to_obs("GetStudioModeEnabled")
        if not self._response_ok(state_res):
            return False
        enabled = bool(self._response_data(state_res).get("studioModeEnabled", False))
        set_res = await self.send_to_obs("SetStudioModeEnabled", {"studioModeEnabled": not enabled})
        return self._response_ok(set_res)

    async def toggle_scene_item(self, scene_name, source_name):
        item_res = await self.send_to_obs("GetSceneItemId", {
            "sceneName": scene_name,
            "sourceName": source_name,
        })
        if not self._response_ok(item_res):
            return False

        scene_item_id = self._response_data(item_res).get("sceneItemId")
        if scene_item_id is None:
            self.log(f"[OBS] Scene item not found: scene={scene_name!r}, source={source_name!r}")
            return False

        enabled_res = await self.send_to_obs("GetSceneItemEnabled", {
            "sceneName": scene_name,
            "sceneItemId": scene_item_id,
        })
        if not self._response_ok(enabled_res):
            return False

        current = bool(self._response_data(enabled_res).get("sceneItemEnabled", False))
        set_res = await self.send_to_obs("SetSceneItemEnabled", {
            "sceneName": scene_name,
            "sceneItemId": scene_item_id,
            "sceneItemEnabled": not current,
        })
        return self._response_ok(set_res)

    async def media_play_pause(self, input_name):
        status_res = await self.send_to_obs("GetMediaInputStatus", {"inputName": input_name})
        if not self._response_ok(status_res):
            return False

        media_state = self._response_data(status_res).get("mediaState")
        if media_state in (
            "OBS_MEDIA_STATE_PLAYING",
            "OBS_MEDIA_STATE_OPENING",
            "OBS_MEDIA_STATE_BUFFERING",
        ):
            action = "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_PAUSE"
        else:
            action = "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_PLAY"

        act_res = await self.send_to_obs("TriggerMediaInputAction", {
            "inputName": input_name,
            "mediaAction": action,
        })
        return self._response_ok(act_res)

    async def screenshot_source(self, source_name):
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"OBS_{source_name}_{timestamp}.png".replace(" ", "_")
        save_path = os.path.join(self.desktop_path, filename).replace("\\", "/")
        res = await self.send_to_obs("SaveSourceScreenshot", {
            "sourceName": source_name,
            "imageFormat": "png",
            "imageFilePath": save_path,
        })
        if self._response_ok(res):
            self.log(f"[OBS] Screenshot saved: {save_path}")
            return True
        return False

    async def on_key_down(self, data):
        context = data.get("context") or data.get("action")
        if not context:
            self.log("[OBS] keyDown without context/action")
            return

        payload = data.get("payload", {}) or {}
        final_settings = await self.ensure_settings(context, payload)

        obs_action = final_settings.get("command") or final_settings.get("obs_action")
        if not obs_action:
            self.log(f"[OBS] No action found for {context}. Ignored.")
            return

        req_type = None
        req_data = {}

        if obs_action == "stream_toggle":
            req_type = "ToggleStream"
        elif obs_action == "record_toggle":
            req_type = "ToggleRecord"
        elif obs_action == "virtual_cam_toggle":
            req_type = "ToggleVirtualCam"
        elif obs_action == "replay_buffer_toggle":
            req_type = "ToggleReplayBuffer"
        elif obs_action == "replay_buffer_save":
            req_type = "SaveReplayBuffer"
        elif obs_action == "record_chapter":
            req_type = "CreateRecordChapter"
            req_data = {"chapterName": "CookieDeck Marker"}
        elif obs_action == "stream_marker":
            self.log("[OBS] stream_marker is not supported in this build")
            return
        elif obs_action == "studio_mode_toggle":
            ok = await self.toggle_studio_mode()
            self.log(f"[OBS] studio_mode_toggle => {ok}")
            return
        elif obs_action == "trigger_transition":
            req_type = "TriggerStudioModeTransition"
        elif obs_action == "set_transition":
            target_trans = final_settings.get("target_transition")
            if target_trans:
                req_type = "SetCurrentSceneTransition"
                req_data = {"transitionName": target_trans}
        elif obs_action == "change_scene":
            target_sc = final_settings.get("target_scene")
            if target_sc:
                req_type = "SetCurrentProgramScene"
                req_data = {"sceneName": target_sc}
        elif obs_action == "toggle_source":
            target_nm = final_settings.get("target_name", "")
            parts = [p.strip() for p in target_nm.split(";", 1)]
            if len(parts) == 2 and parts[0] and parts[1]:
                ok = await self.toggle_scene_item(parts[0], parts[1])
                self.log(f"[OBS] toggle_source => {ok}")
                return
        elif obs_action == "filter_control":
            src = final_settings.get("target_input")
            flt = final_settings.get("filter_name")
            state = final_settings.get("enable_state", "true") == "true"
            if src and flt:
                req_type = "SetSourceFilterEnabled"
                req_data = {"sourceName": src, "filterName": flt, "filterEnabled": state}
        elif obs_action == "media_play_pause":
            inp = final_settings.get("target_input")
            if inp:
                ok = await self.media_play_pause(inp)
                self.log(f"[OBS] media_play_pause => {ok}")
                return
        elif obs_action == "media_restart":
            inp = final_settings.get("target_input")
            if inp:
                req_type = "TriggerMediaInputAction"
                req_data = {
                    "inputName": inp,
                    "mediaAction": "OBS_WEBSOCKET_MEDIA_INPUT_ACTION_RESTART",
                }
        elif obs_action == "toggle_mute":
            inp = final_settings.get("target_input")
            if inp:
                req_type = "ToggleInputMute"
                req_data = {"inputName": inp}
        elif obs_action == "screenshot_source":
            src = final_settings.get("target_input")
            if src:
                ok = await self.screenshot_source(src)
                self.log(f"[OBS] screenshot_source => {ok}")
                return

        if req_type:
            self.log(f"[OBS Action] Executing: {req_type} with data {req_data}")
            await self.send_to_obs(req_type, req_data, f"{obs_action}-{context}")

    async def start(self):
        asyncio.create_task(self.connect_to_obs())
        await self.connect_to_cookiedeck()


if __name__ == "__main__":
    plugin = OBSPlugin()
    try:
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(plugin.start())
    except KeyboardInterrupt:
        print("[OBS Plugin] Shutting down...", flush=True)

