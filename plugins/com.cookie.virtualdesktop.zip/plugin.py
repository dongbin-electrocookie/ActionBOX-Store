import asyncio
import ctypes
import sys
import time
import os
import subprocess

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

VK_CONTROL = 0x11
VK_LWIN = 0x5B
VK_LEFT = 0x25
VK_RIGHT = 0x27
VK_D = 0x44
VK_F4 = 0x73
VK_TAB = 0x09

KEYEVENTF_KEYDOWN = 0x0000
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_EXTENDEDKEY = 0x0001


def press_hardware_key(vk, is_arrow=False):
    if not IS_WINDOWS:
        return
    scan = ctypes.windll.user32.MapVirtualKeyA(vk, 0)
    flags = KEYEVENTF_KEYDOWN
    if is_arrow:
        flags |= KEYEVENTF_EXTENDEDKEY
    ctypes.windll.user32.keybd_event(vk, scan, flags, 0)


def release_hardware_key(vk, is_arrow=False):
    if not IS_WINDOWS:
        return
    scan = ctypes.windll.user32.MapVirtualKeyA(vk, 0)
    flags = KEYEVENTF_KEYUP
    if is_arrow:
        flags |= KEYEVENTF_EXTENDEDKEY
    ctypes.windll.user32.keybd_event(vk, scan, flags, 0)


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.icon_map = {
            "next": "STATE_NEXT",
            "prev": "STATE_PREV",
            "new": "STATE_NEW",
            "close": "STATE_CLOSE",
            "view": "STATE_VIEW",
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "next", "STATE_NEXT")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _send_status_title(self, context, title):
        if context:
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": title}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "command", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        state_val = None
        if "#" in (action_id or ""):
            state_val = action_id.split("#")[-1]

        default_action = state_val or "next"
        if default_action not in self.icon_map:
            default_action = "next"

        new_settings = {
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        action_id = data.get("action", "")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("command") or "next")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        action_id = data.get("action", "")
        state_val = None
        if "#" in action_id:
            state_val = action_id.split("#")[-1]

        payload = data.get("payload", {}) or {}
        settings = payload.get("settings", {}) or {}
        context = data.get("context") or payload.get("context")
        action = settings.get("command") or state_val or "next"

        if IS_WINDOWS:
            await asyncio.to_thread(self._run_windows_vd_command, action)
        elif IS_MACOS:
            ok = await asyncio.to_thread(self._run_macos_space_command, action)
            if not ok and action in ("new", "close"):
                await self._send_status_title(context, "macOS limited")
        else:
            # Linux desktop/workspace shortcuts vary by desktop environment.
            await asyncio.to_thread(self._run_linux_workspace_command, action)

    def _run_windows_vd_command(self, action):
        press_hardware_key(VK_CONTROL)
        press_hardware_key(VK_LWIN)
        time.sleep(0.05)

        if action == "next":
            press_hardware_key(VK_RIGHT, is_arrow=True)
            time.sleep(0.05)
            release_hardware_key(VK_RIGHT, is_arrow=True)
        elif action == "prev":
            press_hardware_key(VK_LEFT, is_arrow=True)
            time.sleep(0.05)
            release_hardware_key(VK_LEFT, is_arrow=True)
        elif action == "new":
            press_hardware_key(VK_D)
            time.sleep(0.05)
            release_hardware_key(VK_D)
        elif action == "close":
            press_hardware_key(VK_F4)
            time.sleep(0.05)
            release_hardware_key(VK_F4)
        elif action == "view":
            release_hardware_key(VK_CONTROL)
            press_hardware_key(VK_TAB)
            time.sleep(0.05)
            release_hardware_key(VK_TAB)

        time.sleep(0.05)
        release_hardware_key(VK_LWIN)
        release_hardware_key(VK_CONTROL)

    def _mac_hotkey(self, *keys):
        if pyautogui_available:
            pyautogui.hotkey(*keys)
            return True

        # Fallback through AppleScript/System Events when pyautogui is unavailable.
        key_code_map = {
            "left": 123,
            "right": 124,
            "up": 126,
            "down": 125,
            "escape": 53,
        }
        modifier_map = {
            "ctrl": "control down",
            "control": "control down",
            "command": "command down",
            "cmd": "command down",
            "option": "option down",
            "alt": "option down",
            "shift": "shift down",
        }
        mods = [modifier_map[k] for k in keys[:-1] if k in modifier_map]
        last = keys[-1]
        if last not in key_code_map:
            return False
        using = f" using {{{', '.join(mods)}}}" if mods else ""
        subprocess.run([
            "osascript", "-e",
            f'tell application "System Events" to key code {key_code_map[last]}{using}'
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True

    def _run_macos_space_command(self, action):
        """
        macOS Spaces is not a 1:1 match with Windows Virtual Desktop.
        Reliable default shortcuts:
          - Control + Left/Right: move between Spaces, if enabled in Mission Control shortcuts.
          - Control + Up: Mission Control.
        Creating/closing a Space has no stable default keyboard shortcut, so those are best-effort only.
        """
        if action == "next":
            return self._mac_hotkey("ctrl", "right")
        if action == "prev":
            return self._mac_hotkey("ctrl", "left")
        if action == "view":
            return self._mac_hotkey("ctrl", "up")

        if action == "new":
            if not pyautogui_available:
                return False
            # Best-effort: open Mission Control and click the + button near the top-right.
            pyautogui.hotkey("ctrl", "up")
            time.sleep(0.45)
            width, _height = pyautogui.size()
            pyautogui.click(width - 32, 28)
            time.sleep(0.15)
            pyautogui.press("escape")
            return True

        if action == "close":
            # macOS has no reliable keyboard-only shortcut to close the current Space.
            # Users can close Spaces in Mission Control manually. Avoid coordinate hacks that may close the wrong Space.
            self._mac_hotkey("ctrl", "up")
            return False

        return False

    def _run_linux_workspace_command(self, action):
        if not pyautogui_available:
            return
        if action == "next":
            pyautogui.hotkey("ctrl", "alt", "right")
        elif action == "prev":
            pyautogui.hotkey("ctrl", "alt", "left")
        elif action == "view":
            pyautogui.hotkey("super", "s")
