import asyncio
import platform

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 모션 그래픽 디자이너의 영혼의 단축키 맵
        self.action_map = {
            # 1. 파일
            "file_save": "ctrl+s",
            "file_render": "ctrl+m",

            # 2. 레이어 속성 (Properties)
            "prop_position": "p",
            "prop_scale": "s",
            "prop_rotation": "r",
            "prop_opacity": "t",
            "prop_anchor": "a",
            "prop_reveal_keys": "u",

            # 3. 키프레임 추가 (Add Keyframes)
            "key_add_position": "alt+p",
            "key_add_scale": "alt+s",
            "key_add_rotation": "alt+r",
            "key_add_opacity": "alt+t",

            # 4. 이지 이즈 (Easy Ease)
            "key_easy_ease": "f9",
            "key_ease_in": "shift+f9",
            "key_ease_out": "ctrl+shift+f9",

            # 5. 타임라인 탐색 (Timeline Navigation)
            "time_prev_key": "j",
            "time_next_key": "k",
            "time_prev_frame": "page up",
            "time_next_frame": "page down",
            "time_go_in": "i",
            "time_go_out": "o",

            # 6. 레이어 편집 (Layer Edit)
            "layer_split": "ctrl+shift+d",
            "layer_trim_in": "alt+[",
            "layer_trim_out": "alt+]",
            "layer_precomp": "ctrl+shift+c",

            # 7. 프리뷰 및 도구 (Preview & Tools)
            "preview_ram": "space", # 최근 버전은 스페이스바로 RAM 프리뷰 기본 통일
            "tool_selection": "v",
            "tool_hand": "h",
            "tool_pen": "g"
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("ae_action", "prop_position")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)