import asyncio
import urllib.request
import json
import os
import re
import urllib.error
from urllib.parse import quote, urlsplit

API_TIMEOUT_SECONDS = 8
WEBHOOK_TIMEOUT_SECONDS = 8
POLL_INTERVAL_SECONDS = 60
RAILWAY_API = "https://backboard.railway.com/graphql/v2"


class APIError(Exception):
    """Only a safe, localized status key crosses the request boundary."""
    def __init__(self, status="API_ERR"):
        self.status = status
        super().__init__(status)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Never forward bearer/project tokens or repeat mutations on redirects.
        return None

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.polling_tasks = {}
        self.active_contexts = {}
        self.context_settings = {}
        self.locale_cache = {}
        self.execution_locks = {}
        self.execution_tasks = {}
        self.removed_contexts = set()
        self.closed = False
        self.http = urllib.request.build_opener(NoRedirect())
        self.icon_map = {
            ("vercel", "redeploy"): "vercel force",
            ("netlify", "monitor"): "netlify monitor", ("netlify", "redeploy"): "netlify trigger build",
            ("cloudflare", "monitor"): "cloudflare monitor", ("cloudflare", "redeploy"): "cloudflare purge cache",
            ("railway", "monitor"): "railway monitor", ("railway", "redeploy"): "railway restart server",
            ("github", "monitor"): "github monitor", ("github", "redeploy"): "github dispatch",
        }

    def tr(self, settings, key):
        lang = str((settings or {}).get("_lang", "en")).replace("_", "-")
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        lang = alias.get(lang, lang)
        if lang not in ("en", "ko", "ja", "de", "es", "fr", "ru", "it", "pt-PT"):
            lang = alias.get(lang.split("-")[0], lang.split("-")[0])
        if lang not in ("en", "ko", "ja", "de", "es", "fr", "ru", "it", "pt-PT"):
            lang = "en"
        for code in ("en", lang):
            if code not in self.locale_cache:
                with open(os.path.join(self.plugin_dir, "locales", code + ".json"), encoding="utf-8-sig") as file:
                    self.locale_cache[code] = json.load(file)
        return self.locale_cache[lang].get("STATUS_" + key, self.locale_cache["en"].get("STATUS_" + key, key))

    def _provider_from_action(self, action_id):
        action_id = (action_id or "").lower()
        for provider in ["vercel", "netlify", "cloudflare", "railway", "github"]:
            if provider in action_id:
                return provider
        return "vercel"

    def _default_settings_for_action(self, action_id):
        provider = self._provider_from_action(action_id)
        action_type = "redeploy" if provider == "vercel" else "monitor"
        return {
            "action_type": action_type,
            "api_key": "",
            "project_id": "",
            "webhook_url": "",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[(provider, action_type)],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, action_id, settings):
        merged = self._default_settings_for_action(action_id)
        merged.update(settings or {})
        if settings and not settings.get("_lang") and settings.get("language"):
            merged["_lang"] = settings["language"]
        provider = self._provider_from_action(action_id)
        if (provider == "vercel" and settings and not settings.get("action_type")
                and (settings.get("api_key") or settings.get("project_id"))):
            # Older monitor configurations may omit their implicit action type.
            merged["action_type"] = "monitor"
        action_type = merged.get("action_type") or ("redeploy" if provider == "vercel" else "monitor")
        merged["action_type"] = action_type
        default_type = "redeploy" if provider == "vercel" else "monitor"
        merged["builtin_icon_name"] = self.icon_map.get((provider, action_type), self.icon_map[(provider, default_type)])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any(s.get(k) not in ("", None, False) for k in [
            "action_type", "api_key", "project_id", "webhook_url", "title",
            "builtin_icon_name", "default_visuals_initialized", "sync_title_on_action_change"
        ])

    def _icon_path_for(self, action_id, action_type):
        provider = self._provider_from_action(action_id)
        default_type = "redeploy" if provider == "vercel" else "monitor"
        icon_name = self.icon_map.get((provider, action_type or default_type), self.icon_map[(provider, default_type)])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_id, action_type):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._icon_path_for(action_id, action_type)
        if os.path.exists(icon_path):
            await self.runner.send_message({"event": "setIcon", "context": context, "payload": {"icon_path": icon_path}})

    async def _initialize_default_visuals_if_new(self, context, action_id, settings):
        if not context:
            return {}
        if not self._has_meaningful_settings(settings):
            new_settings = self._default_settings_for_action(action_id)
            self.context_settings[context] = self._merge_with_defaults(action_id, new_settings)
            await self.runner.send_message({"event": "setSettings", "context": context, "payload": new_settings})
            await self._send_builtin_icon(context, action_id, new_settings["action_type"])
            return new_settings
        merged = self._merge_with_defaults(action_id, settings)
        self.context_settings[context] = merged
        return merged

    async def handle_message(self, data):
        if self.closed:
            return
        event = data.get("event", "")
        context = data.get("context")
        payload = data.get("payload") or {}
        action_id = data.get("action") or self.active_contexts.get(context, {}).get("action")
        if not context:
            return

        if "disappear" in event.lower() or "delete" in event.lower() or "remove" in event.lower() or "clear" in event.lower():
            if context in self.polling_tasks:
                self.polling_tasks[context].cancel()
                del self.polling_tasks[context]
            self.active_contexts.pop(context, None)
            self.context_settings.pop(context, None)
            self.execution_locks.pop(context, None)
            self.removed_contexts.add(context)
            return

        settings = payload.get("settings") if isinstance(payload, dict) and "settings" in payload else payload
        if not isinstance(settings, dict):
            settings = {}

        control_command = data.get("command") or payload.get("command")
        action_type_override = data.get("action_type") or payload.get("action_type")

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            await self._send_builtin_icon(context, action_id, action_type_override or settings.get("action_type") or cached.get("action_type") or "monitor")
            return

        if event in ["willAppear", "keyDidAppear"]:
            self.removed_contexts.discard(context)
            settings = await self._initialize_default_visuals_if_new(context, action_id, settings)
            target_page = payload.get("page", self.active_contexts.get(context, {}).get("page"))
            self.active_contexts[context] = {"action": action_id, "page": target_page}
            self.context_settings[context] = self._merge_with_defaults(action_id, settings)
            if context in self.polling_tasks:
                self.polling_tasks[context].cancel()
            self.polling_tasks[context] = asyncio.create_task(self.start_polling(context, action_id, self.context_settings[context], target_page))
            return

        if event == "didReceiveSettings":
            self.removed_contexts.discard(context)
            cached = self.context_settings.get(context, {})
            merged = self._merge_with_defaults(action_id, {**cached, **settings})
            # Status setTitle messages may echo back as settings. Do not turn
            # those echoes into an endless sequence of new network requests.
            meaningful = lambda value: {k: v for k, v in value.items() if k != "title"}
            if meaningful(cached) == meaningful(merged):
                return
            self.context_settings[context] = merged
            target_page = payload.get("page", self.active_contexts.get(context, {}).get("page"))
            self.active_contexts[context] = {"action": action_id, "page": target_page}
            if context in self.polling_tasks:
                self.polling_tasks[context].cancel()
            self.polling_tasks[context] = asyncio.create_task(self.start_polling(context, action_id, merged, target_page, debounce=True))
            return

        if event == "keyDown":
            task = self.execution_tasks.get(context)
            if task is not None and not task.done():
                return
            if context in self.execution_locks and self.execution_locks[context].locked():
                return
            self.removed_contexts.discard(context)
            cached = self.context_settings.get(context, {})
            merged = self._merge_with_defaults(action_id, {**cached, **settings})
            self.context_settings[context] = merged
            target_page = payload.get("page", self.active_contexts.get(context, {}).get("page"))
            # The shared runner serializes handlers per plugin. Awaiting HTTP
            # here queues subsequent presses *outside* our execution lock, so
            # they run again once the first request finishes. Reserve the task
            # before returning; even a press before it starts is then rejected.
            task = asyncio.create_task(self.on_key_down(context, action_id, merged, target_page))
            self.execution_tasks[context] = task
            task.add_done_callback(lambda finished: self._execution_finished(context, finished))
            return

    def _execution_finished(self, context, task):
        if self.execution_tasks.get(context) is task:
            self.execution_tasks.pop(context, None)
        if task.cancelled():
            return
        error = task.exception()
        if error is not None:
            # Never log a request URL, token, response or exception message.
            print(f"[DevOps] Action task failed: {type(error).__name__}")

    async def shutdown(self):
        self.closed = True
        tasks = set(self.polling_tasks.values()) | set(self.execution_tasks.values())
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        self.polling_tasks.clear()
        self.execution_tasks.clear()
        self.execution_locks.clear()
        self.active_contexts.clear()
        self.context_settings.clear()
        self.removed_contexts.clear()

    async def _status(self, context, settings, status, page):
        current = self.context_settings.get(context)
        if context in self.removed_contexts or (current is not None and current is not settings):
            return  # A deleted/reassigned button must not receive an old response.
        await self.runner.send_message({"event": "setTitle", "context": context,
                                       "payload": {"title": self.tr(settings, status), "page": page}})

    async def start_polling(self, context, action_id, settings, target_page, debounce=False):
        if self._provider_from_action(action_id) == "vercel" or settings.get("action_type") != "monitor":
            return
        try:
            if debounce:
                await asyncio.sleep(0.6)  # Do not query once per typed token character.
            while True:
                current = self.context_settings.get(context, settings)
                if current.get("action_type") != "monitor":
                    return
                await self._refresh_status(context, action_id, current, target_page)
                await asyncio.sleep(POLL_INTERVAL_SECONDS)
        except asyncio.CancelledError:
            return

    @staticmethod
    def _required(settings, key):
        value = settings.get(key)
        if not isinstance(value, str) or not value.strip():
            raise APIError("CONFIG_NEEDED")
        value = value.strip()
        if "\r" in value or "\n" in value:
            raise APIError("INVALID_CONFIG")
        return value

    @staticmethod
    def _url(value, host=None):
        try:
            parsed = urlsplit(value)
            port = parsed.port
        except ValueError:
            raise APIError("INVALID_CONFIG") from None
        if (parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password
                or parsed.fragment or port not in (None, 443)
                or (host and parsed.hostname != host)):
            raise APIError("INVALID_CONFIG")
        return parsed

    async def _request(self, url, headers=None, data=None, method=None, empty_ok=False):
        self._url(url)
        headers = {"User-Agent": "COMBO-X-DevOps", **(headers or {})}
        if data is not None:
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, headers=headers,
                                     data=json.dumps(data).encode("utf-8") if data is not None else None,
                                     method=method or ("POST" if data is not None else "GET"))

        def fetch():
            try:
                with self.http.open(req, timeout=API_TIMEOUT_SECONDS) as response:
                    status = response.getcode()
                    if not isinstance(status, int) or not 200 <= status < 300:
                        raise APIError()
                    raw = response.read(1_048_577)
                if len(raw) > 1_048_576:
                    raise APIError()
                if not raw and empty_ok:
                    return None
                try:
                    return json.loads(raw.decode("utf-8"))
                except (ValueError, UnicodeError):
                    if empty_ok:
                        return None  # Custom hooks may acknowledge with plain text.
                    raise APIError() from None
            except urllib.error.HTTPError as exc:
                raise APIError({401: "AUTH_ERR", 403: "PERMISSION_ERR", 404: "NOT_FOUND",
                                429: "RATE_LIMIT", 400: "INVALID_CONFIG", 422: "INVALID_CONFIG"}.get(exc.code, "API_ERR")) from None
            except APIError:
                raise
            except Exception:
                # Request URLs, headers and response bodies can contain secrets.
                raise APIError() from None
        return await asyncio.to_thread(fetch)

    def _bearer(self, settings):
        return {"Authorization": "Bearer " + self._required(settings, "api_key")}

    async def _monitor(self, context, settings, page, operation):
        try:
            status = await operation(settings)
        except APIError as exc:
            status = exc.status
        except Exception:
            status = "API_ERR"
        await self._status(context, settings, status, page)

    async def _refresh_status(self, context, action_id, settings, page):
        operation = {"netlify": self.check_netlify_status, "github": self.check_github_status,
                     "cloudflare": self.check_cloudflare_status, "railway": self.check_railway_status}.get(self._provider_from_action(action_id))
        if operation:
            await operation(context, settings, page)

    async def check_netlify_status(self, context, settings, target_page):
        await self._monitor(context, settings, target_page, self._netlify_state)

    async def _netlify_state(self, settings):
        site = quote(self._required(settings, "project_id"), safe="")
        result = await self._request(f"https://api.netlify.com/api/v1/sites/{site}/deploys?per_page=1", self._bearer(settings))
        if not isinstance(result, list):
            raise APIError()
        if not result:
            return "NO_RUN"
        state = result[0].get("state")
        return {"ready": "READY", "error": "FAILED", "rejected": "FAILED",
                "new": "QUEUED", "enqueued": "QUEUED", "pending_review": "WAITING",
                **{s: "BUILDING" for s in ("accepted", "building", "uploading", "uploaded", "preparing", "prepared", "processing", "processed", "retrying")}}.get(state, "UNKNOWN")

    def _github_target(self, settings, require_workflow=False):
        repo = str(settings.get("project_id") or "").strip()
        workflow = str(settings.get("workflow_id") or "").strip()
        legacy = str(settings.get("webhook_url") or "").strip()
        if legacy and (not repo or (require_workflow and not workflow)):
            parsed = self._url(legacy, "api.github.com")
            match = re.fullmatch(r"/repos/([^/]+)/([^/]+)/actions/workflows/([^/]+)/dispatches", parsed.path)
            if not match or parsed.query:
                raise APIError("INVALID_CONFIG")
            legacy_repo = match[1] + "/" + match[2]
            if repo and repo != legacy_repo:
                raise APIError("INVALID_CONFIG")
            repo, workflow = legacy_repo, workflow or match[3]
        if not repo or (require_workflow and not workflow):
            raise APIError("CONFIG_NEEDED")
        if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo) or any(p in (".", "..") for p in repo.split("/")):
            raise APIError("INVALID_CONFIG")
        if workflow and ("/" in workflow or "\\" in workflow or workflow in (".", "..")):
            raise APIError("INVALID_CONFIG")
        return repo, workflow

    def _github_headers(self, settings):
        return {**self._bearer(settings), "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2026-03-10"}

    async def check_github_status(self, context, settings, target_page):
        await self._monitor(context, settings, target_page, self._github_state)

    async def _github_state(self, settings):
        repo, workflow = self._github_target(settings)
        suffix = f"actions/workflows/{quote(workflow, safe='')}/runs" if workflow else "actions/runs"
        result = await self._request(f"https://api.github.com/repos/{repo}/{suffix}?per_page=1", self._github_headers(settings))
        if not isinstance(result, dict) or not isinstance(result.get("workflow_runs"), list):
            raise APIError()
        if not result["workflow_runs"]:
            return "NO_RUN"
        run = result["workflow_runs"][0]
        if run.get("status") != "completed":
            return {"queued": "QUEUED", "waiting": "WAITING", "pending": "QUEUED",
                    "in_progress": "RUNNING", "requested": "QUEUED"}.get(run.get("status"), "UNKNOWN")
        return {"success": "SUCCESS", "failure": "FAILED", "timed_out": "FAILED",
                "startup_failure": "FAILED", "action_required": "WAITING", "cancelled": "CANCELED",
                "skipped": "SKIPPED", "neutral": "NEUTRAL", "stale": "UNKNOWN"}.get(run.get("conclusion"), "UNKNOWN")

    async def _dispatch_workflow(self, settings):
        repo, workflow = self._github_target(settings, require_workflow=True)
        headers = self._github_headers(settings)
        raw_inputs = settings.get("workflow_inputs") or "{}"
        try:
            inputs = json.loads(raw_inputs) if isinstance(raw_inputs, str) else raw_inputs
        except (ValueError, TypeError):
            raise APIError("INVALID_CONFIG") from None
        if not isinstance(inputs, dict) or len(inputs) > 25:
            raise APIError("INVALID_CONFIG")
        if any(not isinstance(key, str) or isinstance(value, (dict, list)) or value is None
               for key, value in inputs.items()):
            raise APIError("INVALID_CONFIG")
        ref = str(settings.get("workflow_ref") or "").strip()
        if not ref:
            repo_info = await self._request(f"https://api.github.com/repos/{repo}", headers)
            ref = repo_info.get("default_branch") if isinstance(repo_info, dict) else None
        if not isinstance(ref, str) or not ref.strip():
            raise APIError("INVALID_CONFIG")
        body = {"ref": ref}
        if inputs:
            body["inputs"] = inputs
        await self._request(f"https://api.github.com/repos/{repo}/actions/workflows/{quote(workflow, safe='')}/dispatches",
                            headers, body, empty_ok=True)

    async def check_cloudflare_status(self, context, settings, target_page):
        await self._monitor(context, settings, target_page, self._cloudflare_state)

    def _cf_id(self, settings, key):
        value = self._required(settings, key)
        if not re.fullmatch(r"[0-9a-fA-F]{32}", value):
            raise APIError("INVALID_CONFIG")
        return value

    @staticmethod
    def _cloudflare_result(result):
        if not isinstance(result, dict) or result.get("success") is not True or "result" not in result:
            raise APIError()
        return result["result"]

    async def _cloudflare_state(self, settings):
        account = self._cf_id(settings, "account_id")
        project = self._required(settings, "project_id")
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", project):
            raise APIError("INVALID_CONFIG")
        environment = settings.get("cf_environment", "production")
        if environment not in ("all", "production", "preview"):
            raise APIError("INVALID_CONFIG")
        env_query = "" if environment == "all" else "&env=" + environment
        result = self._cloudflare_result(await self._request(
            f"https://api.cloudflare.com/client/v4/accounts/{account}/pages/projects/{project}/deployments?per_page=1{env_query}",
            self._bearer(settings)))
        if not isinstance(result, list):
            raise APIError()
        if not result:
            return "NO_RUN"
        deploy = result[0]
        stage = deploy.get("latest_stage") or {}
        if deploy.get("is_skipped"):
            return "SKIPPED"
        state = stage.get("status")
        if state == "success":
            return "SUCCESS" if stage.get("name") == "deploy" else "BUILDING"
        return {"failure": "FAILED", "canceled": "CANCELED", "skipped": "SKIPPED",
                "idle": "QUEUED", "active": "BUILDING"}.get(state, "UNKNOWN")

    async def _purge_cache(self, settings):
        zone = str(settings.get("zone_id") or "").strip()
        if not zone and settings.get("webhook_url"):
            parsed = self._url(str(settings["webhook_url"]), "api.cloudflare.com")
            match = re.fullmatch(r"/client/v4/zones/([0-9a-fA-F]{32})/purge_cache", parsed.path)
            if not match or parsed.query:
                raise APIError("INVALID_CONFIG")
            zone = match[1]
        zone = self._cf_id({"zone_id": zone}, "zone_id")
        scope = settings.get("purge_scope", "urls")
        if scope == "all":
            body = {"purge_everything": True}
        elif scope == "urls":
            urls = str(settings.get("purge_urls") or "").splitlines()
            urls = [url.strip() for url in urls if url.strip()]
            if not urls:
                raise APIError("CONFIG_NEEDED")
            if len(urls) > 100:
                raise APIError("INVALID_CONFIG")
            for url in urls:
                parsed = urlsplit(url)
                if parsed.scheme not in ("https", "http") or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
                    raise APIError("INVALID_CONFIG")
            body = {"files": urls}
        else:
            raise APIError("INVALID_CONFIG")
        result = await self._request(f"https://api.cloudflare.com/client/v4/zones/{zone}/purge_cache", self._bearer(settings), body)
        self._cloudflare_result(result)

    async def _railway_query(self, settings, query, variables=None):
        token = self._required(settings, "api_key")
        token_type = settings.get("railway_token_type", "account")
        if token_type not in ("account", "project"):
            raise APIError("INVALID_CONFIG")
        headers = {"Project-Access-Token": token} if token_type == "project" else {"Authorization": "Bearer " + token}
        result = await self._request(RAILWAY_API, headers, {"query": query, "variables": variables or {}})
        if not isinstance(result, dict) or result.get("errors") or not isinstance(result.get("data"), dict):
            errors = result.get("errors", []) if isinstance(result, dict) else []
            codes = {str((error.get("extensions") or {}).get("code")) for error in errors if isinstance(error, dict)}
            raise APIError("AUTH_ERR" if "UNAUTHENTICATED" in codes else "PERMISSION_ERR" if "FORBIDDEN" in codes else "API_ERR")
        return result["data"]

    async def _railway_deployment(self, settings, active_only=False):
        service = self._required(settings, "service_id")
        project = str(settings.get("project_id") or "").strip()
        environment = str(settings.get("environment_id") or "").strip()
        if settings.get("railway_token_type") == "project":
            result = await self._railway_query(settings, "query { projectToken { projectId environmentId } }")
            scope = result.get("projectToken") or {}
            if (project and project != scope.get("projectId")) or (environment and environment != scope.get("environmentId")):
                raise APIError("INVALID_CONFIG")
            project, environment = scope.get("projectId"), scope.get("environmentId")
        if not project or not environment:
            raise APIError("CONFIG_NEEDED")
        target = {"projectId": project, "environmentId": environment, "serviceId": service}
        if active_only:
            target["status"] = {"successfulOnly": True}
        result = await self._railway_query(settings, """query($input: DeploymentListInput!) {
            deployments(input: $input, first: 1) { edges { node { id status createdAt } } }
        }""", {"input": target})
        deployments = result.get("deployments")
        if not isinstance(deployments, dict) or not isinstance(deployments.get("edges"), list):
            raise APIError()
        if not deployments["edges"]:
            return None
        node = deployments["edges"][0].get("node")
        if not isinstance(node, dict) or not node.get("id"):
            raise APIError()
        return node

    async def check_railway_status(self, context, settings, target_page):
        await self._monitor(context, settings, target_page, self._railway_state)

    async def _railway_state(self, settings):
        deploy = await self._railway_deployment(settings)
        if deploy is None:
            return "NO_RUN"
        return {"INITIALIZING": "QUEUED", "QUEUED": "QUEUED", "BUILDING": "BUILDING",
                "DEPLOYING": "DEPLOYING", "SUCCESS": "READY", "FAILED": "FAILED",
                "CRASHED": "CRASHED", "REMOVED": "STOPPED", "REMOVING": "STOPPED",
                "SLEEPING": "SLEEPING", "SKIPPED": "SKIPPED", "WAITING": "WAITING",
                "CANCELED": "CANCELED", "CANCELLED": "CANCELED"}.get(deploy.get("status"), "UNKNOWN")

    async def _restart_railway(self, settings):
        deploy = await self._railway_deployment(settings, active_only=True)
        if not deploy or deploy.get("status") != "SUCCESS":
            raise APIError("NO_RUN")
        result = await self._railway_query(settings, "mutation($id: String!) { deploymentRestart(id: $id) }", {"id": deploy["id"]})
        if result.get("deploymentRestart") is not True:
            raise APIError()

    async def _post_hook(self, settings):
        url = self._required(settings, "webhook_url")
        await self._request(url, method="POST", empty_ok=True)

    async def on_key_down(self, context, action_id, settings, target_page):
        # No background path invokes mutations, and concurrent presses are not
        # queued up into multiple deployments/restarts.
        lock = self.execution_locks.setdefault(context, asyncio.Lock())
        if lock.locked():
            return
        async with lock:
            provider = self._provider_from_action(action_id)
            action_type = settings.get("action_type", "monitor")
            if action_type == "monitor":
                if provider != "vercel":
                    await self._refresh_status(context, action_id, settings, target_page)
                return
            if action_type != "redeploy":
                return
            await self._status(context, settings, "SENDING", target_page)
            try:
                if provider == "cloudflare":
                    await self._purge_cache(settings)
                elif provider == "railway":
                    # Preserve a user's existing custom restart webhook. New
                    # configurations can restart directly using Railway's API.
                    if settings.get("webhook_url") and not settings.get("service_id"):
                        await self._post_hook(settings)
                    else:
                        await self._restart_railway(settings)
                elif provider == "github":
                    await self._dispatch_workflow(settings)
                elif provider in ("vercel", "netlify"):
                    await self._post_hook(settings)
                else:
                    raise APIError("INVALID_CONFIG")
                status = "SENT"  # Request accepted, not a completed build/restart.
            except APIError as exc:
                status = exc.status
            except Exception:
                status = "API_ERR"
            await self._status(context, settings, status, target_page)
