
import asyncio
import json
import os
import urllib.request
import urllib.error
import websockets

PLUGIN_UUID = "com.cookie.tiktok"
COOKIEDECK_URI = "ws://localhost:8765"
PORTS = [28189, 39728, 34246, 42205, 38534, 40825, 40622]
SUBPROTOCOLS = ["streamdeck_ttls_v1"]

ACTIONS = {
    "com.cookie.tiktok.scene": "com.tiktok.livestudio.scene",
    "com.cookie.tiktok.source": "com.tiktok.livestudio.source",
    "com.cookie.tiktok.live": "com.tiktok.livestudio.livestartend",
    "com.cookie.tiktok.audio": "com.tiktok.livestudio.audio",
    "com.cookie.tiktok.mic": "com.tiktok.livestudio.mic",
    "com.cookie.tiktok.recording": "com.tiktok.livestudio.recording",
    "com.cookie.tiktok.pause": "com.tiktok.livestudio.livepauseresume",
    "com.cookie.tiktok.highlight": "com.tiktok.livestudio.highlight",
}

STREAM_STATUS_DEFAULT = 0
STREAM_STATUS_PAUSE = 1
STREAM_STATUS_LIVING = 2

class TikTokPlugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.tt_ws = None
        self.connected_port = None
        self.tt_connected = False
        self.pending_context = {}
        self.settings_cache = {}   # context -> settings
        self.latest_sync = {}
        self.last_status = "대기 중..."
        asyncio.create_task(self.tt_loop())

    def log(self, msg):
        print(f"[{self.uuid}] {msg}", flush=True)

    async def send_pi(self, context, payload):
        await self.runner.send_message({
            "event": "sendToPropertyInspector",
            "context": context,
            "payload": payload
        })

    async def scan_socketio_port(self):
        for port in PORTS:
            url = f"http://127.0.0.1:{port}/socket.io/?EIO=4&transport=polling"
            try:
                with urllib.request.urlopen(url, timeout=1.5) as resp:
                    body = resp.read().decode("utf-8", errors="ignore")
                    if body.startswith("0{") and "sid" in body and "pingInterval" in body:
                        return port
            except Exception:
                continue
        return None

    async def tt_loop(self):
        while True:
            try:
                if self.tt_ws is None:
                    port = await self.scan_socketio_port()
                    if port is None:
                        self.tt_connected = False
                        self.connected_port = None
                        self.last_status = "TikTok Live Studio 서비스를 찾지 못했습니다."
                        await asyncio.sleep(5)
                        continue

                    self.connected_port = port
                    uri = f"ws://127.0.0.1:{port}/socket.io/?EIO=4&transport=websocket"
                    self.log(f"TikTok socket.io 연결 시도: {uri}")
                    self.tt_ws = await websockets.connect(uri, subprotocols=SUBPROTOCOLS, ping_interval=None)
                    open_packet = await asyncio.wait_for(self.tt_ws.recv(), timeout=5)
                    self.log(f"open: {open_packet[:120]}")
                    if not str(open_packet).startswith("0"):
                        raise RuntimeError("socket.io open packet not received")
                    await self.tt_ws.send("40")
                    self.tt_connected = True
                    self.last_status = f"연결됨 (포트 {port})"
                    asyncio.create_task(self.tt_listener())
                    await asyncio.sleep(0.2)
                    await self.emit_socketio("stream_deck/join_room")
                    await asyncio.sleep(0.2)
                    await self.emit_socketio("stream_deck/sync_settings")
                await asyncio.sleep(3)
            except Exception as e:
                self.log(f"TikTok 연결 실패: {e}")
                self.tt_connected = False
                self.last_status = f"연결 실패: {e}"
                try:
                    if self.tt_ws:
                        await self.tt_ws.close()
                except Exception:
                    pass
                self.tt_ws = None
                await asyncio.sleep(5)

    async def tt_listener(self):
        ws = self.tt_ws
        try:
            async for message in ws:
                text = message.decode("utf-8", errors="ignore") if isinstance(message, bytes) else str(message)
                if text == "2":
                    await ws.send("3")
                    continue
                if text.startswith("40"):
                    continue
                if text.startswith("42"):
                    try:
                        payload = json.loads(text[2:])
                    except Exception:
                        continue
                    if not isinstance(payload, list) or not payload:
                        continue
                    event_name = payload[0]
                    event_data = payload[1] if len(payload) > 1 else None
                    await self.handle_tt_event(event_name, event_data)
        except Exception as e:
            self.log(f"TikTok listener 종료: {e}")
        finally:
            if self.tt_ws == ws:
                self.tt_ws = None
                self.tt_connected = False

    async def handle_tt_event(self, event_name, event_data):
        self.log(f"TT event: {event_name}")
        if event_name == "stream_deck/join_room":
            await self.emit_socketio("stream_deck/sync_settings")
            return
        if event_name == "stream_deck/sync_settings":
            data = self.parse_jsonish(event_data, {})
            if isinstance(data, dict):
                self.latest_sync = data
                self.last_status = f"연결됨 (포트 {self.connected_port})"
            return
        if event_name.startswith("stream_deck/"):
            context = event_name.split("/", 1)[1]
            fut = self.pending_context.pop(context, None)
            if fut and not fut.done():
                fut.set_result(self.parse_jsonish(event_data, {}))

    def parse_jsonish(self, value, default=None):
        if isinstance(value, dict) or isinstance(value, list):
            return value
        if isinstance(value, str):
            try:
                return json.loads(value)
            except Exception:
                return default if default is not None else value
        return default if default is not None else value

    async def emit_socketio(self, event_name, data=None):
        if self.tt_ws is None:
            raise RuntimeError("TikTok socket not connected")
        packet = [event_name] if data is None else [event_name, data]
        await self.tt_ws.send("42" + json.dumps(packet, ensure_ascii=False))

    async def emit_action(self, action_name, context, payload):
        if not self.tt_connected or self.tt_ws is None:
            raise RuntimeError("TikTok Live Studio is not connected")
        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        self.pending_context[context] = fut
        await self.emit_socketio("stream_deck/action_emit", json.dumps({
            "action": action_name,
            "context": context,
            "payload": payload
        }, ensure_ascii=False))
        try:
            result = await asyncio.wait_for(fut, timeout=5)
        except asyncio.TimeoutError:
            self.pending_context.pop(context, None)
            result = {"code": -1, "message": "timeout"}
        await self.emit_socketio("stream_deck/sync_settings")
        return result

    def get_scene_names(self):
        return [s.get("name") for s in self.latest_sync.get("scene_list", []) if s.get("name")]

    def get_visible_sources(self, scene_name):
        for scene in self.latest_sync.get("scene_list", []):
            if scene.get("name") == scene_name:
                return scene.get("visible_sources", []) or []
        return []

    async def handle_refresh(self, context):
        if self.tt_connected:
            try:
                await self.emit_socketio("stream_deck/sync_settings")
                await asyncio.sleep(0.2)
            except Exception:
                pass
        scene_names = self.get_scene_names()
        await self.send_pi(context, {
            "command": "syncData",
            "status": self.last_status,
            "connected_port": self.connected_port or "",
            "scene_list": scene_names,
            "sync": self.latest_sync
        })

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or data.get("key")
        action_uuid = data.get("action") or payload.get("action")

        if event == "didReceiveSettings":
            settings = payload.get("settings", {}) or {}
            if settings:
                self.settings_cache[context] = settings
            cmd = settings.get("pi_command")
            if cmd == "refresh":
                await self.handle_refresh(context)
                settings["pi_command"] = ""
            return

        if event == "sendToPlugin":
            cmd = payload.get("command")
            if cmd == "refresh":
                await self.handle_refresh(context)
            return

        if event == "keyDown":
            incoming = payload.get("settings", {}) or {}
            cached = self.settings_cache.get(context, {})
            final_settings = {**cached, **incoming}
            if incoming:
                self.settings_cache[context] = {**cached, **incoming}

            # some engines may not pass action uuid, so allow command override too
            if not action_uuid:
                action_uuid = final_settings.get("action_uuid")

            if action_uuid == "com.cookie.tiktok.scene":
                scene = final_settings.get("scene", "")
                source = final_settings.get("source", "")
                if not scene:
                    self.log("scene action ignored: no scene selected")
                    return
                result = await self.emit_action(ACTIONS[action_uuid], context, {"settings": {"scene": scene, "source": source}})
                self.log(f"scene result: {result}")
            elif action_uuid == "com.cookie.tiktok.source":
                scene = final_settings.get("scene", "")
                source = final_settings.get("source", "")
                if not scene or not source:
                    self.log("source action ignored: scene/source not selected")
                    return
                result = await self.emit_action(ACTIONS[action_uuid], context, {"settings": {"scene": scene, "source": source}})
                self.log(f"source result: {result}")
            elif action_uuid in ACTIONS:
                sync = self.latest_sync or {}
                if action_uuid == "com.cookie.tiktok.live":
                    state = 0 if sync.get("stream_status") == STREAM_STATUS_LIVING else 1
                elif action_uuid == "com.cookie.tiktok.audio":
                    state = 0 if sync.get("audio_mute") else 1
                elif action_uuid == "com.cookie.tiktok.mic":
                    state = 0 if sync.get("mic_mute") else 1
                elif action_uuid == "com.cookie.tiktok.recording":
                    state = 1 if sync.get("recording") else 0
                elif action_uuid == "com.cookie.tiktok.pause":
                    state = 1 if sync.get("stream_status") == STREAM_STATUS_PAUSE else 0
                elif action_uuid == "com.cookie.tiktok.highlight":
                    state = 1 if sync.get("highlight_able") else 0
                else:
                    state = 0
                result = await self.emit_action(ACTIONS[action_uuid], context, {"settings": {}, "state": state})
                self.log(f"{action_uuid} result: {result}")

if __name__ == "__main__":
    class ExternalRunner:
        def __init__(self, ws):
            self.ws = ws
        async def send_message(self, msg):
            await self.ws.send(json.dumps(msg, ensure_ascii=False))

    async def main():
        print(f"[{PLUGIN_UUID}] starting", flush=True)
        while True:
            try:
                manifest_path = os.path.join(os.path.dirname(__file__), "manifest.json")
                with open(manifest_path, "r", encoding="utf-8") as f:
                    manifest = json.load(f)
                async with websockets.connect(COOKIEDECK_URI) as websocket:
                    print(f"[{PLUGIN_UUID}] connected to CookieDeck", flush=True)
                    await websocket.send(json.dumps({"event": "register", "uuid": manifest["UUID"]}))
                    print(f"[{PLUGIN_UUID}] register sent", flush=True)
                    runner = ExternalRunner(websocket)
                    plugin = TikTokPlugin(runner, manifest)
                    async for message in websocket:
                        try:
                            data = json.loads(message)
                        except Exception:
                            continue
                        try:
                            await plugin.handle_message(data)
                        except Exception as e:
                            print(f"[{PLUGIN_UUID}] message error: {e}", flush=True)
            except Exception as e:
                print(f"[{PLUGIN_UUID}] bootstrap error: {e}", flush=True)
                await asyncio.sleep(5)

    asyncio.run(main())
