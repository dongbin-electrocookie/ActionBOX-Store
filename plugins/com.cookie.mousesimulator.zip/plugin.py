import asyncio
import pyautogui

# 안전장치: 마우스를 화면 모서리로 팍 밀면 강제 종료되도록 설정 (개발 중 꼬임 방지)
pyautogui.FAILSAFE = True

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")
        
        # 하드웨어 버튼을 눌렀을 때 (마우스 동작 실행)
        if event == "keyDown":
            await self.on_key_down(data)
            
        # HTML 화면에서 "좌표 따기" 버튼을 눌렀을 때
        elif event == "sendToPlugin":
            payload = data.get("payload", {})
            if payload.get("command") == "capturePosition":
                # 3초 대기 후 현재 마우스 좌표 캡처
                await asyncio.sleep(3)
                x, y = pyautogui.position()
                print(f"🎯 [Mouse] 좌표 캡처됨: X={x}, Y={y}")
                
                # HTML로 좌표 전달
                await self.runner.send_message({
                    "event": "sendToPropertyInspector",
                    "context": context,
                    "payload": {
                        "command": "positionCaptured",
                        "x": x,
                        "y": y
                    }
                })

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        action = settings.get("mouse_action", "click")
        
        # 값이 없으면 None, 있으면 정수로 변환
        x = int(settings.get("pos_x")) if settings.get("pos_x") else None
        y = int(settings.get("pos_y")) if settings.get("pos_y") else None

        # 메인 루프가 멈추지 않도록 백그라운드 스레드에서 실행
        await asyncio.to_thread(self._execute_mouse_action, action, x, y)

    def _execute_mouse_action(self, action, x, y):
        try:
            # 1. 이동
            if x is not None and y is not None:
                # duration=0.2 를 주면 순간이동하지 않고 0.2초에 걸쳐 스르륵 이동합니다. (감성 UP)
                pyautogui.moveTo(x, y, duration=0.2)
            
            # 2. 클릭 동작
            if action == "click":
                pyautogui.click()
            elif action == "double_click":
                pyautogui.doubleClick()
            elif action == "right_click":
                pyautogui.rightClick()
            # "move_only"면 클릭 안 하고 종료
            
        except pyautogui.FailSafeException:
            print("🚨 [Mouse] FailSafe 발동! 마우스 제어가 강제 중단되었습니다.")
        except Exception as e:
            print(f"❌ [Mouse Error] {e}")