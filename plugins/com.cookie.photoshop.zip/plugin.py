import asyncio
import platform

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 블로그 구조를 완벽하게 반영한 단축키 매핑!
        self.action_map = {
            # 1. 파일 (File)
            "file_save": "ctrl+s",
            "file_save_as": "ctrl+shift+s",

            # 2. 브러시 및 채색 (Brush & Fill) - [제일 중요한 기능 추가 완료!]
            "brush_size_down": "[",
            "brush_size_up": "]",
            "brush_hard_down": "shift+[",
            "brush_hard_up": "shift+]",
            "edit_fill_fg": "alt+delete",
            "edit_fill_bg": "ctrl+delete",

            # 3. 도구 선택 (Tools)
            "tool_move": "v",
            "tool_marquee": "m",
            "tool_zoom": "z",
            "tool_lasso": "l",
            "tool_magic": "w",
            "tool_crop": "c",
            "tool_eyedropper": "i",
            "tool_brush": "b",
            "tool_eraser": "e",
            "tool_pen": "p",
            "tool_type": "t",

            # 4. 레이어 (Layer)
            "layer_new": "ctrl+shift+n",
            "layer_copy": "ctrl+j",
            "layer_merge": "ctrl+e",
            "layer_group": "ctrl+g",

            # 5. 선택 영역 (Selection)
            "select_all": "ctrl+a",
            "select_deselect": "ctrl+d",
            "select_invert": "ctrl+shift+i",

            # 6. 편집 및 변형 (Edit & Transform)
            "edit_undo": "ctrl+z",
            "edit_redo": "ctrl+shift+z",
            "edit_transform": "ctrl+t",

            # 7. 이미지 보정 (Adjustments)
            "adj_levels": "ctrl+l",
            "adj_curves": "ctrl+m",
            "adj_hue": "ctrl+u",
            "adj_balance": "ctrl+b",

            # 8. 화면 뷰 (View)
            "view_zoom_in": "ctrl+=",
            "view_zoom_out": "ctrl+-",
            "view_fit": "ctrl+0"
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available: return

        settings = data.get("payload", {}).get("settings", {})
        selected_action = settings.get("ps_action", "tool_brush")

        if selected_action and selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)