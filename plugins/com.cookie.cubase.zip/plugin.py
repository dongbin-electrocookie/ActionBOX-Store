import asyncio
import socket
import struct
import os
import sys

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        self.windows_hotkey_map = {
            "play_stop": "space",
            "record": "*",
            "cycle": "/",
            "rewind": "-",
            "forward": "+",
            "return_zero": ".",
            "metronome": "c",
            "tool_select": "1",
            "tool_range": "2",
            "tool_split": "3",
            "tool_glue": "4",
            "tool_erase": "5",
            "tool_zoom": "6",
            "tool_mute": "7",
            "tool_draw": "8",
            "mixconsole": "f3",
            "vst_instruments": "f11",
            "audio_connections": "f4",
            "video_player": "f8",
            "lower_zone": "ctrl+alt+e",
            "duplicate": "ctrl+d",
            "undo": "ctrl+z",
            "redo": "ctrl+shift+z",
            "quantize": "q",
            "snap": "j",
            "autoscroll": "f"
        }

        # Cubase는 macOS에서도 Transport / Tool / Function Key 계열은 대부분 동일합니다.
        # 일반 편집 명령만 macOS 표준에 맞춰 Command / Option 조합으로 분리합니다.
        self.macos_hotkey_map = {
            **self.windows_hotkey_map,
            "lower_zone": "command+option+e",
            "duplicate": "command+d",
            "undo": "command+z",
            "redo": "command+shift+z",
        }

        self.hotkey_map = self.macos_hotkey_map if IS_MACOS else self.windows_hotkey_map

        self.icon_map = {
            "play_stop": "PLAY_STOP",
            "record": "RECORD",
            "cycle": "CYCLE",
            "rewind": "REWIND",
            "forward": "FORWARD",
            "return_zero": "RETURN_ZERO",
            "metronome": "METRONOME",
            "tool_select": "TOOL_SELECT",
            "tool_range": "TOOL_RANGE",
            "tool_split": "TOOL_SPLIT",
            "tool_glue": "TOOL_GLUE",
            "tool_erase": "TOOL_ERASE",
            "tool_zoom": "TOOL_ZOOM",
            "tool_mute": "TOOL_MUTE",
            "tool_draw": "TOOL_DRAW",
            "mixconsole": "MIXCONSOLE",
            "vst_instruments": "VST_INSTRUMENTS",
            "audio_connections": "AUDIO_CONNECTIONS",
            "video_player": "VIDEO_PLAYER",
            "lower_zone": "LOWER_ZONE",
            "duplicate": "DUPLICATE",
            "undo": "UNDO",
            "redo": "REDO",
            "quantize": "QUANTIZE",
            "snap": "SNAP",
            "autoscroll": "AUTOSCROLL",
            "osc": "OSC_API",
        }

    def _default_hotkey(self):
        return "play_stop"

    def _default_settings(self):
        action = self._default_hotkey()
        return {
            "control_mode": "hotkey",
            "cubase_hotkey": action,
            "command": action,
            "osc_address": "",
            "osc_value": "",
            "osc_port": "8000",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        mode = merged.get("control_mode", "hotkey")

        if mode == "osc":
            merged["control_mode"] = "osc"
            merged["command"] = "osc"
            merged["builtin_icon_name"] = self.icon_map["osc"]
        else:
            action = merged.get("command") or merged.get("cubase_hotkey") or self._default_hotkey()
            merged["control_mode"] = "hotkey"
            merged["cubase_hotkey"] = action
            merged["command"] = action
            merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_hotkey()])

        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("control_mode"),
            s.get("command"),
            s.get("cubase_hotkey"),
            s.get("osc_address"),
            s.get("osc_value"),
            s.get("osc_port"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_hotkey(), self.icon_map[self._default_hotkey()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")
        action_mode = data.get("action_mode") or payload.get("action_mode")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            if action_mode == "osc":
                action_name = "osc"
            else:
                action_name = action_command or settings.get("command") or settings.get("cubase_hotkey") or cached.get("command") or self._default_hotkey()
            await self._send_builtin_icon(context, action_name)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    def _normalize_pyautogui_key(self, key):
        key = str(key).strip().lower()
        aliases = {
            "cmd": "command",
            "win": "command" if IS_MACOS else "win",
            "windows": "command" if IS_MACOS else "win",
            "control": "ctrl",
            "option": "option" if IS_MACOS else "alt",
            "alt": "option" if IS_MACOS else "alt",
            "page up": "pageup",
            "page down": "pagedown",
            "pgup": "pageup",
            "pgdn": "pagedown",
            "return": "enter",
            "esc": "escape",
            "plus": "+",
            "minus": "-",
            "asterisk": "*",
        }
        return aliases.get(key, key)

    def _send_hotkey_sync(self, hotkey):
        if not hotkey:
            return

        if IS_WINDOWS and keyboard_available:
            keyboard.send(hotkey)
            return

        if not pyautogui_available:
            print(f"[{self.uuid}] No input backend available for hotkey: {hotkey}")
            return

        if str(hotkey).strip() == "+":
            parts = ["+"]
        else:
            parts = [self._normalize_pyautogui_key(part) for part in str(hotkey).split("+") if part.strip()]
        if not parts:
            return

        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = settings

        mode = settings.get("control_mode", "hotkey")

        if mode == "hotkey":
            action = settings.get("command") or settings.get("cubase_hotkey") or self._default_hotkey()
            if action in self.hotkey_map:
                await asyncio.to_thread(self._send_hotkey_sync, self.hotkey_map[action])

        elif mode == "osc":
            address = settings.get("osc_address", "").strip()
            val_str = settings.get("osc_value", "").strip()
            try:
                port = int(settings.get("osc_port", 8000))
            except Exception:
                port = 8000

            if not address:
                return
            if not address.startswith("/"):
                address = "/" + address

            value = None
            if val_str:
                try:
                    value = int(val_str)
                except ValueError:
                    try:
                        value = float(val_str)
                    except ValueError:
                        value = val_str

            await asyncio.to_thread(self._send_simple_osc, "127.0.0.1", port, address, value)

    def _send_simple_osc(self, ip, port, address, value):
        try:
            def osc_pad(b_str):
                pad_len = (4 - (len(b_str) % 4)) % 4
                return b_str + (b'\x00' * pad_len)

            msg = osc_pad(address.encode('utf-8'))

            if value is None:
                msg += osc_pad(b',')
            elif isinstance(value, int):
                msg += osc_pad(b',i')
                msg += struct.pack('>i', value)
            elif isinstance(value, float):
                msg += osc_pad(b',f')
                msg += struct.pack('>f', value)
            elif isinstance(value, str):
                msg += osc_pad(b',s')
                msg += osc_pad(value.encode('utf-8'))

            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(msg, (ip, port))
            sock.close()
            print(f"[{self.uuid}] OSC Sent: {address} -> {value} (Port: {port})")
        except Exception as e:
            print(f"[{self.uuid}] OSC send error: {e}")
