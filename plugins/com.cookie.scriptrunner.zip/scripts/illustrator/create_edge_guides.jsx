#target illustrator

if (app.documents.length === 0) {
  alert("❌ 열린 문서가 없습니다.");
} else {
  var doc = app.activeDocument;

  var input = prompt("여백(mm)을 입력하세요:", "10");
  if (input === null) exit();
  var mm = parseFloat(input);

  if (isNaN(mm) || mm <= 0) {
    alert("⚠️ 유효한 숫자를 입력해주세요.");
    exit();
  }

  var pt = mm * 2.834645; // 1mm ≈ 2.834pt

  //app.executeMenuCommand('unlockAllGuides');

  for (var i = 0; i < doc.artboards.length; i++) {
    var ab = doc.artboards[i];
    var rect = ab.artboardRect;

    var left = rect[0] + pt;
    var right = rect[2] - pt;
    var top = rect[1] - pt;
    var bottom = rect[3] + pt;

    // 기준 위치에 따라 경로 설정
    function addGuide(x, y, isVertical) {
      var guide = doc.pathItems.add();
      guide.stroked = true;
      //guide.strokeColor = doc.swatches["[Registration]"].color;
      guide.filled = false;

      if (isVertical) {
        guide.setEntirePath([[x, rect[1]], [x, rect[3]]]);
      } else {
        guide.setEntirePath([[rect[0], y], [rect[2], y]]);
      }

      guide.guides = true;
    }

    // 좌우 상하 가이드 생성
    addGuide(left, 0, true);
    addGuide(right, 0, true);
    addGuide(0, top, false);
    addGuide(0, bottom, false);
  }

  alert("✅ 모든 아트보드에 가이드라인이 생성되었습니다.");
}
