import sys
import os
import asyncio
import json
import keyboard
import threading
import subprocess
import pyperclip
import time

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # --- 설정 및 파일 경로 ---
        self.MAX_HISTORY_SIZE = 20
        # 현재 파일 위치 기준으로 경로 설정
        plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.history_file = os.path.join(plugin_dir, "clipboard_history.txt")
        self.snippets_file = os.path.join(plugin_dir, "my_snippets.txt")
        self.history_lock = threading.Lock()

        # 파일 생성 및 모니터링 스레드 시작
        self._setup_files()
        self._start_monitor_thread()
        
        # print(f"[{self.uuid}] Clipboard Manager Loaded")

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        action_id = data.get("action")
        file_to_open = None
        
        # 액션 ID에 따라 열 파일 결정
        if action_id == "com.cookie.clipboardmanager.view_history":
            file_to_open = self.history_file
        elif action_id == "com.cookie.clipboardmanager.edit_snippets":
            file_to_open = self.snippets_file

        if file_to_open:
            # print(f"[{self.uuid}] Opening: {file_to_open}")
            # 파일 열기는 Blocking I/O일 수 있으므로 스레드로 분리
            await asyncio.to_thread(self._open_file, file_to_open)

    # --- 헬퍼 메소드 (기존 로직 유지) ---

    def _setup_files(self):
        """필요한 텍스트 파일들을 생성합니다."""
        if not os.path.exists(self.history_file):
            with open(self.history_file, 'w', encoding='utf-8') as f:
                f.write("--- Clipboard History ---\n")
        if not os.path.exists(self.snippets_file):
            with open(self.snippets_file, 'w', encoding='utf-8') as f:
                f.write("--- My Snippets ---\n")

    def _start_monitor_thread(self):
        """Ctrl+C를 감지하는 백그라운드 스레드를 시작합니다."""
        # 데몬 스레드로 실행해야 메인 프로그램 종료 시 같이 꺼집니다.
        monitor_thread = threading.Thread(target=self._clipboard_monitor, daemon=True)
        monitor_thread.start()

    def _clipboard_monitor(self):
        """
        [별도 스레드] 키보드 핫키를 등록하고 대기합니다.
        주의: 이 함수는 메인 스레드(asyncio loop)가 아닌 별도 스레드에서 돌므로
        keyboard.wait()를 써도 전체 런타임에 영향을 주지 않습니다.
        """
        try:
            # suppress=False: 원래 복사 기능도 작동하도록 함
            keyboard.add_hotkey('ctrl+c', self._on_copy, suppress=False)
            keyboard.wait() # 스레드 블로킹 대기
        except Exception as e:
            print(f"[{self.uuid} ERROR] Monitor thread crashed: {e}")

    def _on_copy(self):
        """클립보드 내용을 읽어 파일에 저장합니다."""
        try:
            # 클립보드 갱신 대기 (약간의 딜레이 필요)
            time.sleep(0.1)
            copied_text = pyperclip.paste().strip()
            if not copied_text:
                return

            with self.history_lock:
                # 기존 내용 읽기
                lines = []
                if os.path.exists(self.history_file):
                    with open(self.history_file, 'r', encoding='utf-8') as f:
                        lines = f.readlines()
                
                header = lines[0] if lines else "--- Clipboard History ---\n"
                # 내용만 필터링
                content_lines = [line.strip() for line in lines if line.strip() and line.strip() != header.strip()]
                
                # 중복 방지 (가장 최근 것과 같으면 무시)
                if content_lines and content_lines[0] == copied_text:
                    return

                # 새 내용 추가
                new_content = [copied_text] + content_lines
                final_content = new_content[:self.MAX_HISTORY_SIZE]

                # 파일 쓰기
                with open(self.history_file, 'w', encoding='utf-8') as f:
                    f.write(header)
                    f.write('\n\n'.join(final_content))
                
                # print(f"[{self.uuid}] Saved: {copied_text[:20]}...")

        except Exception as e:
            print(f"[{self.uuid} ERROR] on_copy failed: {e}")

    def _open_file(self, file_path):
        """운영체제에 맞는 방식으로 파일을 엽니다."""
        try:
            if sys.platform == "win32":
                os.startfile(file_path)
            elif sys.platform == "darwin": # macOS
                subprocess.run(["open", file_path])
            else: # Linux
                subprocess.run(["xdg-open", file_path])
        except Exception as e:
            print(f"[{self.uuid} ERROR] Failed to open file: {e}")