from __future__ import annotations

import asyncio
import base64
import ctypes
import io
import json
import os
import shlex
import shutil
import subprocess
import sys
import time
import webbrowser
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import psutil
import pyperclip
import requests
from PIL import Image, ImageDraw, ImageFont


PLUGIN_UUID = "com.cookie.hpaistudio"
APP_ACTION = f"{PLUGIN_UUID}.application"
STATUS_ACTION = f"{PLUGIN_UUID}.status"
PROJECT_ACTION = f"{PLUGIN_UUID}.project"
WSL_QUICK_ACTION = f"{PLUGIN_UUID}.wslquick"
WSL_CUSTOM_ACTION = f"{PLUGIN_UUID}.wslcustom"
SERVICE_ACTION = f"{PLUGIN_UUID}.service"
HEALTH_ACTION = f"{PLUGIN_UUID}.health"
INFERENCE_ACTION = f"{PLUGIN_UUID}.inference"
GPU_ACTION = f"{PLUGIN_UUID}.gpu"

AI_STUDIO_CANDIDATES = (
    Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "HP" / "AIStudio" / "bin" / "AIStudio.exe",
)

WSL_PRESETS = {
    "python_environment": "python3 --version && python3 -m pip --version",
    "python_packages": "python3 -m pip list --format=columns",
    "pytorch_cuda": "python3 -c 'import torch; print(\"PyTorch:\", torch.__version__); print(\"GPU available:\", torch.cuda.is_available()); print(\"CUDA:\", torch.version.cuda); print(\"ROCm/HIP:\", torch.version.hip); print(\"Device:\", torch.cuda.get_device_name(0) if torch.cuda.is_available() else \"CPU\")'",
    "docker_containers": "docker ps --format 'table {{.Names}}\\t{{.Status}}\\t{{.Ports}}'",
    "docker_images": "docker images --format 'table {{.Repository}}\\t{{.Tag}}\\t{{.Size}}'",
    "jupyter_servers": "jupyter server list",
    "git_status": "git status --short --branch",
    "project_files": "find . -maxdepth 2 -type f | sort | head -n 80",
    "model_files": "find . -maxdepth 4 -type f \\( -iname '*.onnx' -o -iname '*.pt' -o -iname '*.pth' -o -iname '*.safetensors' -o -iname '*.gguf' \\) | sort | head -n 80",
    "gpu_status": "(command -v nvidia-smi >/dev/null && nvidia-smi) || (command -v rocm-smi >/dev/null && rocm-smi) || (command -v rocminfo >/dev/null && rocminfo | head -n 80) || (command -v lspci >/dev/null && lspci | grep -Ei 'vga|3d|display')",
    "disk_usage": "df -h",
    "memory_usage": "free -h",
    "processes": "ps -eo pid,comm,%cpu,%mem --sort=-%mem | head -n 16",
    "system_info": "cat /etc/os-release && uname -a",
}


class _GUID(ctypes.Structure):
    _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16), ("Data3", ctypes.c_uint16), ("Data4", ctypes.c_ubyte * 8)]


class _LUID(ctypes.Structure):
    _fields_ = [("LowPart", ctypes.c_uint32), ("HighPart", ctypes.c_int32)]


class _DXGI_ADAPTER_DESC1(ctypes.Structure):
    _fields_ = [
        ("Description", ctypes.c_wchar * 128), ("VendorId", ctypes.c_uint32),
        ("DeviceId", ctypes.c_uint32), ("SubSysId", ctypes.c_uint32),
        ("Revision", ctypes.c_uint32), ("DedicatedVideoMemory", ctypes.c_size_t),
        ("DedicatedSystemMemory", ctypes.c_size_t), ("SharedSystemMemory", ctypes.c_size_t),
        ("AdapterLuid", _LUID), ("Flags", ctypes.c_uint32),
    ]


_GPU_COUNTER_SCRIPT = r"""
$ErrorActionPreference='Stop'
Import-Module Microsoft.PowerShell.Diagnostics
$samples=(Get-Counter @('\GPU Engine(*)\Utilization Percentage','\GPU Adapter Memory(*)\Dedicated Usage','\GPU Adapter Memory(*)\Shared Usage')).CounterSamples
$engines=@{}; $memory=@{}
foreach($sample in $samples){
  $instance=$sample.InstanceName.ToLowerInvariant(); $path=$sample.Path.ToLowerInvariant()
  if($instance -notmatch '(luid_0x[0-9a-f]+_0x[0-9a-f]+)'){continue}; $luid=$Matches[1]
  if($path -like '*\gpu engine(*)\utilization percentage'){
    if(-not $engines.ContainsKey($luid)){$engines[$luid]=@{}}
    $engine=$instance -replace '^pid_\d+_',''
    if(-not $engines[$luid].ContainsKey($engine)){$engines[$luid][$engine]=0.0}
    $engines[$luid][$engine]+=[double]$sample.CookedValue
  } else {
    if(-not $memory.ContainsKey($luid)){$memory[$luid]=@{dedicated=0.0;shared=0.0}}
    if($path -like '*\dedicated usage'){$memory[$luid].dedicated=[double]$sample.CookedValue}
    elseif($path -like '*\shared usage'){$memory[$luid].shared=[double]$sample.CookedValue}
  }
}
$keys=@($engines.Keys)+@($memory.Keys)|Sort-Object -Unique
$result=@(foreach($luid in $keys){
  $usage=0.0
  if($engines.ContainsKey($luid) -and $engines[$luid].Count){$usage=[double](($engines[$luid].Values|Measure-Object -Maximum).Maximum)}
  $dedicated=0.0; $shared=0.0
  if($memory.ContainsKey($luid)){$dedicated=[double]$memory[$luid].dedicated;$shared=[double]$memory[$luid].shared}
  [pscustomobject]@{luid=$luid;usage=[math]::Min(100.0,$usage);dedicated=$dedicated;shared=$shared}
})
$result|ConvertTo-Json -Compress
"""


def _dxgi_adapters_sync() -> dict[str, dict[str, Any]]:
    if not sys.platform.startswith("win"):
        return {}
    dxgi = ctypes.WinDLL("dxgi")
    iid = _GUID(0x770AAE78, 0xF26F, 0x4DBA, (ctypes.c_ubyte * 8)(0xA8, 0x29, 0x25, 0x3C, 0x83, 0xD1, 0xB3, 0x87))
    factory = ctypes.c_void_p()
    create = dxgi.CreateDXGIFactory1
    create.argtypes = [ctypes.POINTER(_GUID), ctypes.POINTER(ctypes.c_void_p)]
    create.restype = ctypes.c_long
    if create(ctypes.byref(iid), ctypes.byref(factory)) < 0:
        return {}

    def method(pointer: ctypes.c_void_p, index: int, prototype):
        vtable = ctypes.cast(pointer, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
        return prototype(vtable[index])

    release_type = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)
    enum_type = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_void_p))
    desc_type = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.POINTER(_DXGI_ADAPTER_DESC1))
    adapters: dict[str, dict[str, Any]] = {}
    try:
        enum_adapters = method(factory, 12, enum_type)
        index = 0
        while True:
            adapter = ctypes.c_void_p()
            if enum_adapters(factory, index, ctypes.byref(adapter)) != 0:
                break
            try:
                desc = _DXGI_ADAPTER_DESC1()
                if method(adapter, 10, desc_type)(adapter, ctypes.byref(desc)) >= 0 and not (desc.Flags & 2):
                    luid = f"luid_0x{desc.AdapterLuid.HighPart & 0xffffffff:08x}_0x{desc.AdapterLuid.LowPart:08x}"
                    adapters[luid] = {"name": desc.Description.strip(), "dedicated_total": int(desc.DedicatedVideoMemory), "shared_total": int(desc.SharedSystemMemory)}
            finally:
                method(adapter, 2, release_type)(adapter)
            index += 1
    finally:
        method(factory, 2, release_type)(factory)
    return adapters


def _windows_gpu_status_sync() -> dict[str, Any]:
    try:
        adapters = _dxgi_adapters_sync()
    except (AttributeError, OSError, ValueError) as exc:
        return {"ok": False, "summary": "GPU query error", "details": str(exc)}
    powershell = shutil.which("powershell.exe")
    if not adapters or not powershell:
        return {"ok": False, "summary": "GPU unavailable", "details": "Windows GPU adapters or performance counters were not available."}
    flags = subprocess.CREATE_NO_WINDOW if sys.platform.startswith("win") else 0
    powershell_env = os.environ.copy()
    powershell_env["PSModulePath"] = str(Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "WindowsPowerShell" / "v1.0" / "Modules")
    try:
        completed = subprocess.run(
            [powershell, "-NoProfile", "-NonInteractive", "-Command", "[Console]::OutputEncoding=[Text.UTF8Encoding]::new();" + _GPU_COUNTER_SCRIPT],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=8, creationflags=flags, env=powershell_env, check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return {"ok": False, "summary": "GPU query error", "details": str(exc)}
    if completed.returncode != 0:
        details = (completed.stderr or completed.stdout).decode("utf-8", errors="replace").strip()
        return {"ok": False, "summary": "GPU query error", "details": details}
    raw = completed.stdout.decode("utf-8-sig", errors="replace").strip()
    try:
        values = json.loads(raw or "[]")
    except json.JSONDecodeError as exc:
        return {"ok": False, "summary": "GPU query error", "details": str(exc)}
    if isinstance(values, dict):
        values = [values]
    samples = {str(item.get("luid", "")).lower(): item for item in values if isinstance(item, dict)}

    def gib(value: Any) -> float:
        return float(value or 0) / (1024 ** 3)

    rows: list[str] = []
    peak = -1.0
    peak_name = "GPU"
    for luid, adapter in adapters.items():
        sample = samples.get(luid, {})
        usage = max(0.0, min(float(sample.get("usage", 0) or 0), 100.0))
        name = str(adapter.get("name") or "Windows GPU")
        if usage > peak:
            peak, peak_name = usage, name
        dedicated_total = int(adapter.get("dedicated_total") or 0)
        shared_total = int(adapter.get("shared_total") or 0)
        rows.append(
            f"{name}: {usage:.1f}%\n"
            f"  Dedicated {gib(sample.get('dedicated')):.2f}/{gib(dedicated_total):.2f} GB\n"
            f"  Shared {gib(sample.get('shared')):.2f}/{gib(shared_total):.2f} GB"
        )
    return {"ok": True, "summary": f"{max(peak, 0):.0f}% · {peak_name}", "details": "\n\n".join(rows)}


def user_data_dir(plugin_uuid: str) -> Path:
    root = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
    path = root / "CookieDeck" / plugin_uuid.replace(".", "_")
    path.mkdir(parents=True, exist_ok=True)
    return path


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.manifest = manifest
        self.plugin_uuid = str(manifest.get("UUID") or PLUGIN_UUID)
        self.plugin_dir = Path(__file__).resolve().parent
        self.locale_dir = self.plugin_dir / "locales"
        self.locale_cache: dict[str, dict[str, str]] = {}
        self.data_dir = user_data_dir(self.plugin_uuid)
        self.contexts: dict[str, dict[str, Any]] = {}
        self.tasks: dict[str, asyncio.Task] = {}
        self.command_tasks: dict[str, asyncio.Task] = {}
        self.command_processes: dict[str, asyncio.subprocess.Process] = {}
        self.command_pressed: set[str] = set()

    def _language(self, settings: dict[str, Any] | None) -> str:
        value = str((settings or {}).get("_lang") or "en").replace("_", "-").lower()
        value = "ko" if value == "kr" or value.startswith("ko") else value.split("-", 1)[0]
        return value if (self.locale_dir / f"{value}.json").is_file() else "en"

    def _locale(self, settings: dict[str, Any] | None) -> dict[str, str]:
        language = self._language(settings)
        if language in self.locale_cache:
            return self.locale_cache[language]

        def load(code: str) -> dict[str, str]:
            try:
                value = json.loads((self.locale_dir / f"{code}.json").read_text(encoding="utf-8"))
                return value if isinstance(value, dict) else {}
            except (OSError, json.JSONDecodeError):
                return {}

        english = self.locale_cache.get("en") or load("en")
        self.locale_cache["en"] = english
        translated = english if language == "en" else {**english, **load(language)}
        self.locale_cache[language] = translated
        return translated

    def _t(self, settings: dict[str, Any] | None, key: str, fallback: str = "", **values: Any) -> str:
        text = str(self._locale(settings).get(key) or fallback or key)
        try:
            return text.format(**values)
        except (KeyError, IndexError, ValueError):
            return text

    @staticmethod
    def _settings(data: dict[str, Any]) -> dict[str, Any]:
        payload = data.get("payload", {}) or {}
        if not isinstance(payload, dict):
            return {}
        nested = payload.get("settings")
        return dict(nested) if isinstance(nested, dict) else dict(payload)

    def _remember(self, data: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        context = str(data.get("context") or "")
        payload = data.get("payload", {}) or {}
        state = self.contexts.setdefault(context, {"action": "", "settings": {}, "page": None})
        action = str(data.get("action") or "").split("#", 1)[0]
        if action:
            state["action"] = action
        state["settings"].update(self._settings(data))
        if isinstance(payload, dict) and payload.get("page") is not None:
            try:
                state["page"] = int(payload["page"])
            except (TypeError, ValueError):
                pass
        return context, state

    def _action_defaults(self, action: str) -> dict[str, Any]:
        for item in self.manifest.get("Actions", []):
            if str(item.get("UUID") or "") == action:
                defaults = item.get("DefaultSettings")
                return dict(defaults) if isinstance(defaults, dict) else {}
        return {}

    async def _ensure_action_settings(self, context: str, state: dict[str, Any]) -> None:
        defaults = self._action_defaults(str(state.get("action") or ""))
        if not defaults:
            return
        current = state.get("settings", {})
        merged = {**defaults, **current}
        # feature identifies the manifest Action and is not a user-selectable setting.
        merged["feature"] = defaults.get("feature")
        if merged == current:
            return
        state["settings"] = merged
        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": merged,
        })

    @staticmethod
    def _heading(state: dict[str, Any], fallback: str) -> str:
        return str(state.get("settings", {}).get("title") or fallback).strip() or fallback

    async def _title(self, context: str, value: str) -> None:
        state = self.contexts.get(context, {})
        await self.runner.send_message({
            "event": "setTitle",
            "context": context,
            "payload": {"title": value, "page": state.get("page")},
        })

    async def _pi(self, context: str, payload: dict[str, Any]) -> None:
        await self.runner.send_message({
            "event": "sendToPropertyInspector",
            "context": context,
            "payload": payload,
        })

    @staticmethod
    def _first_existing(candidates: tuple[Path, ...]) -> Path | None:
        return next((path for path in candidates if path.is_file()), None)

    @staticmethod
    def _is_running(names: set[str]) -> bool:
        lowered = {name.lower() for name in names}
        for process in psutil.process_iter(["name"]):
            try:
                if str(process.info.get("name") or "").lower() in lowered:
                    return True
            except (psutil.Error, OSError):
                continue
        return False

    @staticmethod
    def _focus_process_sync(names: set[str]) -> bool:
        try:
            import win32con
            import win32gui
            import win32process
        except ImportError:
            return False
        lowered = {name.lower() for name in names}
        pids: set[int] = set()
        for process in psutil.process_iter(["pid", "name"]):
            try:
                if str(process.info.get("name") or "").lower() in lowered:
                    pids.add(int(process.info["pid"]))
            except (psutil.Error, OSError, TypeError, ValueError):
                continue
        windows: list[int] = []

        def collect(hwnd: int, _extra: object) -> None:
            if not win32gui.IsWindowVisible(hwnd):
                return
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            if pid in pids:
                windows.append(hwnd)

        win32gui.EnumWindows(collect, None)
        for hwnd in windows:
            try:
                win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                win32gui.SetForegroundWindow(hwnd)
                return True
            except Exception:
                continue
        return False

    @staticmethod
    def _launch(args: list[str]) -> None:
        subprocess.Popen(args, close_fds=True)

    async def _open_application(self, context: str) -> None:
        state = self.contexts.get(context, {})
        settings = state.get("settings", {})
        path = self._first_existing(AI_STUDIO_CANDIDATES)
        if path is None:
            await self._title(context, self._t(settings, "STATUS_NOT_INSTALLED", "Not installed"))
            return
        focused = await asyncio.to_thread(self._focus_process_sync, {"aistudio.exe"})
        if not focused:
            await asyncio.to_thread(self._launch, [str(path)])
        await self._title(context, self._t(settings, "STATUS_OPENED", "Opened"))

    @staticmethod
    def _status_image(ok: bool, label: str) -> str:
        image = Image.new("RGB", (144, 144), "#101827")
        draw = ImageDraw.Draw(image)
        color = "#52d7ff" if ok else "#ffae57"
        draw.rounded_rectangle((8, 8, 136, 136), radius=18, outline=color, width=5)
        draw.ellipse((56, 27, 88, 59), fill=color)
        font = ImageFont.load_default()
        lines = label.replace(" · ", "\n").splitlines()[:3]
        draw.multiline_text((14, 77), "\n".join(line[:20] for line in lines), fill="white", font=font, spacing=3, align="center")
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        return "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode("ascii")

    async def _image(self, context: str, ok: bool, label: str) -> None:
        state = self.contexts.get(context, {})
        image = await asyncio.to_thread(self._status_image, ok, label)
        await self.runner.send_message({
            "event": "setImage",
            "context": context,
            "payload": {"image": image, "page": state.get("page")},
        })

    async def _refresh_status(self, context: str) -> None:
        state = self.contexts.get(context)
        if not state:
            return
        settings = state.get("settings", {})
        installed = self._first_existing(AI_STUDIO_CANDIDATES) is not None
        running = await asyncio.to_thread(self._is_running, {"aistudio.exe"})
        key = "STATUS_RUNNING" if running else "STATUS_INSTALLED" if installed else "STATUS_NOT_INSTALLED"
        fallback = "Running" if running else "Installed" if installed else "Not installed"
        status = self._t(settings, key, fallback)
        heading = self._heading(state, "AI Studio")
        await self._title(context, f"{heading}\n{status}")
        await self._image(context, running, status)
        await self._pi(context, {"command": "status_result", "ok": installed, "summary": status})

    @staticmethod
    def _vscode_path() -> str | None:
        candidates = (
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Microsoft VS Code" / "Code.exe",
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Microsoft VS Code" / "Code.exe",
        )
        return next((str(path) for path in candidates if path.is_file()), None)

    async def _open_project(self, context: str) -> None:
        state = self.contexts.get(context, {})
        settings = state.get("settings", {})
        path = Path(str(settings.get("project_path") or "")).expanduser()
        if not path.is_dir():
            await self._title(context, self._t(settings, "STATUS_CHOOSE_PROJECT", "Choose project"))
            return
        target = str(settings.get("project_target") or "explorer")
        args: list[str] | None = None
        if target == "vscode":
            executable = self._vscode_path()
            args = [executable, str(path)] if executable else None
        elif target == "terminal":
            executable = shutil.which("wt.exe")
            args = [executable, "-d", str(path)] if executable else None
        else:
            executable = shutil.which("explorer.exe")
            args = [executable, str(path)] if executable else None
        if not args or not args[0]:
            await self._title(context, self._t(settings, "STATUS_TOOL_MISSING", "Tool missing"))
            return
        await asyncio.to_thread(self._launch, args)
        await self._title(context, self._t(settings, "STATUS_OPENED", "Opened"))

    @staticmethod
    def _valid_http_url(value: str) -> bool:
        parsed = urlparse(value)
        return parsed.scheme in {"http", "https"} and bool(parsed.netloc)

    async def _open_service(self, context: str) -> None:
        state = self.contexts.get(context, {})
        settings = state.get("settings", {})
        url = str(settings.get("service_url") or "").strip()
        if not self._valid_http_url(url):
            await self._title(context, self._t(settings, "STATUS_SET_URL", "Set URL"))
            return
        await asyncio.to_thread(webbrowser.open, url)
        await self._title(context, self._t(settings, "STATUS_OPENED", "Opened"))

    @staticmethod
    def _health_sync(url: str, timeout: float) -> dict[str, Any]:
        started = time.monotonic()
        try:
            response = requests.get(url, timeout=timeout, headers={"User-Agent": "COMBO-X-HP-AI-Studio/1"})
            elapsed = round((time.monotonic() - started) * 1000)
            return {
                "ok": response.ok,
                "summary": f"HTTP {response.status_code} · {elapsed} ms",
                "details": response.text[:1000],
            }
        except requests.RequestException as exc:
            return {"ok": False, "summary": "Offline", "details": str(exc)}

    async def _refresh_health(self, context: str) -> None:
        state = self.contexts.get(context)
        if not state:
            return
        settings = state.get("settings", {})
        url = str(settings.get("health_url") or "").strip()
        if not self._valid_http_url(url):
            await self._title(context, self._t(settings, "STATUS_SET_URL", "Set URL"))
            return
        try:
            timeout = max(1.0, min(float(settings.get("timeout", 5)), 30.0))
        except (TypeError, ValueError):
            timeout = 5.0
        result = await asyncio.to_thread(self._health_sync, url, timeout)
        heading = self._heading(state, "Endpoint")
        await self._title(context, f"{heading}\n{result['summary'][:28]}")
        await self._image(context, bool(result["ok"]), str(result["summary"]))
        await self._pi(context, {"command": "status_result", **result})

    @staticmethod
    def _extract_path(value: Any, path: str) -> Any:
        current = value
        for part in [item for item in path.split(".") if item]:
            if isinstance(current, dict):
                current = current[part]
            elif isinstance(current, list) and part.isdigit():
                current = current[int(part)]
            else:
                raise KeyError(part)
        return current

    @staticmethod
    def _inference_sync(settings: dict[str, Any]) -> dict[str, Any]:
        url = str(settings.get("endpoint_url") or "").strip()
        if not Plugin._valid_http_url(url):
            raise ValueError("A valid HTTP or HTTPS endpoint URL is required.")
        source = str(settings.get("input_source") or "clipboard")
        input_text = pyperclip.paste() if source == "clipboard" else str(settings.get("input_text") or "")
        if not input_text:
            raise ValueError("The selected input is empty.")
        try:
            headers = json.loads(str(settings.get("headers_json") or "{}"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Headers JSON is invalid: {exc}") from exc
        if not isinstance(headers, dict):
            raise ValueError("Headers JSON must be an object.")
        headers = {str(key): str(value) for key, value in headers.items()}
        api_key = str(settings.get("api_key") or "").strip()
        if api_key and not any(key.lower() == "authorization" for key in headers):
            headers["Authorization"] = f"Bearer {api_key}"
        template = str(settings.get("request_template") or '{"inputs":"{{input}}"}')
        rendered = template.replace('"{{input}}"', json.dumps(input_text, ensure_ascii=False))
        rendered = rendered.replace("{{input}}", input_text)
        try:
            body = json.loads(rendered)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Request template is invalid JSON after inserting input: {exc}") from exc
        method = str(settings.get("http_method") or "POST").upper()
        if method not in {"POST", "PUT", "PATCH"}:
            raise ValueError("Inference method must be POST, PUT, or PATCH.")
        try:
            timeout = max(1.0, min(float(settings.get("timeout", 30)), 300.0))
        except (TypeError, ValueError):
            timeout = 30.0
        response = requests.request(method, url, json=body, headers=headers, timeout=timeout)
        response.raise_for_status()
        try:
            value: Any = response.json()
        except ValueError:
            value = response.text
        response_path = str(settings.get("response_path") or "").strip()
        if response_path:
            value = Plugin._extract_path(value, response_path)
        text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2)
        return {"text": text, "status": response.status_code}

    async def _run_inference(self, context: str) -> None:
        state = self.contexts.get(context, {})
        settings = state.get("settings", {})
        heading = self._heading(state, "AI Inference")
        await self._title(context, f"{heading}\n{self._t(settings, 'STATUS_WORKING', 'Working…')}")
        try:
            result = await asyncio.to_thread(self._inference_sync, dict(settings))
            text = str(result["text"])
            mode = str(settings.get("output_mode") or "clipboard")
            path = ""
            if mode == "clipboard":
                await asyncio.to_thread(pyperclip.copy, text)
                status = self._t(settings, "STATUS_COPIED", "Copied")
            elif mode == "file":
                output_path = self.data_dir / "latest_ai_result.txt"
                await asyncio.to_thread(output_path.write_text, text, "utf-8")
                path = str(output_path)
                status = self._t(settings, "STATUS_SAVED", "Saved")
            else:
                status = text.replace("\r", " ").replace("\n", " ")[:28] or self._t(settings, "STATUS_EMPTY", "Empty")
            await self._title(context, f"{heading}\n{status}")
            await self._pi(context, {"command": "inference_result", "ok": True, "summary": status, "details": text[:10000], "path": path})
        except Exception as exc:
            await self._title(context, f"{heading}\n{self._t(settings, 'STATUS_INFERENCE_ERROR', 'Inference error')}")
            await self._pi(context, {"command": "inference_error", "ok": False, "message": str(exc)})

    @staticmethod
    def _run_command(args: list[str], timeout: float = 8.0) -> tuple[int, str]:
        flags = subprocess.CREATE_NO_WINDOW if sys.platform.startswith("win") else 0
        completed = subprocess.run(
            args,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            creationflags=flags,
            check=False,
        )
        return completed.returncode, (completed.stdout or completed.stderr or "").strip()

    @staticmethod
    def _decode_windows_output(raw: bytes) -> str:
        if not raw:
            return ""
        if raw.startswith((b"\xff\xfe", b"\xfe\xff")) or b"\x00" in raw[:80]:
            encoding = "utf-16" if raw.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-16-le"
            return raw.decode(encoding, errors="replace").replace("\x00", "").strip()
        for encoding in ("utf-8", "cp949", "mbcs"):
            try:
                return raw.decode(encoding).strip()
            except (LookupError, UnicodeDecodeError):
                continue
        return raw.decode("utf-8", errors="replace").strip()

    @classmethod
    def _wsl_distributions_sync(cls) -> list[str]:
        executable = shutil.which("wsl.exe")
        if not executable:
            return []
        flags = subprocess.CREATE_NO_WINDOW if sys.platform.startswith("win") else 0
        completed = subprocess.run(
            [executable, "--list", "--quiet"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=8,
            creationflags=flags,
            check=False,
        )
        output = cls._decode_windows_output(completed.stdout or completed.stderr)
        return [line.strip().lstrip("* ").strip() for line in output.splitlines() if line.strip().lstrip("* ").strip()]

    async def _send_wsl_distributions(self, context: str) -> None:
        state = self.contexts.get(context, {})
        settings = state.get("settings", {})
        try:
            distributions = await asyncio.to_thread(self._wsl_distributions_sync)
            await self._pi(context, {
                "command": "wsl_distributions",
                "ok": True,
                "distributions": distributions,
                "summary": self._t(settings, "STATUS_DISTRIBUTIONS_FOUND", "{count} distributions", count=len(distributions)),
            })
        except (OSError, subprocess.SubprocessError) as exc:
            await self._pi(context, {"command": "wsl_distributions", "ok": False, "distributions": [], "message": str(exc)})

    @staticmethod
    def _bounded_timeout(value: Any, fallback: int) -> int:
        try:
            return max(1, min(int(value), 600))
        except (TypeError, ValueError):
            return fallback

    async def _run_wsl_command(self, context: str, state: dict[str, Any]) -> None:
        settings = state.get("settings", {})
        quick = state.get("action") == WSL_QUICK_ACTION
        prefix = "quick" if quick else "custom"
        distribution = str(settings.get(f"{prefix}_distribution") or "").strip()
        workdir = str(settings.get(f"{prefix}_workdir") or "~").strip()
        output_target = str(settings.get(f"{prefix}_output") or "inspector")
        timeout = self._bounded_timeout(settings.get(f"{prefix}_timeout"), 20 if quick else 60)
        preset = str(settings.get("wsl_preset") or "python_environment")
        command = WSL_PRESETS.get(preset, "") if quick else str(settings.get("wsl_custom_command") or "").strip()
        heading = self._heading(state, self._t(settings, "ACTION_WSL_QUICK" if quick else "ACTION_WSL_CUSTOM", "WSL Command"))
        executable = shutil.which("wsl.exe")
        if not executable:
            await self._title(context, f"{heading}\n{self._t(settings, 'STATUS_WSL_MISSING', 'WSL missing')}")
            return
        if quick and preset == "open_terminal":
            args = [executable] + (["-d", distribution] if distribution else []) + (["--cd", workdir] if workdir else [])
            await asyncio.to_thread(self._launch, args)
            await self._title(context, f"{heading}\n{self._t(settings, 'STATUS_STARTED', 'Started')}")
            return
        if not command:
            message = self._t(settings, "STATUS_COMMAND_EMPTY", "Enter a command")
            await self._title(context, f"{heading}\n{message}")
            await self._pi(context, {"command": "wsl_command_result", "ok": False, "summary": message, "details": ""})
            return

        args = [executable] + (["-d", distribution] if distribution else []) + (["--cd", workdir] if workdir else [])
        wrapped = f"timeout --signal=TERM {timeout}s bash -lc {shlex.quote(command)}"
        args += ["--", "bash", "-lc", wrapped]
        await self._title(context, f"{heading}\n{self._t(settings, 'STATUS_RUNNING_COMMAND', 'Running…')}")
        flags = subprocess.CREATE_NO_WINDOW if sys.platform.startswith("win") else 0
        try:
            process = await asyncio.create_subprocess_exec(
                *args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                creationflags=flags,
            )
            self.command_processes[context] = process
            try:
                raw, _ = await asyncio.wait_for(process.communicate(), timeout=timeout + 5)
            except asyncio.TimeoutError:
                process.kill()
                raw, _ = await process.communicate()
                details = self._decode_windows_output(raw)
                summary = self._t(settings, "STATUS_COMMAND_TIMEOUT", "Timed out")
                await self._title(context, f"{heading}\n{summary}")
                await self._pi(context, {"command": "wsl_command_result", "ok": False, "summary": summary, "details": details[:20000]})
                return
            details = self._decode_windows_output(raw)
            ok = process.returncode == 0
            first_line = next((line.strip() for line in details.splitlines() if line.strip()), "")
            summary = first_line[:80] or self._t(settings, "STATUS_COMMAND_DONE" if ok else "STATUS_COMMAND_FAILED", "Done" if ok else "Failed")
            if output_target == "clipboard":
                await asyncio.to_thread(pyperclip.copy, details)
                summary = self._t(settings, "STATUS_COPIED", "Copied")
            elif output_target == "file":
                result_path = self.data_dir / "latest_wsl_result.txt"
                await asyncio.to_thread(result_path.write_text, details, encoding="utf-8")
                summary = self._t(settings, "STATUS_SAVED", "Saved")
                details = f"{result_path}\n\n{details}"
            await self._title(context, f"{heading}\n{summary[:28]}")
            await self._pi(context, {"command": "wsl_command_result", "ok": ok, "summary": summary, "details": details[:20000]})
        except (OSError, subprocess.SubprocessError) as exc:
            summary = self._t(settings, "STATUS_COMMAND_ERROR", "Command error")
            await self._title(context, f"{heading}\n{summary}")
            await self._pi(context, {"command": "wsl_command_result", "ok": False, "summary": summary, "details": str(exc)})
        finally:
            self.command_processes.pop(context, None)

    async def _execute_wsl_command(self, context: str, state: dict[str, Any]) -> None:
        existing = self.command_tasks.get(context)
        if existing and not existing.done():
            await self._pi(context, {"command": "wsl_command_result", "ok": False, "summary": self._t(state.get("settings", {}), "STATUS_COMMAND_BUSY", "Command already running")})
            return
        task = asyncio.create_task(self._run_wsl_command(context, state))
        self.command_tasks[context] = task
        try:
            await task
        finally:
            if self.command_tasks.get(context) is task:
                self.command_tasks.pop(context, None)

    @staticmethod
    def _gpu_status_sync() -> dict[str, Any]:
        windows_result = _windows_gpu_status_sync()
        executable = shutil.which("nvidia-smi.exe")
        if not executable:
            candidate = Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "nvidia-smi.exe"
            executable = str(candidate) if candidate.is_file() else None
        if not executable:
            return windows_result
        args = [executable, "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu", "--format=csv,noheader,nounits"]
        try:
            code, output = Plugin._run_command(args)
        except (OSError, subprocess.SubprocessError) as exc:
            if windows_result.get("ok"):
                windows_result["details"] = f"{windows_result.get('details', '')}\n\nNVIDIA sensor query: {exc}"
                return windows_result
            return {"ok": False, "summary": "GPU query error", "details": str(exc)}
        parts = [part.strip() for part in next((line for line in output.splitlines() if line.strip()), "").split(",")]
        if windows_result.get("ok"):
            if code == 0 and len(parts) >= 5:
                windows_result["details"] = (
                    f"{windows_result.get('details', '')}\n\n"
                    f"NVIDIA sensors: {parts[1]}% · {parts[2]}/{parts[3]} MB · {parts[4]}°C"
                )
            return windows_result
        summary = f"{parts[1]}% · {parts[2]}/{parts[3]} MB · {parts[4]}°C" if code == 0 and len(parts) >= 5 else "GPU query error"
        return {"ok": code == 0, "summary": summary, "details": output[:4000]}

    async def _refresh_gpu(self, context: str) -> None:
        state = self.contexts.get(context)
        if not state:
            return
        result = await asyncio.to_thread(self._gpu_status_sync)
        heading = self._heading(state, "AI GPU")
        await self._title(context, f"{heading}\n{result['summary'][:28]}")
        await self._image(context, bool(result["ok"]), str(result["summary"]))
        await self._pi(context, {"command": "status_result", **result})

    async def _refresh_loop(self, context: str) -> None:
        try:
            while context in self.contexts:
                state = self.contexts.get(context, {})
                action = state.get("action")
                if action == STATUS_ACTION:
                    await self._refresh_status(context)
                elif action == HEALTH_ACTION:
                    await self._refresh_health(context)
                elif action == GPU_ACTION:
                    await self._refresh_gpu(context)
                settings = state.get("settings", {})
                try:
                    interval = max(3.0, min(float(settings.get("refresh_interval", 5)), 300.0))
                except (TypeError, ValueError):
                    interval = 5.0
                await asyncio.sleep(interval)
        except asyncio.CancelledError:
            pass

    def _start_loop(self, context: str) -> None:
        existing = self.tasks.get(context)
        if existing and not existing.done():
            return
        self.tasks[context] = asyncio.create_task(self._refresh_loop(context))

    def _stop_context(self, context: str) -> None:
        task = self.tasks.pop(context, None)
        if task and not task.done():
            task.cancel()
        command_task = self.command_tasks.pop(context, None)
        if command_task and not command_task.done():
            command_task.cancel()
        process = self.command_processes.pop(context, None)
        if process and process.returncode is None:
            process.kill()
        self.command_pressed.discard(context)
        self.contexts.pop(context, None)

    async def _initial(self, context: str, state: dict[str, Any]) -> None:
        action = state.get("action")
        if action in {STATUS_ACTION, HEALTH_ACTION, GPU_ACTION}:
            self._start_loop(context)
            return
        fallback = {
            APP_ACTION: "HP AI Studio",
            PROJECT_ACTION: "AI Project",
            WSL_QUICK_ACTION: "WSL AI Quick",
            WSL_CUSTOM_ACTION: "WSL AI Custom",
            SERVICE_ACTION: "AI Service",
            INFERENCE_ACTION: "AI Inference",
        }.get(action, "HP AI Studio")
        await self._title(context, self._heading(state, fallback))

    async def _press(self, context: str, state: dict[str, Any]) -> None:
        action = state.get("action")
        if action == APP_ACTION:
            await self._open_application(context)
        elif action == STATUS_ACTION:
            await self._refresh_status(context)
        elif action == PROJECT_ACTION:
            await self._open_project(context)
        elif action in {WSL_QUICK_ACTION, WSL_CUSTOM_ACTION}:
            await self._execute_wsl_command(context, state)
        elif action == SERVICE_ACTION:
            await self._open_service(context)
        elif action == HEALTH_ACTION:
            await self._refresh_health(context)
        elif action == INFERENCE_ACTION:
            await self._run_inference(context)
        elif action == GPU_ACTION:
            await self._refresh_gpu(context)

    async def handle_message(self, data):
        event = data.get("event")
        context = str(data.get("context") or "")
        if not context:
            return
        if event in ("keyDidAppear", "willAppear"):
            context, state = self._remember(data)
            await self._ensure_action_settings(context, state)
            await self._initial(context, state)
            return
        if event == "didReceiveSettings":
            context, state = self._remember(data)
            await self._ensure_action_settings(context, state)
            await self._initial(context, state)
            return
        if event == "keyDown":
            context, state = self._remember(data)
            if state.get("action") in {WSL_QUICK_ACTION, WSL_CUSTOM_ACTION}:
                if context in self.command_pressed:
                    return
                self.command_pressed.add(context)
            await self._press(context, state)
            return
        if event == "keyUp":
            self.command_pressed.discard(context)
            return
        if event == "sendToPlugin":
            context, state = self._remember(data)
            command = str((data.get("payload", {}) or {}).get("command") or "")
            if command == "refresh":
                await self._press(context, state)
            elif command == "run_inference":
                await self._run_inference(context)
            elif command == "get_wsl_distributions":
                await self._send_wsl_distributions(context)
            elif command == "run_wsl_command":
                await self._execute_wsl_command(context, state)
            return
        if event == "folderDialogResponse":
            context, state = self._remember(data)
            payload = data.get("payload", {}) or {}
            if payload.get("target") == "ai-project" and payload.get("path"):
                state["settings"]["project_path"] = str(payload["path"])
                await self.runner.send_message({"event": "setSettings", "context": context, "payload": state["settings"]})
            return
        if event in ("keyDidDisappear", "willDisappear"):
            self._stop_context(context)

    async def shutdown(self):
        tasks = list(self.tasks.values()) + list(self.command_tasks.values())
        self.tasks.clear()
        self.command_tasks.clear()
        for process in self.command_processes.values():
            if process.returncode is None:
                process.kill()
        self.command_processes.clear()
        for task in tasks:
            if not task.done():
                task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        self.contexts.clear()
        self.command_pressed.clear()
        self.locale_cache.clear()
