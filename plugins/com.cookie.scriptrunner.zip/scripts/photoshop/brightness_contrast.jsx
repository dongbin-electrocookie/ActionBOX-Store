#target photoshop

if (app.documents.length === 0) {
  alert("❌ 열린 문서가 없습니다.");
} else {
  try {
    var idBrgC = charIDToTypeID("BrgC");
    executeAction(idBrgC, undefined, DialogModes.ALL);
  } catch (e) {
    // 사용자가 취소한 경우에도 조용히 넘어감
    // alert("⛔ 사용자가 취소했습니다."); // 필요하면 메시지 표시
  }
}
