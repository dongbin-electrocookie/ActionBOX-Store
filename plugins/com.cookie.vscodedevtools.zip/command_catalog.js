// The manifest is the single source of built-in commands for both inspectors.
class CommandCatalog {
    constructor(actionId, selectId) {
        this.actionId = actionId;
        this.selectId = selectId;
        this.states = [];
        this.loaded = false;
    }

    getState(value) {
        return this.states.find(state => state.Value === value);
    }

    async load() {
        const response = await fetch('./manifest.json');
        if (!response.ok) throw new Error('Manifest load failed: ' + response.status);
        const manifest = await response.json();
        const action = (manifest.Actions || []).find(entry => entry.UUID === this.actionId);
        this.states = (action?.States || []).filter(state => state.Value && !state.Hidden);
        if (!this.states.length) throw new Error('No commands declared for ' + this.actionId);

        const select = document.getElementById(this.selectId);
        const placeholder = Array.from(select.options).find(option => option.value === '');
        select.replaceChildren();
        if (placeholder) select.appendChild(placeholder);
        const groups = new Map();
        for (const state of this.states) {
            let parent = select;
            if (state.GroupKey || state.Group) {
                const groupId = state.GroupKey || state.Group;
                if (!groups.has(groupId)) {
                    const group = document.createElement('optgroup');
                    group.label = state.Group || groupId;
                    group.setAttribute('data-label-i18n', state.GroupKey || '');
                    group.setAttribute('data-fallback', group.label);
                    groups.set(groupId, group);
                    select.appendChild(group);
                }
                parent = groups.get(groupId);
            }
            const option = document.createElement('option');
            option.value = state.Value;
            option.innerText = state.InspectorName || state.Name;
            option.setAttribute('data-i18n', state.InspectorNameKey || state.NameKey || '');
            option.setAttribute('data-fallback', option.innerText);
            option.setAttribute('data-title-key', state.TitleKey || '');
            parent.appendChild(option);
        }
        this.loaded = true;
        select.disabled = false;
    }

    translate(languageData) {
        const select = document.getElementById(this.selectId);
        select.querySelectorAll('[data-i18n], [data-label-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n') || element.getAttribute('data-label-i18n');
            const text = languageData[key] || element.getAttribute('data-fallback');
            if (!text) return;
            if (element.tagName === 'OPTGROUP') element.label = text;
            else element.innerText = text;
        });
    }
}
