#target photoshop

if (app.documents.length === 0) {
  alert("❌ 열린 문서가 없습니다.");
} else {
  try {
    var doc = app.activeDocument;

    // Adjustment Layer 추가: Photo Filter
    var idMk = charIDToTypeID("Mk  ");
    var desc = new ActionDescriptor();
    var idNw = charIDToTypeID("Nw  ");
    var idAdjL = charIDToTypeID("AdjL");
    desc.putClass(idNw, idAdjL);

    var idUsng = charIDToTypeID("Usng");
    var desc2 = new ActionDescriptor();
    var idType = charIDToTypeID("Type");
    var desc3 = new ActionDescriptor();

    // 필터 색상 (오렌지톤: R:255 G:153 B:51)
    var idClr = charIDToTypeID("Clr ");
    var colorDesc = new ActionDescriptor();
    colorDesc.putDouble(charIDToTypeID("Rd  "), 255);
    colorDesc.putDouble(charIDToTypeID("Grn "), 153);
    colorDesc.putDouble(charIDToTypeID("Bl  "), 51);
    desc3.putObject(idClr, charIDToTypeID("RGBC"), colorDesc);

    desc3.putInteger(charIDToTypeID("Dnst"), 25);   // 밀도
    desc3.putBoolean(charIDToTypeID("PrsL"), true); // 밝기 보존
    desc2.putObject(idType, stringIDToTypeID("photoFilter"), desc3);
    desc.putObject(idUsng, idAdjL, desc2);

    executeAction(idMk, desc, DialogModes.NO);

    alert("✅ 포토 필터 조정 레이어가 추가되었습니다!");

  } catch (e) {
    alert("⚠ 오류 발생: " + e.message);
  }
}
