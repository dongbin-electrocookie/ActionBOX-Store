import asyncio
import json
import os
import ssl
import urllib.request
import urllib.error


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        self.icon_map = {
            "turn_on": "SERVICE_TURN_ON",
            "turn_off": "SERVICE_TURN_OFF",
            "toggle": "SERVICE_TOGGLE",
            "trigger": "SERVICE_TRIGGER",
            "press": "SERVICE_TRIGGER",
            "start": "SERVICE_TRIGGER",
            "stop": "SERVICE_TURN_OFF",
            "pause": "SERVICE_TURN_OFF",
            "resume": "SERVICE_TURN_ON",
            "open_cover": "SERVICE_TURN_ON",
            "close_cover": "SERVICE_TURN_OFF",
            "unlock": "SERVICE_TURN_ON",
            "lock": "SERVICE_TURN_OFF",
            "media_play_pause": "SERVICE_TOGGLE",
            "volume_up": "SERVICE_TURN_ON",
            "volume_down": "SERVICE_TURN_OFF"
        }

    def _default_service(self):
        return "turn_on"

    def _default_settings(self):
        service = self._default_service()
        return {
            "ha_url": "",
            "ha_token": "",
            "ha_domain": "light",
            "ha_service": service,
            "ha_entity_id": "",
            "ha_service_data": "",
            "_lang": "en",
            "sync_title_on_target_change": False,
            "builtin_icon_name": self._icon_name_for_service(service),
            "default_visuals_initialized": True
        }

    def _icon_name_for_service(self, service_name):
        return self.icon_map.get((service_name or "").strip(), "HOMEASSISTANT")

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        merged["ha_domain"] = (merged.get("ha_domain") or "light").strip()
        merged["ha_service"] = (merged.get("ha_service") or self._default_service()).strip()
        merged["ha_entity_id"] = (merged.get("ha_entity_id") or "").strip()
        merged["builtin_icon_name"] = self._icon_name_for_service(merged["ha_service"])

        lang = (merged.get("_lang") or "en").strip()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        merged["_lang"] = alias.get(lang, lang)
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("ha_url"),
            s.get("ha_token"),
            s.get("ha_domain"),
            s.get("ha_service"),
            s.get("ha_entity_id"),
            s.get("ha_service_data"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_target_change", False),
            s.get("_lang")
        ])

    def _get_icon_path(self, service_name):
        icon_name = self._icon_name_for_service(service_name)
        path = os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")
        if os.path.exists(path):
            return path
        fallback = os.path.join(self.plugin_dir, "icon", "HOMEASSISTANT.png")
        return fallback if os.path.exists(fallback) else None

    async def _send_builtin_icon(self, context, service_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(service_name)
        if context and icon_path:
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["ha_service"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            service_name = data.get("action_command") or payload.get("action_command") or settings.get("ha_service") or cached.get("ha_service") or self._default_service()
            await self._send_builtin_icon(context, service_name)
            return

        if event == "keyDown":
            await self.on_key_down(context, settings)

    async def on_key_down(self, context, incoming_settings):
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **(incoming_settings or {})})
        if context:
            self.context_settings[context] = settings

        await asyncio.to_thread(self._call_home_assistant_service, settings)

    def _call_home_assistant_service(self, settings):
        base_url = (settings.get("ha_url") or "").strip().rstrip("/")
        token = (settings.get("ha_token") or "").strip()
        domain = (settings.get("ha_domain") or "").strip()
        service = (settings.get("ha_service") or "").strip()
        entity_id = (settings.get("ha_entity_id") or "").strip()
        raw_data = (settings.get("ha_service_data") or "").strip()

        if not base_url or not token or not domain or not service:
            print(f"[{self.uuid}] Missing Home Assistant URL, token, domain, or service.")
            return

        payload = {}
        if entity_id:
            payload["entity_id"] = entity_id

        if raw_data:
            try:
                extra_data = json.loads(raw_data)
                if isinstance(extra_data, dict):
                    payload.update(extra_data)
            except Exception as e:
                print(f"[{self.uuid}] Invalid JSON in service data: {e}")
                return

        url = f"{base_url}/api/services/{domain}/{service}"
        req = urllib.request.Request(
            url,
            method="POST",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            }
        )

        try:
            with urllib.request.urlopen(req, timeout=8) as response:
                body = response.read().decode("utf-8", errors="replace")
                print(f"[{self.uuid}] Home Assistant service called: {domain}.{service} -> HTTP {response.status}")
                if body:
                    print(body[:500])
        except urllib.error.HTTPError as e:
            try:
                detail = e.read().decode("utf-8", errors="replace")
            except Exception:
                detail = str(e)
            print(f"[{self.uuid}] HTTP error calling Home Assistant: {e.code} {detail}")
        except Exception as e:
            print(f"[{self.uuid}] Failed to call Home Assistant: {e}")
