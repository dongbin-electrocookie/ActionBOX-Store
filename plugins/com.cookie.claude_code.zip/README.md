# Claude Code for COMBO-X (v1.0.0)

The Claude Code plugin contains only controls supported by Claude Code.

## Actions

- **Claude Code Status** — Idle, Thinking, Complete, Permission and Error artwork with matching status LED
- **Claude Code Voice** — sends the built-in Desktop dictation shortcut (`Ctrl+D` on Windows or `Command+D` on macOS)
- **Confirm / Cancel** — sends `Enter` or `Esc` to the focused application

Claude Code hooks are automatically installed or repaired. Local Claude transcript JSONL is also monitored as a read-only fallback when Desktop hooks do not execute.

The former `com.cookie.ai_monitor` Claude action IDs are retained so existing COMBO-X button assignments continue working after the plugin split. Existing AI Monitor user data is copied into the new `com.cookie.claude_code` data directory on first run.
