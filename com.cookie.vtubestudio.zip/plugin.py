import asyncio
import websockets
import json
import os
import sys
import traceback

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

def get_user_data_dir():
    if IS_WINDOWS:
        base = os.environ.get("APPDATA") or os.path.expanduser("~\\AppData\\Roaming")
        path = os.path.join(base, "CookieDeck", "com_cookie_vtubestudio")
    elif IS_MACOS:
        path = os.path.expanduser("~/Library/Application Support/CookieDeck/com_cookie_vtubestudio")
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
        path = os.path.join(base, "CookieDeck", "com_cookie_vtubestudio")
    os.makedirs(path, exist_ok=True)
    return path

class VTubeStudioPlugin:
    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.vtubestudio"
        self.cd_uri = "ws://localhost:8765"
        self.cd_ws = None

        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.user_data_dir = get_user_data_dir()
        self.config_file = os.path.join(self.user_data_dir, 'vts_config.json')

        self.vts_ws = None
        self.vts_connected = False
        self.last_context = None
        self.context_settings = {}
        self.opacity_state = {}

        self.icon_map = {
            "hotkey": "ACTION_HOTKEY",
            "item": "ACTION_ITEM",
            "color": "ACTION_COLOR",
            "model": "ACTION_MODEL",
            "move_absolute": "ACTION_MOVE_ABSOLUTE",
            "zoom_in": "ACTION_ZOOM_IN",
            "zoom_out": "ACTION_ZOOM_OUT",
            "rotate_cw": "ACTION_ROTATE_CW",
            "rotate_ccw": "ACTION_ROTATE_CCW",
            "opacity_cw": "ACTION_OPACITY_CW",
            "opacity_ccw": "ACTION_OPACITY_CCW",
            "move_up": "ACTION_MOVE_UP",
            "move_down": "ACTION_MOVE_DOWN",
            "move_left": "ACTION_MOVE_LEFT",
            "move_right": "ACTION_MOVE_RIGHT",
        }

        self.load_config()

    def _default_action(self):
        return "hotkey"

    def _default_settings(self):
        action = self._default_action()
        return {
            "action_type": action,
            "command": action,
            "hotkeyID": "",
            "itemName": "",
            "modelID": "",
            "colorHex": "#ffffff",
            "zoom_sense": "20",
            "abs_x": "0.0",
            "abs_y": "0.0",
            "abs_size": "0",
            "abs_rot": "0",
            "abs_time": "0.5",
            "move_sense": "30",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or merged.get("action_type") or self._default_action()
        merged["action_type"] = action
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("action_type"),
            s.get("hotkeyID"),
            s.get("itemName"),
            s.get("modelID"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        if not self.cd_ws or not context:
            return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.cd_ws.send(json.dumps({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            }))

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()
            if self.cd_ws:
                await self.cd_ws.send(json.dumps({
                    "event": "setSettings",
                    "context": context,
                    "payload": defaults
                }))
            await self._send_builtin_icon(context, defaults["action_type"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        await self._send_builtin_icon(context, merged["action_type"])
        return True

    def load_config(self):
        # Backward compatibility: migrate an old config that was saved inside the plugin folder.
        legacy_config_file = os.path.join(self.plugin_dir, 'vts_config.json')
        if not os.path.exists(self.config_file) and os.path.exists(legacy_config_file):
            try:
                with open(legacy_config_file, 'r', encoding='utf-8') as f:
                    legacy_config = json.load(f)
                with open(self.config_file, 'w', encoding='utf-8') as f:
                    json.dump(legacy_config, f, indent=4)
            except Exception:
                pass

        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
            except Exception:
                self.config = {"ip": "localhost", "port": 8001, "token": ""}
        else:
            self.config = {"ip": "localhost", "port": 8001, "token": ""}

    def save_config(self):
        os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, indent=4)

    async def vts_connect_loop(self):
        while True:
            vts_uri = f"ws://{self.config.get('ip', 'localhost')}:{self.config.get('port', 8001)}"
            try:
                async with websockets.connect(vts_uri) as ws:
                    self.vts_ws = ws
                    self.vts_connected = True
                    print("[VTS] Connected to VTube Studio!", flush=True)
                    await self.vts_authenticate()

                    async for message in ws:
                        await self.handle_vts_message(json.loads(message))
            except Exception:
                self.vts_connected = False
                self.vts_ws = None
            await asyncio.sleep(3)

    async def vts_authenticate(self):
        token = self.config.get("token", "")
        if not token:
            req = {
                "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "TokenReq",
                "messageType": "AuthenticationTokenRequest",
                "data": {"pluginName": "CookieDeck", "pluginDeveloper": "ElectroCookie"}
            }
        else:
            req = {
                "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "AuthReq",
                "messageType": "AuthenticationRequest",
                "data": {"pluginName": "CookieDeck", "pluginDeveloper": "ElectroCookie", "authenticationToken": token}
            }
        await self.vts_ws.send(json.dumps(req))

    async def handle_vts_message(self, data):
        msg_type = data.get("messageType")

        if msg_type == "AuthenticationTokenResponse":
            token = data.get("data", {}).get("authenticationToken")
            if token:
                self.config["token"] = token
                self.save_config()
                await self.vts_authenticate()

        elif msg_type == "APIError":
            print(f"[VTS Error] {data.get('data', {}).get('message')}", flush=True)

        elif msg_type in ["HotkeysInCurrentModelResponse", "ItemListResponse", "AvailableModelsResponse"]:
            cmd = "hotkeyList" if msg_type.startswith("Hotkey") else "itemList" if msg_type.startswith("Item") else "modelList"
            list_key = "availableHotkeys" if msg_type.startswith("Hotkey") else "availableItems" if msg_type.startswith("Item") else "availableModels"

            if self.cd_ws and self.last_context:
                await self.cd_ws.send(json.dumps({
                    "event": "sendToPropertyInspector",
                    "context": self.last_context,
                    "payload": {"command": cmd, "data": data.get("data", {}).get(list_key, [])}
                }))

    async def cookiedeck_connect_loop(self):
        while True:
            try:
                async with websockets.connect(self.cd_uri) as ws:
                    self.cd_ws = ws
                    await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                    print("[CookieDeck] Connected to main app!", flush=True)

                    async for message in ws:
                        await self.handle_cookiedeck_message(json.loads(message))
            except Exception:
                self.cd_ws = None
            await asyncio.sleep(2)

    async def handle_cookiedeck_message(self, data):
        try:
            event = data.get("event")
            context = data.get("context")
            payload = data.get("payload", {}) or {}

            if event == "keyDidAppear":
                raw_settings = payload.get("settings", {}) or {}
                if context:
                    await self._initialize_default_visuals_if_new(context, raw_settings)
                return

            if event == "didReceiveSettings":
                settings = payload.get("settings", payload) or {}
                if context:
                    cached = self.context_settings.get(context, {})
                    self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
                return

            if event in ["keyDidDisappear", "willDisappear"]:
                if context in self.context_settings:
                    self.context_settings.pop(context, None)
                return

            if event == "keyDown":
                incoming_settings = payload.get("settings", {}) or {}
                if context:
                    cached = self.context_settings.get(context, {})
                    self.context_settings[context] = self._merge_with_defaults({**cached, **incoming_settings})
                settings = self.context_settings.get(context, self._default_settings())
                action_type = settings.get("action_type", "hotkey")

                if not (self.vts_connected and self.vts_ws):
                    return

                req = None

                if action_type in ["zoom_in", "zoom_out"]:
                    sense = float(settings.get("zoom_sense", 20))
                    base_zoom = (sense / 100.0) * 0.15
                    zoom_amount = base_zoom if action_type == "zoom_in" else -base_zoom
                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecZoom",
                        "messageType": "MoveModelRequest",
                        "data": {"timeInSeconds": 0, "valuesAreRelativeToModel": True, "size": zoom_amount}
                    }

                elif action_type in ["rotate_cw", "rotate_ccw"]:
                    sense = float(settings.get("zoom_sense", 20))
                    base_rot = (sense / 100.0) * 15.0
                    rot_amount = base_rot if action_type == "rotate_cw" else -base_rot
                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecRotRel",
                        "messageType": "MoveModelRequest",
                        "data": {"timeInSeconds": 0, "valuesAreRelativeToModel": True, "rotation": rot_amount}
                    }

                elif action_type in ["opacity_cw", "opacity_ccw"]:
                    if context not in self.opacity_state:
                        self.opacity_state[context] = 255

                    sense = float(settings.get("zoom_sense", 20))
                    step = int((sense / 100.0) * 25)

                    if action_type == "opacity_cw":
                        self.opacity_state[context] = min(255, self.opacity_state[context] + step)
                    else:
                        self.opacity_state[context] = max(0, self.opacity_state[context] - step)

                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecOpacity",
                        "messageType": "ColorTintRequest",
                        "data": {
                            "colorTint": {
                                "colorR": 255, "colorG": 255, "colorB": 255,
                                "colorA": self.opacity_state[context]
                            },
                            "artMeshMatcher": {"tintAll": True}
                        }
                    }

                elif action_type == "move_absolute":
                    time_sec = float(settings.get("abs_time", 0.5))
                    pos_x = float(settings.get("abs_x", 0.0))
                    pos_y = float(settings.get("abs_y", 0.0))
                    size_val = float(settings.get("abs_size", 0.0))
                    rot_val = float(settings.get("abs_rot", 0.0))
                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecMoveAbs",
                        "messageType": "MoveModelRequest",
                        "data": {
                            "timeInSeconds": time_sec,
                            "valuesAreRelativeToModel": False,
                            "positionX": pos_x,
                            "positionY": pos_y,
                            "size": size_val,
                            "rotation": rot_val
                        }
                    }

                elif action_type in ["move_up", "move_down", "move_left", "move_right"]:
                    sense = float(settings.get("move_sense", 30))
                    base_move = (sense / 100.0) * 0.1
                    dx, dy = 0.0, 0.0
                    if action_type == "move_up": dy = base_move
                    elif action_type == "move_down": dy = -base_move
                    elif action_type == "move_right": dx = base_move
                    elif action_type == "move_left": dx = -base_move
                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecMoveRel",
                        "messageType": "MoveModelRequest",
                        "data": {"timeInSeconds": 0, "valuesAreRelativeToModel": True, "positionX": dx, "positionY": dy}
                    }

                elif action_type == "hotkey" and settings.get("hotkeyID"):
                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecHotkey",
                        "messageType": "HotkeyTriggerRequest",
                        "data": {"hotkeyID": settings.get("hotkeyID")}
                    }
                elif action_type == "item" and settings.get("itemName"):
                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecItem",
                        "messageType": "ItemLoadRequest",
                        "data": {"fileName": settings.get("itemName"), "positionX": 0, "positionY": 0, "size": 0.3}
                    }
                elif action_type == "color" and settings.get("colorHex"):
                    hex_color = settings.get("colorHex").lstrip('#')
                    if len(hex_color) == 6:
                        r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
                        req = {
                            "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecColor",
                            "messageType": "ColorTintRequest",
                            "data": {"colorTint": {"colorR": r, "colorG": g, "colorB": b, "colorA": 255}, "artMeshMatcher": {"tintAll": True}}
                        }
                elif action_type == "model" and settings.get("modelID"):
                    req = {
                        "apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": "ExecModel",
                        "messageType": "ModelLoadRequest",
                        "data": {"modelID": settings.get("modelID")}
                    }

                if req:
                    await self.vts_ws.send(json.dumps(req))
                return

            if event == "sendToPlugin":
                command = payload.get("command") or data.get("command")
                if command in ["getHotkeys", "getItems", "getModels"]:
                    self.last_context = context
                    if self.vts_connected and self.vts_ws:
                        req_type = "HotkeysInCurrentModelRequest" if command == "getHotkeys" else "ItemListRequest" if command == "getItems" else "AvailableModelsRequest"
                        req = {"apiName": "VTubeStudioPublicAPI", "apiVersion": "1.0", "requestID": command, "messageType": req_type}
                        await self.vts_ws.send(json.dumps(req))

                elif command == "setVtsSettings":
                    settings = payload.get("settings", {})
                    self.config["ip"] = settings.get("ip", "localhost")
                    self.config["port"] = int(settings.get("port", 8001))
                    self.save_config()
                    if self.vts_ws:
                        await self.vts_ws.close()

                elif command == "getVtsSettings":
                    if self.cd_ws and context:
                        await self.cd_ws.send(json.dumps({
                            "event": "sendToPropertyInspector",
                            "context": context,
                            "payload": {"command": "vtsSettings", "settings": self.config}
                        }))

                elif command == "apply_builtin_icon":
                    action_name = payload.get("action_command")
                    if not action_name and context:
                        action_name = self.context_settings.get(context, {}).get("action_type")
                    await self._send_builtin_icon(context, action_name or self._default_action())
                return

        except Exception:
            traceback.print_exc()

    async def run(self):
        asyncio.create_task(self.vts_connect_loop())
        await self.cookiedeck_connect_loop()

if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(VTubeStudioPlugin().run())
