/* Display names shared by Shortcuts itself and all application editors. */
(() => {
    function label(key, platform='windows', texts={}) {
        const num=texts.numpad || 'Numeric keypad';
        const names={ctrl:'Ctrl',control:'Ctrl',command:'Command',cmd:'Command',win:'Win',windows:'Win',
            alt:platform==='darwin'?'Option':'Alt',option:'Option',shift:'Shift',left:'←',right:'→',up:'↑',down:'↓',
            space:'Space',enter:'Enter',forwarddelete:'Delete',backspace:'Backspace',numenter:num+' Enter',
            numequal:num+' =',add:num+' +',subtract:num+' −',decimal:num+' .',multiply:num+' ×',divide:num+' ÷'};
        if(/^num[0-9]$/.test(key)) return num+' '+key.slice(3);
        if(/^(left|right) /.test(key)){const [side,...rest]=key.split(' ');return(texts[side] || (side==='left'?'Left':'Right'))+' '+label(rest.join(' '),platform,texts);}
        return names[key] || (key.length===1?key.toUpperCase():key);
    }
    window.ComboXShortcutKeys={label};
})();
