#target photoshop

var targetWidth = 800;
var targetHeight = 800;

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else {
    var doc = app.activeDocument;
    var width = doc.width.as("px");
    var height = doc.height.as("px");

    if (width < targetWidth || height < targetHeight) {
        alert("문서가 800 x 800px보다 작아 크롭할 수 없습니다.");
    } else {
        var centerX = width / 2;
        var centerY = height / 2;
        doc.crop([
            centerX - targetWidth / 2,
            centerY - targetHeight / 2,
            centerX + targetWidth / 2,
            centerY + targetHeight / 2
        ]);
    }
}
