import asyncio
import keyboard
import sys

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # [매핑 유지] 윈도우 창 관리 단축키
        self.hotkey_map = {
            "left": "win+left",
            "right": "win+right",
            "maximize": "win+up",
            "minimize": "win+down",
        }

    async def handle_message(self, data):
        event = data.get("event")
        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        # OS 체크: Windows가 아니면 무시
        if sys.platform != "win32":
            print(f"[{self.uuid}] Ignored: Window Mover works only on Windows.")
            return

        settings = data.get("payload", {}).get("settings", {})
        
        # 설정된 동작 가져오기 (기본값: left)
        selected_action = settings.get("win_action", "left")
        
        hotkey_to_send = self.hotkey_map.get(selected_action)
        
        if hotkey_to_send:
            # print(f"[{self.uuid}] Action: {selected_action} -> Sending: {hotkey_to_send}")
            # keyboard.send는 동기 함수이므로 공유 런타임 멈춤 방지를 위해 스레드로 실행
            await asyncio.to_thread(keyboard.send, hotkey_to_send)
        else:
            print(f"[{self.uuid}] Unknown action: {selected_action}")