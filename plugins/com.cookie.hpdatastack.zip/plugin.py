from __future__ import annotations

import asyncio
import base64
import ctypes
import html
import io
import json
import os
import shlex
import shutil
import subprocess
import sys
import webbrowser
from pathlib import Path
from typing import Any

import psutil
from PIL import Image, ImageDraw, ImageFont


PLUGIN_UUID = "com.cookie.hpdatastack"
APP_ACTION = f"{PLUGIN_UUID}.application"
TOOL_ACTION = f"{PLUGIN_UUID}.tool"
ENV_ACTION = f"{PLUGIN_UUID}.environment"
WSL_ACTION = f"{PLUGIN_UUID}.wsl"
WSL_QUICK_ACTION = f"{PLUGIN_UUID}.wslquick"
WSL_CUSTOM_ACTION = f"{PLUGIN_UUID}.wslcustom"
GPU_ACTION = f"{PLUGIN_UUID}.gpu"
REPORT_ACTION = f"{PLUGIN_UUID}.report"

STACK_EXE_CANDIDATES = (
    Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
    / "HP" / "Z By HP Data Science Stack Manager" / "Z by HP Data Science Stack Manager.exe",
)

WSL_PRESETS = {
    "system_info": "cat /etc/os-release && uname -a",
    "current_path": "pwd",
    "list_files": "ls -la",
    "ip_address": "hostname -I",
    "disk_usage": "df -h",
    "memory_usage": "free -h",
    "processes": "ps -eo pid,comm,%cpu,%mem --sort=-%mem | head -n 16",
    "python_version": "python3 --version || python --version",
    "git_status": "git status --short --branch",
    "docker_containers": "docker ps --format 'table {{.Names}}\\t{{.Status}}\\t{{.Ports}}'",
    "docker_images": "docker images --format 'table {{.Repository}}\\t{{.Tag}}\\t{{.Size}}'",
    "jupyter_servers": "jupyter server list",
    "gpu_status": "(command -v nvidia-smi >/dev/null && nvidia-smi) || (command -v rocm-smi >/dev/null && rocm-smi) || (command -v rocminfo >/dev/null && rocminfo | head -n 80) || (command -v lspci >/dev/null && lspci | grep -Ei 'vga|3d|display')",
    "uptime": "uptime",
}


class _GUID(ctypes.Structure):
    _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16), ("Data3", ctypes.c_uint16), ("Data4", ctypes.c_ubyte * 8)]


class _LUID(ctypes.Structure):
    _fields_ = [("LowPart", ctypes.c_uint32), ("HighPart", ctypes.c_int32)]


class _DXGI_ADAPTER_DESC1(ctypes.Structure):
    _fields_ = [
        ("Description", ctypes.c_wchar * 128), ("VendorId", ctypes.c_uint32),
        ("DeviceId", ctypes.c_uint32), ("SubSysId", ctypes.c_uint32),
        ("Revision", ctypes.c_uint32), ("DedicatedVideoMemory", ctypes.c_size_t),
        ("DedicatedSystemMemory", ctypes.c_size_t), ("SharedSystemMemory", ctypes.c_size_t),
        ("AdapterLuid", _LUID), ("Flags", ctypes.c_uint32),
    ]


_GPU_COUNTER_SCRIPT = r"""
$ErrorActionPreference='Stop'
Import-Module Microsoft.PowerShell.Diagnostics
$samples=(Get-Counter @('\GPU Engine(*)\Utilization Percentage','\GPU Adapter Memory(*)\Dedicated Usage','\GPU Adapter Memory(*)\Shared Usage')).CounterSamples
$engines=@{}; $memory=@{}
foreach($sample in $samples){
  $instance=$sample.InstanceName.ToLowerInvariant(); $path=$sample.Path.ToLowerInvariant()
  if($instance -notmatch '(luid_0x[0-9a-f]+_0x[0-9a-f]+)'){continue}; $luid=$Matches[1]
  if($path -like '*\gpu engine(*)\utilization percentage'){
    if(-not $engines.ContainsKey($luid)){$engines[$luid]=@{}}
    $engine=$instance -replace '^pid_\d+_',''
    if(-not $engines[$luid].ContainsKey($engine)){$engines[$luid][$engine]=0.0}
    $engines[$luid][$engine]+=[double]$sample.CookedValue
  } else {
    if(-not $memory.ContainsKey($luid)){$memory[$luid]=@{dedicated=0.0;shared=0.0}}
    if($path -like '*\dedicated usage'){$memory[$luid].dedicated=[double]$sample.CookedValue}
    elseif($path -like '*\shared usage'){$memory[$luid].shared=[double]$sample.CookedValue}
  }
}
$keys=@($engines.Keys)+@($memory.Keys)|Sort-Object -Unique
$result=@(foreach($luid in $keys){
  $usage=0.0
  if($engines.ContainsKey($luid) -and $engines[$luid].Count){$usage=[double](($engines[$luid].Values|Measure-Object -Maximum).Maximum)}
  $dedicated=0.0; $shared=0.0
  if($memory.ContainsKey($luid)){$dedicated=[double]$memory[$luid].dedicated;$shared=[double]$memory[$luid].shared}
  [pscustomobject]@{luid=$luid;usage=[math]::Min(100.0,$usage);dedicated=$dedicated;shared=$shared}
})
$result|ConvertTo-Json -Compress
"""


def _dxgi_adapters_sync() -> dict[str, dict[str, Any]]:
    if not sys.platform.startswith("win"):
        return {}
    dxgi = ctypes.WinDLL("dxgi")
    iid = _GUID(0x770AAE78, 0xF26F, 0x4DBA, (ctypes.c_ubyte * 8)(0xA8, 0x29, 0x25, 0x3C, 0x83, 0xD1, 0xB3, 0x87))
    factory = ctypes.c_void_p()
    create = dxgi.CreateDXGIFactory1
    create.argtypes = [ctypes.POINTER(_GUID), ctypes.POINTER(ctypes.c_void_p)]
    create.restype = ctypes.c_long
    if create(ctypes.byref(iid), ctypes.byref(factory)) < 0:
        return {}

    def method(pointer: ctypes.c_void_p, index: int, prototype):
        vtable = ctypes.cast(pointer, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
        return prototype(vtable[index])

    release_type = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)
    enum_type = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_void_p))
    desc_type = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.POINTER(_DXGI_ADAPTER_DESC1))
    adapters: dict[str, dict[str, Any]] = {}
    try:
        enum_adapters = method(factory, 12, enum_type)
        index = 0
        while True:
            adapter = ctypes.c_void_p()
            if enum_adapters(factory, index, ctypes.byref(adapter)) != 0:
                break
            try:
                desc = _DXGI_ADAPTER_DESC1()
                if method(adapter, 10, desc_type)(adapter, ctypes.byref(desc)) >= 0 and not (desc.Flags & 2):
                    luid = f"luid_0x{desc.AdapterLuid.HighPart & 0xffffffff:08x}_0x{desc.AdapterLuid.LowPart:08x}"
                    adapters[luid] = {"name": desc.Description.strip(), "dedicated_total": int(desc.DedicatedVideoMemory), "shared_total": int(desc.SharedSystemMemory)}
            finally:
                method(adapter, 2, release_type)(adapter)
            index += 1
    finally:
        method(factory, 2, release_type)(factory)
    return adapters


def _windows_gpu_status_sync() -> dict[str, Any]:
    try:
        adapters = _dxgi_adapters_sync()
    except (AttributeError, OSError, ValueError) as exc:
        return {"ok": False, "summary": "GPU query error", "details": str(exc)}
    powershell = shutil.which("powershell.exe")
    if not adapters or not powershell:
        return {"ok": False, "summary": "GPU unavailable", "details": "Windows GPU adapters or performance counters were not available."}
    flags = subprocess.CREATE_NO_WINDOW if sys.platform.startswith("win") else 0
    powershell_env = os.environ.copy()
    powershell_env["PSModulePath"] = str(Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "WindowsPowerShell" / "v1.0" / "Modules")
    try:
        completed = subprocess.run(
            [powershell, "-NoProfile", "-NonInteractive", "-Command", "[Console]::OutputEncoding=[Text.UTF8Encoding]::new();" + _GPU_COUNTER_SCRIPT],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=8, creationflags=flags, env=powershell_env, check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return {"ok": False, "summary": "GPU query error", "details": str(exc)}
    if completed.returncode != 0:
        details = (completed.stderr or completed.stdout).decode("utf-8", errors="replace").strip()
        return {"ok": False, "summary": "GPU query error", "details": details}
    raw = completed.stdout.decode("utf-8-sig", errors="replace").strip()
    try:
        values = json.loads(raw or "[]")
    except json.JSONDecodeError as exc:
        return {"ok": False, "summary": "GPU query error", "details": str(exc)}
    if isinstance(values, dict):
        values = [values]
    samples = {str(item.get("luid", "")).lower(): item for item in values if isinstance(item, dict)}

    def gib(value: Any) -> float:
        return float(value or 0) / (1024 ** 3)

    rows: list[str] = []
    peak = -1.0
    peak_name = "GPU"
    for luid, adapter in adapters.items():
        sample = samples.get(luid, {})
        usage = max(0.0, min(float(sample.get("usage", 0) or 0), 100.0))
        name = str(adapter.get("name") or "Windows GPU")
        if usage > peak:
            peak, peak_name = usage, name
        dedicated_total = int(adapter.get("dedicated_total") or 0)
        shared_total = int(adapter.get("shared_total") or 0)
        rows.append(
            f"{name}: {usage:.1f}%\n"
            f"  Dedicated {gib(sample.get('dedicated')):.2f}/{gib(dedicated_total):.2f} GB\n"
            f"  Shared {gib(sample.get('shared')):.2f}/{gib(shared_total):.2f} GB"
        )
    return {"ok": True, "summary": f"{max(peak, 0):.0f}% · {peak_name}", "details": "\n\n".join(rows)}


def user_data_dir(plugin_uuid: str) -> Path:
    root = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
    path = root / "CookieDeck" / plugin_uuid.replace(".", "_")
    path.mkdir(parents=True, exist_ok=True)
    return path


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.manifest = manifest
        self.plugin_uuid = str(manifest.get("UUID") or PLUGIN_UUID)
        self.plugin_dir = Path(__file__).resolve().parent
        self.locale_dir = self.plugin_dir / "locales"
        self.locale_cache: dict[str, dict[str, str]] = {}
        self.data_dir = user_data_dir(self.plugin_uuid)
        self.contexts: dict[str, dict[str, Any]] = {}
        self.tasks: dict[str, asyncio.Task] = {}
        self.command_tasks: dict[str, asyncio.Task] = {}
        self.command_processes: dict[str, asyncio.subprocess.Process] = {}
        self.command_pressed: set[str] = set()

    def _language(self, settings: dict[str, Any] | None) -> str:
        value = str((settings or {}).get("_lang") or "en").replace("_", "-").lower()
        value = "ko" if value == "kr" or value.startswith("ko") else value.split("-", 1)[0]
        return value if (self.locale_dir / f"{value}.json").is_file() else "en"

    def _locale(self, settings: dict[str, Any] | None) -> dict[str, str]:
        language = self._language(settings)
        if language in self.locale_cache:
            return self.locale_cache[language]

        def load(code: str) -> dict[str, str]:
            try:
                value = json.loads((self.locale_dir / f"{code}.json").read_text(encoding="utf-8"))
                return value if isinstance(value, dict) else {}
            except (OSError, json.JSONDecodeError):
                return {}

        english = self.locale_cache.get("en") or load("en")
        self.locale_cache["en"] = english
        translated = english if language == "en" else {**english, **load(language)}
        self.locale_cache[language] = translated
        return translated

    def _t(self, settings: dict[str, Any] | None, key: str, fallback: str = "", **values: Any) -> str:
        text = str(self._locale(settings).get(key) or fallback or key)
        try:
            return text.format(**values)
        except (KeyError, IndexError, ValueError):
            return text

    @staticmethod
    def _settings(data: dict[str, Any]) -> dict[str, Any]:
        payload = data.get("payload", {}) or {}
        if not isinstance(payload, dict):
            return {}
        nested = payload.get("settings")
        return dict(nested) if isinstance(nested, dict) else dict(payload)

    def _remember(self, data: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        context = str(data.get("context") or "")
        payload = data.get("payload", {}) or {}
        state = self.contexts.setdefault(context, {"action": "", "settings": {}, "page": None})
        action = str(data.get("action") or "").split("#", 1)[0]
        if action:
            state["action"] = action
        state["settings"].update(self._settings(data))
        if isinstance(payload, dict) and payload.get("page") is not None:
            try:
                state["page"] = int(payload["page"])
            except (TypeError, ValueError):
                pass
        return context, state

    def _action_defaults(self, action: str) -> dict[str, Any]:
        for item in self.manifest.get("Actions", []):
            if str(item.get("UUID") or "") == action:
                defaults = item.get("DefaultSettings")
                return dict(defaults) if isinstance(defaults, dict) else {}
        return {}

    async def _ensure_action_settings(self, context: str, state: dict[str, Any]) -> None:
        defaults = self._action_defaults(str(state.get("action") or ""))
        if not defaults:
            return
        current = state.get("settings", {})
        merged = {**defaults, **current}
        # feature identifies the manifest Action and is not a user-selectable setting.
        merged["feature"] = defaults.get("feature")
        if merged == current:
            return
        state["settings"] = merged
        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": merged,
        })

    async def _title(self, context: str, value: str) -> None:
        state = self.contexts.get(context, {})
        await self.runner.send_message({
            "event": "setTitle",
            "context": context,
            "payload": {"title": value, "page": state.get("page")},
        })

    async def _pi(self, context: str, payload: dict[str, Any]) -> None:
        await self.runner.send_message({
            "event": "sendToPropertyInspector",
            "context": context,
            "payload": payload,
        })

    @staticmethod
    def _heading(state: dict[str, Any], fallback: str) -> str:
        return str(state.get("settings", {}).get("title") or fallback).strip() or fallback

    @staticmethod
    def _first_existing(candidates: tuple[Path, ...]) -> Path | None:
        return next((path for path in candidates if path.is_file()), None)

    @staticmethod
    def _is_running(names: set[str]) -> bool:
        lowered = {name.lower() for name in names}
        for process in psutil.process_iter(["name"]):
            try:
                if str(process.info.get("name") or "").lower() in lowered:
                    return True
            except (psutil.Error, OSError):
                continue
        return False

    @staticmethod
    def _focus_process_sync(names: set[str]) -> bool:
        try:
            import win32con
            import win32gui
            import win32process
        except ImportError:
            return False
        lowered = {name.lower() for name in names}
        pids: set[int] = set()
        for process in psutil.process_iter(["pid", "name"]):
            try:
                if str(process.info.get("name") or "").lower() in lowered:
                    pids.add(int(process.info["pid"]))
            except (psutil.Error, OSError, TypeError, ValueError):
                continue
        windows: list[int] = []

        def collect(hwnd: int, _extra: object) -> None:
            if not win32gui.IsWindowVisible(hwnd):
                return
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            if pid in pids:
                windows.append(hwnd)

        win32gui.EnumWindows(collect, None)
        for hwnd in windows:
            try:
                win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                win32gui.SetForegroundWindow(hwnd)
                return True
            except Exception:
                continue
        return False

    @staticmethod
    def _launch_process(args: list[str]) -> None:
        subprocess.Popen(args, close_fds=True)

    @staticmethod
    def _launch_elevated_sync(path: Path) -> None:
        # Stack Manager declares an elevated Windows launch. Direct Popen from
        # the non-elevated COMBO-X Runner fails with WinError 740, so use the
        # same ShellExecute elevation flow as its Start menu shortcut.
        shell_execute = ctypes.windll.shell32.ShellExecuteW
        shell_execute.restype = ctypes.c_void_p
        result = shell_execute(
            None,
            "runas",
            str(path),
            None,
            str(path.parent),
            1,
        )
        code = int(result or 0)
        if code <= 32:
            raise OSError(code, f"ShellExecuteW failed with code {code}")

    async def _open_stack_manager(self, context: str) -> None:
        state = self.contexts.get(context, {})
        settings = state.get("settings", {})
        path = self._first_existing(STACK_EXE_CANDIDATES)
        if path is None:
            await self._title(context, self._t(settings, "STATUS_NOT_INSTALLED", "Not installed"))
            return
        focused = await asyncio.to_thread(
            self._focus_process_sync,
            {"z by hp data science stack manager.exe"},
        )
        if not focused:
            await self._title(context, self._t(settings, "STATUS_LAUNCHING", "Opening…"))
            try:
                await asyncio.to_thread(self._launch_elevated_sync, path)
            except OSError as exc:
                await self._title(context, self._t(settings, "STATUS_LAUNCH_ERROR", "Launch error"))
                await self._pi(context, {"command": "status_error", "ok": False, "message": str(exc)})
                return
        await self._title(context, self._t(settings, "STATUS_OPENED", "Opened"))

    @staticmethod
    def _vscode_path() -> str | None:
        candidates = (
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Microsoft VS Code" / "Code.exe",
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Microsoft VS Code" / "Code.exe",
        )
        found = next((str(path) for path in candidates if path.is_file()), None)
        return found or shutil.which("code")

    async def _open_tool(self, context: str) -> None:
        state = self.contexts.get(context, {})
        settings = state.get("settings", {})
        tool = str(settings.get("tool") or "vscode")
        args: list[str] | None = None
        if tool == "stack_manager":
            await self._open_stack_manager(context)
            return
        if tool == "vscode":
            executable = self._vscode_path()
            args = [executable] if executable else None
        elif tool == "terminal":
            executable = shutil.which("wt.exe") or shutil.which("powershell.exe")
            args = [executable] if executable else None
        elif tool == "powershell":
            executable = shutil.which("powershell.exe")
            args = [executable, "-NoExit"] if executable else None
        elif tool == "wsl":
            executable = shutil.which("wsl.exe")
            args = [executable] if executable else None
        if not args or not args[0]:
            await self._title(context, self._t(settings, "STATUS_TOOL_MISSING", "Tool missing"))
            return
        await asyncio.to_thread(self._launch_process, args)
        await self._title(context, self._t(settings, "STATUS_OPENED", "Opened"))

    @staticmethod
    def _run_command(args: list[str], timeout: float = 8.0) -> tuple[int, str]:
        flags = subprocess.CREATE_NO_WINDOW if sys.platform.startswith("win") else 0
        completed = subprocess.run(
            args,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            creationflags=flags,
            check=False,
        )
        output = (completed.stdout or completed.stderr or "").strip()
        return completed.returncode, output

    @staticmethod
    def _decode_windows_output(raw: bytes) -> str:
        if not raw:
            return ""
        if raw.startswith((b"\xff\xfe", b"\xfe\xff")) or b"\x00" in raw[:80]:
            encoding = "utf-16" if raw.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-16-le"
            return raw.decode(encoding, errors="replace").replace("\x00", "").strip()
        for encoding in ("utf-8", "cp949", "mbcs"):
            try:
                return raw.decode(encoding).strip()
            except (LookupError, UnicodeDecodeError):
                continue
        return raw.decode("utf-8", errors="replace").strip()

    @classmethod
    def _run_decoded_command(cls, args: list[str], timeout: float = 8.0) -> tuple[int, str]:
        flags = subprocess.CREATE_NO_WINDOW if sys.platform.startswith("win") else 0
        completed = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            creationflags=flags,
            check=False,
        )
        return completed.returncode, cls._decode_windows_output(completed.stdout or completed.stderr)

    @classmethod
    def _wsl_distributions_sync(cls) -> list[str]:
        executable = shutil.which("wsl.exe")
        if not executable:
            return []
        flags = subprocess.CREATE_NO_WINDOW if sys.platform.startswith("win") else 0
        completed = subprocess.run(
            [executable, "--list", "--quiet"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=8,
            creationflags=flags,
            check=False,
        )
        output = cls._decode_windows_output(completed.stdout or completed.stderr)
        return [line.strip().lstrip("* ").strip() for line in output.splitlines() if line.strip().lstrip("* ").strip()]

    @staticmethod
    def _copy_text_sync(value: str) -> None:
        # Use the Win32 Unicode clipboard API so the plugin has no optional
        # clipboard package dependency in the embedded Python runtime.
        kernel32 = ctypes.windll.kernel32
        user32 = ctypes.windll.user32
        kernel32.GlobalAlloc.restype = ctypes.c_void_p
        kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
        kernel32.GlobalLock.restype = ctypes.c_void_p
        kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
        kernel32.GlobalFree.argtypes = [ctypes.c_void_p]
        user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
        user32.SetClipboardData.restype = ctypes.c_void_p
        global_moveable = 0x0002
        unicode_text = 13
        data = (value + "\0").encode("utf-16-le")
        if not user32.OpenClipboard(None):
            raise OSError("Could not open the Windows clipboard")
        handle = None
        try:
            user32.EmptyClipboard()
            handle = kernel32.GlobalAlloc(global_moveable, len(data))
            if not handle:
                raise MemoryError("Could not allocate clipboard memory")
            pointer = kernel32.GlobalLock(handle)
            if not pointer:
                raise OSError("Could not lock clipboard memory")
            ctypes.memmove(pointer, data, len(data))
            kernel32.GlobalUnlock(handle)
            if not user32.SetClipboardData(unicode_text, handle):
                raise OSError("Could not set clipboard data")
            handle = None  # Ownership transfers to the clipboard.
        finally:
            if handle:
                kernel32.GlobalFree(handle)
            user32.CloseClipboard()

    async def _send_wsl_distributions(self, context: str) -> None:
        state = self.contexts.get(context, {})
        settings = state.get("settings", {})
        try:
            distributions = await asyncio.to_thread(self._wsl_distributions_sync)
            await self._pi(context, {
                "command": "wsl_distributions",
                "ok": True,
                "distributions": distributions,
                "summary": self._t(settings, "STATUS_DISTRIBUTIONS_FOUND", "{count} distributions", count=len(distributions)),
            })
        except (OSError, subprocess.SubprocessError) as exc:
            await self._pi(context, {"command": "wsl_distributions", "ok": False, "distributions": [], "message": str(exc)})

    @staticmethod
    def _bounded_timeout(value: Any, fallback: int) -> int:
        try:
            return max(1, min(int(value), 600))
        except (TypeError, ValueError):
            return fallback

    async def _run_wsl_command(self, context: str, state: dict[str, Any]) -> None:
        settings = state.get("settings", {})
        action = state.get("action")
        quick = action == WSL_QUICK_ACTION
        prefix = "quick" if quick else "custom"
        distribution = str(settings.get(f"{prefix}_distribution") or "").strip()
        workdir = str(settings.get(f"{prefix}_workdir") or "~").strip()
        output_target = str(settings.get(f"{prefix}_output") or "inspector")
        timeout = self._bounded_timeout(settings.get(f"{prefix}_timeout"), 15 if quick else 60)
        preset = str(settings.get("wsl_preset") or "system_info")
        command = WSL_PRESETS.get(preset, "") if quick else str(settings.get("wsl_custom_command") or "").strip()
        heading = self._heading(state, self._t(settings, "ACTION_WSL_QUICK" if quick else "ACTION_WSL_CUSTOM", "WSL Command"))
        executable = shutil.which("wsl.exe")
        if not executable:
            await self._title(context, f"{heading}\n{self._t(settings, 'STATUS_WSL_MISSING', 'WSL missing')}")
            return
        if quick and preset == "open_terminal":
            args = [executable] + (["-d", distribution] if distribution else []) + (["--cd", workdir] if workdir else [])
            await asyncio.to_thread(self._launch_process, args)
            await self._title(context, f"{heading}\n{self._t(settings, 'STATUS_STARTED', 'Started')}")
            return
        if not command:
            message = self._t(settings, "STATUS_COMMAND_EMPTY", "Enter a command")
            await self._title(context, f"{heading}\n{message}")
            await self._pi(context, {"command": "wsl_command_result", "ok": False, "summary": message, "details": ""})
            return

        args = [executable] + (["-d", distribution] if distribution else []) + (["--cd", workdir] if workdir else [])
        # Linux coreutils timeout terminates the command inside WSL as well as
        # the Windows client process. The command is quoted as one bash value.
        wrapped = f"timeout --signal=TERM {timeout}s bash -lc {shlex.quote(command)}"
        args += ["--", "bash", "-lc", wrapped]
        await self._title(context, f"{heading}\n{self._t(settings, 'STATUS_RUNNING_COMMAND', 'Running…')}")
        flags = subprocess.CREATE_NO_WINDOW if sys.platform.startswith("win") else 0
        try:
            process = await asyncio.create_subprocess_exec(
                *args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                creationflags=flags,
            )
            self.command_processes[context] = process
            try:
                raw, _ = await asyncio.wait_for(process.communicate(), timeout=timeout + 5)
            except asyncio.TimeoutError:
                process.kill()
                raw, _ = await process.communicate()
                details = self._decode_windows_output(raw)
                summary = self._t(settings, "STATUS_COMMAND_TIMEOUT", "Timed out")
                await self._title(context, f"{heading}\n{summary}")
                await self._pi(context, {"command": "wsl_command_result", "ok": False, "summary": summary, "details": details[:20000]})
                return
            details = self._decode_windows_output(raw)
            ok = process.returncode == 0
            first_line = next((line.strip() for line in details.splitlines() if line.strip()), "")
            summary = first_line[:80] or self._t(settings, "STATUS_COMMAND_DONE" if ok else "STATUS_COMMAND_FAILED", "Done" if ok else "Failed")
            if output_target == "clipboard":
                await asyncio.to_thread(self._copy_text_sync, details)
                summary = self._t(settings, "STATUS_COPIED", "Copied to clipboard")
            elif output_target == "file":
                result_path = self.data_dir / "latest_wsl_result.txt"
                await asyncio.to_thread(result_path.write_text, details, encoding="utf-8")
                summary = self._t(settings, "STATUS_SAVED", "Saved")
                details = f"{result_path}\n\n{details}"
            await self._title(context, f"{heading}\n{summary[:28]}")
            await self._pi(context, {"command": "wsl_command_result", "ok": ok, "summary": summary, "details": details[:20000]})
        except (OSError, subprocess.SubprocessError) as exc:
            summary = self._t(settings, "STATUS_COMMAND_ERROR", "Command error")
            await self._title(context, f"{heading}\n{summary}")
            await self._pi(context, {"command": "wsl_command_result", "ok": False, "summary": summary, "details": str(exc)})
        finally:
            self.command_processes.pop(context, None)

    async def _execute_wsl_command(self, context: str, state: dict[str, Any]) -> None:
        existing = self.command_tasks.get(context)
        if existing and not existing.done():
            await self._pi(context, {"command": "wsl_command_result", "ok": False, "summary": self._t(state.get("settings", {}), "STATUS_COMMAND_BUSY", "Command already running")})
            return
        task = asyncio.create_task(self._run_wsl_command(context, state))
        self.command_tasks[context] = task
        try:
            await task
        finally:
            if self.command_tasks.get(context) is task:
                self.command_tasks.pop(context, None)

    def _component_status_sync(self, component: str) -> dict[str, Any]:
        if component == "overview":
            path = self._first_existing(STACK_EXE_CANDIDATES)
            return {
                "ok": path is not None,
                "summary": "Running" if self._is_running({"z by hp data science stack manager.exe"}) else ("Installed" if path else "Not installed"),
                "details": str(path or ""),
            }
        commands = {
            "python": ([shutil.which("python.exe") or sys.executable, "--version"], "Python"),
            "git": ([shutil.which("git.exe") or "git.exe", "--version"], "Git"),
            "wsl": ([shutil.which("wsl.exe") or "wsl.exe", "--status"], "WSL"),
            "docker": ([shutil.which("docker.exe") or "docker.exe", "version", "--format", "{{.Server.Version}}"], "Docker"),
            "conda": ([shutil.which("conda.exe") or "conda.exe", "--version"], "Conda"),
            "jupyter": ([shutil.which("jupyter.exe") or "jupyter.exe", "--version"], "Jupyter"),
        }
        args, label = commands.get(component, commands["python"])
        if shutil.which(args[0]) is None and not Path(args[0]).is_file():
            return {"ok": False, "summary": f"{label}: missing", "details": ""}
        try:
            code, output = self._run_decoded_command(args) if component == "wsl" else self._run_command(args)
        except (OSError, subprocess.SubprocessError) as exc:
            return {"ok": False, "summary": f"{label}: error", "details": str(exc)}
        first_line = next((line.strip() for line in output.splitlines() if line.strip()), "OK" if code == 0 else "Error")
        return {"ok": code == 0, "summary": first_line[:80], "details": output[:4000]}

    async def _refresh_environment(self, context: str) -> None:
        state = self.contexts.get(context)
        if not state:
            return
        settings = state.get("settings", {})
        component = str(settings.get("component") or "overview")
        result = await asyncio.to_thread(self._component_status_sync, component)
        if component == "overview":
            installed = self._first_existing(STACK_EXE_CANDIDATES) is not None
            running = await asyncio.to_thread(
                self._is_running,
                {"z by hp data science stack manager.exe"},
            )
            status_key = "STATUS_RUNNING" if running else "STATUS_INSTALLED" if installed else "STATUS_NOT_INSTALLED"
            fallback = "Running" if running else "Installed" if installed else "Not installed"
            result["summary"] = self._t(settings, status_key, fallback)
        heading = self._heading(state, self._t(settings, "ACTION_ENVIRONMENT", "Environment"))
        await self._title(context, f"{heading}\n{result['summary'][:28]}")
        await self._pi(context, {"command": "status_result", **result})

    async def _run_wsl(self, context: str) -> None:
        state = self.contexts.get(context, {})
        settings = state.get("settings", {})
        operation = str(settings.get("wsl_operation") or "status")
        distribution = str(settings.get("distribution") or "").strip()
        executable = shutil.which("wsl.exe")
        if not executable:
            await self._title(context, self._t(settings, "STATUS_WSL_MISSING", "WSL missing"))
            return
        if operation == "launch":
            args = [executable] + (["-d", distribution] if distribution else [])
            await asyncio.to_thread(self._launch_process, args)
            summary = self._t(settings, "STATUS_STARTED", "Started")
            details = ""
            ok = True
        else:
            args = [executable, "--shutdown"] if operation == "shutdown" else [executable, "--list", "--verbose"] if operation == "list" else [executable, "--status"]
            try:
                code, details = await asyncio.to_thread(self._run_decoded_command, args, 15.0)
                ok = code == 0
                summary = next((line.strip() for line in details.splitlines() if line.strip()), "OK" if ok else "Error")
            except (OSError, subprocess.SubprocessError) as exc:
                ok, summary, details = False, self._t(settings, "STATUS_COMMAND_ERROR", "Command error"), str(exc)
        heading = self._heading(state, "WSL")
        await self._title(context, f"{heading}\n{summary[:28]}")
        await self._pi(context, {"command": "status_result", "ok": ok, "summary": summary, "details": details})

    @staticmethod
    def _gpu_status_sync() -> dict[str, Any]:
        windows_result = _windows_gpu_status_sync()
        executable = shutil.which("nvidia-smi.exe")
        if not executable:
            system_candidate = Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "nvidia-smi.exe"
            executable = str(system_candidate) if system_candidate.is_file() else None
        if not executable:
            return windows_result
        args = [
            executable,
            "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu",
            "--format=csv,noheader,nounits",
        ]
        try:
            code, output = Plugin._run_command(args)
        except (OSError, subprocess.SubprocessError) as exc:
            if windows_result.get("ok"):
                windows_result["details"] = f"{windows_result.get('details', '')}\n\nNVIDIA sensor query: {exc}"
                return windows_result
            return {"ok": False, "summary": "GPU query error", "details": str(exc)}
        line = next((item.strip() for item in output.splitlines() if item.strip()), "")
        parts = [part.strip() for part in line.split(",")]
        if windows_result.get("ok"):
            if code == 0 and len(parts) >= 5:
                windows_result["details"] = (
                    f"{windows_result.get('details', '')}\n\n"
                    f"NVIDIA sensors: {parts[1]}% · {parts[2]}/{parts[3]} MB · {parts[4]}°C"
                )
            return windows_result
        summary = f"{parts[1]}% · {parts[2]}/{parts[3]} MB · {parts[4]}°C" if code == 0 and len(parts) >= 5 else "GPU query error"
        return {"ok": code == 0, "summary": summary, "details": output[:4000]}

    @staticmethod
    def _status_image(ok: bool, label: str) -> str:
        image = Image.new("RGB", (144, 144), "#111820")
        draw = ImageDraw.Draw(image)
        color = "#35d07f" if ok else "#ffb24a"
        draw.rounded_rectangle((8, 8, 136, 136), radius=18, outline=color, width=5)
        draw.ellipse((56, 28, 88, 60), fill=color)
        font = ImageFont.load_default()
        words = label.replace(" · ", "\n").splitlines()[:3]
        draw.multiline_text((14, 78), "\n".join(item[:20] for item in words), fill="white", font=font, spacing=3, align="center")
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        return "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode("ascii")

    async def _refresh_gpu(self, context: str) -> None:
        state = self.contexts.get(context)
        if not state:
            return
        settings = state.get("settings", {})
        result = await asyncio.to_thread(self._gpu_status_sync)
        heading = self._heading(state, "GPU")
        await self._title(context, f"{heading}\n{result['summary'][:28]}")
        image = await asyncio.to_thread(self._status_image, bool(result["ok"]), str(result["summary"]))
        await self.runner.send_message({
            "event": "setImage",
            "context": context,
            "payload": {"image": image, "page": state.get("page")},
        })
        await self._pi(context, {"command": "status_result", **result})

    async def _refresh_loop(self, context: str) -> None:
        try:
            while context in self.contexts:
                state = self.contexts.get(context, {})
                if state.get("action") == GPU_ACTION:
                    await self._refresh_gpu(context)
                elif state.get("action") == ENV_ACTION:
                    await self._refresh_environment(context)
                settings = state.get("settings", {})
                try:
                    interval = max(3.0, min(float(settings.get("refresh_interval", 15)), 300.0))
                except (TypeError, ValueError):
                    interval = 15.0
                await asyncio.sleep(interval)
        except asyncio.CancelledError:
            pass

    def _start_loop(self, context: str) -> None:
        existing = self.tasks.get(context)
        if existing and not existing.done():
            return
        self.tasks[context] = asyncio.create_task(self._refresh_loop(context))

    def _stop_context(self, context: str) -> None:
        task = self.tasks.pop(context, None)
        if task and not task.done():
            task.cancel()
        command_task = self.command_tasks.pop(context, None)
        if command_task and not command_task.done():
            command_task.cancel()
        process = self.command_processes.pop(context, None)
        if process and process.returncode is None:
            process.kill()
        self.command_pressed.discard(context)
        self.contexts.pop(context, None)

    def _report_sync(self, settings: dict[str, Any]) -> Path:
        components = ["overview", "python", "git", "wsl", "docker", "conda", "jupyter"]
        report = {name: self._component_status_sync(name) for name in components}
        report["gpu"] = self._gpu_status_sync()
        path = self.data_dir / "hp_data_science_environment_report.html"
        rows = "".join(
            f"<tr><th>{html.escape(name)}</th><td>{'OK' if item['ok'] else 'CHECK'}</td>"
            f"<td><pre>{html.escape(str(item['summary']))}\n{html.escape(str(item['details']))}</pre></td></tr>"
            for name, item in report.items()
        )
        title = html.escape(self._t(settings, "REPORT_TITLE", "HP Data Science Environment Report"))
        path.write_text(
            "<!doctype html><meta charset='utf-8'>"
            f"<title>{title}</title><style>body{{font:14px system-ui;margin:32px;background:#101720;color:#eee}}"
            "table{border-collapse:collapse;width:100%}th,td{padding:10px;border:1px solid #344;text-align:left;vertical-align:top}"
            "pre{white-space:pre-wrap;margin:0}</style>"
            f"<h1>{title}</h1><table>{rows}</table>",
            encoding="utf-8",
        )
        if settings.get("open_report", True):
            webbrowser.open(path.as_uri())
        return path

    async def _generate_report(self, context: str) -> None:
        state = self.contexts.get(context, {})
        settings = state.get("settings", {})
        await self._title(context, self._t(settings, "STATUS_WORKING", "Working…"))
        try:
            path = await asyncio.to_thread(self._report_sync, settings)
            await self._title(context, self._t(settings, "STATUS_REPORT_READY", "Report ready"))
            await self._pi(context, {"command": "report_ready", "path": str(path)})
        except Exception as exc:
            await self._title(context, self._t(settings, "STATUS_REPORT_ERROR", "Report error"))
            await self._pi(context, {"command": "status_error", "message": str(exc)})

    async def _initial(self, context: str, state: dict[str, Any]) -> None:
        action = state.get("action")
        if action in {ENV_ACTION, GPU_ACTION}:
            self._start_loop(context)
            return
        fallback = {
            APP_ACTION: "Stack Manager",
            TOOL_ACTION: "Dev Tool",
            WSL_ACTION: "WSL",
            WSL_QUICK_ACTION: "WSL Quick",
            WSL_CUSTOM_ACTION: "WSL Custom",
            REPORT_ACTION: "Env Report",
        }.get(action, "HP Stack")
        await self._title(context, self._heading(state, fallback))

    async def _press(self, context: str, state: dict[str, Any]) -> None:
        action = state.get("action")
        if action == APP_ACTION:
            await self._open_stack_manager(context)
        elif action == TOOL_ACTION:
            await self._open_tool(context)
        elif action == ENV_ACTION:
            await self._refresh_environment(context)
        elif action == WSL_ACTION:
            await self._run_wsl(context)
        elif action in {WSL_QUICK_ACTION, WSL_CUSTOM_ACTION}:
            await self._execute_wsl_command(context, state)
        elif action == GPU_ACTION:
            await self._refresh_gpu(context)
        elif action == REPORT_ACTION:
            await self._generate_report(context)

    async def handle_message(self, data):
        event = data.get("event")
        context = str(data.get("context") or "")
        if not context:
            return
        if event in ("keyDidAppear", "willAppear"):
            context, state = self._remember(data)
            await self._ensure_action_settings(context, state)
            await self._initial(context, state)
            return
        if event == "didReceiveSettings":
            context, state = self._remember(data)
            await self._ensure_action_settings(context, state)
            await self._initial(context, state)
            return
        if event == "keyDown":
            context, state = self._remember(data)
            if state.get("action") in {WSL_QUICK_ACTION, WSL_CUSTOM_ACTION}:
                if context in self.command_pressed:
                    return
                self.command_pressed.add(context)
            await self._press(context, state)
            return
        if event == "keyUp":
            self.command_pressed.discard(context)
            return
        if event == "sendToPlugin":
            context, state = self._remember(data)
            command = str((data.get("payload", {}) or {}).get("command") or "")
            if command == "refresh":
                await self._press(context, state)
            elif command == "generate_report":
                await self._generate_report(context)
            elif command == "get_wsl_distributions":
                await self._send_wsl_distributions(context)
            elif command == "run_wsl_command":
                await self._execute_wsl_command(context, state)
            return
        if event in ("keyDidDisappear", "willDisappear"):
            self._stop_context(context)

    async def shutdown(self):
        tasks = list(self.tasks.values()) + list(self.command_tasks.values())
        self.tasks.clear()
        self.command_tasks.clear()
        for process in self.command_processes.values():
            if process.returncode is None:
                process.kill()
        self.command_processes.clear()
        for task in tasks:
            if not task.done():
                task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        self.contexts.clear()
        self.command_pressed.clear()
        self.locale_cache.clear()
