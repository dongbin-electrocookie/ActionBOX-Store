import asyncio
import os

try:
    import keyboard
except ImportError:
    keyboard = None

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))

        self.hotkey_map = {
            "play_stop": "space",
            "record": "f12",
            "return_zero": "enter",
            "loop_toggle": "4",
            "click_toggle": "7",
            "tool_zoom": "f5",
            "tool_trim": "f6",
            "tool_select": "f7",
            "tool_grabber": "f8",
            "tool_scrub": "f9",
            "tool_pencil": "f10",
            "tool_smart": "f6+f7+f8",
            "separate": "b",
            "heal": "ctrl+h",
            "fade_in": "d",
            "fade_out": "g",
            "crossfade": "f",
            "undo": "z",
            "redo": "shift+z",
            "copy": "c",
            "paste": "v",
            "cut": "x",
            "toggle_mix_edit": "ctrl+=",
            "zoom_in": "t",
            "zoom_out": "r",
            "zoom_vertical_in": "alt+shift+]",
            "zoom_vertical_out": "alt+shift+[",
            "fit_to_window": "alt+a",
            "new_track": "ctrl+shift+n",
            "group_tracks": "ctrl+g",
            # "solo_clear" intentionally left unmapped to preserve original behavior
        }

        self.icon_map = {
            "play_stop": "STATE_PLAY_STOP",
            "record": "STATE_RECORD",
            "return_zero": "STATE_RETURN_ZERO",
            "loop_toggle": "STATE_LOOP_TOGGLE",
            "click_toggle": "STATE_CLICK_TOGGLE",
            "tool_smart": "STATE_TOOL_SMART",
            "tool_zoom": "STATE_TOOL_ZOOM",
            "tool_trim": "STATE_TOOL_TRIM",
            "tool_select": "STATE_TOOL_SELECT",
            "tool_grabber": "STATE_TOOL_GRABBER",
            "tool_scrub": "STATE_TOOL_SCRUB",
            "tool_pencil": "STATE_TOOL_PENCIL",
            "separate": "STATE_SEPARATE",
            "heal": "STATE_HEAL",
            "fade_in": "STATE_FADE_IN",
            "fade_out": "STATE_FADE_OUT",
            "crossfade": "STATE_CROSSFADE",
            "undo": "STATE_UNDO",
            "redo": "STATE_REDO",
            "copy": "STATE_COPY",
            "paste": "STATE_PASTE",
            "cut": "STATE_CUT",
            "toggle_mix_edit": "STATE_TOGGLE_MIX_EDIT",
            "zoom_in": "STATE_ZOOM_IN",
            "zoom_out": "STATE_ZOOM_OUT",
            "zoom_vertical_in": "STATE_ZOOM_VERTICAL_IN",
            "zoom_vertical_out": "STATE_ZOOM_VERTICAL_OUT",
            "fit_to_window": "STATE_FIT_TO_WINDOW",
            "new_track": "STATE_NEW_TRACK",
            "group_tracks": "STATE_GROUP_TRACKS",
            "solo_clear": "STATE_SOLO_CLEAR",
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "play_stop", "STATE_PLAY_STOP")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "pt_hotkey", "command", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title"
        ])
        if meaningful:
            return

        default_action = "play_stop"
        new_settings = {
            "pt_hotkey": default_action,
            "command": default_action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        # Initial placement: icon only, never overwrite title
        await self._send_builtin_icon(context, default_action)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if control_command == "apply_builtin_icon":
            await self._send_builtin_icon(context, action_command or settings.get("pt_hotkey") or settings.get("command") or "play_stop")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard:
            return

        settings = data.get("payload", {}).get("settings", {})
        action = settings.get("pt_hotkey") or settings.get("command")

        if action and action in self.hotkey_map:
            hotkey = self.hotkey_map[action]

            if action == "tool_smart":
                await asyncio.to_thread(self._send_smart_tool)
            else:
                await asyncio.to_thread(keyboard.send, hotkey)

            print(f"[{self.uuid}] Pro Tools Hotkey Sent: {hotkey}")

    def _send_smart_tool(self):
        keyboard.press('f6')
        keyboard.press('f7')
        keyboard.press('f8')
        keyboard.release('f8')
        keyboard.release('f7')
        keyboard.release('f6')
