import asyncio
import os
import platform

IS_WINDOWS = (platform.system() == "Windows")
win32_available = False

if IS_WINDOWS:
    try:
        import win32com.client
        win32_available = True
    except ImportError:
        print("[Excel Plugin Error] 'pywin32' library is missing.")

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.excel = None
        self.win32 = win32com.client if win32_available else None
        self.context_settings = {}

        self.action_map = {
            "togglebold": self.apply_bold,
            "applyborder": self.apply_border,
            "formatheader": self.format_as_header,
            "formatnumber": self.format_as_number,
            "pastevalues": self.paste_as_values,
            "autofitcolumns": self.autofit_columns,
            "togglefilter": self.toggle_filter,
            "freezepanes": self.freeze_panes,
            "unfreezepanes": self.unfreeze_panes,
            "addsheet": self.add_new_sheet,
            "saveaspdf": self.save_sheet_as_pdf,
            "reportformat": self.apply_report_format,
        }

        self.icon_map = {
            "togglebold": "STATE_TOGGLEBOLD",
            "applyborder": "STATE_APPLYBORDER",
            "formatheader": "STATE_FORMATHEADER",
            "formatnumber": "STATE_FORMATNUMBER",
            "autofitcolumns": "STATE_AUTOFITCOLUMNS",
            "pastevalues": "STATE_PASTEVALUES",
            "togglefilter": "STATE_TOGGLEFILTER",
            "freezepanes": "STATE_FREEZEPANES",
            "unfreezepanes": "STATE_UNFREEZEPANES",
            "addsheet": "STATE_ADDSHEET",
            "saveaspdf": "STATE_SAVEASPDF",
            "reportformat": "STATE_REPORTFORMAT",
        }

    def _default_action(self):
        return "togglebold"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "excel_action": action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or merged.get("excel_action") or self._default_action()
        merged["command"] = action
        merged["excel_action"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("excel_action"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            current_action = action_command or settings.get("command") or settings.get("excel_action") or cached.get("command") or self._default_action()
            await self._send_builtin_icon(context, current_action)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not win32_available:
            print(f"[{self.uuid}] Plugin disabled: pywin32 not installed or not Windows.")
            return

        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = settings

        selected_action = settings.get("command") or settings.get("excel_action") or self._default_action()

        if selected_action:
            action_func = self.action_map.get(selected_action)
            if action_func:
                await asyncio.to_thread(action_func)
            else:
                print(f"[{self.uuid}] Unknown action: {selected_action}")

    def _connect_to_excel(self):
        if not self.win32:
            return False
        try:
            self.excel = self.win32.GetActiveObject("Excel.Application")
            return True
        except Exception:
            print(f"[{self.uuid}] Could not connect to Excel. Is it running?")
            return False

    def apply_bold(self):
        if self._connect_to_excel():
            self.excel.Selection.Font.Bold = not self.excel.Selection.Font.Bold

    def apply_border(self):
        if self._connect_to_excel():
            for i in range(7, 13):
                try:
                    self.excel.Selection.Borders(i).LineStyle = 1
                except Exception:
                    pass

    def format_as_header(self):
        if self._connect_to_excel():
            s = self.excel.Selection
            s.Font.Bold = True
            s.Interior.ColorIndex = 15
            s.HorizontalAlignment = -4108

    def format_as_number(self):
        if self._connect_to_excel():
            self.excel.Selection.NumberFormat = "#,##0"

    def paste_as_values(self):
        if self._connect_to_excel():
            self.excel.Selection.PasteSpecial(Paste=-4163)

    def autofit_columns(self):
        if self._connect_to_excel():
            self.excel.Selection.Columns.AutoFit()

    def toggle_filter(self):
        if self._connect_to_excel():
            self.excel.Selection.AutoFilter()

    def freeze_panes(self):
        if self._connect_to_excel():
            self.excel.ActiveWindow.FreezePanes = True

    def unfreeze_panes(self):
        if self._connect_to_excel():
            self.excel.ActiveWindow.FreezePanes = False

    def add_new_sheet(self):
        if self._connect_to_excel():
            self.excel.Worksheets.Add()

    def save_sheet_as_pdf(self):
        if self._connect_to_excel():
            try:
                wb = self.excel.ActiveWorkbook
                sheet = self.excel.ActiveSheet
                if wb and sheet:
                    base_name = os.path.splitext(wb.FullName)[0]
                    pdf_path = f"{base_name}-{sheet.Name}.pdf"
                    sheet.ExportAsFixedFormat(0, pdf_path)
                    print(f"[{self.uuid}] Saved as PDF: {pdf_path}")
            except Exception as e:
                print(f"[{self.uuid}] Failed to save as PDF. Error: {e}")

    def apply_report_format(self):
        if self._connect_to_excel():
            self.format_as_header()
            self.apply_border()
