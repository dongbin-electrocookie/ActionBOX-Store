import asyncio
import base64
import io
import json
import os
import re
import sys
import time
import html
import webbrowser
from pathlib import Path
from datetime import datetime, timedelta, timezone

try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None

try:
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build
    GOOGLE_AVAILABLE = True
except Exception:
    GOOGLE_AVAILABLE = False

try:
    from PIL import Image, ImageDraw, ImageFont
    PIL_AVAILABLE = True
except Exception:
    PIL_AVAILABLE = False


SCOPES = ["https://www.googleapis.com/auth/calendar.events.readonly"]
DEFAULT_TITLE_FORMAT = "{time}\\n{title}"
DEFAULT_ICON_NAME = "ACTION_CALENDAR"

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


I18N = {
    "ko": {
        "not_connected": "Google 계정이 연결되지 않았습니다. 설정에서 [Google 계정 연결]을 먼저 진행하세요.",
        "packages_missing": "Google API Python packages가 설치되지 않았습니다. requirements.txt를 먼저 설치하세요.",
        "credentials_missing": "credentials.json이 없습니다. Google OAuth Desktop credential을 만들고 plugin.py 옆에 넣으세요.",
        "login_prompt": "Google 로그인 페이지가 브라우저에서 열립니다. 인증 후 이 창으로 돌아오세요.",
        "login_success": "ActionBOX Google Calendar 플러그인 연결이 완료되었습니다. 이 창을 닫아도 됩니다.",
        "calendar_error_title": "Calendar\nError",
        "login_title": "Google\nLogin",
        "login_error_title": "Login\nError",
        "calendar_title": "Calendar",
        "no_event": "일정 없음",
        "no_meeting": "회의 없음",
        "meeting": "회의",
        "today": "오늘",
        "clock": "시계",
        "next": "다음",
        "countdown": "카운트다운",
        "all_day": "종일",
        "now": "진행중",
        "min_left": "{n}분 후",
        "hour_left": "{h}시간 {m}분",
        "ended": "종료",
    },
    "en": {
        "not_connected": "Google account is not connected. Use [Connect Google Account] in settings.",
        "packages_missing": "Google API Python packages are not installed. Install requirements.txt first.",
        "credentials_missing": "credentials.json is missing. Create a Google OAuth Desktop credential and place it next to plugin.py.",
        "login_prompt": "Google login page will open in your browser. Return here after authentication.",
        "login_success": "ActionBOX Google Calendar plugin is connected. You can close this browser window.",
        "calendar_error_title": "Calendar\nError",
        "login_title": "Google\nLogin",
        "login_error_title": "Login\nError",
        "calendar_title": "Calendar",
        "no_event": "No Event",
        "no_meeting": "No Meeting",
        "meeting": "Meeting",
        "today": "Today",
        "clock": "Clock",
        "next": "Next",
        "countdown": "Countdown",
        "all_day": "All Day",
        "now": "Now",
        "min_left": "in {n} min",
        "hour_left": "{h}h {m}m",
        "ended": "Ended",
    }
}

LANG_ALIASES = {
    "kr": "ko", "ko-kr": "ko", "en-us": "en", "en-gb": "en",
    "ja-jp": "ja", "de-de": "de", "es-es": "es", "fr-fr": "fr",
    "it-it": "it", "pt-br": "pt", "pt-pt": "pt-PT", "ru-ru": "ru"
}


def normalize_lang(lang):
    lang = str(lang or "en").replace("_", "-")
    low = lang.lower()
    if low in LANG_ALIASES:
        return LANG_ALIASES[low]
    primary = low.split("-")[0]
    if primary in ["ko", "en", "ja", "de", "es", "fr", "it", "pt", "ru"]:
        return primary
    return "en"


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.active_buttons = {}
        self.loop_started = False
        self.default_icon_name = DEFAULT_ICON_NAME
        self.data_dir = self._appdata_dir()
        self.log_file = str(self.data_dir / "calendar_debug_log.txt")
        self._migrate_legacy_files()

    def tr(self, key, lang="en", **kwargs):
        lang = normalize_lang(lang)
        value = (I18N.get(lang) or {}).get(key) or I18N["en"].get(key) or key
        try:
            return value.format(**kwargs)
        except Exception:
            return value

    def _log(self, msg):
        try:
            ts = time.strftime("%Y-%m-%d %H:%M:%S")
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(f"[{ts}] {msg}\n")
        except Exception:
            pass

    def _get_icon_path(self):
        return os.path.join(self.plugin_dir, "icon", f"{self.default_icon_name}.png")

    def _appdata_dir(self):
        if IS_WINDOWS:
            base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
            p = Path(base) / "CookieDeck" / "com_cookie_googlecalendar"
        elif IS_MACOS:
            p = Path.home() / "Library" / "Application Support" / "CookieDeck" / "com_cookie_googlecalendar"
        else:
            base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
            p = Path(base) / "CookieDeck" / "com_cookie_googlecalendar"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def _token_path(self):
        return self.data_dir / "token.json" if hasattr(self, "data_dir") else self._appdata_dir() / "token.json"

    def _user_credentials_path(self):
        return self.data_dir / "credentials.json" if hasattr(self, "data_dir") else self._appdata_dir() / "credentials.json"

    def _plugin_credentials_path(self):
        return Path(self.plugin_dir) / "credentials.json"

    def _credentials_path(self):
        # Keep plugin-local credentials for portable/testing builds, but also support
        # a user-writable location for macOS app bundles and Linux packages.
        plugin_path = self._plugin_credentials_path()
        user_path = self._user_credentials_path()
        if plugin_path.exists():
            return plugin_path
        return user_path

    def _migrate_legacy_files(self):
        # Older builds wrote logs/tokens next to the plugin or under APPDATA/ActionBOX.
        # Copy once when possible so existing authorizations survive the new layout.
        migrations = [
            (Path(self.plugin_dir) / "token.json", self.data_dir / "token.json"),
            (Path(self.plugin_dir) / "credentials.json", self.data_dir / "credentials.json"),
            (Path(self.plugin_dir) / "calendar_debug_log.txt", self.data_dir / "calendar_debug_log.txt"),
        ]
        old_appdata = os.environ.get("APPDATA")
        if old_appdata:
            old_dir = Path(old_appdata) / "ActionBOX" / "plugins" / "com.cookie.googlecalendar"
            migrations.extend([
                (old_dir / "token.json", self.data_dir / "token.json"),
                (old_dir / "credentials.json", self.data_dir / "credentials.json"),
            ])
        for src, dst in migrations:
            try:
                if src.exists() and not dst.exists():
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    dst.write_bytes(src.read_bytes())
            except Exception:
                pass

    def _has_credentials_file(self):
        return self._credentials_path().exists()

    def _has_token_file(self):
        return self._token_path().exists()

    def _normalize_settings(self, settings):
        s = dict(settings or {})
        s.setdefault("mode", "next_event")
        s.setdefault("calendar_id", "primary")
        s.setdefault("lookahead_days", 7)
        s.setdefault("refresh_interval", 60)
        s.setdefault("clock_format", "HH:mm")
        s.setdefault("title_format", DEFAULT_TITLE_FORMAT)
        s.setdefault("auto_update_title", True)
        s.setdefault("open_on_press", True)
        s.setdefault("include_all_day", False)
        s.setdefault("meeting_only", False)
        s.setdefault("alert_minutes", 0)
        s.setdefault("builtin_icon_name", self.default_icon_name)
        s.setdefault("default_visuals_initialized", True)
        s.setdefault("_lang", "en")
        return s

    async def _send_builtin_icon(self, context):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path()
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _set_title(self, context, title):
        if context:
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": title or ""}
            })

    async def _set_image(self, context, b64_image, page=None):
        if context and b64_image:
            payload = {"image": b64_image}
            if page is not None:
                payload["page"] = page
            await self.runner.send_message({
                "event": "setImage",
                "context": context,
                "payload": payload
            })

    async def _send_to_pi(self, context, payload):
        if context:
            await self.runner.send_message({
                "event": "sendToPropertyInspector",
                "context": context,
                "payload": payload or {}
            })

    # -----------------------------
    # Google Calendar OAuth / API
    # -----------------------------
    def _load_credentials(self, lang="en"):
        if not GOOGLE_AVAILABLE:
            raise RuntimeError(self.tr("packages_missing", lang))
        if not self._has_credentials_file():
            raise RuntimeError(self.tr("credentials_missing", lang))

        token_path = self._token_path()
        creds = None
        if token_path.exists():
            creds = Credentials.from_authorized_user_file(str(token_path), SCOPES)

        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
            token_path.write_text(creds.to_json(), encoding="utf-8")

        if not creds or not creds.valid:
            raise RuntimeError(self.tr("not_connected", lang))
        return creds

    def _authenticate_blocking(self, lang="en"):
        if not GOOGLE_AVAILABLE:
            raise RuntimeError(self.tr("packages_missing", lang))
        if not self._has_credentials_file():
            raise RuntimeError(self.tr("credentials_missing", lang))

        flow = InstalledAppFlow.from_client_secrets_file(str(self._credentials_path()), SCOPES)
        creds = flow.run_local_server(
            port=0,
            open_browser=True,
            authorization_prompt_message=self.tr("login_prompt", lang),
            success_message=self.tr("login_success", lang)
        )
        self._token_path().write_text(creds.to_json(), encoding="utf-8")
        return True

    def _build_service(self, lang="en"):
        creds = self._load_credentials(lang)
        return build("calendar", "v3", credentials=creds, cache_discovery=False)

    def _get_profile_email_blocking(self, lang="en"):
        # Calendar API itself does not always expose the email neatly.
        # calendarList.get('primary') usually returns the primary calendar summary.
        service = self._build_service(lang)
        try:
            cal = service.calendarList().get(calendarId="primary").execute()
            return cal.get("summary", "") or cal.get("id", "")
        except Exception:
            return "connected"

    def _disconnect_blocking(self):
        p = self._token_path()
        if p.exists():
            p.unlink()
        return True

    # -----------------------------
    # Calendar helpers
    # -----------------------------
    def _now(self):
        return datetime.now().astimezone()

    def _parse_event_time(self, event, key):
        data = event.get(key, {}) or {}
        if data.get("dateTime"):
            dt = datetime.fromisoformat(data["dateTime"].replace("Z", "+00:00"))
            return dt.astimezone(), False
        if data.get("date"):
            d = datetime.fromisoformat(data["date"]).date()
            local = self._now().tzinfo
            return datetime(d.year, d.month, d.day, tzinfo=local), True
        return None, False

    def _event_title(self, event):
        return event.get("summary") or "(No title)"

    def _strip_html(self, s):
        s = html.unescape(str(s or ""))
        s = re.sub(r"<[^>]+>", " ", s)
        return re.sub(r"\s+", " ", s).strip()

    def _extract_meeting_link(self, event):
        # 1) Google Meet convenience field
        hangout = event.get("hangoutLink")
        if hangout:
            return {"platform": "Meet", "url": hangout}

        # 2) conferenceData entry points
        conf = event.get("conferenceData") or {}
        for ep in conf.get("entryPoints") or []:
            uri = ep.get("uri")
            if uri and ep.get("entryPointType") in ("video", "more"):
                return {"platform": self._detect_platform(uri), "url": uri}

        # 3) description/location URL extraction
        text = " ".join([
            self._strip_html(event.get("description", "")),
            self._strip_html(event.get("location", "")),
        ])
        urls = re.findall(r"https?://[^\s<>\"']+", text)
        for u in urls:
            u = u.rstrip(").,;]")
            platform = self._detect_platform(u)
            if platform != "Link":
                return {"platform": platform, "url": u}
        if urls:
            return {"platform": "Link", "url": urls[0].rstrip(").,;]")}
        return None

    def _detect_platform(self, url):
        low = str(url or "").lower()
        if "meet.google.com" in low:
            return "Meet"
        if "zoom.us" in low or "zoom.com" in low:
            return "Zoom"
        if "teams.microsoft.com" in low or "teams.live.com" in low:
            return "Teams"
        if "webex.com" in low:
            return "Webex"
        return "Link"

    def _list_events_blocking(self, settings):
        settings = self._normalize_settings(settings)
        lang = settings.get("_lang", "en")
        service = self._build_service(lang)
        now = self._now()
        days = max(1, min(int(settings.get("lookahead_days") or 7), 30))
        time_min = now.isoformat()
        time_max = (now + timedelta(days=days)).isoformat()
        events_result = service.events().list(
            calendarId=settings.get("calendar_id") or "primary",
            timeMin=time_min,
            timeMax=time_max,
            maxResults=20,
            singleEvents=True,
            orderBy="startTime"
        ).execute()
        events = events_result.get("items", []) or []
        out = []
        include_all_day = bool(settings.get("include_all_day"))
        meeting_only = bool(settings.get("meeting_only"))
        for ev in events:
            start, all_day = self._parse_event_time(ev, "start")
            end, _ = self._parse_event_time(ev, "end")
            if not start:
                continue
            if all_day and not include_all_day:
                continue
            link = self._extract_meeting_link(ev)
            if meeting_only and not link:
                continue
            out.append({
                "raw": ev,
                "title": self._event_title(ev),
                "start": start,
                "end": end,
                "all_day": all_day,
                "htmlLink": ev.get("htmlLink", ""),
                "meeting": link,
            })
        return out

    def _today_count_blocking(self, settings):
        settings = self._normalize_settings(settings)
        lang = settings.get("_lang", "en")
        service = self._build_service(lang)
        now = self._now()
        local = now.tzinfo
        start = datetime(now.year, now.month, now.day, tzinfo=local)
        end = start + timedelta(days=1)
        events_result = service.events().list(
            calendarId=settings.get("calendar_id") or "primary",
            timeMin=now.isoformat(),
            timeMax=end.isoformat(),
            maxResults=50,
            singleEvents=True,
            orderBy="startTime"
        ).execute()
        events = events_result.get("items", []) or []
        count = 0
        for ev in events:
            st, all_day = self._parse_event_time(ev, "start")
            if all_day and not settings.get("include_all_day", False):
                continue
            if settings.get("meeting_only", False) and not self._extract_meeting_link(ev):
                continue
            count += 1
        return count

    def _format_clock(self, fmt):
        now = self._now()
        if fmt == "HH:mm:ss":
            return now.strftime("%H:%M:%S")
        if fmt == "date_time":
            return now.strftime("%m/%d\n%H:%M")
        return now.strftime("%H:%M")

    def _format_date(self):
        return self._now().strftime("%Y-%m-%d")

    def _remaining_text(self, dt, lang="en"):
        if not dt:
            return ""
        delta = dt - self._now()
        total_min = int(delta.total_seconds() // 60)
        if total_min < 0:
            return self.tr("now", lang)
        if total_min < 60:
            return self.tr("min_left", lang, n=max(0, total_min))
        h, m = divmod(total_min, 60)
        return self.tr("hour_left", lang, h=h, m=m)

    def _short_title(self, title, max_len=14):
        title = str(title or "")
        return title if len(title) <= max_len else title[:max_len-1] + "…"

    def _build_title(self, settings, info):
        fmt = settings.get("title_format") or DEFAULT_TITLE_FORMAT
        lang = settings.get("_lang", "en")
        title = info.get("title") or ""
        values = {
            "time": info.get("time") or "",
            "date": info.get("date") or self._format_date(),
            "title": self._short_title(title, 18),
            "count": str(info.get("count", "")),
            "platform": info.get("platform") or "",
            "remaining": info.get("remaining") or "",
            "mode": settings.get("mode") or "",
        }
        out = fmt
        for k, v in values.items():
            out = out.replace("{" + k + "}", str(v))
        return out.replace("\\n", "\n")

    def _open_url(self, url):
        if url:
            webbrowser.open(url)

    def _open_google_calendar(self):
        webbrowser.open("https://calendar.google.com/calendar/u/0/r")

    # -----------------------------
    # Image generation
    # -----------------------------
    def _font_paths(self, names):
        search_dirs = [Path(self.plugin_dir)]
        if IS_WINDOWS:
            search_dirs += [Path(r"C:\Windows\Fonts")]
        elif IS_MACOS:
            search_dirs += [
                Path("/System/Library/Fonts"),
                Path("/System/Library/Fonts/Supplemental"),
                Path("/Library/Fonts"),
                Path.home() / "Library" / "Fonts",
            ]
        else:
            search_dirs += [
                Path("/usr/share/fonts"),
                Path("/usr/local/share/fonts"),
                Path.home() / ".fonts",
                Path.home() / ".local" / "share" / "fonts",
            ]

        paths = []
        for name in names:
            for d in search_dirs:
                paths.append(str(d / name))
            paths.append(name)
        return paths

    def _load_font(self, names, size):
        if not PIL_AVAILABLE:
            return None
        for path in self._font_paths(names):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
        return ImageFont.load_default()

    def _make_calendar_image(self, main, sub="", platform=""):
        if not PIL_AVAILABLE:
            return None
        img = Image.new("RGB", (128, 128), (42, 99, 216))
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([8, 8, 120, 120], radius=18, fill=(255, 255, 255), outline=(28, 80, 190), width=3)
        d.rounded_rectangle([8, 8, 120, 40], radius=18, fill=(42, 99, 216))
        d.rectangle([8, 24, 120, 42], fill=(42, 99, 216))
        bold = [
            "malgunbd.ttf", "arialbd.ttf", "segoeuib.ttf", "arial.ttf",
            "AppleSDGothicNeo.ttc", "AppleGothic.ttf", "Helvetica.ttc",
            "NotoSansCJK-Bold.ttc", "NotoSansCJKkr-Bold.otf", "DejaVuSans-Bold.ttf"
        ]
        reg = [
            "malgun.ttf", "arial.ttf", "segoeui.ttf",
            "AppleSDGothicNeo.ttc", "AppleGothic.ttf", "Helvetica.ttc",
            "NotoSansCJK-Regular.ttc", "NotoSansCJKkr-Regular.otf", "DejaVuSans.ttf"
        ]
        font_main = self._load_font(bold, 26 if len(str(main)) <= 8 else 20)
        font_sub = self._load_font(reg, 14)
        font_top = self._load_font(bold, 13)
        top = (platform or "Calendar")[:13]
        bbox = d.textbbox((0, 0), top, font=font_top)
        d.text(((128-(bbox[2]-bbox[0]))/2, 14), top, font=font_top, fill=(255,255,255))
        main = str(main or "")
        bbox = d.textbbox((0, 0), main, font=font_main)
        d.text(((128-(bbox[2]-bbox[0]))/2, 58), main, font=font_main, fill=(25,25,25))
        sub = str(sub or "")[:18]
        bbox = d.textbbox((0, 0), sub, font=font_sub)
        d.text(((128-(bbox[2]-bbox[0]))/2, 96), sub, font=font_sub, fill=(90,90,90))
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return base64.b64encode(buf.getvalue()).decode("utf-8")

    async def update_action(self, context, settings):
        settings = self._normalize_settings(settings)
        lang = settings.get("_lang", "en")
        mode = settings.get("mode", "next_event")
        info = {"open_url": ""}

        try:
            if mode == "clock":
                clock = self._format_clock(settings.get("clock_format"))
                info.update({"time": clock, "title": self.tr("clock", lang), "platform": self.tr("clock", lang)})
                title = settings.get("title_format") or "{time}\\n{date}"
                settings["title_format"] = title
                main, sub, platform = clock.replace("\n", " "), self._format_date(), self.tr("clock", lang)

            elif mode == "today_count":
                count = await asyncio.to_thread(self._today_count_blocking, settings)
                info.update({"count": count, "title": self.tr("today", lang), "platform": self.tr("today", lang)})
                if settings.get("title_format") == DEFAULT_TITLE_FORMAT:
                    settings["title_format"] = self.tr("today", lang) + "\\n{count}"
                main, sub, platform = str(count), self.tr("today", lang), self.tr("calendar", lang)

            elif mode == "open_calendar":
                info.update({"title": self.tr("calendar", lang), "platform": self.tr("calendar", lang), "open_url": "https://calendar.google.com/calendar/u/0/r"})
                if settings.get("title_format") == DEFAULT_TITLE_FORMAT:
                    settings["title_format"] = self.tr("calendar", lang)
                main, sub, platform = self.tr("calendar", lang), "", self.tr("calendar", lang)

            else:
                events = await asyncio.to_thread(self._list_events_blocking, settings)
                if not events:
                    no_text = self.tr("no_meeting" if mode == "join_next_meeting" else "no_event", lang)
                    info.update({"title": no_text, "platform": self.tr("calendar", lang)})
                    if settings.get("title_format") == DEFAULT_TITLE_FORMAT:
                        settings["title_format"] = no_text
                    main, sub, platform = no_text, "", self.tr("calendar", lang)
                else:
                    ev = events[0]
                    meeting = ev.get("meeting")
                    platform = meeting.get("platform") if meeting else self.tr("calendar", lang)
                    remaining = self._remaining_text(ev.get("start"), lang)
                    time_text = self.tr("all_day", lang) if ev.get("all_day") else ev["start"].strftime("%H:%M")
                    open_url = ""
                    if meeting:
                        open_url = meeting.get("url") or ""
                    else:
                        open_url = ev.get("htmlLink") or "https://calendar.google.com/calendar/u/0/r"
                    info.update({
                        "time": time_text,
                        "title": ev.get("title"),
                        "platform": platform,
                        "remaining": remaining,
                        "open_url": open_url
                    })
                    if mode == "countdown":
                        if settings.get("title_format") == DEFAULT_TITLE_FORMAT:
                            settings["title_format"] = "{remaining}\\n{title}"
                        main, sub = remaining, self._short_title(ev.get("title"), 14)
                    elif mode == "join_next_meeting":
                        if settings.get("title_format") == DEFAULT_TITLE_FORMAT:
                            settings["title_format"] = "{platform}\\n{remaining}"
                        main, sub = platform, remaining
                    else:
                        main, sub = time_text, self._short_title(ev.get("title"), 14)

            self.active_buttons[context] = dict(settings, _last_info=info)
            if settings.get("auto_update_title", True):
                await self._set_title(context, self._build_title(settings, info))
            img = await asyncio.to_thread(self._make_calendar_image, main, sub, platform)
            if img:
                await self._set_image(context, img, settings.get("_target_page"))
            return info, None

        except Exception as e:
            self._log(f"update_action error: {e}")
            await self._send_builtin_icon(context)
            if settings.get("auto_update_title", True):
                await self._set_title(context, self.tr("calendar_error_title", lang))
            return None, str(e)

    async def auto_update_loop(self):
        while True:
            await asyncio.sleep(5)
            now = time.time()
            for context, settings in list(self.active_buttons.items()):
                settings = self._normalize_settings(settings)
                interval = int(settings.get("refresh_interval") or 60)
                if interval < 10:
                    interval = 10
                last = float(settings.get("_last_update", 0) or 0)
                if now - last >= interval:
                    settings["_last_update"] = now
                    self.active_buttons[context] = settings
                    await self.update_action(context, settings)

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return
        settings = self._normalize_settings(settings)
        self.active_buttons[context] = settings
        await self._send_builtin_icon(context)
        if settings.get("mode") == "clock" or self._has_token_file():
            await self.update_action(context, settings)
        else:
            await self._set_title(context, self.tr("calendar_title", settings.get("_lang")))

    async def handle_message(self, data):
        try:
            event = data.get("event")
            payload = data.get("payload", {}) or {}
            command = payload.get("command") or data.get("command")
            context = payload.get("context") or data.get("context")
            settings = payload.get("settings") or data.get("settings", {}) or {}

            if not self.loop_started:
                self.loop_started = True
                asyncio.create_task(self.auto_update_loop())

            if event and ("disappear" in event.lower() or "delete" in event.lower() or "remove" in event.lower() or "clear" in event.lower()):
                self.active_buttons.pop(context, None)
                return

            if event in ["willAppear", "keyDidAppear"]:
                settings["_target_page"] = payload.get("page")
                await self._initialize_default_visuals_if_new(context, settings)
                return

            if event == "didReceiveSettings":
                if context:
                    merged = dict(self.active_buttons.get(context, {}))
                    merged.update(self._normalize_settings(settings))
                    merged["_target_page"] = payload.get("page", merged.get("_target_page"))
                    self.active_buttons[context] = merged
                return

            if event == "keyDown":
                settings = self._normalize_settings(self.active_buttons.get(context) or settings)
                if settings.get("open_on_press", True):
                    info = settings.get("_last_info") or {}
                    url = info.get("open_url")
                    if not url:
                        await self.update_action(context, settings)
                        info = self.active_buttons.get(context, {}).get("_last_info") or {}
                        url = info.get("open_url")
                    if settings.get("mode") == "clock" or not url:
                        await asyncio.to_thread(self._open_google_calendar)
                    else:
                        await asyncio.to_thread(self._open_url, url)
                await self.update_action(context, settings)
                return

            if event == "sendToPlugin" or command:
                s = self._normalize_settings(settings)
                lang = s.get("_lang", "en")

                if command == "apply_builtin_icon":
                    await self._send_builtin_icon(context)
                    return

                if command == "connect_google":
                    try:
                        if s.get("auto_update_title", True):
                            await self._set_title(context, self.tr("login_title", lang))
                        await asyncio.to_thread(self._authenticate_blocking, lang)
                        email = await asyncio.to_thread(self._get_profile_email_blocking, lang)
                        await self._send_to_pi(context, {"command": "oauth_status", "ok": True, "email": email, "message": "connected"})
                        if context:
                            self.active_buttons[context] = s
                            await self.update_action(context, s)
                    except Exception as e:
                        self._log(f"connect_google error: {e}")
                        await self._send_to_pi(context, {"command": "oauth_status", "ok": False, "message": str(e)})
                        if s.get("auto_update_title", True):
                            await self._set_title(context, self.tr("login_error_title", lang))
                    return

                if command == "disconnect_google":
                    try:
                        await asyncio.to_thread(self._disconnect_blocking)
                        await self._send_to_pi(context, {"command": "oauth_status", "ok": True, "email": "", "message": "disconnected"})
                        await self._send_builtin_icon(context)
                        if s.get("auto_update_title", True):
                            await self._set_title(context, self.tr("calendar_title", lang))
                    except Exception as e:
                        await self._send_to_pi(context, {"command": "oauth_status", "ok": False, "message": str(e)})
                    return

                if command == "get_oauth_status":
                    email = ""
                    ok = False
                    msg = "not connected"
                    try:
                        if self._has_token_file():
                            email = await asyncio.to_thread(self._get_profile_email_blocking, lang)
                            ok = True
                            msg = "connected"
                        elif not self._has_credentials_file():
                            msg = "credentials.json missing"
                    except Exception as e:
                        msg = str(e)
                    await self._send_to_pi(context, {"command": "oauth_status", "ok": ok, "email": email, "message": msg})
                    return

                if command == "force_update" or command == "test_update":
                    if context:
                        self.active_buttons[context] = s
                    info, err = await self.update_action(context, s)
                    await self._send_to_pi(context, {"command": "test_result", "ok": err is None, "info": info or {}, "message": err or "ok"})
                    return

                if command == "open_calendar":
                    await asyncio.to_thread(self._open_google_calendar)
                    return

        except Exception as e:
            self._log(f"handle_message fatal: {e}")
            print(f"❌ [Google Calendar] Internal error: {e}")
