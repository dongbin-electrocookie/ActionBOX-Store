import asyncio
import sys
import os

# 🚀 플러그인 내부에 있는 'lib' 폴더를 파이썬 라이브러리 경로에 추가
lib_path = os.path.join(os.path.dirname(__file__), 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

try:
    import spotipy
    from spotipy.oauth2 import SpotifyOAuth
    SPOTIPY_AVAILABLE = True
except ImportError:
    SPOTIPY_AVAILABLE = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.sp = None
        # 🚀 [대통합 규격] 멀티액션 시 누락되는 API 인증 정보를 기억하기 위한 저장소
        self.last_valid_settings = {}

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    def init_spotify(self, client_id, client_secret):
        if not SPOTIPY_AVAILABLE:
            print(f"[{self.uuid}] ❌ 'spotipy' 라이브러리가 없습니다.")
            return False
            
        if not client_id or not client_secret:
            print(f"[{self.uuid}] ⚠️ Client ID와 Secret 정보가 부족합니다.")
            return False
            
        try:
            cache_path = os.path.join(os.path.dirname(__file__), ".spotify_cache")
            auth_manager = SpotifyOAuth(
                client_id=client_id,
                client_secret=client_secret,
                redirect_uri="http://localhost:8080/callback",
                scope="user-modify-playback-state user-read-playback-state user-library-modify user-read-currently-playing",
                open_browser=True,
                cache_path=cache_path
            )
            self.sp = spotipy.Spotify(auth_manager=auth_manager)
            return True
        except Exception as e:
            print(f"[{self.uuid}] ❌ 인증 에러: {e}")
            return False

    def control_spotify(self, settings):
        # 🚀 [표준화] 'command' 주머니에서 동작을 먼저 꺼내고, 없으면 기존 'sp_action'을 씁니다.
        action = settings.get("command") or settings.get("sp_action", "play_pause")

        # API 클라이언트 초기화 (기억된 인증 정보 사용)
        if not self.sp:
            c_id = settings.get("client_id", "").strip()
            c_secret = settings.get("client_secret", "").strip()
            if not self.init_spotify(c_id, c_secret):
                return
        
        try:
            if action == "play_pause":
                curr = self.sp.current_playback()
                if curr and curr.get('is_playing'):
                    self.sp.pause_playback()
                    print(f"[{self.uuid}] 일시정지")
                else:
                    self.sp.start_playback()
                    print(f"[{self.uuid}] 재생")
            elif action == "next":
                self.sp.next_track()
                print(f"[{self.uuid}] 다음 곡")
            elif action == "prev":
                self.sp.previous_track()
                print(f"[{self.uuid}] 이전 곡")
            elif action == "like":
                curr = self.sp.current_user_playing_track()
                if curr and curr.get('item'):
                    track_id = curr['item']['id']
                    self.sp.current_user_saved_tracks_add([track_id])
                    print(f"[{self.uuid}] ❤️ 좋아요 추가 완료")
        except Exception as e:
            print(f"[{self.uuid}] ❌ 실행 에러: {e}")

    async def on_key_down(self, data):
        incoming_settings = data.get("payload", {}).get("settings", {})
        
        # 🚀 1. 유효한 인증 정보가 들어오면 기억해둡니다 (캐시 업데이트)
        if incoming_settings.get("client_id"):
            self.last_valid_settings.update(incoming_settings)
        
        # 🚀 2. 마지막 유효 설정과 현재 명령을 병합 (멀티액션 대응)
        final_settings = {**self.last_valid_settings, **incoming_settings}
        
        # 네트워크 통신이므로 백그라운드 스레드에서 실행
        await asyncio.to_thread(self.control_spotify, final_settings)