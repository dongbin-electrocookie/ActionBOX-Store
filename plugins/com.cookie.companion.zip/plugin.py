import json
import urllib.request
import asyncio
import os

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.default_icon_path = os.path.join(self.plugin_dir, "icon", "ACTION_PRESS_NAME.png")
        self.context_settings = {}

    def _default_settings(self):
        return {
            "ip": "127.0.0.1",
            "port": "8000",
            "page": "1",
            "row": "0",
            "col": "0",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("ip"),
            s.get("port"),
            s.get("page"),
            s.get("row"),
            s.get("col"),
            s.get("title"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ["willAppear", "keyDidAppear"]:
            await self.on_key_did_appear(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                self.context_settings[context] = self._merge_with_defaults(settings)
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if event == "keyDown":
            await self.on_key_down(context, settings)

    async def on_key_did_appear(self, context, incoming_settings):
        if not context:
            return

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            if os.path.exists(self.default_icon_path):
                await self.runner.send_message({
                    "event": "setIcon",
                    "context": context,
                    "payload": {"icon_path": self.default_icon_path}
                })
            return

        self.context_settings[context] = self._merge_with_defaults(incoming_settings)

    async def on_key_down(self, context, incoming_settings):
        if isinstance(incoming_settings, str) and incoming_settings.startswith("{"):
            try:
                incoming_settings = json.loads(incoming_settings)
            except Exception:
                incoming_settings = {}

        if not isinstance(incoming_settings, dict):
            incoming_settings = {}

        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = settings

        ip = settings.get("ip", "127.0.0.1")
        port = settings.get("port", "8000")
        page = settings.get("page", "1")
        row = settings.get("row", "0")
        col = settings.get("col", "0")

        url = f"http://{ip}:{port}/api/location/{page}/{row}/{col}/press"

        def make_request():
            try:
                req = urllib.request.Request(url, method="POST")
                with urllib.request.urlopen(req, timeout=1.0) as response:
                    print(f"[Companion] Triggered {page}/{row}/{col} -> Status: {response.status}")
            except Exception as e:
                print(f"[Companion Error] Failed to trigger URL ({url}): {e}")

        asyncio.create_task(asyncio.to_thread(make_request))
