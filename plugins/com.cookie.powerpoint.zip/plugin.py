import asyncio
import os
import sys
import time
try:
    from utility.native_hotkeys import send_windows_hotkey
    from utility.powerpoint_shortcuts import load_powerpoint_profiles, resolve_powerpoint_shortcut
except ModuleNotFoundError:
    from native_hotkeys import send_windows_hotkey
    from powerpoint_shortcuts import load_powerpoint_profiles, resolve_powerpoint_shortcut

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        self.profiles = load_powerpoint_profiles(self.plugin_dir)
        self.windows_action_map = self.profiles['bindings']['windows']['desktop']
        self.macos_action_map = self.profiles['bindings']['darwin']['desktop']
        self.action_map = self.macos_action_map if IS_MACOS else self.windows_action_map

        self.icon_map = {
            "show_start": "STATE_SHOW_START",
            "show_current": "STATE_SHOW_CURRENT",
            "show_next": "STATE_SHOW_NEXT",
            "show_prev": "STATE_SHOW_PREV",
            "show_end": "STATE_SHOW_END",
            "show_black": "STATE_SHOW_BLACK",
            "show_white": "STATE_SHOW_WHITE",
            "show_laser": "STATE_SHOW_LASER",
            "show_pen": "STATE_SHOW_PEN",
            "show_eraser": "STATE_SHOW_ERASER",
            "show_arrow": "STATE_SHOW_ARROW",
            "edit_new_slide": "STATE_EDIT_NEW_SLIDE",
            "edit_duplicate": "STATE_EDIT_DUPLICATE",
            "edit_undo": "STATE_EDIT_UNDO",
            "edit_redo": "STATE_EDIT_REDO",
            "format_copy": "STATE_FORMAT_COPY",
            "format_paste": "STATE_FORMAT_PASTE",
            "format_group": "STATE_FORMAT_GROUP",
            "format_ungroup": "STATE_FORMAT_UNGROUP",
            "font_bold": "STATE_FONT_BOLD",
            "font_italic": "STATE_FONT_ITALIC",
            "file_save": "STATE_FILE_SAVE",
            "file_save_as": "STATE_FILE_SAVE_AS"
        }

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or "show_next", "STATE_SHOW_NEXT")
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, settings):
        if not context:
            return

        settings = dict(settings or {})
        meaningful = any(settings.get(k) not in ("", None, False) for k in [
            "command", "builtin_icon_name", "default_visuals_initialized",
            "sync_title_on_action_change", "title", "execution_environment"
        ])
        if meaningful:
            self.context_settings[context] = dict(settings or {})
            return

        default_action = "show_next"
        new_settings = {
            "command": default_action,
            "execution_environment": "desktop",
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[default_action],
            "default_visuals_initialized": True
        }

        await self.runner.send_message({
            "event": "setSettings",
            "context": context,
            "payload": new_settings
        })

        self.context_settings[context] = new_settings.copy()

        await self._send_builtin_icon(context, default_action)

    def _normalize_pyautogui_key(self, key_name):
        key = str(key_name).strip().lower()
        aliases = {
            "ctrl": "ctrl",
            "control": "ctrl",
            "alt": "option" if IS_MACOS else "alt",
            "option": "option" if IS_MACOS else "alt",
            "cmd": "command" if IS_MACOS else "win",
            "command": "command" if IS_MACOS else "win",
            "win": "command" if IS_MACOS else "win",
            "windows": "command" if IS_MACOS else "win",
            "return": "enter",
            "escape": "esc",
        }
        return aliases.get(key, key)

    def _send_hotkey_sync(self, hotkey):
        sequence = hotkey if isinstance(hotkey, (list, tuple)) else [hotkey]
        for chord in sequence:
            parts = [self._normalize_pyautogui_key(p) for p in chord.split('+') if p.strip()]
            if not parts:
                continue

            if IS_WINDOWS and send_windows_hotkey(parts):
                pass
            elif IS_WINDOWS and keyboard_available:
                keyboard.send(chord)
            elif pyautogui_available:
                if len(parts) == 1:
                    pyautogui.press(parts[0])
                else:
                    pyautogui.hotkey(*parts, interval=0.04)
            else:
                print(f"[{self.uuid}] No keyboard injection library is available.")
                return
            time.sleep(0.06)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings" and context:
            cached = self.context_settings.get(context, {})
            self.context_settings[context] = {**cached, **settings}
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            await self._send_builtin_icon(context, action_command or settings.get("command") or cached.get("command") or "show_next")
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming = data.get("payload", {}).get("settings", {}) or {}
        settings = {**self.context_settings.get(context, {}), **incoming}
        if context:
            self.context_settings[context] = settings
        resolved = resolve_powerpoint_shortcut(settings, self.profiles, IS_MACOS)
        if not resolved or not resolved['hotkey']:
            reason = resolved['reason'] if resolved else 'unknown_binding'
            print(f'[{self.uuid}] No keys sent: {reason}')
            return
        try:
            await asyncio.to_thread(self._send_hotkey_sync, resolved['hotkey'])
        except Exception as error:
            print(f'[{self.uuid}] Input error: {error}')
