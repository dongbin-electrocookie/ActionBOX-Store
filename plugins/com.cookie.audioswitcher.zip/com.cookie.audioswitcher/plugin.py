import sys
import os
import asyncio
import subprocess
import threading
import ctypes
import time

IS_WINDOWS = (sys.platform == "win32")
IS_MACOS = (sys.platform == "darwin")
sc = None
ToastNotifier = None
libraries_ok = False

if IS_WINDOWS:
    try:
        import soundcard as sc
        from win10toast import ToastNotifier
        libraries_ok = True
    except ImportError:
        print("[Audio Switcher Error] Required libraries (soundcard, win10toast) missing.")


def _fourcc(value):
    return int.from_bytes(value.encode("ascii"), "big")


class _AudioPropertyAddress(ctypes.Structure):
    _fields_ = [("selector", ctypes.c_uint32), ("scope", ctypes.c_uint32),
                ("element", ctypes.c_uint32)]


class MacAudioDevices:
    """Default-device control only: no recording, audio routing, or extra binaries."""

    SYSTEM = 1  # kAudioObjectSystemObject

    def __init__(self):
        self.audio = ctypes.CDLL("/System/Library/Frameworks/CoreAudio.framework/CoreAudio")
        self.cf = ctypes.CDLL("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")
        address = ctypes.POINTER(_AudioPropertyAddress)
        size_pointer = ctypes.POINTER(ctypes.c_uint32)
        self.audio.AudioObjectGetPropertyDataSize.argtypes = [
            ctypes.c_uint32, address, ctypes.c_uint32, ctypes.c_void_p, size_pointer]
        self.audio.AudioObjectGetPropertyDataSize.restype = ctypes.c_int32
        self.audio.AudioObjectGetPropertyData.argtypes = [
            ctypes.c_uint32, address, ctypes.c_uint32, ctypes.c_void_p,
            size_pointer, ctypes.c_void_p]
        self.audio.AudioObjectGetPropertyData.restype = ctypes.c_int32
        self.audio.AudioObjectSetPropertyData.argtypes = [
            ctypes.c_uint32, address, ctypes.c_uint32, ctypes.c_void_p,
            ctypes.c_uint32, ctypes.c_void_p]
        self.audio.AudioObjectSetPropertyData.restype = ctypes.c_int32
        self.audio.AudioObjectHasProperty.argtypes = [ctypes.c_uint32, address]
        self.audio.AudioObjectHasProperty.restype = ctypes.c_ubyte
        self.audio.AudioObjectIsPropertySettable.argtypes = [
            ctypes.c_uint32, address, ctypes.POINTER(ctypes.c_ubyte)]
        self.audio.AudioObjectIsPropertySettable.restype = ctypes.c_int32
        self.cf.CFStringGetLength.argtypes = [ctypes.c_void_p]
        self.cf.CFStringGetLength.restype = ctypes.c_long
        self.cf.CFStringGetMaximumSizeForEncoding.argtypes = [ctypes.c_long, ctypes.c_uint32]
        self.cf.CFStringGetMaximumSizeForEncoding.restype = ctypes.c_long
        self.cf.CFStringGetCString.argtypes = [
            ctypes.c_void_p, ctypes.c_void_p, ctypes.c_long, ctypes.c_uint32]
        self.cf.CFStringGetCString.restype = ctypes.c_ubyte
        self.cf.CFRelease.argtypes = [ctypes.c_void_p]
        self.cf.CFRelease.restype = None

    @staticmethod
    def _address(selector, scope="glob"):
        return _AudioPropertyAddress(_fourcc(selector), _fourcc(scope), 0)

    @staticmethod
    def _check(status):
        if status:
            raise RuntimeError(f"Core Audio error: {status}")

    def _read(self, device, selector, value, scope="glob"):
        address = self._address(selector, scope)
        size = ctypes.c_uint32(ctypes.sizeof(value))
        self._check(self.audio.AudioObjectGetPropertyData(
            device, ctypes.byref(address), 0, None, ctypes.byref(size), ctypes.byref(value)))
        if size.value != ctypes.sizeof(value):
            raise RuntimeError("Core Audio returned an unexpected property size")
        return value

    def _ids(self, device, selector, scope="glob"):
        address = self._address(selector, scope)
        size = ctypes.c_uint32()
        self._check(self.audio.AudioObjectGetPropertyDataSize(
            device, ctypes.byref(address), 0, None, ctypes.byref(size)))
        if not size.value:
            return []
        if size.value % 4 or size.value > 1024 * 1024:
            raise RuntimeError("Core Audio returned an invalid device/stream list size")
        values = (ctypes.c_uint32 * (size.value // 4))()
        capacity = size.value
        self._check(self.audio.AudioObjectGetPropertyData(
            device, ctypes.byref(address), 0, None, ctypes.byref(size), ctypes.byref(values)))
        if size.value > capacity or size.value % 4:
            raise RuntimeError("Core Audio device/stream list changed during enumeration")
        return list(values)[:size.value // 4]

    def _uint(self, device, selector, scope="glob"):
        return self._read(device, selector, ctypes.c_uint32(), scope).value

    def _name(self, device):
        name = self._read(device, "lnam", ctypes.c_void_p())
        if not name.value:
            return str(device)
        try:
            encoding = 0x08000100  # kCFStringEncodingUTF8
            length = self.cf.CFStringGetLength(name)
            capacity = self.cf.CFStringGetMaximumSizeForEncoding(length, encoding) + 1
            if capacity < 1 or capacity > 1024 * 1024:
                return str(device)
            buffer = ctypes.create_string_buffer(capacity)
            if self.cf.CFStringGetCString(name, buffer, capacity, encoding):
                return buffer.value.decode("utf-8") or str(device)
            return str(device)
        finally:
            # AudioObject's name property returns an owned CFString.
            self.cf.CFRelease(name)

    def devices(self, is_output=True):
        scope = "outp" if is_output else "inpt"
        devices = []
        for device in dict.fromkeys(self._ids(self.SYSTEM, "dev#")):
            try:
                if not self._uint(device, "livn"):
                    continue
                hidden_address = self._address("hidn")
                if (self.audio.AudioObjectHasProperty(device, ctypes.byref(hidden_address))
                        and self._uint(device, "hidn")):
                    continue
                if not self._uint(device, "dflt", scope) or not self._ids(device, "stm#", scope):
                    continue
                devices.append((device, self._name(device)))
            except RuntimeError:
                # A USB/Bluetooth device may disappear between property reads.
                continue
        return devices

    def default_device(self, is_output=True):
        return self._uint(self.SYSTEM, "dOut" if is_output else "dIn ")

    def set_default_device(self, device, is_output=True):
        address = self._address("dOut" if is_output else "dIn ")
        writable = ctypes.c_ubyte()
        self._check(self.audio.AudioObjectIsPropertySettable(
            self.SYSTEM, ctypes.byref(address), ctypes.byref(writable)))
        if not writable.value:
            raise RuntimeError("The default audio device property is not writable")
        value = ctypes.c_uint32(device)
        self._check(self.audio.AudioObjectSetPropertyData(
            self.SYSTEM, ctypes.byref(address), 0, None,
            ctypes.sizeof(value), ctypes.byref(value)))
        # Device changes can settle asynchronously, particularly over Bluetooth.
        for _ in range(50):
            if self.default_device(is_output) == device:
                return
            time.sleep(0.02)
        raise RuntimeError("The requested audio device did not become the default")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.toaster = ToastNotifier() if (IS_WINDOWS and libraries_ok) else None

        self.endpoint_controller_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "EndpointController.exe"
        )
        self.icon_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon")
        self.context_settings = {}
        self._device_switch_lock = threading.Lock()
        self._mac_audio = None

        if IS_WINDOWS and not os.path.exists(self.endpoint_controller_path):
            print(f"[{self.uuid} ERROR] EndpointController.exe not found!")
            self.endpoint_controller_path = None

        self.I18N = {
            "en": {"TOAST_TITLE": "Audio Device Changed", "TOAST_OUTPUT": "Output Device", "TOAST_INPUT": "Input Device", "TOAST_ACTIVE": "Active"},
            "ko": {"TOAST_TITLE": "오디오 장치가 변경되었습니다", "TOAST_OUTPUT": "출력 장치", "TOAST_INPUT": "입력 장치", "TOAST_ACTIVE": "현재"},
            "ja": {"TOAST_TITLE": "オーディオデバイスを変更しました", "TOAST_OUTPUT": "出力デバイス", "TOAST_INPUT": "入力デバイス", "TOAST_ACTIVE": "現在の"},
            "de": {"TOAST_TITLE": "Audiogerät geändert", "TOAST_OUTPUT": "Ausgabegerät", "TOAST_INPUT": "Eingabegerät", "TOAST_ACTIVE": "Aktives"},
            "es": {"TOAST_TITLE": "Dispositivo de audio cambiado", "TOAST_OUTPUT": "Dispositivo de salida", "TOAST_INPUT": "Dispositivo de entrada", "TOAST_ACTIVE": "Activo"},
            "fr": {"TOAST_TITLE": "Périphérique audio modifié", "TOAST_OUTPUT": "Périphérique de sortie", "TOAST_INPUT": "Périphérique d’entrée", "TOAST_ACTIVE": "Actif"},
            "ru": {"TOAST_TITLE": "Аудиоустройство изменено", "TOAST_OUTPUT": "Устройство вывода", "TOAST_INPUT": "Устройство ввода", "TOAST_ACTIVE": "Текущее"},
            "it": {"TOAST_TITLE": "Dispositivo audio cambiato", "TOAST_OUTPUT": "Dispositivo di uscita", "TOAST_INPUT": "Dispositivo di ingresso", "TOAST_ACTIVE": "Attivo"},
            "pt-PT": {"TOAST_TITLE": "Dispositivo de áudio alterado", "TOAST_OUTPUT": "Dispositivo de saída", "TOAST_INPUT": "Dispositivo de entrada", "TOAST_ACTIVE": "Ativo"},
        }

    def _norm_lang(self, lang):
        lang = (lang or "en").strip()
        alias = {"pt": "pt-PT", "kr": "ko", "jp": "ja"}
        lang = alias.get(lang, lang)
        return lang if lang in self.I18N else "en"

    def _tr(self, lang, key):
        lang = self._norm_lang(lang)
        return self.I18N.get(lang, self.I18N["en"]).get(key, self.I18N["en"].get(key, key))

    def _command_from_action(self, action_id, settings=None):
        settings = settings or {}
        command = (settings.get("command") or "").strip()
        if command in ("cycle_output", "cycle_input"):
            return command

        action_id = action_id or ""
        if "cycle_input" in action_id:
            return "cycle_input"
        return "cycle_output"

    def _default_title_key(self, command):
        return "TITLE_CYCLE_INPUT_DEVICE" if command == "cycle_input" else "TITLE_CYCLE_OUTPUT_DEVICE"

    def _default_settings(self, action_id=""):
        command = self._command_from_action(action_id, {})
        return {
            "command": command,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self._default_title_key(command),
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings, action_id=""):
        merged = self._default_settings(action_id)
        merged.update(settings or {})
        command = self._command_from_action(action_id, merged)
        merged["command"] = command
        merged["builtin_icon_name"] = self._default_title_key(command)
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False),
            s.get("_lang")
        ])

    def _get_default_icon_path(self, command):
        icon_name = "CYCLE_OUTPUT_DEVICE.png" if command == "cycle_output" else "CYCLE_INPUT_DEVICE.png"
        icon_path = os.path.join(self.icon_dir, icon_name)
        if os.path.exists(icon_path):
            return icon_path
        fallback = os.path.join(self.icon_dir, "pluginIcon.png")
        return fallback if os.path.exists(fallback) else None

    async def _send_default_icon(self, context, command):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_default_icon_path(command)
        if context and icon_path:
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, action_id, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings(action_id)
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_default_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings, action_id)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        action_id = data.get("action", "")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        if event in ("willAppear", "keyDidAppear"):
            await self._initialize_default_visuals_if_new(context, action_id, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings}, action_id)
            return

        if event in ("keyDidDisappear", "willDisappear"):
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if event == "keyDown":
            await self.on_key_down(data)
            return

    async def on_key_down(self, data):
        if not IS_MACOS and not (IS_WINDOWS and libraries_ok):
            return

        context = data.get("context")
        action_id = data.get("action", "")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        settings = self._merge_with_defaults({**cached, **incoming_settings}, action_id)
        if context:
            self.context_settings[context] = settings

        command = self._command_from_action(action_id, settings)
        is_output = (command == "cycle_output")
        lang = settings.get("_lang", "en")

        print(f"[{self.uuid}] Command: {command} (is_output={is_output})")
        await asyncio.to_thread(self.cycle_default_device, is_output, lang)

    def cycle_default_device(self, is_output=True, lang="en"):
        # Serialise rapid button presses so two workers cannot select the same
        # next device from the same previous default.
        with self._device_switch_lock:
            if IS_MACOS:
                try:
                    if self._mac_audio is None:
                        self._mac_audio = MacAudioDevices()
                    devices = self._mac_audio.devices(is_output)
                    if len(devices) < 2:
                        print(f"[{self.uuid}] Not enough devices to cycle.")
                        return
                    current = self._mac_audio.default_device(is_output)
                    current_index = next((i for i, (device, _) in enumerate(devices)
                                          if device == current), -1)
                    device, name = devices[(current_index + 1) % len(devices)]
                    self._mac_audio.set_default_device(device, is_output)
                    print(f"[{self.uuid}] Switched to: {name}")
                    return name
                except Exception as error:
                    print(f"[{self.uuid}] Failed to switch macOS audio device: {error}")
                    return
            if IS_WINDOWS and libraries_ok:
                return self._cycle_windows_default_device(is_output, lang)

    def _cycle_windows_default_device(self, is_output=True, lang="en"):
        if not self.endpoint_controller_path:
            return

        try:
            if is_output:
                all_devices, current_default = sc.all_speakers(), sc.default_speaker()
            else:
                all_devices, current_default = sc.all_microphones(), sc.default_microphone()

            if len(all_devices) < 2:
                print(f"[{self.uuid}] Not enough devices to cycle.")
                return

            device_names = [dev.name for dev in all_devices]
            try:
                current_index = device_names.index(current_default.name)
            except ValueError:
                current_index = -1

            next_index = (current_index + 1) % len(all_devices)
            next_device = all_devices[next_index]

            command = [self.endpoint_controller_path, str(next_index + 1)]
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                check=False,
                creationflags=subprocess.CREATE_NO_WINDOW
            )

            if result.returncode == 0:
                device_type = self._tr(lang, "TOAST_OUTPUT") if is_output else self._tr(lang, "TOAST_INPUT")
                title = self._tr(lang, "TOAST_TITLE")
                message = f"{self._tr(lang, 'TOAST_ACTIVE')} {device_type}:\n{next_device.name}"

                if self.toaster:
                    threading.Thread(
                        target=self.toaster.show_toast,
                        args=(title, message),
                        kwargs={"duration": 3, "threaded": False},
                        daemon=True
                    ).start()

                print(f"[{self.uuid}] Switched to: {next_device.name}")
            else:
                print(f"[{self.uuid}] Failed to switch. Error: {result.stderr.strip()}")

        except Exception as e:
            print(f"[{self.uuid} CRITICAL] cycle_default_device failed: {e}")
