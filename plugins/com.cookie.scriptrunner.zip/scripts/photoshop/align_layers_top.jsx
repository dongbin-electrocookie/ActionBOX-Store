#target photoshop

if (app.documents.length === 0) {
  alert("❌ 열린 문서가 없습니다.");
} else {
  try {
    var doc = app.activeDocument;

    // 캔버스를 기준으로 정렬 설정
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
    desc1.putReference(charIDToTypeID("null"), ref1);
    desc1.putEnumerated(charIDToTypeID("Usng"), charIDToTypeID("ADSt"), stringIDToTypeID("alignHorizontalCenters"));
    executeAction(charIDToTypeID("Algn"), desc1, DialogModes.NO);

    var desc2 = new ActionDescriptor();
    var ref2 = new ActionReference();
    ref2.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
    desc2.putReference(charIDToTypeID("null"), ref2);
    desc2.putEnumerated(charIDToTypeID("Usng"), charIDToTypeID("ADSt"), stringIDToTypeID("alignVerticalCenters"));
    executeAction(charIDToTypeID("Algn"), desc2, DialogModes.NO);

    alert("✅ 선택한 레이어가 캔버스 중앙에 정렬되었습니다.");
  } catch (e) {
    alert("⚠ 정렬 오류: 선택된 레이어가 없거나 배경 레이어일 수 있습니다.\n" + e.message);
  }
}
