#target photoshop

function safeFileName(name) {
    return name.replace(/[\\\/:*?"<>|]/g, "_").replace(/^\s+|\s+$/g, "") || "LayerExport";
}

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else {
    var originalDoc = app.activeDocument;
    var selectedLayer = originalDoc.activeLayer;
    var newDoc = null;

    try {
        selectedLayer.copy();
        newDoc = app.documents.add(
            originalDoc.width,
            originalDoc.height,
            originalDoc.resolution,
            "ExportedLayer",
            NewDocumentMode.RGB,
            DocumentFill.TRANSPARENT
        );
        newDoc.paste();

        var defaultName = safeFileName(selectedLayer.name);
        var fileName = prompt("저장할 파일 이름을 입력하세요 (확장자 제외)", defaultName);
        if (fileName) {
            var saveFile = new File(Folder.desktop.fsName + "/" + safeFileName(fileName) + ".png");
            if (!saveFile.exists || confirm("같은 이름의 파일이 있습니다. 덮어쓸까요?")) {
                var pngOptions = new PNGSaveOptions();
                pngOptions.compression = 9;
                pngOptions.interlaced = false;
                newDoc.saveAs(saveFile, pngOptions, true, Extension.LOWERCASE);
                alert("PNG 저장 완료:\n" + saveFile.fsName);
            }
        }
    } catch (e) {
        alert("PNG 저장 오류: " + e.message);
    } finally {
        if (newDoc) newDoc.close(SaveOptions.DONOTSAVECHANGES);
        app.activeDocument = originalDoc;
    }
}
