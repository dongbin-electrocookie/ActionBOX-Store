# Codex for COMBO-X (v1.0.0)

The Codex plugin monitors Codex Desktop/CLI session state and provides Codex-specific voice and reasoning controls.

## Actions

- **Codex Status** — Idle, Thinking, Complete, Permission and Error artwork with matching status LED
- **Talk to Codex** — activates Codex and taps `globalDictationSingleTap` once per press; Codex starts/stops dictation itself
- The unpublished legacy **Codex Push to Talk** action uses `globalDictationHold` while pressed
- **Codex Reasoning Down / Up** — adjusts the focused Codex composer's reasoning effort
- **Approve / Reject** — activates Codex and invokes `approval.approve` or `approval.decline` via its configured app shortcut; no blind `Enter`/`Esc` fallback

Existing Codex shortcuts are preserved. Missing voice/reasoning bindings are assigned an unused reserved chord and written atomically with a backup. Codex hooks are automatically installed or repaired; local rollout JSONL is also monitored as a read-only Desktop fallback.

Status monitoring remembers completed turn IDs. Late tool callbacks cannot reopen
a completed, interrupted or ended turn, and callbacks for an older turn cannot
change the current one. A matching rollout completion is accepted even when a
tool hook arrived later; rollout record timestamps retain subsecond precision.
Completion fences are saved and restored across plugin restarts. There is no
inactivity timeout: silent, long-running work stays Thinking until an actual
lifecycle signal arrives. Recent-session mode follows recorded Codex chats.

On ComboX startup the Codex status starts Idle (white LED). Starts from earlier
logs do not restore Thinking, and completion callbacks without a start observed
in this runtime stay Idle. A new observed turn follows Thinking (blue) then
Complete (green). Completion fences survive restart, but the observed-start flag
is reset; historical completion can never earn the green LED on a fresh launch.

Automatic hook monitoring follows chats with a local rollout record. Codex's
ephemeral approvals_reviewer sessions also emit lifecycle hooks but are not user
chats and do not change the status key. Hooks arriving before a new chat's rollout
are retained for up to ten seconds, with a bounded queue, then discarded if no
recorded chat appears. No Codex database schema or private control API is used.
Periodic display retries do not resend an unchanged desktop preview or LED;
hardware-only animation continues, and frames loaded for an old state are dropped.

After updating the plugin, restart COMBO-X so it reads/prepares the current
dictation binding. Then fully quit and reopen Codex to register any newly added
global shortcut. Existing `globalDictationSingleTap` bindings take precedence;
the former `globalDictationToggle` name is reused only when Codex would normalize
it to SingleTap (a Hold entry exists and no explicit SingleTap entry). Existing user/global bindings and
reasoning shortcuts are never deleted. The retired `composer.startDictation`
binding is not used on current Windows/macOS builds. Window activation remains
in place; this does not guarantee composer text-field focus or microphone access.

Approve/Reject bindings are prepared on assignment and startup using the same
preserve-or-create flow. Restart COMBO-X first, then fully quit/reopen Codex after
new bindings are added. Commands target the active approval in Codex, not a
background monitored session. They do not change the permission mode, approve
automatically, select answers to general questions, or grant permanent access.
Their behavior for a particular prompt is owned by Codex's active approval UI.
Questionnaire/multiple-choice navigation remains outside these two actions.

The inspector shows hook installation as a red/green **Codex Hook** button,
with an equally sized **Remove Codex Hook** button alongside it.
Clicking it keeps the existing install/repair action and opens a localized
full-quit/restart notice. **Remove hooks** remains available; the manual status
refresh button and lower diagnostic/session details are no longer displayed.
Inspector labels and restart notices support English, Korean, Japanese, German,
Spanish, French, Italian, Portuguese and Russian. Installation status indicates
configuration presence, not whether Codex has trusted or executed the hooks.

Async question requests stay in Permission until an actual answer, cancellation,
or a new turn. Their immediate `accepted` result is not a user answer, and results
from other tools do not resolve the pending question. Normal command/file approvals
still use the `PermissionRequest` hook. Explicit app-server approval/resolution
records are also understood when exposed by the monitored log source; not every
Codex build writes those records to rollout JSONL.

Questions, choices and permission approvals share the existing Permission
animation and LED. A narrowly matched PreToolUse hook also observes questions
called inside code mode, even when the outer rollout only records the code
tool. Partial answers to a multi-question request keep Permission until all
question items are answered. Unrelated tool output cannot resolve another
request. Hook setup automatically repairs older configurations; after updating
the plugin, show its status action and fully quit/reopen Codex so it loads the
updated hooks. Existing Codex hook trust/security settings are never bypassed.

For approval compatibility tests, state-only diagnostics appear as
`[Codex Approval]` in the COMBO-X console and in `approval_trace.jsonl` inside this
plugin's user-data directory. The file is capped at 2 MiB and never includes
questions, answers or command arguments. Set `COMBOX_CODEX_APPROVAL_TRACE=0` to
disable these diagnostics. This monitoring never approves requests, changes
Codex security/trust settings or sends automatic replies.

The former `com.cookie.ai_monitor` action IDs are retained so existing COMBO-X button assignments continue working after the plugin split. Existing AI Monitor user data is copied into the new `com.cookie.codex` data directory on first run.
