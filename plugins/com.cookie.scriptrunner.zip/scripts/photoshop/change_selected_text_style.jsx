#target photoshop

if (app.documents.length === 0) {
  alert("❌ 열린 문서가 없습니다.");
} else {
  var doc = app.activeDocument;
  var layer = doc.activeLayer;

  if (layer.kind !== LayerKind.TEXT) {
    alert("⚠ 선택된 레이어가 텍스트 레이어가 아닙니다.");
  } else {
    var textItem = layer.textItem;

    // === 사용자 설정값 ===
    var fontName = "Arial";       // 시스템에 설치된 폰트 이름
    var fontSize = 72;            // 포인트 단위
    var tracking = -25;           // 자간
    var leading = 0;              // 행간 (0이면 자동)
    var justification = Justification.CENTER;

    // === 적용 ===
    textItem.font = fontName;
    textItem.size = fontSize;
    textItem.tracking = tracking;
    textItem.justification = justification;

    if (leading > 0) {
      textItem.leading = leading;
    }

    alert("✅ 텍스트 스타일이 적용되었습니다:\n폰트: " + fontName + "\n크기: " + fontSize + "pt");
  }
}
