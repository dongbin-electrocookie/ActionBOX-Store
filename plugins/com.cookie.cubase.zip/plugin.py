import asyncio
import socket
import struct

try:
    import keyboard
except ImportError:
    keyboard = None

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        
        # 큐베이스 핵심 단축키 맵 (Numpad 및 숫자키 중심)
        self.hotkey_map = {
            # 트랜스포트
            "play_stop": "space",
            "record": "*",           # Numpad *
            "cycle": "/",            # Numpad /
            "rewind": "-",           # Numpad -
            "forward": "+",          # Numpad +
            "return_zero": ".",      # Numpad .
            "metronome": "c",
            
            # 툴 (1~8번 키)
            "tool_select": "1",
            "tool_range": "2",
            "tool_split": "3",
            "tool_glue": "4",
            "tool_erase": "5",
            "tool_zoom": "6",
            "tool_mute": "7",
            "tool_draw": "8",
            
            # 윈도우 뷰
            "mixconsole": "f3",
            "vst_instruments": "f11",
            "audio_connections": "f4",
            "video_player": "f8",
            "lower_zone": "ctrl+alt+e",
            
            # 편집
            "duplicate": "ctrl+d",
            "undo": "ctrl+z",
            "redo": "ctrl+shift+z",  # 큐베이스는 Shift가 들어감
            "quantize": "q",
            "snap": "j",
            "autoscroll": "f"
        }

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        settings = data.get("payload", {}).get("settings", {})
        mode = settings.get("control_mode", "hotkey")

        # 1. 단축키 모드
        if mode == "hotkey":
            if not keyboard: return
            action = settings.get("cubase_hotkey")
            if action in self.hotkey_map:
                hotkey = self.hotkey_map[action]
                await asyncio.to_thread(keyboard.send, hotkey)

        # 2. API (OSC) 모드
        elif mode == "osc":
            address = settings.get("osc_address", "").strip()
            val_str = settings.get("osc_value", "").strip()
            port = int(settings.get("osc_port", 8000))
            
            if not address: return
            if not address.startswith("/"): address = "/" + address

            value = None
            if val_str:
                try: value = int(val_str)
                except ValueError:
                    try: value = float(val_str)
                    except ValueError: value = val_str

            await asyncio.to_thread(self._send_simple_osc, "127.0.0.1", port, address, value)

    def _send_simple_osc(self, ip, port, address, value):
        """OSC 패킷 생성 및 전송"""
        try:
            def osc_pad(b_str):
                pad_len = 4 - (len(b_str) % 4)
                return b_str + (b'\x00' * pad_len)

            msg = osc_pad(address.encode('utf-8'))

            if value is None:
                msg += osc_pad(b',')
            elif isinstance(value, int):
                msg += osc_pad(b',i')
                msg += struct.pack('>i', value)
            elif isinstance(value, float):
                msg += osc_pad(b',f')
                msg += struct.pack('>f', value)
            elif isinstance(value, str):
                msg += osc_pad(b',s')
                msg += osc_pad(value.encode('utf-8'))

            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(msg, (ip, port))
            sock.close()
            print(f"[{self.uuid}] OSC Sent: {address} -> {value} (Port: {port})")

        except Exception as e:
            print(f"[{self.uuid}] OSC 전송 에러: {e}")