import asyncio
import urllib.request
import urllib.parse
import json
import os
from PIL import Image, ImageDraw, ImageFont

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.countries_cache = []
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        
        # 🚀 자동 갱신을 위한 타이머 변수
        self.active_buttons = {} # 화면에 떠있는 버튼들의 설정을 기억
        self.loop_started = False

    async def auto_update_loop(self):
        """15분(900초)마다 화면에 있는 모든 날씨 버튼을 자동 갱신합니다."""
        while True:
            await asyncio.sleep(900) 
            for context, settings in self.active_buttons.items():
                await self.update_weather_action(context, settings)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {})
        command = payload.get("command")
        context = data.get("context")
        settings = payload.get("settings", {})

        # 최초 1회: 15분 자동 갱신 루프 백그라운드 가동
        if not self.loop_started:
            self.loop_started = True
            asyncio.create_task(self.auto_update_loop())

        # 1. 앱을 켜서 버튼이 화면에 나타날 때 (켜자마자 최신 날씨로 그리기)
        if event == "willAppear":
            self.active_buttons[context] = settings
            await self.update_weather_action(context, settings)

        # 2. 버튼이 화면에서 사라질 때 (업데이트 목록에서 제외)
        elif event == "willDisappear":
            if context in self.active_buttons:
                del self.active_buttons[context]

        # 3. 사용자가 물리 버튼을 꾹 눌렀을 때 (수동 강제 새로고침)
        elif event == "keyDown":
            self.active_buttons[context] = settings
            await self.update_weather_action(context, settings)

        # 4. HTML 설정창과 통신할 때
        elif event == "sendToPlugin":
            if command == "get_countries":
                countries_data = await asyncio.to_thread(self._fetch_countries)
                await self.runner.send_message({
                    "event": "sendToPropertyInspector",
                    "context": context,
                    "payload": {"command": "countries_loaded", "data": countries_data}
                })
            # 🚀 콤보박스에서 도시나 단위를 바꿨을 때 (즉시 새로고침)
            elif command == "force_update":
                new_settings = payload.get("settings", {})
                self.active_buttons[context] = new_settings
                await self.update_weather_action(context, new_settings)

    def _fetch_countries(self):
        if self.countries_cache: return self.countries_cache
        try:
            req = urllib.request.Request("https://countriesnow.space/api/v0.1/countries", headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as res:
                data = json.loads(res.read().decode('utf-8'))
                if not data.get("error"):
                    self.countries_cache = data.get("data", [])
                    return self.countries_cache
        except Exception as e:
            print(f"[{self.uuid}] 국가 목록 가져오기 오류: {e}")
        return []

    def fetch_weather_image(self, city, units, context):
        """날씨 데이터를 가져와 128x128 이미지를 그린 뒤 경로를 반환합니다."""
        if not city or city == "도시 없음":
            return None

        try:
            safe_city = urllib.parse.quote(city)
            url = f"https://wttr.in/{safe_city}?format=j1"
            
            # API 응답 지연에 대비해 timeout을 10초로 넉넉하게!
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=10) as res:
                weather_data = json.loads(res.read().decode('utf-8'))

            current = weather_data['current_condition'][0]
            temp = current['temp_C'] if units == 'celsius' else current['temp_F']
            symbol = "°C" if units == 'celsius' else "°F"
            condition = current['weatherDesc'][0]['value'].lower()
            
            temp_str = f"{temp}{symbol}"

            if "rain" in condition or "shower" in condition or "drizzle" in condition:
                bg_color = (52, 73, 94)    
                kor_cond = "비 옴"
            elif "snow" in condition:
                bg_color = (149, 165, 166) 
                kor_cond = "눈 옴"
            elif "cloud" in condition or "overcast" in condition:
                bg_color = (127, 140, 141) 
                kor_cond = "흐림"
            elif "thunder" in condition or "storm" in condition:
                bg_color = (44, 62, 80)    
                kor_cond = "천둥/번개"
            else:
                bg_color = (41, 128, 185)  
                kor_cond = "맑음"

            img = Image.new('RGB', (128, 128), color=bg_color)
            draw = ImageDraw.Draw(img)

            try:
                font_city = ImageFont.truetype("malgun.ttf", 16)
                font_temp = ImageFont.truetype("malgunbd.ttf", 36)
                font_cond = ImageFont.truetype("malgun.ttf", 20)
            except:
                font_city = font_temp = font_cond = ImageFont.load_default()

            def draw_centered_text(y_pos, text, font, fill_color):
                try:
                    bbox = font.getbbox(text)
                    w = bbox[2] - bbox[0]
                except AttributeError:
                    w = len(text) * 10
                x_pos = (128 - w) / 2
                draw.text((x_pos, y_pos), text, font=font, fill=fill_color)

            display_city = city[:8] + ".." if len(city) > 8 else city
            draw_centered_text(10, display_city, font_city, (220, 220, 220))
            draw_centered_text(40, temp_str, font_temp, (255, 255, 255))
            draw_centered_text(95, kor_cond, font_cond, (241, 196, 15))

            save_path = os.path.join(self.plugin_dir, f"weather_{context}.png")
            img.save(save_path)
            return save_path

        except Exception as e:
            print(f"[{self.uuid}] 날씨 가져오기 오류: {e}")
            return None

    async def update_weather_action(self, context, settings):
        """실제로 화면에 로딩을 띄우고 이미지를 갱신하는 핵심 로직"""
        city = settings.get("city", "")
        units = settings.get("units", "celsius")

        if not city or city == "도시 없음":
            return

        # 로딩중 텍스트 표시
        await self.runner.send_message({
            "event": "setTitle",
            "context": context,
            "payload": {"title": "로딩중..."}
        })

        # 비동기 이미지 생성
        icon_path = await asyncio.to_thread(self.fetch_weather_image, city, units, context)

        # 갱신 완료 처리
        if icon_path:
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": ""}
            })
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })
        else:
            await self.runner.send_message({
                "event": "setTitle",
                "context": context,
                "payload": {"title": "날씨\n오류"}
            })