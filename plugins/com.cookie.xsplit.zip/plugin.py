"""XSplit control through the bundled XSplit-hosted XJS extension."""
import asyncio
import json
import os
import time
from pathlib import Path

import websockets
from websockets.legacy.server import serve


class BridgeError(Exception):
    def __init__(self, code, detail=""):
        super().__init__(detail or code)
        self.code = code
        self.detail = detail


class XSplitPlugin:
    BRIDGE_PORT = 47653
    BRIDGE_PATH = "/combox-xsplit"
    PROTOCOL = "combox-xsplit-v1"
    REQUEST_TIMEOUT = 12.0

    def __init__(self):
        self.PLUGIN_UUID = "com.cookie.xsplit"
        self.cd_uri = "ws://localhost:8765"
        self.cd_ws = None
        self.xs_ws = None
        self.is_connected = False
        self.bridge_error = ""
        self.req_id = 0
        self.pending_requests = {}
        self.xsplit_task = None
        self.server = None
        self._stopping = False
        self._jobs = set()
        self._action_lock = asyncio.Lock()
        self._pi_contexts = set()
        self.last_valid_settings = {}
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.icon_map = {
            "set_scene": "switch_scene",
            "toggle_source": "showhide_source",
            "set_preset": "apply_preset",
            "toggle_output": "startstop_streaming",
            "toggle_record": "startstop_recording",
            "toggle_mic": "toggle_microphone",
            "toggle_speaker": "toggle_speaker",
        }

    def _default_action(self):
        return "set_scene"

    def _merge_with_defaults(self, settings):
        source = dict(settings or {})
        # Read the supplied action BEFORE adding defaults; xs_action-only
        # manifest settings must never silently become microphone toggles.
        action = source.get("xs_action") or source.get("command") or self._default_action()
        merged = {
            "target_scene": "", "target_source": "", "target_preset": "",
            "target_output": "", "_lang": "en",
        }
        merged.update(source)
        merged.update(command=action, xs_action=action)
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if context:
            self.last_valid_settings[context] = self._merge_with_defaults(incoming_settings)
        # COMBO-X owns artwork and manual titles; never overwrite either here.

    async def _send_pi(self, context, payload):
        if self.cd_ws and context and not self._stopping:
            await self.cd_ws.send(json.dumps({
                "event": "sendToPropertyInspector", "context": context, "payload": payload
            }, ensure_ascii=False))

    def _status(self):
        return {
            "command": "bridgeStatus", "connected": self.is_connected,
            "errorCode": self.bridge_error,
            "extensionPath": str(Path(self.plugin_dir, "Combo-X Extend.html").resolve()),
            "extensionUrl": Path(self.plugin_dir, "Combo-X Extend.html").resolve().as_uri(),
            "port": self.BRIDGE_PORT,
        }

    async def _publish_status(self):
        for context in tuple(self._pi_contexts):
            try:
                await self._send_pi(context, self._status())
            except Exception as exc:
                print(f"[XSplit] Status delivery failed: {exc}", flush=True)

    def _schedule(self, coroutine):
        task = asyncio.create_task(coroutine)
        self._jobs.add(task)
        task.add_done_callback(self._jobs.discard)
        task.add_done_callback(self._job_finished)

    @staticmethod
    def _job_finished(task):
        if not task.cancelled():
            error = task.exception()
            if error:
                print(f"[XSplit] Request failed: {error}", flush=True)

    async def start_bridge(self):
        while not self._stopping:
            try:
                # Loopback only. Ordinary websites may not connect. Clients
                # can only return replies; they cannot submit host commands.
                async with serve(
                    self._accept_extension, "127.0.0.1", self.BRIDGE_PORT,
                    origins=[None, "null", "file://"],
                    max_size=1024 * 1024, ping_interval=10, ping_timeout=10
                ) as server:
                    self.server = server
                    self.bridge_error = ""
                    await self._publish_status()
                    await asyncio.Future()
            except OSError as exc:
                self.bridge_error = "ERR_PORT_BUSY"
                print(f"[XSplit] Bridge could not listen on {self.BRIDGE_PORT}: {exc}", flush=True)
                await self._publish_status()
                await asyncio.sleep(3)
            finally:
                self.server = None

    async def _accept_extension(self, ws):
        if ws.path != self.BRIDGE_PATH:
            await ws.close(code=1008, reason="Invalid bridge path")
            return
        try:
            hello = json.loads(await asyncio.wait_for(ws.recv(), timeout=5))
            if (not isinstance(hello, dict) or hello.get("event") != "hello" or hello.get("protocol") != self.PROTOCOL
                    or hello.get("role") != "xsplit-extension"):
                await ws.close(code=1008, reason="Invalid extension handshake")
                return
            if self.xs_ws is not None:
                await ws.close(code=1008, reason="An extension is already connected")
                return
            self.xs_ws = ws
            self.is_connected = True
            self.bridge_error = ""
            await ws.send(json.dumps({"event": "welcome", "protocol": self.PROTOCOL}))
            await self._publish_status()
            print("[XSplit] COMBO-X extension connected.", flush=True)
            async for raw in ws:
                data = json.loads(raw)
                if not isinstance(data, dict) or data.get("event") != "response":
                    continue
                pending = self.pending_requests.get(data.get("asyncId"))
                if pending and pending[1] is ws and not pending[0].done():
                    pending[0].set_result(data)
        except (websockets.ConnectionClosed, asyncio.TimeoutError, ValueError, TypeError):
            pass
        finally:
            if self.xs_ws is ws:
                self.xs_ws = None
                self.is_connected = False
                for future, peer in tuple(self.pending_requests.values()):
                    if peer is ws and not future.done():
                        future.set_exception(BridgeError("ERR_DISCONNECTED"))
                await self._publish_status()

    async def send_to_xsplit(self, event, payload=None):
        peer = self.xs_ws
        if not self.is_connected or peer is None:
            raise BridgeError(self.bridge_error or "ERR_NOT_CONNECTED")
        self.req_id += 1
        req_id = self.req_id
        future = asyncio.get_running_loop().create_future()
        self.pending_requests[req_id] = (future, peer)
        try:
            await peer.send(json.dumps({
                "event": "request", "asyncId": req_id, "command": event,
                "payload": payload or {},
                "deadline": int((time.time() + self.REQUEST_TIMEOUT) * 1000),
            }))
            response = await asyncio.wait_for(future, timeout=self.REQUEST_TIMEOUT)
            if not response.get("ok"):
                raise BridgeError(response.get("errorCode") or "ERR_API", response.get("detail", ""))
            return response.get("payload") or {}
        except asyncio.TimeoutError as exc:
            # Never retry toggles: the first request may already have executed.
            raise BridgeError("ERR_TIMEOUT") from exc
        except websockets.ConnectionClosed as exc:
            raise BridgeError("ERR_DISCONNECTED") from exc
        finally:
            self.pending_requests.pop(req_id, None)

    async def on_pi_request(self, payload, context):
        command = payload.get("command")
        if not context:
            return
        self._pi_contexts.add(context)
        if command == "getBridgeStatus":
            await self._send_pi(context, self._status())
            return
        if command == "copyExtensionPath":
            try:
                import pyperclip
                await asyncio.to_thread(pyperclip.copy, self._status()["extensionUrl"])
                await self._send_pi(context, {"command": "pathCopied", "requestId": payload.get("requestId")})
            except Exception as exc:
                await self._send_pi(context, {
                    "command": "actionError", "errorCode": "ERR_COPY", "detail": str(exc),
                    "requestId": payload.get("requestId")
                })
            return
        requests = {
            "getSceneList": ("getAllScenes", "sceneList", "scenes"),
            "getSourceList": ("getSceneSources", "sourceList", "sources"),
            "getPresetList": ("getScenePresets", "presetList", "presets"),
            "getOutputList": ("getAllOutputs", "outputList", "outputs"),
        }
        if command not in requests:
            return
        api_command, response_command, field = requests[command]
        reply = {
            "command": response_command, field: [],
            "sceneId": payload.get("sceneId", ""), "requestId": payload.get("requestId"),
        }
        try:
            result = await self.send_to_xsplit(api_command, {"sceneId": payload.get("sceneId", "")})
            reply[field] = result.get(field, [])
        except BridgeError as exc:
            reply.update(errorCode=exc.code, detail=exc.detail)
        if context in self._pi_contexts:
            await self._send_pi(context, reply)

    async def on_key_down(self, data):
        context = data.get("context")
        saved = self.last_valid_settings.get(context)
        if saved is None:
            return
        incoming = (data.get("payload") or {}).get("settings") or {}
        settings = self._merge_with_defaults({**saved, **incoming})
        queued_at = time.monotonic()
        async with self._action_lock:
            # Lifecycle messages remain dispatchable while I/O is pending.
            if (self.last_valid_settings.get(context) is not saved
                    or time.monotonic() - queued_at > self.REQUEST_TIMEOUT):
                return
            action = settings["xs_action"]
            commands = {
                "set_scene": ("setActiveScene", {"id": settings["target_scene"]}, ("target_scene",)),
                "toggle_source": ("toggleSourceState", {
                    "sceneId": settings["target_scene"], "sourceId": settings["target_source"]
                }, ("target_scene", "target_source")),
                "set_preset": ("setActivePreset", {
                    "sceneId": settings["target_scene"], "presetId": settings["target_preset"]
                }, ("target_scene", "target_preset")),
                "toggle_output": ("toggleOutputState", {
                    "id": settings["target_output"], "kind": "stream"
                }, ("target_output",)),
                "toggle_record": ("toggleOutputState", {
                    "id": settings["target_output"], "kind": "record"
                }, ("target_output",)),
                "toggle_mic": ("toggleMicrophoneState", {}, ()),
                "toggle_speaker": ("toggleSpeakerState", {}, ()),
            }
            try:
                if action not in commands:
                    raise BridgeError("ERR_UNSUPPORTED")
                command, args, required = commands[action]
                if any(not settings.get(field) for field in required):
                    raise BridgeError("ERR_SELECT_TARGET")
                await self.send_to_xsplit(command, args)
                reply = {"command": "actionResult", "action": action}
            except BridgeError as exc:
                reply = {
                    "command": "actionError", "action": action,
                    "errorCode": exc.code, "detail": exc.detail,
                }
                print(f"[XSplit] {action}: {exc.code} {exc.detail}", flush=True)
            if self.last_valid_settings.get(context) is saved:
                await self._send_pi(context, reply)

    async def handle_message(self, data):
        event = data.get("event")
        context = data.get("context")
        payload = data.get("payload") or {}
        if event in ("willAppear", "keyDidAppear"):
            await self._initialize_default_visuals_if_new(context, payload.get("settings") or {})
        elif event == "didReceiveSettings" and context:
            settings = payload.get("settings", payload) or {}
            self.last_valid_settings[context] = self._merge_with_defaults({
                **self.last_valid_settings.get(context, {}), **settings
            })
        elif event in ("keyDidDisappear", "willDisappear"):
            self.last_valid_settings.pop(context, None)
            self._pi_contexts.discard(context)
        elif event == "sendToPlugin":
            self._schedule(self.on_pi_request(payload, context))
        elif event == "keyDown":
            self._schedule(self.on_key_down(data))

    async def shutdown(self):
        self._stopping = True
        self._pi_contexts.clear()
        self.last_valid_settings.clear()
        for task in tuple(self._jobs):
            task.cancel()
        await asyncio.gather(*tuple(self._jobs), return_exceptions=True)
        if self.xsplit_task:
            self.xsplit_task.cancel()
            await asyncio.gather(self.xsplit_task, return_exceptions=True)
        if self.xs_ws:
            await self.xs_ws.close()
        self.xs_ws = None
        self.is_connected = False

    async def connect(self):
        self.xsplit_task = asyncio.create_task(self.start_bridge())
        try:
            while True:
                try:
                    async with websockets.connect(self.cd_uri) as ws:
                        self.cd_ws = ws
                        await ws.send(json.dumps({"event": "register", "uuid": self.PLUGIN_UUID}))
                        async for raw in ws:
                            await self.handle_message(json.loads(raw))
                except (websockets.ConnectionClosed, OSError):
                    await asyncio.sleep(3)
                finally:
                    self.cd_ws = None
        finally:
            await self.shutdown()


class Plugin(XSplitPlugin):
    """COMBO-X shared-runtime entry point."""

    def __init__(self, runner, manifest):
        super().__init__()
        self.runner = runner
        self.uuid = manifest["UUID"]
        self.cd_ws = runner
        self.xsplit_task = asyncio.create_task(self.start_bridge())


async def main():
    await XSplitPlugin().connect()


if __name__ == "__main__":
    asyncio.run(main())
