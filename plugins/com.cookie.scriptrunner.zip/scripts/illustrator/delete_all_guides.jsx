#target illustrator

if (app.documents.length === 0) {
    alert("열린 문서가 없습니다.");
} else {
    var doc = app.activeDocument;
    var removed = 0;
    for (var i = doc.pathItems.length - 1; i >= 0; i--) {
        if (doc.pathItems[i].guides) {
            try {
                doc.pathItems[i].locked = false;
                doc.pathItems[i].hidden = false;
                doc.pathItems[i].remove();
                removed++;
            } catch (ignore) {}
        }
    }
    alert(removed + "개 가이드 삭제 완료.");
}
