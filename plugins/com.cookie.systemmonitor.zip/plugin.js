const WebSocket = require('ws');
const { Worker, isMainThread, parentPort } = require('worker_threads');
const { execFile, spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

const args = {};
for (let i = 2; i < process.argv.length; i += 2) args[process.argv[i]] = process.argv[i + 1];
const port = args['-port'] || '8765';
const pluginUUID = args['-pluginUUID'] || 'com.cookie.systemmonitor';
const registerEvent = args['-registerEvent'] || 'register';
const uri = `ws://localhost:${port}`;

let activeKeys = {};
let cookieDeckSocket = null;
let reconnectAttempts = 0;
let pollInFlight = false;
const MAX_RETRIES = 5;
const IS_WINDOWS = process.platform === 'win32';
const WORKER_TIMEOUT_MS = 1500;

const lhmPath = path.resolve(__dirname, 'LibreHardwareMonitor', 'LibreHardwareMonitor.exe');
const exeName = "LibreHardwareMonitor.exe";
const DEFAULT_METRIC = 'cpu_usage';

const iconMap = {
  cpu_usage:'STATE_CPU_USAGE', memory_usage:'STATE_MEMORY_USAGE', gpu_temp:'STATE_GPU_TEMP',
  gpu_usage:'STATE_GPU_USAGE', network_upload:'STATE_NETWORK_UPLOAD', network_download:'STATE_NETWORK_DOWNLOAD',
  cpu_power:'STATE_CPU_POWER', gpu_power:'STATE_GPU_POWER'
};

const i18n = {
  en:{cpu_usage:'CPU',memory_usage:'RAM',gpu_temp:'GPU',gpu_usage:'GPU',cpu_temp:'CPU',cpu_power:'CPU',gpu_power:'GPU',network_upload:'UP',network_download:'DN'},
  ko:{cpu_usage:'CPU',memory_usage:'RAM',gpu_temp:'GPU',gpu_usage:'GPU',cpu_temp:'CPU',cpu_power:'CPU',gpu_power:'GPU',network_upload:'업',network_download:'다운'},
  ja:{cpu_usage:'CPU',memory_usage:'RAM',gpu_temp:'GPU',gpu_usage:'GPU',cpu_temp:'CPU',cpu_power:'CPU',gpu_power:'GPU',network_upload:'UP',network_download:'DN'},
  de:{cpu_usage:'CPU',memory_usage:'RAM',gpu_temp:'GPU',gpu_usage:'GPU',cpu_temp:'CPU',cpu_power:'CPU',gpu_power:'GPU',network_upload:'UP',network_download:'DN'},
  es:{cpu_usage:'CPU',memory_usage:'RAM',gpu_temp:'GPU',gpu_usage:'GPU',cpu_temp:'CPU',cpu_power:'CPU',gpu_power:'GPU',network_upload:'SUB',network_download:'BAJ'},
  fr:{cpu_usage:'CPU',memory_usage:'RAM',gpu_temp:'GPU',gpu_usage:'GPU',cpu_temp:'CPU',cpu_power:'CPU',gpu_power:'GPU',network_upload:'UP',network_download:'DL'},
  ru:{cpu_usage:'CPU',memory_usage:'RAM',gpu_temp:'GPU',gpu_usage:'GPU',cpu_temp:'CPU',cpu_power:'CPU',gpu_power:'GPU',network_upload:'ВВ',network_download:'ЗАГ'},
  it:{cpu_usage:'CPU',memory_usage:'RAM',gpu_temp:'GPU',gpu_usage:'GPU',cpu_temp:'CPU',cpu_power:'CPU',gpu_power:'GPU',network_upload:'UP',network_download:'DN'},
  'pt-PT':{cpu_usage:'CPU',memory_usage:'RAM',gpu_temp:'GPU',gpu_usage:'GPU',cpu_temp:'CPU',cpu_power:'CPU',gpu_power:'GPU',network_upload:'UP',network_download:'DN'}
};
const unsupportedText = {
  en: "Win\nOnly",
  ko: "윈도우\n전용",
  ja: "Win\n専用",
  de: "Nur\nWin",
  es: "Solo\nWin",
  fr: "Win\nseul",
  ru: "Только\nWin",
  it: "Solo\nWin",
  'pt-PT': "So\nWin"
};

function normLang(v) {
  const code = String(v || 'en').toLowerCase();
  const alias = { pt: 'pt-PT', kr: 'ko', jp: 'ja' };
  const normalized = alias[code] || code;
  return i18n[normalized] ? normalized : 'en';
}

function getDefaultSettings() {
  return {
    selected_metric: DEFAULT_METRIC,
    command: DEFAULT_METRIC,
    _lang: 'en',
    sync_title_on_action_change: false,
    builtin_icon_name: iconMap[DEFAULT_METRIC],
    default_visuals_initialized: true
  };
}

function mergeWithDefaults(settings) {
  const merged = { ...getDefaultSettings(), ...(settings || {}) };
  const metric = merged.command || merged.selected_metric || DEFAULT_METRIC;
  merged.selected_metric = metric;
  merged.command = metric;
  merged.builtin_icon_name = iconMap[metric] || iconMap[DEFAULT_METRIC];
  return merged;
}

function hasMeaningfulSettings(settings) {
  const s = settings || {};
  return !!(s.command || s.selected_metric || s.builtin_icon_name || s.default_visuals_initialized || s.sync_title_on_action_change || s.title);
}

function getIconPath(metric) {
  const iconName = iconMap[metric || DEFAULT_METRIC] || iconMap[DEFAULT_METRIC];
  return path.join(__dirname, 'icon', `${iconName}.png`);
}

function sendBuiltinIcon(context, metric) {
  if (!cookieDeckSocket || cookieDeckSocket.readyState !== WebSocket.OPEN || !context) return;
  const iconPath = getIconPath(metric);
  if (!fs.existsSync(iconPath)) return;
  cookieDeckSocket.send(JSON.stringify({ event: "setIcon", context, payload: { icon_path: iconPath } }));
}

function launchLHM() {
  if (!IS_WINDOWS) return;
  if (fs.existsSync(lhmPath)) {
    execFile('tasklist', ['/FI', `IMAGENAME eq ${exeName}`, '/NH'], (err, stdout) => {
      if (stdout && stdout.includes(exeName)) console.log("[SysMon] LibreHardwareMonitor is already running.");
      else {
        try {
          const child = spawn(lhmPath, [], { detached: true, stdio: 'ignore' });
          child.on('error', () => {});
          child.unref();
        } catch (e) {}
      }
    });
  }
}

if (isMainThread) {
  launchLHM();

  setInterval(() => {
    if (!IS_WINDOWS || pollInFlight || Object.keys(activeKeys).length === 0) return;
    pollInFlight = true;
    const worker = new Worker(__filename);
    const timer = setTimeout(() => worker.terminate(), WORKER_TIMEOUT_MS);
    worker.on('message', (data) => {
      if (data.error) return;
      if (cookieDeckSocket && cookieDeckSocket.readyState === WebSocket.OPEN && data.result) updateDynamicContent(data.result);
    });
    worker.on('error', () => {});
    worker.on('exit', () => {
      clearTimeout(timer);
      pollInFlight = false;
    });
  }, 1000);

  function initializeDefaultVisualsIfNew(context, payload) {
    const incomingSettings = (payload && payload.settings) || {};
    const merged = mergeWithDefaults(incomingSettings);
    const lang = normLang(merged._lang);

    activeKeys[context] = { page: payload ? payload.page : undefined, metric: merged.command || merged.selected_metric || DEFAULT_METRIC, lang };

    if (!hasMeaningfulSettings(incomingSettings)) {
      const defaults = getDefaultSettings();
      activeKeys[context].metric = defaults.command;
      activeKeys[context].lang = normLang(defaults._lang);
      if (cookieDeckSocket && cookieDeckSocket.readyState === WebSocket.OPEN) {
        cookieDeckSocket.send(JSON.stringify({ event: "setSettings", context, payload: defaults }));
      }
      sendBuiltinIcon(context, defaults.command);
      return false;
    }
    sendBuiltinIcon(context, merged.command);
    return true;
  }

  function connectToCookieDeck() {
    cookieDeckSocket = new WebSocket(uri);

    cookieDeckSocket.on('open', () => {
      reconnectAttempts = 0;
      cookieDeckSocket.send(JSON.stringify({ event: registerEvent, uuid: pluginUUID }));
    });

    cookieDeckSocket.on('message', (message) => {
      const data = JSON.parse(message);
      const context = data.context;
      const payload = data.payload || {};

      if (data.event === 'keyDidAppear') {
        initializeDefaultVisualsIfNew(context, payload);
        if (!IS_WINDOWS) updateUnsupportedContent(context);
      } else if (data.event === 'keyDidDisappear' || data.event === 'willDisappear') {
        delete activeKeys[context];
      } else if (data.event === 'didReceiveSettings') {
        const merged = mergeWithDefaults(data.payload || {});
        const prevMetric = activeKeys[context] ? activeKeys[context].metric : null;
        if (!activeKeys[context]) activeKeys[context] = { page: undefined, metric: merged.command, lang: normLang(merged._lang) };
        else {
          activeKeys[context].metric = merged.command;
          activeKeys[context].lang = normLang(merged._lang);
        }
        if (prevMetric !== merged.command) sendBuiltinIcon(context, merged.command);
        if (!IS_WINDOWS) updateUnsupportedContent(context);
      } else if (data.event === 'sendToPlugin') {
        const innerPayload = payload.payload || payload;
        const command = innerPayload.command || payload.command;
        if (command === 'apply_builtin_icon') {
          const metric = innerPayload.metric || (activeKeys[context] ? activeKeys[context].metric : DEFAULT_METRIC);
          sendBuiltinIcon(context, metric);
        }
      } else if (data.event === 'keyDown') {
        const merged = mergeWithDefaults(payload.settings || {});
        if (!activeKeys[context]) activeKeys[context] = { page: payload.page, metric: merged.command, lang: normLang(merged._lang) };
        else {
          activeKeys[context].metric = merged.command;
          activeKeys[context].lang = normLang(merged._lang);
        }
        if (!IS_WINDOWS) updateUnsupportedContent(context);
      }
    });

    cookieDeckSocket.on('close', () => {
      reconnectAttempts++;
      if (reconnectAttempts <= MAX_RETRIES) setTimeout(connectToCookieDeck, 2000);
      else process.exit(0);
    });

    cookieDeckSocket.on('error', () => {});
  }

  function updateDynamicContent(parsedData) {
    for (const context in activeKeys) {
      const keyInfo = activeKeys[context];
      const metric = keyInfo.metric;
      const lang = normLang(keyInfo.lang);
      const labels = i18n[lang] || i18n.en;
      let textContent = "N/A";

      switch(metric) {
        case "cpu_usage": textContent = `${labels.cpu_usage}\n${parsedData.cpu_load}%`; break;
        case "memory_usage": textContent = `${labels.memory_usage}\n${parsedData.mem_percent}%`; break;
        case "gpu_temp": textContent = `${labels.gpu_temp}\n${parsedData.gpu_temp}°C`; break;
        case "gpu_usage": textContent = `${labels.gpu_usage}\n${parsedData.gpu_load}%`; break;
        case "cpu_temp": textContent = `${labels.cpu_temp}\n${parsedData.cpu_temp}°C`; break;
        case "cpu_power": textContent = `${labels.cpu_power}\n${parsedData.cpu_power}W`; break;
        case "gpu_power": textContent = `${labels.gpu_power}\n${parsedData.gpu_power}W`; break;
        case "network_upload": textContent = `${labels.network_upload}\n${parsedData.net_upload}`; break;
        case "network_download": textContent = `${labels.network_download}\n${parsedData.net_download}`; break;
      }

      cookieDeckSocket.send(JSON.stringify({
        event: "setDynamicText",
        context: context,
        payload: { text: textContent, font_size: "24px", color: "#FFFFFF", page: keyInfo.page }
      }));
    }
  }

  function updateUnsupportedContent(context) {
    if (!cookieDeckSocket || cookieDeckSocket.readyState !== WebSocket.OPEN || !context) return;
    const keyInfo = activeKeys[context] || {};
    const lang = normLang(keyInfo.lang);
    cookieDeckSocket.send(JSON.stringify({
      event: "setDynamicText",
      context: context,
      payload: { text: unsupportedText[lang] || unsupportedText.en, font_size: "22px", color: "#FFFFFF", page: keyInfo.page }
    }));
  }

  connectToCookieDeck();

} else {
  const axios = require('axios');

  function getLocalIpAddress() {
    const interfaces = os.networkInterfaces();
    for (const name in interfaces) {
      for (const iface of interfaces[name]) {
        if (iface.family === 'IPv4' && !iface.internal) return iface.address;
      }
    }
    return 'localhost';
  }

  const cleanValue = (valStr) => {
    if (!valStr || valStr === "-" || valStr === "N/A") return "0";
    const num = parseFloat(valStr);
    return isNaN(num) ? "0" : num.toFixed(0);
  };

  const findValue = (hardwareNodes, imgKeywords, categoryText, sensorKeywords) => {
    for (const hw of hardwareNodes) {
      const img = (hw.ImageURL || "").toLowerCase();
      if (imgKeywords.some(k => img.includes(k))) {
        const cat = hw.Children?.find(c => c.Text === categoryText);
        if (cat?.Children) {
          for (const kw of sensorKeywords) {
            const sensor = cat.Children.find(s => s.Text.includes(kw));
            if (sensor) return sensor.Value;
          }
        }
      }
    }
    return "0";
  };

  const findNetwork = (hardwareNodes, type) => {
    const nic = hardwareNodes.find(hw => (hw.ImageURL || "").includes("nic"));
    const throughput = nic?.Children?.find(c => c.Text === "Throughput");
    const sensor = throughput?.Children?.find(s => s.Text.includes(type));
    return sensor ? sensor.Value.split('/')[0].replace(" ", "") : "0";
  };

  const fetchData = async () => {
    try {
      const url = `http://${getLocalIpAddress()}:8085/data.json`;
      const response = await axios.get(url, { timeout: 900 });
      const hardwareNodes = response.data?.Children?.[0]?.Children || [];
      parentPort.postMessage({ result: {
        cpu_load: cleanValue(findValue(hardwareNodes, ['cpu'], 'Load', ['CPU Total'])),
        mem_percent: cleanValue(findValue(hardwareNodes, ['ram'], 'Load', ['Memory'])),
        gpu_temp: cleanValue(findValue(hardwareNodes, ['gpu'], 'Temperatures', ['GPU Core'])),
        gpu_load: cleanValue(findValue(hardwareNodes, ['gpu'], 'Load', ['GPU Core'])),
        cpu_temp: cleanValue(findValue(hardwareNodes, ['cpu'], 'Temperatures', ['Package', 'Core Max'])),
        cpu_power: cleanValue(findValue(hardwareNodes, ['cpu'], 'Powers', ['Package'])),
        gpu_power: cleanValue(findValue(hardwareNodes, ['gpu'], 'Powers', ['GPU Power'])),
        net_upload: findNetwork(hardwareNodes, 'Upload'),
        net_download: findNetwork(hardwareNodes, 'Download')
      }});
    } catch (e) {
      parentPort.postMessage({ error: e.message });
    }
  };
  fetchData();
}
