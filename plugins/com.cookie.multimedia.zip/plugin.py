import asyncio
import os
import sys

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard = None
    keyboard_available = False

try:
    import pyautogui
    pyautogui_available = True
except ImportError:
    pyautogui = None
    pyautogui_available = False

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        # Windows는 기존 keyboard 모듈의 미디어키 이름을 유지합니다.
        self.windows_action_map = {
            "volume_up": "volume up",
            "volume_down": "volume down",
            "mute": "volume mute",
            "play_pause": "play/pause media",
            "next_track": "next track",
            "prev_track": "previous track",
        }

        # macOS/Linux fallback은 pyautogui의 미디어키 이름을 사용합니다.
        self.pyautogui_action_map = {
            "volume_up": "volumeup",
            "volume_down": "volumedown",
            "mute": "volumemute",
            "play_pause": "playpause",
            "next_track": "nexttrack",
            "prev_track": "prevtrack",
        }

        self.icon_map = {
            "play_pause": "PLAY_PAUSE",
            "next_track": "NEXT_TRACK",
            "prev_track": "PREV_TRACK",
            "mute": "MUTE",
            "volume_up": "VOL_UP",
            "volume_down": "VOL_DOWN",
        }

    def _default_action(self):
        return "play_pause"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or self._default_action()
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    def _run_media_action(self, action_name):
        if IS_WINDOWS and keyboard_available:
            key_name = self.windows_action_map.get(action_name)
            if key_name:
                keyboard.send(key_name)
                return

        if pyautogui_available:
            key_name = self.pyautogui_action_map.get(action_name)
            if key_name:
                pyautogui.press(key_name)
                return

        print(f"[{self.uuid}] Media key backend unavailable: {action_name}")

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            await self._send_builtin_icon(context, action_command or settings.get("command") or cached.get("command") or self._default_action())
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        final_settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = final_settings

        selected_action = final_settings.get("command") or self._default_action()
        if selected_action in self.icon_map:
            await asyncio.to_thread(self._run_media_action, selected_action)
        else:
            print(f"[{self.uuid}] Unknown action: {selected_action}")
