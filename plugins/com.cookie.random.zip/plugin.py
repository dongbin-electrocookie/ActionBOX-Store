import asyncio
import random
import base64
import io
from PIL import Image, ImageDraw, ImageFont

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest.get('UUID', 'com.cookie.random')

    async def handle_message(self, data):
        if data.get("event") == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        context = data.get("context")
        settings = data.get("payload", {}).get("settings", {})
        
        # 스레드에서 이미지 생성 및 Base64 인코딩
        b64_image = await asyncio.to_thread(self.run_random_game, settings)
        
        if b64_image:
            await self.runner.send_message({"event": "setImage", "context": context, "payload": {"image": b64_image}})

    def run_random_game(self, settings):
        """설정에 따라 다른 랜덤 게임을 실행하고 결과 이미지를 생성합니다."""
        mode = settings.get("game_mode", "d6")
        
        # --- 게임 로직 실행 ---
        if mode == "d6":
            result_text = str(random.randint(1, 6))
            return self.create_dice_image(result_text, (231, 76, 60)) # 빨간색
        elif mode == "d20":
            result_text = str(random.randint(1, 20))
            return self.create_dice_image(result_text, (41, 128, 185)) # 파란색
        elif mode == "coin":
            result_text = random.choice(["앞면", "뒷면"])
            return self.create_text_image(result_text, "🪙", (241, 196, 15)) # 노란색
        elif mode == "magic_conch":
            answers = ["안 돼.", "다시 한번.", "가만히 있어.", "그것도 안 돼.", "물론!", "언젠가는..."]
            result_text = random.choice(answers)
            return self.create_text_image(result_text, "🐚", (142, 68, 173)) # 보라색
        elif mode == "custom_roulette":
            items_str = settings.get("roulette_items", "항목 없음")
            items = [item.strip() for item in items_str.split(',') if item.strip()]
            result_text = random.choice(items) if items else "항목 없음"
            return self.create_text_image(result_text, "🎯", (26, 188, 156)) # 청록색
        elif mode == "russian_roulette":
            if random.randint(1, 6) == 1:
                return self.create_text_image("탕!!!", "💥", (192, 57, 43), large_font=True)
            else:
                return self.create_text_image("찰칵!", "😌", (46, 204, 113)) # 녹색
        elif mode == "gacha":
            rand_val = random.random()
            if rand_val < 0.05: result, color = "LEGENDARY", (255, 215, 0)
            elif rand_val < 0.20: result, color = "EPIC", (155, 89, 182)
            elif rand_val < 0.50: result, color = "RARE", (52, 152, 219)
            else: result, color = "NORMAL", (149, 165, 166)
            return self.create_text_image(result, "✨", color, large_font=True)
        elif mode == "rps":
            choices = {"가위": "✌️", "바위": "✊", "보": "✋"}
            result = random.choice(list(choices.keys()))
            return self.create_text_image(result, choices[result], (230, 126, 34))
            
        return None

    # --- 이미지 생성 헬퍼 함수들 ---
    def get_font(self, font_name, size):
        try: return ImageFont.truetype(font_name, size)
        except: return ImageFont.load_default()

    def create_dice_image(self, text, bg_color):
        """주사위 전용 이미지"""
        img = Image.new('RGB', (128, 128), color=bg_color)
        draw = ImageDraw.Draw(img)
        font = self.get_font("malgunbd.ttf", 80)
        
        try: w = draw.textlength(text, font=font)
        except: w = len(text) * 40
        draw.text(((128-w)/2, 10), text, font=font, fill=(255,255,255))
        
        return self._image_to_base64(img)

    def create_text_image(self, text, icon, bg_color, large_font=False):
        """일반 텍스트 + 아이콘 이미지"""
        img = Image.new('RGB', (128, 128), color=bg_color)
        draw = ImageDraw.Draw(img)
        
        font_icon = self.get_font("seguiemj.ttf", 40) # 윈도우 이모지 폰트
        font_text = self.get_font("malgunbd.ttf", 22 if not large_font else 28)
        
        # 텍스트가 너무 길면 자동으로 줄바꿈
        if len(text) > 8:
            parts = text.split(' ')
            if len(parts) > 1:
                mid = len(parts) // 2
                text = " ".join(parts[:mid]) + "\n" + " ".join(parts[mid:])

        # 아이콘
        try: w = draw.textlength(icon, font=font_icon)
        except: w = 40
        draw.text(((128-w)/2, 15), icon, font=font_icon, fill=(255,255,255))
        
        # 텍스트
        try: w = draw.textlength(text, font=font_text)
        except: w = len(text) * 10
        draw.text(((128-w)/2, 70), text, font=font_text, fill=(255,255,255), align="center")

        return self._image_to_base64(img)

    def _image_to_base64(self, img):
        """PIL 이미지를 Base64 문자열로 변환"""
        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        return f"data:image/png;base64,{base64.b64encode(buffered.getvalue()).decode('utf-8')}"