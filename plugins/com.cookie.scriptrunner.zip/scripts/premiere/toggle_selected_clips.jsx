#target premierepro
(function () {
    var sequence = app.project.activeSequence;
    if (!sequence) {
        alert("Open a sequence first.");
        return;
    }
    var clips = sequence.getSelection();
    if (!clips || clips.length === 0) {
        alert("Select at least one clip.");
        return;
    }
    for (var i = 0; i < clips.length; i++) {
        clips[i].disabled = !clips[i].disabled;
    }
}());
