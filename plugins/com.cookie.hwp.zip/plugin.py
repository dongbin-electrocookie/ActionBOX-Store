import asyncio
import os
import sys

try:
    import keyboard
except ImportError:
    print("[Warning] keyboard library is missing. Windows hotkey fallback will use pyautogui.")
    keyboard = None

try:
    import pyautogui
except ImportError:
    print("[Error] pyautogui library is missing. pip install pyautogui")
    pyautogui = None

IS_WINDOWS = sys.platform.startswith("win")
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        # Windows용 한컴오피스/한글 단축키
        self.windows_action_map = {
            "font_shape": "alt+l",
            "paragraph_shape": "alt+t",
            "font_size_up": "ctrl+]",
            "font_size_down": "ctrl+[",
            "widen_tracking": "alt+shift+w",
            "narrow_tracking": "alt+shift+n",
            "create_table": "ctrl+n,t",
            "cell_properties": "enter",
            "add_row_col": "alt+insert",
            "delete_row_col": "alt+delete",
            "merge_cells": "m",
            "split_cells": "s",
            "set_height_equal": "h",
            "set_width_equal": "w",
            "find_replace_pro": "ctrl+q,a",
            "spell_check": "f8",
            "hanja_convert": "f9",
            "special_chars": "ctrl+f10",
            "copy_format": "alt+c",
            "paste_format": "alt+v",
            "toggle_page_layout": "ctrl+g,g",
            "toggle_control_codes": "ctrl+g,c",
        }

        # macOS용 한글 단축키
        # 한컴 macOS 단축키는 Adobe처럼 Ctrl을 전부 Command로 바꾸는 구조가 아닙니다.
        # Option(Alt) 계열과 Control 계열이 섞여 있어서 액션별로 따로 둡니다.
        self.macos_action_map = {
            "font_shape": "command+l",
            "paragraph_shape": "option+t",
            "font_size_up": "ctrl+]",
            "font_size_down": "ctrl+[",
            "widen_tracking": "option+shift+w",
            "narrow_tracking": "ctrl+shift+i",
            "create_table": "ctrl+n,t",
            "cell_properties": "p",
            "add_row_col": "option+insert",
            "delete_row_col": "option+delete",
            "merge_cells": "m",
            "split_cells": "s",
            "set_height_equal": "h",
            "set_width_equal": "w",
            "find_replace_pro": "ctrl+q,a",
            "spell_check": "f8",
            "hanja_convert": "f9",
            "special_chars": "command+ctrl+f10",
            "copy_format": "option+c",
            "paste_format": "option+v",
            "toggle_page_layout": "ctrl+g,l",
            "toggle_control_codes": "ctrl+g,c",
        }

        self.action_map = self.macos_action_map if IS_MACOS else self.windows_action_map

        self.icon_map = {
            "font_shape": "FONT_SHAPE",
            "paragraph_shape": "PARAGRAPH_SHAPE",
            "font_size_up": "FONT_SIZE_UP",
            "font_size_down": "FONT_SIZE_DOWN",
            "widen_tracking": "WIDEN_TRACKING",
            "narrow_tracking": "NARROW_TRACKING",
            "create_table": "CREATE_TABLE",
            "cell_properties": "CELL_PROPERTIES",
            "add_row_col": "ADD_ROW_COL",
            "delete_row_col": "DELETE_ROW_COL",
            "merge_cells": "MERGE_CELLS",
            "split_cells": "SPLIT_CELLS",
            "set_height_equal": "SET_HEIGHT_EQUAL",
            "set_width_equal": "SET_WIDTH_EQUAL",
            "find_replace_pro": "FIND_REPLACE_PRO",
            "spell_check": "SPELL_CHECK",
            "hanja_convert": "HANJA_CONVERT",
            "special_chars": "SPECIAL_CHARS",
            "copy_format": "COPY_FORMAT",
            "paste_format": "PASTE_FORMAT",
            "toggle_page_layout": "TOGGLE_PAGE_LAYOUT",
            "toggle_control_codes": "TOGGLE_CONTROL_CODES",
        }

    def _default_action(self):
        return "font_shape"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or self._default_action()
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):

        # Action artwork is assigned once by COMBO-X from the manifest.

        return
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    def _normalize_key(self, key):
        key = str(key).strip().lower()
        aliases = {
            "cmd": "command",
            "win": "command" if IS_MACOS else "windows",
            "windows": "command" if IS_MACOS else "windows",
            "control": "ctrl",
            "alt": "option" if IS_MACOS else "alt",
            "option": "option" if IS_MACOS else "alt",
            "page up": "pageup",
            "page down": "pagedown",
            "return": "enter",
            "esc": "escape",
        }
        return aliases.get(key, key)

    def _send_hotkey_sequence(self, hotkey):
        if not hotkey:
            return

        # Windows에서는 기존 keyboard 모듈이 한글식 연속 단축키(ctrl+n,t)를 잘 처리합니다.
        if IS_WINDOWS and keyboard:
            keyboard.send(hotkey)
            return

        if pyautogui is None:
            print("[HWP] pyautogui is not available.")
            return

        # pyautogui는 ctrl+n,t 같은 연속 단축키를 직접 이해하지 못하므로 콤마 기준으로 순차 입력합니다.
        for chord in str(hotkey).split(','):
            chord = chord.strip()
            if not chord:
                continue
            parts = [self._normalize_key(part) for part in chord.split('+') if part.strip()]
            if not parts:
                continue
            if len(parts) == 1:
                pyautogui.press(parts[0])
            else:
                pyautogui.hotkey(*parts)
            pyautogui.sleep(0.06)

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            current_action = action_command or settings.get("command") or cached.get("command") or self._default_action()
            await self._send_builtin_icon(context, current_action)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard and pyautogui is None:
            return

        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        final_settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = final_settings

        selected_action = final_settings.get("command") or self._default_action()
        if selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(self._send_hotkey_sequence, hotkey)
