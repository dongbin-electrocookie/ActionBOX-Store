import asyncio
import os

try:
    import keyboard
    keyboard_available = True
except ImportError:
    keyboard_available = False

class Plugin:
    def __init__(self, runner, manifest):
        self.runner = runner
        self.uuid = manifest['UUID']
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.context_settings = {}

        self.action_map = {
            "tool_move": "v",
            "tool_frame": "f",
            "tool_pen": "p",
            "tool_text": "t",
            "tool_rect": "r",
            "tool_ellipse": "o",
            "tool_hand": "h",
            "action_add_autolayout": "shift+a",
            "action_remove_autolayout": "alt+shift+a",
            "action_create_component": "ctrl+alt+k",
            "action_detach_instance": "ctrl+alt+b",
            "action_copy_props": "ctrl+alt+c",
            "action_paste_props": "ctrl+alt+v",
            "action_group": "ctrl+g",
            "action_ungroup": "ctrl+shift+g",
            "action_frame_selection": "ctrl+alt+g",
            "arrange_front": "ctrl+shift+]",
            "arrange_forward": "ctrl+]",
            "arrange_back": "ctrl+shift+[",
            "arrange_backward": "ctrl+[",
            "view_zoom_in": "ctrl+=",
            "view_zoom_out": "ctrl+-",
            "view_zoom_100": "shift+0",
            "view_zoom_fit": "shift+1",
            "view_zoom_selection": "shift+2",
            "view_toggle_ui": "ctrl+\\"
        }

        self.icon_map = {
            "tool_move": "STATE_TOOL_MOVE",
            "tool_frame": "STATE_TOOL_FRAME",
            "tool_pen": "STATE_TOOL_PEN",
            "tool_text": "STATE_TOOL_TEXT",
            "tool_rect": "STATE_TOOL_RECT",
            "tool_ellipse": "STATE_TOOL_ELLIPSE",
            "tool_hand": "STATE_TOOL_HAND",
            "action_add_autolayout": "STATE_ADD_AUTOLAYOUT",
            "action_remove_autolayout": "STATE_REMOVE_AUTOLAYOUT",
            "action_create_component": "STATE_CREATE_COMPONENT",
            "action_detach_instance": "STATE_DETACH_INSTANCE",
            "action_copy_props": "STATE_COPY_PROPS",
            "action_paste_props": "STATE_PASTE_PROPS",
            "action_group": "STATE_GROUP",
            "action_ungroup": "STATE_UNGROUP",
            "action_frame_selection": "STATE_FRAME_SELECTION",
            "arrange_front": "STATE_ARRANGE_FRONT",
            "arrange_forward": "STATE_ARRANGE_FORWARD",
            "arrange_back": "STATE_ARRANGE_BACK",
            "arrange_backward": "STATE_ARRANGE_BACKWARD",
            "view_zoom_in": "STATE_VIEW_ZOOM_IN",
            "view_zoom_out": "STATE_VIEW_ZOOM_OUT",
            "view_zoom_100": "STATE_VIEW_ZOOM_100",
            "view_zoom_fit": "STATE_VIEW_ZOOM_FIT",
            "view_zoom_selection": "STATE_VIEW_ZOOM_SELECTION",
            "view_toggle_ui": "STATE_VIEW_TOGGLE_UI"
        }

    def _default_action(self):
        return "action_add_autolayout"

    def _default_settings(self):
        action = self._default_action()
        return {
            "command": action,
            "_lang": "en",
            "sync_title_on_action_change": False,
            "builtin_icon_name": self.icon_map[action],
            "default_visuals_initialized": True
        }

    def _merge_with_defaults(self, settings):
        merged = self._default_settings()
        merged.update(settings or {})
        action = merged.get("command") or self._default_action()
        merged["command"] = action
        merged["builtin_icon_name"] = self.icon_map.get(action, self.icon_map[self._default_action()])
        return merged

    def _has_meaningful_settings(self, settings):
        s = settings or {}
        return any([
            s.get("command"),
            s.get("title"),
            s.get("builtin_icon_name"),
            s.get("default_visuals_initialized"),
            s.get("sync_title_on_action_change", False)
        ])

    def _get_icon_path(self, action_name):
        icon_name = self.icon_map.get(action_name or self._default_action(), self.icon_map[self._default_action()])
        return os.path.join(self.plugin_dir, "icon", f"{icon_name}.png")

    async def _send_builtin_icon(self, context, action_name):
        icon_path = self._get_icon_path(action_name)
        if os.path.exists(icon_path):
            await self.runner.send_message({
                "event": "setIcon",
                "context": context,
                "payload": {"icon_path": icon_path}
            })

    async def _initialize_default_visuals_if_new(self, context, incoming_settings):
        if not context:
            return False

        if not self._has_meaningful_settings(incoming_settings):
            defaults = self._default_settings()
            self.context_settings[context] = defaults.copy()

            await self.runner.send_message({
                "event": "setSettings",
                "context": context,
                "payload": defaults
            })

            # Initial placement: icon only, never overwrite title
            await self._send_builtin_icon(context, defaults["command"])
            return False

        merged = self._merge_with_defaults(incoming_settings)
        self.context_settings[context] = merged
        return True

    async def handle_message(self, data):
        event = data.get("event")
        payload = data.get("payload", {}) or {}
        context = data.get("context") or payload.get("context")
        payload_settings = payload.get("settings")
        settings = payload_settings if isinstance(payload_settings, dict) else data.get("settings", {}) or {}

        control_command = data.get("command") or payload.get("command")
        action_command = data.get("action_command") or payload.get("action_command")

        if event in ["willAppear", "keyDidAppear"]:
            await self._initialize_default_visuals_if_new(context, settings)
            return

        if event == "didReceiveSettings":
            if context:
                cached = self.context_settings.get(context, {})
                self.context_settings[context] = self._merge_with_defaults({**cached, **settings})
            return

        if event in ["keyDidDisappear", "willDisappear"]:
            if context in self.context_settings:
                self.context_settings.pop(context, None)
            return

        if control_command == "apply_builtin_icon":
            cached = self.context_settings.get(context, {})
            current_action = action_command or settings.get("command") or cached.get("command") or self._default_action()
            await self._send_builtin_icon(context, current_action)
            return

        if event == "keyDown":
            await self.on_key_down(data)

    async def on_key_down(self, data):
        if not keyboard_available:
            return

        context = data.get("context")
        incoming_settings = data.get("payload", {}).get("settings", {}) or {}
        cached = self.context_settings.get(context, {})
        final_settings = self._merge_with_defaults({**cached, **incoming_settings})
        if context:
            self.context_settings[context] = final_settings

        selected_action = final_settings.get("command") or self._default_action()
        if selected_action in self.action_map:
            hotkey = self.action_map[selected_action]
            await asyncio.to_thread(keyboard.send, hotkey)
